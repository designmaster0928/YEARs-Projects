
uint8_t		usb_resp[1024];
uint8_t		newcount;
bool		_flg_ep3_in;
uint32_t	sofcount;
uint8_t		Net_ID[10];
char		imei[20];
char		GMemory[5][20];
char		*Guardian[5];
char		*IMEI;
char		*Longitude;
char		*Latitude;
#define Guardian1 &GMemory[0][0];
#define Guardian2 &GMemory[1][0];
#define Guardian3 &GMemory[2][0];
#define Guardian4 &GMemory[3][0];

enum Tracker_Msgs
{
	msg_low_battery = 1,
	msg_out_of_geofence = 2,
	msg_emergency = 3,
	msg_guardian1_not_found = 4,
	msg_guardian2_not_found = 5,
	msg_guardian3_not_found = 6,
	msg_guardian4_not_found = 7,
	msg_guardian5_not_found = 8,
	msg_calling_911 = 9
};

/************Mesages text***************************************************************************************/
	char *Tck_Msg_Pointer[30];

	
	
	