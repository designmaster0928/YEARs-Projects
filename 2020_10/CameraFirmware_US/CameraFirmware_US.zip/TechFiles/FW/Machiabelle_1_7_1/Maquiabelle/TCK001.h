/*********************************************************************
 *                TCK001 IO Config
 *********************************************************************
 * FileName:        TCK001_IOcfg.h
 * Dependencies:    See INCLUDES section below
 * Processor:       SAMS70N21
 * Compiler:        
 * Company:         E2pro Engenharia
 *
 
 *********************************************************************
 * Paulo Schaefer       26/07/2018   initial release                 */

/***IPB001 OUTPUT Pins ************************************************/


#define _SDN			1
#define _CAM_PWDN		2
#define _GSM_PWR_ON		3
#define _GSM_RST		4
#define _GSM_ON			5
#define _RF_SEL			6
#define _LED_BAT		7
#define _CHARGE			8
#define _GPS_RST		9
#define _GPS_SEL		10
#define _LED1_Green		11
#define _LED1_Red		12
#define _LED2_Green		13
#define _LED2_Red		14


/***IPB001 INPUT Pins ************************************************/

#define _IBT_EMG		1
#define _IBT_RCD		2


#define _ARM_CORTEX_

//#define BOARD_FREQ_MAINCK_BYPASS	(16000000UL)
//#define BOARD_FREQ_MAINCK_XTAL		(16000000UL)
//#define BOARD_OSC_STARTUP_US		(15625UL)
