/****************************************************************************************************************
	
				Projeto Machiabelle
				E2pro Engenharia
				Placa TCK001 rev2
				Paulo Schaefer
				03/03/19
				
****************************************************************************************************************/

/**************Configura��es Espec�ficas*************************************************************************

	Ao recompilar o Start, configurar manualmente os par�metros abaixo:

	Em main.c:

	USBHS->USBHS_CTRL = 0;
	
	UTMI->UTMI_CKTRIM = UTMI_CKTRIM_FREQ_XTAL16;
	UTMI->UTMI_OHCIICR = 0x00000001;
	
	Alterar cdchf_acm_install para rejeitar interfaces 0 e 1:
	
	if((piface->bInterfaceNumber==0)||(piface->bInterfaceNumber==1)) return ERR_NOT_FOUND;
	
	Alterar pipe_alocatte para false: 
	
	pipe = usb_h_pipe_allocate(hcd,
	dev->dev_addr,
	pep->bEndpointAddress,
	pep->wMaxPacketSize,
	pep->bmAttributes,
	pep->bInterval,
	dev->speed,
	false);
	
	
	Substituir a rotina usb_h_in:
	
//	static void _usb_h_in(struct usb_h_pipe *pipe)
//	{
//		uint8_t            pi  = _usb_h_pipe_i(pipe);
//		struct usb_h_desc *drv = (struct usb_h_desc *)pipe->hcd;
//		uint8_t *          src, *dst;
//		uint32_t           size, count, i;
//		uint32_t           n_rx = 0;
//		uint32_t           n_remain;
//		uint16_t           max_pkt_size = pipe->type == 0 ? pipe->x.ctrl.pkt_size : pipe->max_pkt_size;
//		bool               shortpkt = false, full = false;
//
//		if (pipe->x.general.state == USB_H_PIPE_S_STATI) {
//			/* Control status : ZLP IN done */
//			hri_usbhs_write_HSTPIPIER_reg(drv->hw, pi, USBHS_HSTPIPIER_PFREEZES);
//			hri_usbhs_write_HSTPIPIDR_reg(drv->hw, pi, USBHS_HSTPIPIDR_SHORTPACKETIEC | USBHS_HSTPIPIDR_RXINEC);
//			hri_usbhs_write_HSTPIPINRQ_reg(drv->hw, pi, 0);
//			_usb_h_end_transfer(pipe, USB_H_OK);
//			return;
//			} else if (pipe->x.general.state != USB_H_PIPE_S_DATI) {
//			return;
//		}
//		/* Read byte count */
//		n_rx = hri_usbhs_read_HSTPIPISR_PBYCT_bf(drv->hw, pi);
//		if (n_rx < max_pkt_size) {
//			shortpkt = true;
//		}
//		if (n_rx) {
//			
//			_usb_h_load_x_param(pipe, &dst, &size, &count);
//			if(pipe->ep==0x83)
//			{
//				count = newcount;
//			}
//			
//			n_remain = size - count;
//			src      = (uint8_t *)&_usbhs_get_pep_fifo_access(pi, 8);
//			dst      = &dst[count];
//			if (n_rx >= n_remain) {
//				n_rx = n_remain;
//				full = true;
//			}
//			count += n_rx;
//			for (i = 0; i < n_rx; i++) {
//				*dst++ = *src++;
//			}
//			_usb_h_save_x_param(pipe, count);
//			
//			if(pipe->ep==0x83)
//			{
//				newcount= count;
//				if(newcount>64) newcount = 0;
//			}
//			
//		}
//		/* Clear FIFO status */
//		hri_usbhs_write_HSTPIPIDR_reg(drv->hw, pi, USBHS_HSTPIPIDR_FIFOCONC);
//		/* Reset timeout for control pipes */
//		if (pipe->type == 0) {
//			pipe->x.ctrl.pkt_timeout = USB_CTRL_DPKT_TIMEOUT;
//		}
//		/* Finish on error or short packet */
//		if (full || shortpkt) {
//			hri_usbhs_write_HSTPIPIDR_reg(drv->hw, pi, USBHS_HSTPIPIDR_SHORTPACKETIEC | USBHS_HSTPIPIDR_RXINEC);
//			if (pipe->type == 0) { /* Control transfer: DatI -> StatO */
//				pipe->x.ctrl.state       = USB_H_PIPE_S_STATO;
//				pipe->x.ctrl.pkt_timeout = USB_CTRL_STAT_TIMEOUT;
//				_usb_h_out_zlp_ex(pipe);
//				} else {
//				hri_usbhs_write_HSTPIPIER_reg(drv->hw, pi, USBHS_HSTPIPIER_PFREEZES);
//				hri_usbhs_write_HSTPIPINRQ_reg(drv->hw, pi, 0);
//				_usb_h_end_transfer(pipe, USB_H_OK);
//			}
//		} else if (!hri_usbhs_read_HSTPIPINRQ_reg(drv->hw, pi)
//		&& hri_usbhs_get_HSTPIPIMR_reg(drv->hw, pi, USBHS_HSTPIPIMR_PFREEZE)) {
//			/* Unfreeze if request packet by packet */
//			hri_usbhs_write_HSTPIPIDR_reg(drv->hw, pi, USBHS_HSTPIPIMR_PFREEZE);
//			} else {
//			/* Just wait another packet */
//		}
//	}
	
/***************************************************************************************************************/	
#include <atmel_start.h>
#include "TCK001.h"
#include "hpl_usbhs_host.h"
#include "main.h"
#include <string.h>
#include <stdio.h>

/*********TCK001 Variables**************************************************************************************/

uint8_t		GPS_Buffer[255];
float		LON_Pos;
float		LAT_Pos;
uint32_t	T_GPSFail;
uint32_t	T_SendNav;
uint8_t		LT[10];
uint8_t		LG[11];
uint16_t	Speed;
int8_t		GPS_Day;
int8_t		GPS_Month;
int8_t		GPS_Year;
int8_t		GPS_Hour;
int8_t		GPS_Minute;
uint16_t	T_Led1;
uint16_t	T_Led2;
bool		_flg_GPSFail;
bool		_flg_SendNav;
bool		_flg_SendImage;
bool		_flg_SendSound;
bool		_flg_Gurtam_Logged;
bool		_flg_Led1_G_Flash;
bool		_flg_Led1_R_Flash;
bool		_flg_Led2_G_Flash;
bool		_flg_Led2_R_Flash;
bool		_flg_Led1_State;
bool		_flg_Led2_State;
uint8_t		nPulsesL1;
uint8_t		nPulsesL2;
uint8_t		L1PulsesCount;
uint8_t		L2PulsesCount;
uint32_t	TimeOut;
uint16_t	DelTime;

uint8_t		TCP_Socket;
char		*url_target;
char		IP_addr[16];


static usb_cdc_line_coding_t lcoding = {115200, CDC_STOP_BITS_1, CDC_PAR_NONE, 8};

#define _flag_cdc_available cdchf_acm_is_open(&USB_HOST_CDC_ACM_0_inst)

struct usbhc_driver *tck_drv;

enum Color
{
	Red = 0,
	Green = 1
};

enum MainState
{
	TCK_reset = 0,
	GPS_Interface_Activation = 1,
	GPS_Satellites_Find = 2,
	GPS_Locked = 3,
	Toby_USB_Activation = 4,
	Toby_Enumeration1 = 5,
	Toby_Enumeration2 = 6,
	Toby_Enumeration3 = 7,
	USB_cdc_init = 8,
	Start_AT_Command = 9,
	Check_SimCard = 10,
	Check_Signal = 11,
	NetWork_Register = 12,
	NetWork_Logon = 13,
	NetWork_Logged = 14
};

enum tcksts
{
	tck_init_datacom = 0,
	tck_standby = 1,
	tck_tracking = 2,
	tck_emergency = 3
};

enum ATResp
{
	Net_Registered = 0,
	SIM_Ready = 1,
	Signal_Present = 2,
	Net_Logged = 3,
	Tcp_Socket_Created = 4,
	Tcp_Socket_Closed = 5,
	Tcp_url_resolved = 6,
	Tcp_socket_connected = 7,
	Gprs_on = 8,
	Gurtam_Logged = 9,
	Ping = 10,
	Login = 11,
	ASD = 12
};

enum apn
{
	Vivo = 0,
	ATeT = 1
};


enum MainState MState;
enum tcksts TrackerStatus;
enum ATResp AT_RespType;
enum apn APN_Oper;

#define tcp_protocol 1
#define udp_protocol 2


/************Gurtam Variables***********************************************************************************/

const char *Tck_ID = "PauloBrazil";
const char *Gurtam_Password = "FPeBIzCtHB";
const char *Gurtam_UserName = "machiabelle";
const char *url_e2pro = "177.102.62.180";
char *url_addr;

 
 /*****CheckSum Table*******************************************************************************************/
 
 static const unsigned short crc16_table[256] =
 {
	 0x0000,0xC0C1,0xC181,0x0140,0xC301,0x03C0,0x0280,0xC241,
	 0xC601,0x06C0,0x0780,0xC741,0x0500,0xC5C1,0xC481,0x0440,
	 0xCC01,0x0CC0,0x0D80,0xCD41,0x0F00,0xCFC1,0xCE81,0x0E40,
	 0x0A00,0xCAC1,0xCB81,0x0B40,0xC901,0x09C0,0x0880,0xC841,
	 0xD801,0x18C0,0x1980,0xD941,0x1B00,0xDBC1,0xDA81,0x1A40,
	 0x1E00,0xDEC1,0xDF81,0x1F40,0xDD01,0x1DC0,0x1C80,0xDC41,
	 0x1400,0xD4C1,0xD581,0x1540,0xD701,0x17C0,0x1680,0xD641,
	 0xD201,0x12C0,0x1380,0xD341,0x1100,0xD1C1,0xD081,0x1040,
	 0xF001,0x30C0,0x3180,0xF141,0x3300,0xF3C1,0xF281,0x3240,
	 0x3600,0xF6C1,0xF781,0x3740,0xF501,0x35C0,0x3480,0xF441,
	 0x3C00,0xFCC1,0xFD81,0x3D40,0xFF01,0x3FC0,0x3E80,0xFE41,
	 0xFA01,0x3AC0,0x3B80,0xFB41,0x3900,0xF9C1,0xF881,0x3840,
	 0x2800,0xE8C1,0xE981,0x2940,0xEB01,0x2BC0,0x2A80,0xEA41,
	 0xEE01,0x2EC0,0x2F80,0xEF41,0x2D00,0xEDC1,0xEC81,0x2C40,
	 0xE401,0x24C0,0x2580,0xE541,0x2700,0xE7C1,0xE681,0x2640,
	 0x2200,0xE2C1,0xE381,0x2340,0xE101,0x21C0,0x2080,0xE041,
	 0xA001,0x60C0,0x6180,0xA141,0x6300,0xA3C1,0xA281,0x6240,
	 0x6600,0xA6C1,0xA781,0x6740,0xA501,0x65C0,0x6480,0xA441,
	 0x6C00,0xACC1,0xAD81,0x6D40,0xAF01,0x6FC0,0x6E80,0xAE41,
	 0xAA01,0x6AC0,0x6B80,0xAB41,0x6900,0xA9C1,0xA881,0x6840,
	 0x7800,0xB8C1,0xB981,0x7940,0xBB01,0x7BC0,0x7A80,0xBA41,
	 0xBE01,0x7EC0,0x7F80,0xBF41,0x7D00,0xBDC1,0xBC81,0x7C40,
	 0xB401,0x74C0,0x7580,0xB541,0x7700,0xB7C1,0xB681,0x7640,
	 0x7200,0xB2C1,0xB381,0x7340,0xB101,0x71C0,0x7080,0xB041,
	 0x5000,0x90C1,0x9181,0x5140,0x9301,0x53C0,0x5280,0x9241,
	 0x9601,0x56C0,0x5780,0x9741,0x5500,0x95C1,0x9481,0x5440,
	 0x9C01,0x5CC0,0x5D80,0x9D41,0x5F00,0x9FC1,0x9E81,0x5E40,
	 0x5A00,0x9AC1,0x9B81,0x5B40,0x9901,0x59C0,0x5880,0x9841,
	 0x8801,0x48C0,0x4980,0x8941,0x4B00,0x8BC1,0x8A81,0x4A40,
	 0x4E00,0x8EC1,0x8F81,0x4F40,0x8D01,0x4DC0,0x4C80,0x8C41,
	 0x4400,0x84C1,0x8581,0x4540,0x8701,0x47C0,0x4680,0x8641,
	 0x8201,0x42C0,0x4380,0x8341,0x4100,0x81C1,0x8081,0x4040
 };

 

/******PROTOTYPES***********************************************************************************************/

void Clear_WDT(void);
void InitGPS(void);
void SPI_Init(void);
char Send_GPS_SPI(char val);
bool GPS_Read_NAV(void);
char Send_ATCommand(const char *p,bool wait, uint16_t tout);
char Send1_ATCommand(const char *p,bool wait, uint16_t tout);
bool Find_OK(void);
bool Find_Ping(void);
bool Find_Login(void);
bool Resp_Char_Verif(char *rc,char start, char size);
bool Verify_AT_Response(char RespType);
bool Verify_Gurtam_Response(char rt);
bool Set_PSD_Profile(char oper);
bool AT_Resp_OK(void);
void TCK001_CDC_Init(void);
void SetOut(char line, char val);
void TCK001_Init(void);
void Send_SMS(char *phone_number, char *text);
bool Open_Socket(char protocol);
bool Close_Socket(void);
bool TCP_socket_connect(const char *dest_url,const char *t_port);
bool TCP_url_resolution(char *url);
void Send_TCP(char *frame);
void Get_IMEI(void);
bool Gurtam_Login(char prot);
bool Gurtam_Send_Data(void);
bool Gurtam_Ping(void);
bool Send_NAV(void);
bool Send_Image(void);
void SetLed(char led, char pulses, char color);
 unsigned short crc16 (const void *data, unsigned data_size);

static void port_read_complete(struct cdchf_acm *cdc, uint32_t count);
static void port_write_complete(struct cdchf_acm *cdc, uint32_t count);

int main(void)
  {
	
	char test[50];
	MState = TCK_reset;
	
	while (1) {
	
again:
	
		switch(MState)
			{
				case TCK_reset:
				
					SetLed(1, 3, Red);
					
					USBHS->USBHS_CTRL = 0;
					UTMI->UTMI_CKTRIM = UTMI_CKTRIM_FREQ_XTAL16;
					UTMI->UTMI_OHCIICR = 0x00000001;
					atmel_start_init();
					TCK001_Init();
					
					
					SPI_Init();
					USBHS->USBHS_CTRL = 0;
					
					SetOut(_GSM_ON,0);
					
					delay_ms(25);
					
			
					SetOut(_GSM_RST,0);
					SetOut(_GSM_PWR_ON,0);
					SetOut(_SDN,1);
					NVIC_EnableIRQ(RTT_IRQn);
					InitGPS();
					
					DelTime = 0;
					TimeOut = 0;
					
					MState = GPS_Interface_Activation;
					
					
				break;
				
				case GPS_Interface_Activation:
				
					SetLed(1, 2, Red);
					
					if(DelTime>300)
					{
						GPS_Read_NAV();
						DelTime = 0;
					}
						
					
					if(GPS_Buffer[0] == '$')
					{
						MState = GPS_Satellites_Find;
						TimeOut = 0;
					}
					
					if(TimeOut>100000) MState = TCK_reset;
				
				break;
					
				case GPS_Satellites_Find:
				
					SetLed(1, 1, Red);
					
					if(DelTime>300)
					{
						if(GPS_Read_NAV())
						{
							MState = GPS_Locked;
							TimeOut=0;
						}
						DelTime = 0;
					}
					
					if(TimeOut>100000)
					{
						InitGPS();
						TimeOut = 0;
					} 
				
				break;
				
				case GPS_Locked:
				
					SetLed(1, 1, Green);
					MState = Toby_USB_Activation;
					 
				break;
				
				case Toby_USB_Activation:
				
					USBHS->USBHS_CTRL = 0;
					
					SetLed(2, 11, Red);
					
					SetOut(_GSM_ON,1);
					delay_ms(2500);
					
					SetOut(_GSM_RST,1);
					delay_ms(2500);
					
					SetOut(_GSM_RST,0);
					delay_ms(6000);
					
					MState = Toby_Enumeration1;
					
				
				break;
					
			
				case Toby_Enumeration1:
				
					SetLed(2,10,Red);
					 
					usbhc_start(&USB_HOST_CORE_INSTANCE_inst);
					 
					tck_drv = &USB_HOST_CORE_INSTANCE_inst;
					
					MState = Toby_Enumeration2;
					TimeOut=0;
					
				break;
				
				case Toby_Enumeration2:
				
					SetLed(2,9,Red);
				
					//if(DelTime>30)
				//	{
						
						if(tck_drv->dev.status.bm.usable)
						{
							MState = Toby_Enumeration3;
							TimeOut = 0;
						} 
						DelTime=0;
						
			//		}
					
					if(TimeOut>20000) MState = Toby_USB_Activation;
					
				break;
					
					
				case Toby_Enumeration3:
				
					SetLed(2,8,Red);
					
					if(DelTime>30)
					{
						if(tck_drv->dev.status.bm.state == 0x06)
						{
							MState = USB_cdc_init;
							TimeOut = 0;
						}
						DelTime=0;
					}
					
					if(TimeOut>20000) MState = Toby_USB_Activation;
						
						
				break;
			
			
				case USB_cdc_init:
			
					SetLed(2,7,Red);
					
					if(DelTime>300)
					{
						TCK001_CDC_Init();
						DelTime=0;	
					}
					
					
					if(_flag_cdc_available)
					{	
						MState = Start_AT_Command;
						TimeOut = 0;
					}
					
					if(TimeOut>20000) MState = Toby_USB_Activation;
					
					
					
				break;
					
				case Start_AT_Command:
					
					SetLed(2,6,Red);
					
					if(DelTime>300)
					{
						Send_ATCommand("ATI9\r",true,600);
						DelTime=0;
					}
					
					if (AT_Resp_OK())
					{
						 MState= Check_SimCard;
						 TimeOut = 0;
						// Send_ATCommand("AT+CREG=1\r",true,300);
						 Send_ATCommand("AT+CMEE=2\r",true,300);
					}
					
					if(TimeOut>20000) MState = Toby_USB_Activation;
					
				break;
			
				case Check_SimCard:
				
					SetLed(2,5,Red);
					
					if(DelTime>300)
					{
						Send_ATCommand("AT+CPIN?\r",true,300);
						DelTime=0;
					}
					
					if ( Verify_AT_Response(SIM_Ready))
					{
						MState= Check_Signal;
						Send_ATCommand("AT+CREG=1\r",true,300);
						TimeOut = 0;
					}
					
					if(TimeOut>20000) MState = Toby_USB_Activation;
					
				break;
				
				case Check_Signal:
				
					SetLed(2,4,Red);
					
					
					
					//if(DelTime>300)
					//{
						Send_ATCommand("AT+CSQ\r",true,300);
					//	DelTime=0;
				//	}
					
					if ( Verify_AT_Response(Signal_Present))
					{
				
						if(Send_ATCommand("AT+CREG=1\r",true,300)) MState= NetWork_Register;
						TimeOut = 0;
					}
					
					if(TimeOut>100000) MState = Toby_USB_Activation;
				
				break;
				
				case NetWork_Register:
				
					SetLed(2,3,Red);
					
					
					
			//		if(DelTime>300)
			//		{
						Send_ATCommand("AT+CREG?\r",true,300);
			//			DelTime=0;
			//		}
					
					if (Verify_AT_Response(Net_Registered))
					{
						MState= NetWork_Logon;
						TimeOut = 0;
					}
					
					if(TimeOut>100000) MState = Toby_USB_Activation;
				
				break;
					
					
				case NetWork_Logon:
				
					SetLed(2,2,Red);
					
					Send_ATCommand("AT+COPS?\r",true,300);
					
					if (Verify_AT_Response(Net_Logged))
					{
						MState= NetWork_Logged;
						TimeOut = 0;
						T_GPSFail = 0;
						_flg_GPSFail = false;
						TrackerStatus = tck_init_datacom;
						
						SetLed(2,1,Red);
					}
					
					if(TimeOut>100000) MState = Toby_USB_Activation;
					
				break;
					
				case NetWork_Logged:
				
					
					if(_flg_GPSFail)
					{
						SetLed(1,1,Red);
						InitGPS();
						delay_ms(4000);			
					}
					
					DelTime=0;
				
					while(DelTime<100)
					{
						if(GPS_Read_NAV())
						{
							T_GPSFail=0;
							_flg_GPSFail=false;
							DelTime=101;
						}	
					}
					
					switch(TrackerStatus)
					{
						
						case tck_init_datacom:
						
							SetLed(2,1,Red);
						
							Get_IMEI();
							Send_ATCommand("AT+UDCONF=1,1\r",true,2000);
							Set_PSD_Profile(Vivo);
							Open_Socket(tcp_protocol);	
							
							Send_ATCommand("AT+CREG?\r",true,300);
							
							if(! Verify_AT_Response(Net_Registered))
							{
								MState = NetWork_Logon;
								Close_Socket();
								break;	
							}		
							
							TCP_socket_connect("64.120.108.24","20332");
							
							Gurtam_Ping();
					
							_flg_Gurtam_Logged = Gurtam_Login(tcp_protocol);
							
							if(_flg_Gurtam_Logged)
							{
								 TrackerStatus = tck_tracking;
							}
							else
							{
								Close_Socket();
							}
						
							
						break;
						
						case tck_tracking:
						
						if(TimeOut>60000)
						{
							
							Send_ATCommand("AT+COPS?\r",true,300);
							
							if (!Verify_AT_Response(Net_Logged))
							{
								MState= Check_Signal;
								TimeOut = 0;
							}
							
							Send_ATCommand("AT+CGATT?\r",true,300);
							
							
							if(!Verify_AT_Response(Gprs_on))
							{
								TrackerStatus= tck_init_datacom;
								TimeOut = 0;
							}
							
							TimeOut=0;
			
						}
						
									
						if(!_flg_GPSFail)
						{
							if(_flg_SendNav)
							{
								T_SendNav=0;
								
								DelTime=0;
								while(DelTime<500)
								{
									if(Gurtam_Send_Data())
									{
										TimeOut=0;
										DelTime=1000;
									} 
								}
					
								
								if(DelTime>800) SetLed(2,1,Green); else SetLed(2,11,Red);
								SetLed(1,1,Green);

							}
						}
						
						if(_flg_SendImage) Send_Image();
						
						break;
					
						case tck_emergency:
						break;
						
						default:
						break;
					}
				
				break;
				
				default:
				break;
			}
	
	}
}

/****************************************************************************************************************
*										TCK001 ROUTINES                                                         *
****************************************************************************************************************/

/*************Timebase Interrupt********************************************************************************/
void RTT_Handler(void)										//base de tempo de 1mS
{
	
	//uint32_t j;
	
	NVIC_DisableIRQ(RTT_IRQn);
	//j = RTT->RTT_SR;								// necess�rio para limpar interrup��o
	RTT->RTT_SR;
	NVIC_ClearPendingIRQ(RTT_IRQn);

	//increments
	T_GPSFail++;
	T_SendNav++;
	T_Led1++;
	T_Led2++;
	TimeOut++;
	DelTime++;
	
	
	//flags
	if(T_GPSFail>300000) _flg_GPSFail=true; else _flg_GPSFail=false;
	if(T_SendNav>10000) _flg_SendNav=true; else _flg_SendNav=false;
	
	
	if(_flg_Led1_R_Flash)
	{
		if(L1PulsesCount)
		{
			if(_flg_Led1_State)
			{
				if(T_Led1>200)
				{
					T_Led1=0;
					SetOut(_LED1_Red,false);
					_flg_Led1_State=false;
					L1PulsesCount--;
				}
			}
			else
			{
				if(T_Led1>200)
				{
					T_Led1=0;
					SetOut(_LED1_Red,true);
					_flg_Led1_State=true;
				}
			}
		}
		else
		{
			if(T_Led1>2000)
			{
				T_Led1=0;
				SetOut(_LED1_Red,true);
				_flg_Led1_State=true;
				L1PulsesCount = nPulsesL1;
			}
		}
	}
	
	
	
	if(_flg_Led1_G_Flash)
	{
		if(L1PulsesCount)
		{
			if(_flg_Led1_State)
			{
				if(T_Led1>200)
				{
					T_Led1=0;
					SetOut(_LED1_Green,false);
					_flg_Led1_State=false;
					L1PulsesCount--;
				}
			}
			else
			{
				if(T_Led1>200)
				{
					T_Led1=0;
					SetOut(_LED1_Green,true);
					_flg_Led1_State=true;
				}
			}
		}
		else
		{
			if(T_Led1>2000)
			{
				T_Led1=0;
				SetOut(_LED1_Green,true);
				_flg_Led1_State=true;
				L1PulsesCount = nPulsesL1;
			}
		}
	}

	
	
	if(_flg_Led2_R_Flash)
	{
		if(L2PulsesCount)
		{
			if(_flg_Led2_State)
			{
				if(T_Led2>200)
				{
					T_Led2=0;
					SetOut(_LED2_Red,false);
					_flg_Led2_State=false;
					L2PulsesCount--;
				}
			}
			else
			{
				if(T_Led2>200)
				{
					T_Led2=0;
					SetOut(_LED2_Red,true);
					_flg_Led2_State=true;
				}
			}
		}
		else
		{
			if(T_Led2>2000)
			{
				T_Led2=0;
				SetOut(_LED2_Red,true);
				_flg_Led2_State=true;
				L2PulsesCount = nPulsesL2;
			}
		}
	}
	
	
	if(_flg_Led2_G_Flash)
	{
		if(L2PulsesCount)
		{
			if(_flg_Led2_State)
			{
				if(T_Led2>200)
				{
					T_Led2=0;
					SetOut(_LED2_Green,false);
					_flg_Led2_State=false;
					L2PulsesCount--;
				}
			}
			else
			{
				if(T_Led2>200)
				{
					T_Led2=0;
					SetOut(_LED2_Green,true);
					_flg_Led2_State=true;
				}
			}
		}
		else
		{
			if(T_Led2>2000)
			{
				T_Led2=0;
				SetOut(_LED2_Green,true);
				_flg_Led2_State=true;
				L2PulsesCount = nPulsesL2;
			}
		}
	}
		
	//limits
	if(T_GPSFail>600000) T_GPSFail=600000;
	if(T_SendNav>20000) T_SendNav=20000;
	if(TimeOut>1000000) TimeOut=1000000;
	if(DelTime>10000) DelTime=10000;
//	if(T_Led1>10000) T_Led1=10000;
	NVIC_EnableIRQ(RTT_IRQn);
}

/***************************************************************************************************************/
void TCK001_Init(void)
{
	PIOA->PIO_WPMR = 0x50494F00;
	PIOB->PIO_WPMR = 0x50494F00;
	PIOD->PIO_WPMR = 0x50494F00;
	
	PIOA->PIO_ABCDSR[0] = 0x4B018223;

	PIOA->PIO_ABCDSR[1] = 0xDF018003;
	PIOA->PIO_PDR = 0XFFFFFFFF;
	PIOA->PIO_PER = 0X20FE0DC4;
	PIOA->PIO_ODR = 0xFFFFFFFF;
	PIOA->PIO_OER = 0x00FE6D94;
	PIOA->PIO_PUER = 0x00000000;
	
	PIOB->PIO_ABCDSR[0] = 0x00001008;
	PIOB->PIO_ABCDSR[1] = 0x00001008;

	PIOD->PIO_ABCDSR[0] = 0xDB601800;
	PIOD->PIO_ABCDSR[1] = 0xDB601800;
	//
	// 	MATRIX->MATRIX_WPMR = 0x4D415400;
	//
	// 	MATRIX->CCFG_SYSIO = CCFG_SYSIO_SYSIO12;
	//
	// 	MATRIX->MATRIX_WPMR = 0x4D415401;

	PIOB->PIO_PDR = 0xFFFFFFFF;
	PIOB->PIO_PER = 0xFFFFEC17;

	PIOD->PIO_PDR = 0x83601800;
	PIOD->PIO_PER = 0x2C9FE7FF;

	
	PIOB->PIO_OER = 0xFFFFF017;
	PIOD->PIO_ODR = 0xFFFFFFFF;
	PIOD->PIO_OER = 0x041000BF;
	
	PIOA->PIO_WPMR = 0x50494F01;
	PIOB->PIO_WPMR = 0x50494F01;
	PIOD->PIO_WPMR = 0x241FE3F3;
	
	/*********Pointers******************************************************************************************/
	Guardian[0] = &GMemory[0][20];
	Guardian[1] = &GMemory[1][20];
	Guardian[2] = &GMemory[2][20];
	Guardian[3] = &GMemory[3][20];
	Guardian[4] = &GMemory[4][20];
		
	GMemory[0][0] = '0';
	GMemory[0][1] = '1';
	GMemory[0][2] = '5';
	GMemory[0][3] = '1';
	GMemory[0][4] = '1';
	GMemory[0][5] = '9';
	GMemory[0][6] = '5';
	GMemory[0][7] = '7';
	GMemory[0][8] = '8';
	GMemory[0][9] = '3';
	GMemory[0][10] = '3';
	GMemory[0][11] = '2';
	GMemory[0][12] = '3';
	GMemory[0][13] = '0';
	GMemory[0][14] = 0;
	
	/*********Messages******************************************************************************************/
	
	Tck_Msg_Pointer[1] =  "Tracker battery in critical level!";
	Tck_Msg_Pointer[2] =  "Tracker leaves geofence!";
	Tck_Msg_Pointer[3] =  "Tracker emergency activated!";
	Tck_Msg_Pointer[4] =  "Guardian 1 not found. Tracker emergency activated!";
	Tck_Msg_Pointer[5] =  "Guardian 2 not found. Tracker emergency activated!";
	Tck_Msg_Pointer[6] =  "Guardian 3 not found. Tracker emergency activated!";
	Tck_Msg_Pointer[7] =  "Guardian 4 not found. Tracker emergency activated!";
	Tck_Msg_Pointer[8] =  "Guardian 5 not found. Tracker emergency activated!";
	Tck_Msg_Pointer[9] =  "Tracker emergency activated! Guardians not found! Calling 911!";								
	
/****************Iniciando RTT**********************************************************************************/
	RTT->RTT_MR = 0x20020;						//base de tempo de 1mS
 }

/***************************************************************************************************************/
void TCK001_CDC_Init(void)
{

	while (!cdcfh_acm_is_installed(&USB_HOST_CDC_ACM_0_inst));
	
	while (!cdchf_acm_is_enabled(&USB_HOST_CDC_ACM_0_inst));
	
	cdchf_acm_register_callback(&USB_HOST_CDC_ACM_0_inst, CDCHF_ACM_READ_CB,(FUNC_PTR)port_read_complete);
	cdchf_acm_register_callback(&USB_HOST_CDC_ACM_0_inst, CDCHF_ACM_WRITE_CB,(FUNC_PTR)port_write_complete);
	
	cdchf_acm_open(&USB_HOST_CDC_ACM_0_inst, &lcoding);
	
	while (!cdchf_acm_is_open(&USB_HOST_CDC_ACM_0_inst));
	
}

/***************************************************************************************************************/
void SPI_Init(void)
{
	PMC->PMC_WPMR = 0x504D4300;
	PMC->PMC_PCR = 0x00;
	PMC->PMC_PCR = PMC_PCR_CMD | PMC_PCR_EN | PMC_PCR_PID(43);

	QSPI->QSPI_WPMR = 0x51535000;
	QSPI->QSPI_CR = QSPI_CR_QSPIEN;
	QSPI->QSPI_SCR = 0x0000F000;
	QSPI->QSPI_MR = 0xF0F00000;
	QSPI->QSPI_WPMR = 0x51535001;
	
}

/***************************************************************************************************************/
void InitGPS(void)
{
	SetOut(_GPS_SEL,1);
	SetOut(_GPS_RST,0);
	delay_ms(1000);
	SetOut(_GPS_RST,1);
}

/***************************************************************************************************************/
char Send_GPS_SPI(char val)
{
	char SPI_Read_Byte;
	
	QSPI->QSPI_TDR = val;
	
	while(!(QSPI->QSPI_SR & QSPI_SR_RDRF))
	{
		delay_ms(1);
	}
	
	SPI_Read_Byte = QSPI->QSPI_RDR;
	
	return SPI_Read_Byte;
}

/***************************************************************************************************************/
bool GPS_Read_NAV(void)
{
	uint8_t k;
	bool _aux_flg;
	uint16_t aux_speed;
	
	Longitude = &LG;
	Latitude = &LT;
	
	_aux_flg=false;
	
	SetOut(_GPS_SEL,0);

	for(k=0;k<70;k++)
	{
		GPS_Buffer[k] = Send_GPS_SPI(0xFF);
		//delay_ms(1);
		if(GPS_Buffer[k] == '$') k=90;
	}
	
	if(k>71)
	{
		GPS_Buffer[0] = '$';
		for(k=1;k<70;k++)
		{
			GPS_Buffer[k] = Send_GPS_SPI(0xFF);
		//	delay_ms(1);
		}
	}
	
	SetOut(_GPS_SEL,1);
	
	if((GPS_Buffer[0]=='$') && (GPS_Buffer[3]=='R') && (GPS_Buffer[8]!='V') && (GPS_Buffer[17]=='A'))// && (GPS_Buffer[11]!=0x30) && (GPS_Buffer[12]!=0x30))// && (GPS_Buffer[30]=='S'))
	{
		_aux_flg = true;

		T_GPSFail=0;

		LAT_Pos = (GPS_Buffer[19]-0x30)*1000;
		LAT_Pos = LAT_Pos + (GPS_Buffer[20]-0x30)*100;
		LAT_Pos =LAT_Pos + (GPS_Buffer[21]-0x30)*10;
		LAT_Pos = LAT_Pos + (GPS_Buffer[22]-0x30)*1;
		LAT_Pos = LAT_Pos + (GPS_Buffer[24]-0x30)*0.1;
		LAT_Pos = LAT_Pos + (GPS_Buffer[25]-0x30)*0.01;
		LAT_Pos = LAT_Pos + (GPS_Buffer[26]-0x30)*0.001;
		LAT_Pos = LAT_Pos + (GPS_Buffer[27]-0x30)*0.0001;
			
		LT[0] = GPS_Buffer[19];
		LT[1] = GPS_Buffer[20];
		LT[2] = GPS_Buffer[21];
		LT[3] = GPS_Buffer[22];
		LT[4] = GPS_Buffer[23];
		LT[5] = GPS_Buffer[24];
		LT[6] = GPS_Buffer[25];
		LT[7] = GPS_Buffer[26];
		LT[8] = GPS_Buffer[27];
		LT[9] = 0;
		

		LON_Pos = (GPS_Buffer[32]-0x30)*10000;
		LON_Pos =  LON_Pos + (GPS_Buffer[33]-0x30)*1000;
		LON_Pos =  LON_Pos + (GPS_Buffer[34]-0x30)*100;
		LON_Pos =  LON_Pos + (GPS_Buffer[35]-0x30)*10;
		LON_Pos =  LON_Pos + (GPS_Buffer[36]-0x30)*1;
		LON_Pos =  LON_Pos + (GPS_Buffer[38]-0x30)*0.1;
		LON_Pos =  LON_Pos + (GPS_Buffer[39]-0x30)*0.01;
		LON_Pos =  LON_Pos + (GPS_Buffer[40]-0x30)*0.001;
			
		LG[0] = GPS_Buffer[32];
		LG[1] = GPS_Buffer[33];
		LG[2] = GPS_Buffer[34];
		LG[3] = GPS_Buffer[35];
		LG[4] = GPS_Buffer[36];
		LG[5] = GPS_Buffer[37];
		LG[6] = GPS_Buffer[38];
		LG[7] = GPS_Buffer[39];
		LG[8] = GPS_Buffer[40];
		LG[9] = GPS_Buffer[41];
		LG[10] = 0;
		

		Speed = (GPS_Buffer[46]-0x30)* 1000;
			
		if(GPS_Buffer[47] == '.')
		{
			aux_speed = 1000;
		}
		else
		{
			Speed = Speed + (GPS_Buffer[47]-0x30)* 100;
		}
			
		if(GPS_Buffer[48] == '.')
		{
			aux_speed = 100;
		}
		else
		{
			Speed = Speed + (GPS_Buffer[48]-0x30)* 10;
		}
			
		if(GPS_Buffer[49] == '.')
		{
			aux_speed = 10;
		}
		else
		{
			Speed = Speed + (GPS_Buffer[49]-0x30)* 10;
		}
			
		if(GPS_Buffer[50] == '.')
		{
			aux_speed = 1;
		}
		else
		{
			Speed = Speed + (GPS_Buffer[50]-0x30)* 1;
		}
		Speed = Speed/aux_speed;
			
		GPS_Minute = (GPS_Buffer[9] - 0x30)*10 + (GPS_Buffer[10] - 0x30);
		GPS_Hour = (GPS_Buffer[7] - 0x30)*10 + (GPS_Buffer[8] - 0x30);
		GPS_Day = (GPS_Buffer[53] - 0x30)*10 + (GPS_Buffer[54] - 0x30);
		GPS_Month = (GPS_Buffer[55] - 0x30)*10 + (GPS_Buffer[56] - 0x30);
		GPS_Year = (GPS_Buffer[57] - 0x30)*10 + (GPS_Buffer[58] - 0x30);	
		
	}

	return _aux_flg;
}

/***************************************************************************************************************/
char Send_ATCommand(const char *p, bool wait,uint16_t timeout)
{
	static bool startup;
	uint8_t size;
	uint16_t resp_TimeOut;
	uint8_t AuxResp;
	uint16_t k;
	uint8_t i;
	bool _flg_end;
	
	startup = true;
	resp_TimeOut=0;
	
	newcount = 0;
	_flg_end=false;
	
	size = strlen(p);
	
	if (! _flag_cdc_available) {
		startup = true;
		return false;
	}
	if (startup) {
		startup = false;
	
		while(cdchf_acm_read(&USB_HOST_CDC_ACM_0_inst,usb_resp,255));		//flush
		
		for(int i=0;i<256;i++)
		{
			usb_resp[i]=0x00;
		}
		
		while(cdchf_acm_write(&USB_HOST_CDC_ACM_0_inst, (uint8_t *)p, size));
		
		while(cdchf_acm_is_writing(&USB_HOST_CDC_ACM_0_inst));
		
		if(wait)
		{	
			while(!_flg_ep3_in)
			{
				cdchf_acm_read(&USB_HOST_CDC_ACM_0_inst,usb_resp,255);
				delay_us(1000);
				resp_TimeOut++;
				if(resp_TimeOut>timeout)
				{
					return 0;
				}
			}
			
			_flg_ep3_in=false;
	
			for(k=0;k<timeout;k++)
			{
				delay_us(1000);
				cdchf_acm_read(&USB_HOST_CDC_ACM_0_inst,usb_resp,255);
			
				AuxResp=0;
				for(i=0;i<256;i++)
				{
					if((usb_resp[i]=='K')&&(usb_resp[i-1]=='O'))_flg_end=true;
					if(usb_resp[i]=='O' && usb_resp[i-1]== 'R'&& usb_resp[i-2]== 'R'&& usb_resp[i-3]== 'E')_flg_end=true;
					if(usb_resp[i]=='R' && usb_resp[i-1]== 'O'&& usb_resp[i-2]== 'B'&& usb_resp[i-3]== 'A')_flg_end=true;
					if(usb_resp[i]=='@')_flg_end=true;
					
					if(! usb_resp[i])
					{
						break;
					} 
					AuxResp++;
				}
				if(_flg_end) break;
			}
			
			k=0;
			delay_ms(30);
			if(_flg_end) return AuxResp; else return 0;
		}
		else
		{
			return 1;
		}	
	}
	return 0;
}

/***************************************************************************************************************/
void Send_SMS(char *phone_number, char *text)
 {

	char AT_Command[256];
	
	Send_ATCommand("AT+CMGF=1\r",true,300);																			//modo texto
	
	strcpy(AT_Command,"AT+CMGS=\"");
	strcat(AT_Command,phone_number);
	strcat(AT_Command,"\"\r");
	strcat(AT_Command,text);
	strcat(AT_Command,"\032\r");
	
	Send_ATCommand(AT_Command,true,1000);
	
 }

/***************************************************************************************************************/
bool Open_Socket(char prot)
{

	switch(prot)
	{
		case udp_protocol:
			Send_ATCommand("AT+USOCR=17\r",true,1000);
		break;
		
		case tcp_protocol:
			Send_ATCommand("AT+USOCR=6\r",true,1000);
		break;
	}
	
	
	
	if(Verify_AT_Response(Tcp_Socket_Created)) return true; else return false;
	
}

/***************************************************************************************************************/
bool Close_Socket(void)
{

	Send_ATCommand("AT+USOCL=0",true,5000);
	if(Verify_AT_Response(Tcp_Socket_Closed)) return true; else return false;
	
}

/***************************************************************************************************************/
bool TCP_url_resolution(char *url)
{
	char AT_Command[256];
	uint8_t i;
	uint8_t a1;
	uint8_t a2;
	
	a1=0xFF;
	a2=0xFF;
	
	for(i=0;i<16;i++)
	{
		IP_addr[i]=0;
	}
	
	strcpy(AT_Command,"AT+UDNSRN=0,\"");
	strcat(AT_Command,url);
	strcat(AT_Command,"\"\r");

	if(Send_ATCommand(AT_Command,true,10000))
	{
		for(i=0;i<255;i++)
		{
			if((usb_resp[i]== 'S') && (usb_resp[i+1]== 'R') && (usb_resp[i+2]== 'N') && (usb_resp[i+3]== ':') && (usb_resp[i+5]== '"'))
			{
				 a1=i+6;
				 i=a1+1;
			}
			
			if(a1!=0xFF)
			{
				if(usb_resp[i]=='"')
				{
					a2=i;
				}
			}
				
			if(a2!=0xFF) break;
		}
		
		if((a1!=0xFF) && (a2!=0xFF))
		{	
			for(i=a1;i<a2;i++)
			{
				IP_addr[i-a1] = usb_resp[i];
			}
		}
	}

	if(Verify_AT_Response(Tcp_url_resolved)) return true; else return false;

}

/***************************************************************************************************************/
bool TCP_socket_connect(const char *dest_url,const char *t_port)
{
	char AT_Command[256];

	strcpy(AT_Command,"AT+USOCO=0,\"");
	strcat(AT_Command,dest_url);
	strcat(AT_Command,"\",");
	strcat(AT_Command,t_port);
	strcat(AT_Command,"\r");
	Send_ATCommand(AT_Command,true,30000);

	if(Verify_AT_Response(Tcp_socket_connected)) return true; else return false;

}

/***************************************************************************************************************/
void Get_IMEI(void)
{
	uint8_t i;
	
	IMEI = &imei;
	
	if(Send_ATCommand("AT+CGSN\r",true,5000))
	{
		while((usb_resp[3]!='C') || (usb_resp[5]!='S') || (usb_resp[6]!='N'))
		{
			Send_ATCommand("AT+CGSN\r",true,5000);
		}
		
		for(i=0;i<20;i++)
		{
			imei[i]=NULL;	
		}
		
		for(i=10;i<25;i++)
		{
			imei[i-10] = usb_resp[i];
		}
	}
}

 /**************************************************************************************************************/
 void Send_TCP(char *tcp_frame)
 {
	unsigned int dl;
	
	char AT_Command[256];
	char conv[6];
	
	dl = strlen(tcp_frame)+2;
	sprintf(conv, "%d", dl); 
	strcpy(AT_Command,"AT+USOWR=0,");
	strcat(AT_Command,conv);
	//strcat(AT_Command,",\"");
	//strcat(AT_Command,tcp_frame);
	strcat(AT_Command,"\r");
	
	Send_ATCommand(AT_Command,true,5000);
	delay_ms(50);
	strcpy(AT_Command,tcp_frame);
	strcat(AT_Command,"\r\n");
	Send_ATCommand(AT_Command,true,5000);
	
	
 }
 
/***************************************************************************************************************/
bool Verify_AT_Response(char rt)
{
	bool rr=false;
	uint8_t i=0;
	uint8_t k=0;
	uint8_t l=0;
	uint8_t index1=0;
	uint8_t index2=0;
	

	switch(rt)
	{
		case Net_Registered:
		
			if(Resp_Char_Verif("AT+CREG",0,7) && (usb_resp[20]==0x31) && Find_OK()) rr=true; else rr=false;
			
		break;
		
		case SIM_Ready:
		
			if(Resp_Char_Verif("AT+CPIN",0,7) && Resp_Char_Verif("READY",18,5) && Find_OK()) rr=true; else rr=false;

		break;
		
		case Signal_Present:

			if(Resp_Char_Verif("AT+CSQ",0,6) && Find_OK())
			{
				if((usb_resp[15]!=0x39) && (usb_resp[16]!=0x39)) rr=true; else rr=false;
			}

		break;
		
		case Net_Logged:

			if(Resp_Char_Verif("AT+COPS",0,7) && Find_OK())
			{
				for(i=0;i<64;i++)
				{
					
					if(usb_resp[i]==0x22)
					{
						if(!index1)index1=i; else index2=i;	
					}
					
					if(index1 && index2) break;
				}
				
				for(k=index1;k<index2+1;k++)
				{
					Net_ID[l++] = usb_resp[k];
				}
				
				if(index1 && index2) rr=true; else rr=false;
			}

		break;

		case Tcp_Socket_Created:

			if(Resp_Char_Verif("+USOCR",0,6) && Find_OK())
			{
				rr = true;
				TCP_Socket = usb_resp[8];
			}
			else
			{
				rr = false;
				TCP_Socket=0xFF;
			}

		break;

		case Tcp_url_resolved:

			if(Resp_Char_Verif("+UDNSRN",0,7) && Find_OK())
			{
				rr = true;
			}
			else
			{
				rr = false;
			}

		break;

		case Tcp_socket_connected:

			if(Find_OK()) return true; else return false;

		break;
		
		case Gprs_on:
		
			if(Resp_Char_Verif("AT+CGATT",0,8) && (usb_resp[20]==0x31) && Find_OK()) rr=true; else rr=false;
			
		break;
		
		case Gurtam_Logged:
		
		if(Resp_Char_Verif("AT+CGATT",0,8) && (usb_resp[20]==0x31) && Find_OK()) rr=true; else rr=false;
		
		break;
		
		default:
		break;
		
	}
	
	return rr;

}



/***************************************************************************************************************/
bool Set_PSD_Profile(char oper)
{
	
	switch(oper)
	{
		case Vivo:
		
			DelTime=0;
			
			while((!Verify_AT_Response(Gprs_on)) && (DelTime<10000))
			{
				Send_ATCommand("AT+UPSD=1,1,\"zap.vivo.com.br\"\r",true,5000);
				Send_ATCommand("AT+UPSDA=1,3\r",true,5000);
				Send_ATCommand("AT+CGATT?\r",true,5000);
			}
		
		break;
		
		case ATeT:
		break;
		
		default:
		break;
		
	}
	
	return true;
}

/***************************************************************************************************************/
bool Resp_Char_Verif(char *rc,char start, char size)
{
	uint8_t i;
	bool rr;
	
	rr=true;

	for(i = start;i<size;i++)
	{
		if(rc[i-start] != usb_resp[i])
		{
			rr=false;
			break;
		}
	}
	return rr;
}

/***************************************************************************************************************/
bool Find_OK(void)
{

	uint16_t i;
	bool rr;

	rr = false;
	
	for(i=0;i<256;i++)
	{
		if((usb_resp[i]=='O') && (usb_resp[i+1]=='K'))
		{
			rr = true;
			break;
		}
	}
	return rr;
}



/***************************************************************************************************************/
bool AT_Resp_OK(void)
{
	uint8_t i;
	uint8_t k;
	
	k='A';
	
	k=0;
	
	for(i=0;i<255;i++)
	{
		if(usb_resp[i]=='A' && usb_resp[i+1]== 'T') k++;
		if(usb_resp[i]=='O' && usb_resp[i+1]== 'K') k++;
	}
	
	if(k>1) return true; else return false;
}

/***************************************************************************************************************/
void SetOut(char line, char val)
{
	switch(line)
	{
		case _SDN:
		
			if(val)
			{
				PIOA->PIO_SODR |= 0x00400000;
			}
			else
			{
				PIOA->PIO_CODR |= 0x00400000;
			}
		
		break;
		
		case _CAM_PWDN:
		
			if(val)
			{
				PIOA->PIO_SODR |= 0x00000100;
			}
			else
			{
				PIOA->PIO_CODR |= 0x00000100;
			}
		
		break;
		
		case _GSM_PWR_ON:
		
			if(val)
			{
				PIOA->PIO_SODR |= 0x00000400;
			}
			else
			{
				PIOA->PIO_CODR |= 0x00000400;
			}
		
		break;
		
		case _GSM_RST:
		
			if(val)
			{
				PIOA->PIO_SODR |= 0x00000800;
			}
			else
			{
				PIOA->PIO_CODR |= 0x00000800;
			}
		
		break;
		
		case _GSM_ON:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000080;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000080;
			}
		
		break;
		
		case _RF_SEL:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000001;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000001;
			}
		
		break;
		
		case _LED_BAT:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000002;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000002;
			}
		
		break;
		
		case _CHARGE:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000020;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000020;
			}
		
		break;
		
		case _GPS_RST:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00100000;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00100000;
			}
		
		break;
		
		case _GPS_SEL:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x04000000;
			}
			else
			{
				PIOD->PIO_CODR |= 0x04000000;
			}
		
		break;
		
		case _LED1_Green:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000002;
				PIOD->PIO_CODR |= 0x00000004;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000002;
				PIOD->PIO_CODR |= 0x00000004;
			}
		
		break;
		
		case _LED1_Red:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000004;
				PIOD->PIO_CODR |= 0x00000002;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000004;
				PIOD->PIO_CODR |= 0x00000002;
			}
		
		break;
		
		case _LED2_Green:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000008;
				PIOD->PIO_CODR |= 0x00000010;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000008;
				PIOD->PIO_CODR |= 0x00000010;
			}
		
		break;
		
		case _LED2_Red:
		
			if(val)
			{
				PIOD->PIO_SODR |= 0x00000010;
				PIOD->PIO_CODR |= 0x00000008;
			}
			else
			{
				PIOD->PIO_CODR |= 0x00000010;
				PIOD->PIO_CODR |= 0x00000008;
			}
		
		break;
		
		default:
		break;
	}
	
}

/***************************************************************************************************************/
void Clear_WDT(void)
{
	WDT->WDT_CR = 0xA5000000 | WDT_CR_WDRSTT;
}

/***************************************************************************************************************/
static void port_read_complete(struct cdchf_acm *cdc, uint32_t rd_count)
{
	if (rd_count) {
		
	}
}

/***************************************************************************************************************/
static void port_write_complete(struct cdchf_acm *cdc, uint32_t wr_count)
{
	if (wr_count) {

	}
}

void SetLed(char led, char pulses, char color)
{
	
	if(led==1)
	{
		//T_Led1=0;
		//L1PulsesCount=pulses;
	}
	
	if(led==2)
	{
		//T_Led2=0;
		//L2PulsesCount=pulses;
	}
	
	
	
	if(color==Red)
	{
		if(led==1)
		{
			_flg_Led1_R_Flash = true;
			_flg_Led1_G_Flash = false;
			
			if(! pulses) _flg_Led1_R_Flash = false;
			nPulsesL1 = pulses;
			//L1PulsesCount=pulses;
			//if(	_flg_Led1_R_Flash) SetOut(_LED1_Red,true);
			//_flg_Led1_State = true;
			
		}
		
		if(led==2)
		{
			_flg_Led2_R_Flash = true;
			_flg_Led2_G_Flash = false;
			
			if(! pulses) _flg_Led2_R_Flash = false;
			nPulsesL2 = pulses;
			//if(	_flg_Led2_R_Flash) SetOut(_LED2_Red,true);
			//_flg_Led2_State = true;
		}			
	}
	
	if(color==Green)
	{
		if(led==1)
		{
			_flg_Led1_G_Flash = true;
			_flg_Led1_R_Flash = false;
			
			if(! pulses) _flg_Led1_G_Flash = false;
			nPulsesL1 = pulses;
			//if(	_flg_Led1_G_Flash) SetOut(_LED1_Green,true);
			//_flg_Led1_State = true;
		}
		
		if(led==2)
		{
			_flg_Led2_G_Flash = true;
			_flg_Led2_R_Flash = false;
			
			if(! pulses) _flg_Led2_G_Flash = false;
			nPulsesL2 = pulses;
			//if(	_flg_Led2_G_Flash) SetOut(_LED2_Green,true);
			//_flg_Led2_State = true;
		}
	}
	
}

/****************************************************************************************************************
											Gurtam Routines Protocol											*
****************************************************************************************************************/

 unsigned short crc16 (const void *data, unsigned data_size)
 {
	 if (!data || !data_size)
	 return 0;
	 unsigned short crc = 0;
	 unsigned char* buf = (unsigned char*)data;
	 while (data_size--)
	 crc = (crc >> 8) ^ crc16_table[(unsigned char)crc ^ *buf++];
	 return crc;
 }
 /**************************************************************************************************************/
 bool Gurtam_Login(char prot)
 {
	char G_Command[256];
	char G_Data[256];
	uint16_t crcVal;
	uint16_t data_len;
	uint16_t locAux;
	char locc[20];
	
	switch(prot)
	{
		
		case udp_protocol:
		
		
		break;
		
		case tcp_protocol:
		
			
			for(int i = 0;i<255;i++)
			{
				G_Command[i]=NULL;
			}
		
			for(int i = 0;i<255;i++)
			{
				G_Data[i]=NULL;
			}
			
			for(int i = 0;i<200;i++)
			{
				locc[i]=NULL;
			}
			
			
			strcpy(G_Data,"2.0;");
			strcat(G_Data,IMEI);
			strcat(G_Data,";");
			strcat(G_Data,"NA");
			strcat(G_Data,";");
	
			data_len = strlen(G_Data);
	
			crcVal = crc16(G_Data,data_len);
			
			sprintf(locc, "%x", crcVal); 
	
			strcpy(G_Command,"#L#");
			strcat(G_Command,G_Data);
			strcat(G_Command,locc);
		
		
		break;
		
		default:
		break;
		
	}
	
	Send_TCP(G_Command);
	
	if(Verify_Gurtam_Response(Login)) return true; else return false;
	
 }
 
  /**************************************************************************************************************/
  bool Gurtam_Ping(void)
  {
	  char G_Command[256];
	  char G_Data[256];
	  uint16_t crcVal;
	  uint16_t data_len;
	  uint16_t locAux;
	  
	  for(int i = 0;i<255;i++)
	  {
		  G_Data[i]=NULL;
	  }
	 
	  strcpy(G_Data,"#P#\r\n");
		  
	  Send_TCP(G_Data);
	  
	 	if(Verify_Gurtam_Response(Ping))return true; else return false;
  }
  
  /**************************************************************************************************************/
	bool Gurtam_Send_Data(void)
	{
		char G_Command[256];
		char G_Data[256];
		uint16_t crcVal;
		uint16_t data_len;
		uint16_t locAux;
		char locc[20];
	  
	 
		for(int i = 0;i<255;i++)
		{
			G_Command[i]=NULL;
		}
	
		for(int i = 0;i<255;i++)
		{
			G_Data[i]=NULL;
		}
	
		for(int i = 0;i<200;i++)
		{
			locc[i]=NULL;
		}
	
	
		strcpy(G_Data,"NA;NA;");
		strcat(G_Data,Latitude);
		strcat(G_Data,";S;");
		strcat(G_Data,Longitude);
		strcat(G_Data,";W;");
		strcat(G_Data,"NA;NA;NA;4;");
	
		data_len = strlen(G_Data);
	
		crcVal = crc16(G_Data,data_len);
	
		sprintf(locc, "%x", crcVal);
	
		strcpy(G_Command,"#SD#");
		strcat(G_Command,G_Data);
		strcat(G_Command,locc);
		  
		
	  
		Send_TCP(G_Command);
	  
		if(Verify_Gurtam_Response(ASD)) return true; else return false;
	  
  }
  
  /***************************************************************************************************************/
  bool Find_Login(void)
  {

	  uint16_t i;
	  bool rr;

	  rr = false;
	  
	  for(char i = 0;i<255;i++)
	  {
		  if(Resp_Char_Verif("23414C23310D0A",i,14))
		  {
			   rr = true;
			   break;
		  }
	  }
	  
	  
	  return rr;
  }
  
  /***************************************************************************************************************/
  bool Find_ASD(void)
  {

	  uint16_t i;
	  bool rr;

	  rr = false;
	  
	  for(char i = 0;i<255;i++)
	  {
		  if(Resp_Char_Verif("2341534423310D0A",i,16))
		  {
			  rr = true;
			  break;
		  }
	  }
	  
	  
	  return rr;
  }
  
  /***************************************************************************************************************/
 bool Find_Ping(void)
  {

	  uint16_t i;
	  bool rr;

	  rr = false;
	  
	  for(char i = 0;i<255;i++)
	  {
		  if(Resp_Char_Verif("234150230D0A",i,12))
		  {
			   rr = true;
			   break;
		  }
	  }
	  
	  
	  return rr;
  }
  
  /***************************************************************************************************************/
  bool Verify_Gurtam_Response(char rt)
  {
	  bool rr=false;
	  uint8_t i=0;
	  uint8_t k=0;
	  uint8_t l=0;
	  uint8_t index1=0;
	  uint8_t index2=0;
	  
	  delay_ms(2000);
	  Send_ATCommand("AT+USORD=0,64\r",true,10000);
	  
	  rr=false;
	  
	  switch(rt)
	  {
		  case Ping:
		  
		  if(Resp_Char_Verif("AT+USORD",0,8) && Find_Ping() && Find_OK()) rr=true; else rr=false;
		  
		  break;
		  
		  case Login:
		  
		  if(Resp_Char_Verif("AT+USORD",0,8) && Find_Login() && Find_OK()) rr=true; else rr=false;
		  
		  break;
		  
		   case ASD:
		   
		   if(Resp_Char_Verif("AT+USORD",0,8) && Find_ASD() && Find_OK()) rr=true; else rr=false;
		   
		   break;
		  
		  default:
		  break;
	  }
	  
	  return rr;
  }


	  
	  
 
/***************************************************************************************************************/
 bool Send_NAV(void)
 {
	return true; 
 }
 
 /**************************************************************************************************************/
 bool Send_Image(void)
 {
	 return true;
	 
 }




