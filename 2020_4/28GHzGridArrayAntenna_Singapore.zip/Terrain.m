clc, clear all;

l = linearArray;
d = dipole;
l.Element = [d d d];
l.Element(1).Length = 2;
l.Element(2).Length = 3;
l.Element(3).Length = 4;
show(l);
