close all
clear
clc

%% Setup the Simulation
physical_constants;
unit = 1e-3; % all length in mm

%%%%%%%%%%//////Setup FDTD parameters, excitation signals & boundary conditions
f0 = 30e9;
fc = 10e9;

ll = 5.6;
ww = 2.63;
wl = 1.5;
ws = 0.5;

substrate.epsR = 4.4;                          %%%%%%%%%%% real
##substrate.kappa = 1e-3 * 2 * pi * 2.45e9 * EPS0 * substrate.epsR;
substrate.kappa = 1e-3 * 2 * pi * 28e9 * EPS0 * substrate.epsR;
substrate.width = 15;                          %%%%%%%%%%% real
substrate.height = 15;                         %%%%%%%%%%% real
substrate.thickness = 0.8;                     %%%%%%%%%%% real
patch.thickness = 0.017;                       %%%%%%%%%%% real 
substrate.cells = 4;

feed.pos = 0;                   %feeding position in x-direction
feed.R = 50;                    %feed resistance

% size of the simulation box
SimBox = [50 50 40];

FDTD = InitFDTD('NrTS', 30000);
FDTD = SetGaussExcite(FDTD, f0, fc);
BC = {'MUR' 'MUR' 'MUR' 'MUR' 'MUR' 'MUR'};
FDTD = SetBoundaryCond(FDTD, BC);

%% Setup the CSXCAD mesh
CSX = InitCSX();

mesh.x = [-SimBox(1)/2 SimBox(1)/2];
mesh.y = [-SimBox(2)/2 SimBox(2)/2];
mesh.z = [-SimBox(3)/3 SimBox(3)*2/3];

%%%%%%%%%%//////Setup Geometry ////////

%% create patch
CSX = AddMetal(CSX, 'patch');
start = [-wl/2 -(ww-ws)/2 0];                 % rectangle1
stop = [wl/2 (ww-ws)/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -ww/2-ws/2 0];              % rectangle2 
stop = [ll+wl/2 -ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 ww/2-ws/2 0];               % rectangle3
stop = [ll+wl/2 ww/2+ws/2, patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -ww/2+ws/2 0];              % rectangle4
stop = [-ll+wl/2 ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll-wl/2 -ww/2+ws/2 0];               % rectangle5
stop = [ll+wl/2 ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll/2-wl/2 ww/2+ws/2 0];           % rectangle6 
stop = [-ll/2+wl/2 3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll/2-wl/2 ww/2+ws/2 0];                % rectangle7
stop = [ll/2+wl/2 3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 3*ww/2-ws/2 0];                % rectangle8
stop = [ll+wl/2 3*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 3*ww/2+ws/2 0];                % rectangle9
stop = [-ll+wl/2 5*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-wl/2 3*ww/2+ws/2 0];                 % rectangle10
stop = [wl/2 5*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll-wl/2 3*ww/2+ws/2 0];               % rectangle11
stop = [ll+wl/2 5*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 5*ww/2-ws/2 0];                % rectangle12
stop = [ll+wl/2 5*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll/2-wl/2 -3*ww/2+ws/2 0];                % rectangle13
stop = [-ll/2+wl/2 -ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll/2-wl/2 -3*ww/2+ws/2 0];                % rectangle14
stop = [ll/2+wl/2 -ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -3*ww/2-ws/2 0];                % rectangle15
stop = [ll+wl/2 -3*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -5*ww/2-ws/2 0];                % rectangle16
stop = [ll+wl/2 -5*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -5*ww/2+ws/2 0];                % rectangle17
stop = [-ll+wl/2 -3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-wl/2 -5*ww/2+ws/2 0];                 % rectangle18
stop = [wl/2 -3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll-wl/2 -5*ww/2+ws/2 0];               % rectangle19
stop = [ll+wl/2 -3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);

%% create substrate
CSX = AddMaterial(CSX, 'substrate');
CSX = SetMaterialProperty(CSX, 'substrate', 'Epsilon', substrate.epsR, 'Kappa', substrate.kappa);
start = [-substrate.width/2 -substrate.height/2, 0];
stop = [substrate.width/2 substrate.height/2, -substrate.thickness];
CSX = AddBox(CSX, 'substrate', 0, start, stop);

% add extra cells to discretize the substrate thickness
##mesh.z = [linspace(0,substrate.thickness,substrate.cells+1) mesh.z];
mesh.z = [linspace(0,substrate.thickness,substrate.cells) mesh.z];

%% create ground
CSX = AddMetal(CSX, 'gnd');
start = [-substrate.width/2 -substrate.height/2 -substrate.thickness];
stop = [substrate.width/2 substrate.height/2 -substrate.thickness-patch.thickness];
CSX = AddBox(CSX, 'gnd', 10, start, stop);

%%%%%%%%%%%%%%///Setup the feeding port as a lumped port with 50 Ohms

start = [feed.pos ww/2 -substrate.thickness];
stop  = [feed.pos ww/2 0];
[CSX port] = AddLumpedPort(CSX, 5, 1, feed.R, start, stop, [0 0 1], true);

% Finalize the Mesh
% detect all edges except of the patch
mesh = DetectEdges(CSX, mesh,'ExcludeProperty','patch');
% detect and set a special 2D metal edge mesh for the patch
mesh = DetectEdges(CSX, mesh,'SetProperty','patch','2D_Metal_Edge_Res', c0/(f0+fc)/unit/50);
% generate a smooth mesh with max. cell size: lambda_min / 20
mesh = SmoothMesh(mesh, c0/(f0+fc)/unit/6);
CSX = DefineRectGrid(CSX, unit, mesh);

CSX = AddDump(CSX, 'Hf', 'DumpType', 10, 'Frequency',[28e9]);
CSX = AddBox(CSX,'Hf',10,[-substrate.width -substrate.height -10*substrate.thickness],[substrate.width substrate.height 10*substrate.thickness]); %assign box

%%%%%%%%%%///Add a nf2ff box
start = [mesh.x(4)     mesh.y(4)     mesh.z(4)];
stop  = [mesh.x(end-3) mesh.y(end-3) mesh.z(end-3)];
[CSX nf2ff] = CreateNF2FFBox(CSX, 'nf2ff', start, stop);

%% prepare simulation folder
Sim_Path = 'tmp_Patch_Ant';
Sim_CSX = 'patch_ant.xml';

% create an empty working directory
[status, message, messageid] = rmdir(Sim_Path, 's');   % clear previous directory
[status, message, messageid] = mkdir(Sim_Path);        % create empty simulation folder

%% write openEMS compatible xml-file
WriteOpenEMS([Sim_Path '/' Sim_CSX], FDTD, CSX);

%% show the structure
CSXGeomPlot([Sim_Path '/' Sim_CSX]);

% run openEMS
RunOpenEMS(Sim_Path, Sim_CSX);

%%%%%%%%%// Read in port voltages and currents
%% postprocessing & do the plots
freq = linspace(max([1e9, f0-fc]), f0+fc, 501);
port = calcPort(port, Sim_Path, freq);

% plot reflection coefficient S11
s11 = port.uf.ref ./ port.uf.inc;
figure
plot( freq/1e6, 20*log10(abs(s11)), 'k-', 'Linewidth', 2 );
grid on
title( 'reflection coefficient S_{11}' );
xlabel( 'frequency f / MHz' );
ylabel( 'reflection coefficient |S_{11}|' );
drawnow