close all
clear
clc

%% Setup the Simulation
physical_constants;
unit = 1e-3; % all length in mm

ll = 5.66;
ww = 2.83;
wl = 2;
ws = 0.5;

%substrate setup
substrate.epsR   = 4.4;
substrate.kappa  = 1e-3 * 2*pi*28e9 * EPS0*substrate.epsR;
substrate.thickness = 0.8;
substrate.cells = 4;
patch.thickness = 0.017;

%setup feeding
feed.pos = 0; %feeding position in x-direction
feed.R = 50;     %feed resistance

% size of the simulation box
SimBox = [150 100 40];

%% Setup FDTD Parameter & Excitation Function
f0 = 30e9; % center frequency
fc = 10e9; % 20 dB corner frequency
FDTD = InitFDTD( 'NrTs', 30000 );
FDTD = SetGaussExcite( FDTD, f0, fc );
BC = {'MUR' 'MUR' 'MUR' 'MUR' 'MUR' 'MUR'}; % boundary conditions
FDTD = SetBoundaryCond( FDTD, BC );

%% Setup CSXCAD Geometry & Mesh
CSX = InitCSX();

%initialize the mesh with the "air-box" dimensions
mesh.x = [-SimBox(1)*2/5 SimBox(1)*3/5];
mesh.y = [-SimBox(2)/2 SimBox(2)/2];
mesh.z = [-SimBox(3)/3 SimBox(3)*2/3];

% Create Patch
CSX = AddMetal(CSX, 'patch');
start = [-wl/2 -(ww-ws)/2 0];                 % rectangle1
stop = [wl/2 (ww-ws)/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -ww/2-ws/2 0];              % rectangle2 
stop = [ll+wl/2 -ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 ww/2-ws/2 0];               % rectangle3
stop = [ll+wl/2 ww/2+ws/2, patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -ww/2+ws/2 0];              % rectangle4
stop = [-ll+wl/2 ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll-wl/2 -ww/2+ws/2 0];               % rectangle5
stop = [ll+wl/2 ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll/2-wl/2 ww/2+ws/2 0];           % rectangle6 
stop = [-ll/2+wl/2 3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll/2-wl/2 ww/2+ws/2 0];                % rectangle7
stop = [ll/2+wl/2 3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 3*ww/2-ws/2 0];                % rectangle8
stop = [ll+wl/2 3*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 3*ww/2+ws/2 0];                % rectangle9
stop = [-ll+wl/2 5*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-wl/2 3*ww/2+ws/2 0];                 % rectangle10
stop = [wl/2 5*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll-wl/2 3*ww/2+ws/2 0];               % rectangle11
stop = [ll+wl/2 5*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 5*ww/2-ws/2 0];                % rectangle12
stop = [ll+wl/2 5*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll/2-wl/2 -3*ww/2+ws/2 0];                % rectangle13
stop = [-ll/2+wl/2 -ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll/2-wl/2 -3*ww/2+ws/2 0];                % rectangle14
stop = [ll/2+wl/2 -ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -3*ww/2-ws/2 0];                % rectangle15
stop = [ll+wl/2 -3*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -5*ww/2-ws/2 0];                % rectangle16
stop = [ll+wl/2 -5*ww/2+ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-ll-wl/2 -5*ww/2+ws/2 0];                % rectangle17
stop = [-ll+wl/2 -3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [-wl/2 -5*ww/2+ws/2 0];                 % rectangle18
stop = [wl/2 -3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);
start = [ll-wl/2 -5*ww/2+ws/2 0];               % rectangle19
stop = [ll+wl/2 -3*ww/2-ws/2 patch.thickness];
CSX = AddBox(CSX, 'patch', 10, start, stop);

% Create Substrate
CSX = AddMaterial(CSX, 'substrate');
CSX = SetMaterialProperty(CSX, 'substrate', 'Epsilon', substrate.epsR, 'Kappa', substrate.kappa);
start = [-7.6 -15 0];
stop = [42.4 15 -substrate.thickness];
CSX = AddBox(CSX, 'substrate', 0, start, stop);

% add extra cells to discretize the substrate thickness
mesh.z = [linspace(-substrate.thickness, 0, substrate.cells+1) mesh.z];

% Create Ground same size as substrate
CSX = AddMetal(CSX, 'gnd');
start = [-7.6 -15 -substrate.thickness];
stop = [42.4 15 -substrate.thickness-patch.thickness];
CSX = AddBox(CSX, 'gnd', 10, start, stop);

% Apply the Excitation & Resist as a Current Source
start = [feed.pos ww/2 -substrate.thickness];
stop  = [feed.pos ww/2 0];
[CSX port] = AddLumpedPort(CSX, 5, 1, feed.R, start, stop, [0 0 1], true);

% Finalize the Mesh
% detect all edges except of the patch
mesh = DetectEdges(CSX, mesh,'ExcludeProperty','patch');
% detect and set a special 2D metal edge mesh for the patch
mesh = DetectEdges(CSX, mesh,'SetProperty','patch','2D_Metal_Edge_Res', c0/(f0+fc)/unit/50);

% generate a smooth mesh with max. cell size: lambda_min / 20
mesh = SmoothMesh(mesh, c0/(f0+fc)/unit/6);
CSX = DefineRectGrid(CSX, unit, mesh);

##CSX = AddDump(CSX,'Hf', 'DumpType', 11, 'Frequency',[28e9]);
##CSX = AddBox(CSX,'Hf',10,[-substrate.width -substrate.height -10*substrate.thickness],[substrate.width substrate.height 10*substrate.thickness]); %assign box

% add a nf2ff calc box; size is 3 cells away from MUR boundary condition
start = [mesh.x(4)     mesh.y(4)     mesh.z(4)];
stop  = [mesh.x(end-3) mesh.y(end-3) mesh.z(end-3)];
[CSX nf2ff] = CreateNF2FFBox(CSX, 'nf2ff', start, stop);

%% Prepare and Run Simulation
Sim_Path = 'tmp_Patch_Ant';
Sim_CSX = 'patch_ant.xml';

% create an empty working directory
[status, message, messageid] = rmdir( Sim_Path, 's' ); % clear previous directory
[status, message, messageid] = mkdir( Sim_Path ); % create empty simulation folder

% write openEMS compatible xml-file
WriteOpenEMS( [Sim_Path '/' Sim_CSX], FDTD, CSX );

% show the structure
CSXGeomPlot( [Sim_Path '/' Sim_CSX] );

% run openEMS
RunOpenEMS( Sim_Path, Sim_CSX);

%% Postprocessing & Plots
freq = linspace( max([1e9,f0-fc]), f0+fc, 501 );
port = calcPort(port, Sim_Path, freq);

%% Smith chart port reflection
plotRefl(port, 'threshold', -10)
title( 'reflection coefficient' );

% plot feed point impedance
Zin = port.uf.tot ./ port.if.tot;
figure
plot( freq/1e6, real(Zin), 'k-', 'Linewidth', 2 );
hold on
grid on
plot( freq/1e6, imag(Zin), 'r--', 'Linewidth', 2 );
title( 'feed point impedance' );
xlabel( 'frequency f / MHz' );
ylabel( 'impedance Z_{in} / Ohm' );
legend( 'real', 'imag' );

% plot reflection coefficient S11
s11 = port.uf.ref ./ port.uf.inc;
figure
plot( freq/1e6, 20*log10(abs(s11)), 'k-', 'Linewidth', 2 );
grid on
title( 'reflection coefficient S_{11}' );
xlabel( 'frequency f / MHz' );
ylabel( 'reflection coefficient |S_{11}|' );
drawnow

%% NFFF Plots
%find resonance frequncy from s11
f_res_ind = find(s11==min(s11));
f_res = freq(f_res_ind);

% calculate the far field at phi=0 degrees and at phi=90 degrees
disp( 'calculating far field at phi=[0 90] deg...' );

nf2ff = CalcNF2FF(nf2ff, Sim_Path, f_res, [-180:2:180]*pi/180, [0 90]*pi/180);

% display power and directivity
disp( ['radiated power: Prad = ' num2str(nf2ff.Prad) ' Watt']);
disp( ['directivity: Dmax = ' num2str(nf2ff.Dmax) ' (' num2str(10*log10(nf2ff.Dmax)) ' dBi)'] );
disp( ['efficiency: nu_rad = ' num2str(100*nf2ff.Prad./port.P_inc(f_res_ind)) ' %']);

% normalized directivity as polar plot
figure
polarFF(nf2ff,'xaxis','theta','param',[1 2],'normalize',1)

% log-scale directivity plot
figure
plotFFdB(nf2ff,'xaxis','theta','param',[1 2])
% conventional plot approach
% plot( nf2ff.theta*180/pi, 20*log10(nf2ff.E_norm{1}/max(nf2ff.E_norm{1}(:)))+10*log10(nf2ff.Dmax));

drawnow

% Show 3D pattern
disp( 'calculating 3D far field pattern and dumping to vtk (use Paraview to visualize)...' );
thetaRange = (0:2:180);
phiRange = (0:2:360) - 180;
nf2ff = CalcNF2FF(nf2ff, Sim_Path, f_res, thetaRange*pi/180, phiRange*pi/180,'Verbose',1,'Outfile','3D_Pattern.h5');

figure
plotFF3D(nf2ff,'logscale',-20);


E_far_normalized = nf2ff.E_norm{1} / max(nf2ff.E_norm{1}(:)) * nf2ff.Dmax;
DumpFF2VTK([Sim_Path '/3D_Pattern.vtk'],E_far_normalized,thetaRange,phiRange,'scale',1e-3);