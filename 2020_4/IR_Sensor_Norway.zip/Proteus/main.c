 
#include <12F683.h>

#device adc=8

#FUSES NOWDT                    //No Watch Dog Timer
#FUSES INTRC_IO                 //Internal RC Osc
#FUSES NOCPD                    //No EE protection
#FUSES NOPROTECT                //Code not protected from reading
#FUSES NOMCLR                   //Master Clear pin used for I/O
#FUSES PUT                      //Power Up Timer
#FUSES NOBROWNOUT               //No brownout reset
#FUSES NOIESO                   //Internal External Switch Over mode disabled
#FUSES NOFCMEN                  //Fail-safe clock monitor disabled
#FUSES RESERVED                 //Used to set the reserved FUSE bits

#use delay(clock=4000000)

#define Motor_CON PIN_A4
#define End_Stop_Switch PIN_A1

unsigned int8 flag;

#INT_EXT
void ext_isr() // This is the routine that is run each time an external interrupt is triggered.
{
   delay_ms (20);  //debounce
   output_high (Motor_CON); 	

   	disable_interrupts(GLOBAL);       
	
}

void main()
{	

	//setup_comparator(NC_NC);
 	//setup_adc_ports(NO_ANALOGS);

	ext_int_edge(H_TO_L);     
   	clear_interrupt(INT_EXT); //May be fired by setting the edge
   	enable_interrupts(INT_EXT);
   	enable_interrupts(GLOBAL);
	
	output_low (Motor_CON);


    while(true) 
    {	
		
			
	
		if(!input(End_Stop_Switch)){		// Wait for press 
		flag=1;
		}
		if(flag==1){
			if(input(End_Stop_Switch)){
				output_low (Motor_CON); 
				enable_interrupts(GLOBAL);
			}
		}        
    }
} 