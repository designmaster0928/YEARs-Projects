
#include <xc.h>

#define _XTAL_FREQ (4000000)

#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator: High-speed crystal/resonator on RA4/OSC2/CLKOUT and RA5/OSC1/CLKIN)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config MCLRE = ON       // MCLR Pin Function Select bit (MCLR pin function is MCLR)
#pragma config CP = OFF         // Code Protection bit (Program memory code protection is disabled)
#pragma config CPD = OFF        // Data Code Protection bit (Data memory code protection is disabled)
#pragma config BOREN = OFF      // Brown Out Detect (BOR disabled)
#pragma config IESO = OFF       // Internal External Switchover bit (Internal External Switchover mode is disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor Enabled bit (Fail-Safe Clock Monitor is disabled)

#define EndStop PORTCbits.RC2
#define Buzzer PORTCbits.RC3
#define Motor PORTCbits.RC4
#define LED PORTCbits.RC5

unsigned motor_flag, EndStop_flag;

char temp = 0; 

void MSdelay(unsigned int val)
{
 unsigned int i,j;
 for (i=0; i<val; i++)
     for (j=0; j<20; j++);	/* Delay count for 1ms for 8MHz freq. */
}


void main(){    
    
    OSCCON = 0b00000000;    
    
    ANSEL = 0b00010000;  //set analog for AN4
    CMCON0 = 0x00;       //set Comparator off
    
    ADCON0bits.ADFM = 0; //left justify, left 8 bits will be 0-256   
    ADCON0bits.VCFG = 1; //VDD reference
    ADCON0bits.CHS2 = 1; //combine with line below  
    ADCON0bits.CHS1 = 0; //combine with line below   
    ADCON0bits.CHS0 = 0; //this makes AN4 input     
    
    OPTION_REGbits.INTEDG = 0;             // falling edge trigger the interrupt                
    
    INTCONbits.GIE = 1;  
    INTCONbits.PEIE = 1;
    INTCONbits.INTE = 1;  // enable the external interrupt
    INTCONbits.INTF = 0;    
    
    TRISA = 0b11111111;
    TRISC = 0b00000101;
    LED = 0;   
    
    ADRESH = 0;
    ADRESL = 0;
    
    while(1){       
        
        if(motor_flag == 1){
            
            Motor = 1;
            LED = 1;            
             
            if(EndStop == 0){                
               
                EndStop_flag = 1;
            }

            if(temp < 100){
                Buzzer = 1;
            }            
        }        
        
        if(EndStop_flag == 1){
            
            if(EndStop == 1){
                
                Motor = 0;
                LED = 0;
                Buzzer = 0;
                EndStop_flag = 0;
                motor_flag = 0;
                ADCON0bits.ADON = 0;
                temp = 0;
                
            }
        }
        
    }    
    
}

void __interrupt() myISR(void)
{
    if(INTCONbits.INTF == 1 && motor_flag == 0)
    {           
        motor_flag = 1;       
        
        ADCON0bits.ADON = 1;    
        ADCON0bits.GO_DONE = 1; //enable conversion  
        __delay_us(10);
        temp = ADRESH; 
        INTCONbits.INTF = 0;
    }
}
