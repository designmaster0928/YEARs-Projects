/*
 * radio_config.h
 *
 *  Created on: Dec 6, 2015
 *      Author: peter
 */

#ifndef RADIO_CONFIG_STUB_H_
#define RADIO_CONFIG_STUB_H_


#include "radio_config_ph_all_channels.h"

#endif /* RADIO_CONFIG_H_ */
