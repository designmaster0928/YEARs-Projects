These files are from stsw-stm32108.zip, the folder:

	STM32F30x_DSP_StdPeriph_Lib_V1.0.0/Libraries/STM32F30x_StdPeriph_Driver/inc

