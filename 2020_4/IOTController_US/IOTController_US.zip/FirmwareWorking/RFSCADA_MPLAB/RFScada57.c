/*      Copyright (C) 2003, 2004, 2005, 2006 Data Delivery Devices LLC    
        RFScada Main Control Program. 

        Processor: PIC18F6720-I/PT
        Oscillator: 20MHz
    Written 3/15/03     AGS 
    0.1     3/25/03     AGS     Functioning.
    0.2     4/03/03     AGS     Multi unit system working. Modbus working. Config working
    0.3     4/12/03     AGS     Ready for Tulsa show. 
    0.4     4/16/03     AGS     Cleaned up Modbus & comm timers. Added Modbus registers. Brownout / low voltage shutdown
    0.5     4/25/03     AGS     Modbus ms timeout independant for id of RFSCADAID
    0.6     5/17/03     AGS     Special pump mode added
    0.7     5/26/03     AGS     Default config error corrected. RS-485 driver enabled. 
                                May be master with no slaves for Modbus control. Special toggling mode added.
                                Analog pump control mode added.
    0.8     6/16/03     AGS     Watchdog timer added
    0.9     6/17/03     AGS     Hop pattern, S/N and physical channels in EEPROM & Modbus
    1.0     6/19/03     AGS     # of Rx/Tx packets in Modbus
    1.1     8/15/03     AGS     TestRelays() added. Low voltage detection disabled so PWA's could be tested without error.
    1.2     8/20/03     AGS     Low voltage detection enabled.
    1.3     8/30/03     AGS     SPMODEANASTORE added for Schlumberger RTU control. Runtime added 
    1.4     9/02/03     AGS     Spectrum analyser now stops at 65535 tx packets. Shortened brownout time, could cause
                                WD hangs at power up. 
    1.5     9/08/03     AGS     Incorrectly sent out to Storr with wrong build options.
    1.6     9/12/03     AGS     Rebuilt correctly. Compiler switches defined in this file. Essentially the same as 1.4
                                Call to SpecialMode() moved so it only occurs once for each Tx instead of continuosly.  
    1.7     11/23/03    AGS     First build with MPLab V6.40. Stopped SA from overflowing at 0xFFFF
    1.8     02/11/04    AGS     Output relay register at MB register 609. Total control mode added. MB command 6 added. 
                                Default hop pattern now 5. MEMCON setting removed for version 2.30 of MCC18
    2.0     04/30/04    AGS     Boot block support. LMR / RadInt interface support. Adjustable forced transmit rate added. 
                                MB reg 609 (relay image) corrected.    
    2.1     06/08/04    AGS     Boot block support restored. Comm fail override added.
    2.2     07/22/04    AGS     Support for RF4. unitschannels now derived from RC1 on PU. Analog inputs and digital inputs
                                configured and derived depending on RF4/RF8 state. Call to nocomms() in main loop modified to
                                catch case of commfail & master outputs sourced from master inputs & cfo which caused relay chatter 
    2.3     09/??/04    AGS     9XTend additions, enable RSSI
    2.4     10/04/04    AGS     9XTend options changed to set over the air baud rate to 9600 and retries off. Several changes to init
                                strings - NEEDS FIXING TO OPERATE WITH XSTREAM!!!!. Sent to FBI with XTend  
    2.5     Not released        9XTend/9Xtream options now selectable. Pulse packets and RF data rate selectable. Interrupts disabled 
                                while configuration is being written to EEPROM 

    2.6    01/02/05     AGS     Skipped 2.5, could not resolve problems proably related to interrupt enable/disable. Interrupts from 
                                serial sources now disabled until powered up and correctly configured. Ints disabled during EEPROM \
                                writes. XTream config writes 6553 as ID to match incorrectly configured earlier field units.

    3.0                 AGS     First attempt with 18F6722 & RF16 PWA

	3.0    03/06/06     MPH		(search for MPH to see code changes.) 
	3.0    03/06/06     MPH		Started A2D function AnalogIn()(became AnalogInRF16)
    3.0    03/06/06     MPH     Found Relay ports releative to PortD 0-7 = 21436587 relay channels
    3.0    03/06/06     MPH     Found labels on components are obscured.
	3.0    03/07/06     MPH		Using RA4(OPT1) to detect if RF16 is 1=connected , 0=must be RF4 or RF8, sets unitschannels
	3.0    03/07/06     MPH		changes to void InitChip(void)
	3.0    03/07/06     MPH		changes to void ReadInputs(void)
    3.0    03/08/06     MPH     changes to void UpdateAnalogs(void)
    3.0    03/08/06     MPH     added void AnalogInRF16(unsigned char chan)
    3.0    03/09/06     MPH     added void AnalogOutRF16(unsigned char chan)
    3.0    03/09/06     MPH     Found LM4040 U19 pin 3 must be left floating or tied to pin 2 (I tied it to pin 2)
    3.0    03/09/06     MPH     Found Analog inputs are reversed relative to the chip channels 1-8 = 7-0
    3.0    03/09/06     MPH     Solder problem with channel labeled 1 analog in. (was ground pin - needed more heat)
    3.0    03/09/06     MPH     A2Ds working , D2As working full=5.00V and doublefull=9.95V , digital inputs working
	3.0	   03/15/06     MPH     Alistair modifed RFScada3.4 and works on my Dell computer now.
    3.0    03/16/06     MPH     Corrected analog in ports 1-8, AnalogoutRF16 corrected.
    3.0    03/17/06     MPH     Added RS485 TX enable to all instances of TXREG2 usage. (may need to add conditional enable)	
	3.0    03/17/06     MPH     Temperature value test good ((5V/4096) * AtoD channel AN1) / .01V/C = temp in C
	3.0    03/17/06     MPH     Put 830 code in RF8 board. It seemed to work correctly as master.
	3.0    03/17/06     MPH     Changed p18F6720.h to p18F6722.h . didn't notice any difference.
	3.0    03/18/06     MPH     Changed project code space model to large >64K
	3.0    03/18/06     MPH     NEED to change linker CODEPAGE settings - replaced with 0x22f - 0x1ffff
	3.0    03/18/06     MPH     Replaced TransmitRS232 and TransmitRF with interrupt driven transmits
	3.0    03/24/06     MPH     Added repeater code.
	3.0    03/24/06     MPH     need to adjust transmit rate to delay extra time for repeater (setup from rfscada 3.4)
	3.0    03/28/06     MPH     added this variable for repeater settings unsigned char repeater_target[32];		//MPH - repeater target for each id that the master may send. (targets = 1-31 , repeater_target[0] used for temp storage)
    3.0    03/29/06     AGS     Fixed modbus writes for repeater_target[] and changed EESIZE. Changed CS's for V1.1 board. 
	3.0    04/03/06     MPH     modified>  InitUsart2(baud) for RADINT emulation now sets baud to passed parameter
	3.0    04/03/06     MPH     modified>  timer[RFRXTIMEOUT] = UI rs232gaptime.big;//(default config=4) (was hardcoded at 3) mS until Rx packet gets trashed
	3.0    04/03/06     MPH     modified>  transmitrate.big = 2000;   //default 2seconds (was 200ms)  This is now the timeout value (CYCLE TIME) started when packet transmit packet is started
                                  if nothing receieved Master will wait full 2000ms before next tranmit. if a packet is received then the TXTIMER will be set to txdelay.big to accomodate keydown time before next tranmit(see next note)
	3.0    04/03/06     MPH     added>  timer[TXTIMER] = UI txdelay.big; // when received a (good, too big, bad crc, or bad version) packet - now wait txdelay time (KeyDown) to accomodate keydown time before next tranmit.
	3.0    04/03/06     MPH     increased size of EESIZE by 2 to store txdelay.big
	3.0    04/03/06     MPH     added txdelay.big to modbus map at 1014 (this is in same area as transmitrate.big)
	3.0    04/04/06     MPH     Tested changes on Master and 3slaves sirect and then master 1 direct slave, 1 repeater, and 1 repeater slave, works.
	3.0    04/04/06     MPH     (will test again after Alistair adds txdelay setting in RFSCADA 3.6)
	3.0    04/05/06     MPH     Added this for delay before slave/repeater response> timer[RFSLAVETXTIMEOUT] = txdelay.big;    //MPH-040506 Have to wait before responding, to allow key down time
	3.0    04/12/06     AGS     Flag to set call to CheckRFPacket() now set when RFRXTIMEOUT timer expires rather than when every byte arrives. Changed CheckRFPacket() to expect correct packet size of 18 instead of 17 
	3.0    04/15/06     MPH     The RFRXtimeout should be extended depending on the baud rate. 
									The Modbus standard recommends 3.5 character periods.
									19200 = .00052 per char (10 bits) * 3.5 = .0018 - use 2mS
									9600 = .00104 per char (10 bits) * 3.5 = .00364 - use 4mS
									4800 = .00208 per char (10 bits) * 3.5 = .00728 - use 8mS
									2400 = .00416 per char (10 bits) * 3.5 = .0145 - use 15mS
									1200 = .0083 per char (10 bits) * 3.5 = .0291 - use 30mS
									Since radios may need more time this can be overridden to a higher value by the RFscada config program.
									added a check of the value in rs232gaptime.big and if it is below the modbus value for a given baud rate it will be updated to the minimum.
	3.0    04/15/06     MPH     Fixed - wasn't calling RestartRFRx() after checking for repeater. 
    3.0    04/24/06     AGS     Limited txdelay eeprom value to 20 and greater. Enabled brownout check for 4/8. Enabled pushbutton.
                                Comm fail time changed to minutes for A/D Instruments.
    3.1    04/25/06     AGS     Fix for RF8 detection when 4-20mA board is installed in 8CH
    3.2    05/22/06     AGS     Support for 16 bit usersnocommlimit, 16 bit nocommtimers, repeat mapping up to 255 and ID to 255. 
                                Delete srctimeout[], nocommsecs.  
    3.3    05/29/06     AGS     Fix to Analog Ch4 on RF16 PWA. Defaults set up for XTEND 
    3.4    06/12/06     AGS     Fix to HiPri interrupt to prevent rxpacket[] from overflowing and trashing memory if too much rf data arrived. 
                                CheckRFPacket modified to restartrfrx if received rf data packet is too small 
                                Brownout modified to support 16CH
    3.5                 AGS     Fix for radio RS-485 driver remaining on after power up. Added 2 timers to disable 485 drivers after 15ms, normally the
                                drivers are turned off during the tx complete interrupt but occasionally this would be missed, so the 485 drivers remained 
                                on and data would never be received again over 485. EnableUart left tx interrupt disabled, may have caused the problem if powerontime updated
                                during an interrupt.
    3.6    09/19/06     AGS     Fix for Xtend bug, where successive matching seq. #' cause xtends to filter out received data. Adds ATAM config parameter.
    3.7    09/21/06     AGS     Fix bug in relayimage. Add MB regs 1020-1027
    3.8    11/30/06     AGS     Support for RF4V2. Analogs also show up as dig5-8. Modbus cmd6 enabled. Fixed bug in UpdateAnalogs() that could cause
                                Unit 1 analog 1 input to be ovewritten by Unit 0 Analog 0 due to reading chan 10.
    3.9    07/10/07     AGS     Added specialmode 4 to use 2 ain's for hi/low trip level. Support for Modbus baud rate changes. Added Modbus command 4 support
    3.9X   04/02/08     AGS     Temporary support for pulse counting on analog 8 input, or analog 4 on RF4.
    4.0    04/25/08     AGS     Pulse counting for RF4 & RF16 enabled via MB 1016. MB 1017-1019 spares added.
    4.1    11/25/08     AGS     8 pump control type trips added, with MB regs 1028 to 1045  
    4.2    06/15/09     AGS     Support for Modbus scanning mode. Added MB command 2. Automatic saves for ana trip levels and new digital register.
    4.3    01/26/10     AGS     Change of analog trip levels for switch inputs.
    5.0    06/24/10     AGS     Adjustable analog trip levels. First support for 4G mode; operate as a slave and/or repeater. Add MB functions 1, 2 and 5.
    5.1                 AGS     Ain4 now DC voltage for 4ADI unit. AnalogInRF16 now 12 bit. 
    5.2    07/08/11     AGS     Fix to Special regs prevents multiple writes due to flatpanel rounding errors. Cleared bit 4 in 4G slave response.
    5.3    08/04/11     AGS     Fix to analog response when repliing as a classic slave. 
    5.4    03/10/11     AGS     Page boundary fix to correct MB bit write error. EEWrite now only writes changes. 8 aux. trip settings now 
                                automatically saved after being changed and left for 2 minutes.
    5.5    03/28/11     AGS     Fix to analog outputs.  
    5.6    06/21/13     AGS     Fix to status relay 
    5.7    01/14/14     AGS     Added 8 User regs 840-847 (or 13440-13567 as bits addressable). MB bit control mode (unit 29). 

// need to test TX2 tranmit interupt in network for RF4 and RF8 and R16 (USE these in new code 4.0)
  What to do with    - channel 9?  union wordy pcbtemperature;	//MPH int that holds pcb temp from LM61
  When to read RSSI and where to put result (channel 10 ?)  resanalog[inty][chan-1].big = RSSI.big;	// need to increase size of resanalog
  need to add the RB command so 9xtend radio goes into RSSI output mode.

To fix / add.....

Stop using resanalog if a slave  - no point and cannot use after unit > 31
4G slave reply with the MS bit not set


Catch out of range parameters stored in EEPROM 
Smooth analogs
Test Mode


*******************************PROGRAMMING NOTES****************************************
//  When programming the device following configuration bits that need to be set.....
//
// EC-OSC2             = RA6 (external clock source)  
// Oscillator Switch   = DISABLED
// Power Up Timer      = ENABLED
// Brown Out Detect    = ENABLED
// Brown Out Volatge   = 4.5V
// Watchdog Timer      = ENABLED
// Watchdog PostScaler = 1:128
// CCP2 Mux            = RC1
// Low Voltage Program = DISABLED   !!! Unit may reset with any stray EMF if enabled !!!
// Background Debug    = DISABLED
// Stack Overflow Reset= ENABLED
// Code Protect        = ENABLED 00200-1FFFF
// Data EE Protect     = DISABLED
// Flash Program Write = DISABLED
//        The following project files are included by the linker script:
//
//        c018iz.o         -- C startup code
//        clib.lib         -- Math and function libraries
//        p18f6720.lib     -- Processor library
//
****************************** BUILD / COMPILER NOTES ************************************
The project must have certain options set correctly. 
General....
    Include Path C:\mcc18\h\
    Library Path C:\mcc18\lib\
MPASM Asembler
    Output: Errors, Warnings and Messages
    Generate cross reference
    INHX32 format
MPLINK
    Generate Map file
    INHX32
MPLAB C18
    General:    Treat char as unsigned 
    General:    Errors, warnings & messages 
    General:    Default storage static
    Memory:     small code
    Memory:     large data
    Memory:     single bank stack
    Optimizartion:  Disable
*/


#define SWVERSION             57           // 12 = Ver. 1.2 on PC

#define UC (unsigned char)
#define UI (unsigned int)
#define hi 1
#define lo 0
                                           // Various 1mS timers        
#define YELONTIMER            0            // For the leds....
#define YELOFFTIMER           1            // 
#define REDONTIMER            2           
#define REDOFFTIMER           3           
#define GREENONTIMER          4           
#define GREENOFFTIMER         5         
#define TXTIMER               6
#define TESTTIMER             7   
#define MODBUSTIMEOUT         8
#define RFRXTIMEOUT           9
#define RFSLAVETXTIMEOUT      10
#define COMMRELAYTOGGLETIM    11
#define NOCOMMLEDTOGGLETIM    12
#define BROWNOUTTIM           13
#define LOCKTIMER             14 
#define TX1485TIMER           15 
#define TX2485TIMER           16 
#define POSTPOLLTIM           17
#define LASTTIMER             18

#define SPMODENONE           0
#define SPMODEDIGPUMP        1
#define SPMODEANAPUMP        2
#define SPMODEANASTORE       3
#define SPMODEANAPUMPINPUT   4

#define SPSTAGEINIT          0
#define SPSTAGEFILL          1
#define SPSTAGEDISCHARGE     2
#define SPSTAGEERROR         3

#define LEVELEMPTY           0
#define LEVELERROR           1
#define LEVELLOW             2
#define LEVELFULL            3
   
#define ON                   1
#define OFF                  0

#define PACKETBUFFSIZE      19          // Ver B = 12, Ver C = 18. 4G packets are M->S 17, S->M 19
#define VERSION             'C'         // Packet version.  
#define ID                  1
#define CFOKEY              38749       // Key to enable commfailoverride
#define NEWFWKEY            28571       // Key to place unit in boot block mode

#define IDLE                0           // rs232 modes
#define CONFIGDATA          1 
#define NOCOMMLIMIT         10          // # of seconds of no response from slaves before comm relay error flagged   
#define RFSCADAID           99          // Modbus address we will always answer to 

#define RADIOXSTREAM        0           // Xstream radio module
#define RADIORADINT         1           // RadInt interface board
#define RADIOXTEND          2           // Xtend radio module

#define XTENDSTRINGSIZE     48 
#define XTREAMSTRINGSIZE    24  
#define SAVETRIPSECS        120

#define EESIZE             746          // Size of eeprom data stored, also address of CRCLOW checksum

#define BAUD1200            0           // For RadInt board....
#define BAUD2400            1
#define BAUD4800            2
#define BAUD9600            3
#define BAUD19200           4
rom const unsigned char chartime35[5] = {30,15,8,4,2};	//MPH-4-15-06

#include <p18f6720.h>                   // Register definitions
#include <stdlib.h>			 

#pragma code
                                        // NOTE ALL MAXSTREAM PARAMETERS MUST BE IN HEX !!!
rom const unsigned char xtendstring[XTENDSTRINGSIZE] = 
                          {'A','T','R','E',0x0D,                    // Reset to defaults
                           'A','T','R','R','0',0x0D,                // 0 retries if no response     
                           'A','T','R','P','1','4',0x0D,            // Enable RSSI for 2000mS after packet received
                           'A','T','C','D','0',0x0D,                // Enable Rx LED     
                           'A','T','A','M',0x0D,                    // Auto Set MY from xtend s/n v.36 fix     
                           'A','T','D','T','F','F','F','F',0x0D,    // Unit ID, 0xFFFF is global
                           'A','T','W','R',0x0D,                    // Write parameters
                           'A','T','C','N',0x0D};                   // Return to operational mode
                                        // If adding also change XTENDSTRINGSIZE                            


rom const unsigned char xtreamstring[XTREAMSTRINGSIZE] = 
                          {'A','T','R','E',0x0D,// Reset to defaults
                           'A','T','D','T','6','5','5','3',0x0D,// Unit ID, 0xFFFF is global - Must be compatible with older units
                                                                // which were incorrectly set to 6553 instead of 0xFFFF 
                           'A','T','W','R',0x0D,// Write parameters
                           'A','T','C','N',0x0D};// Return to operational mode
                                        // If adding also change XTREAMSTRINGSIZE                            


//#pragma romdata page
void AddModbusTxCRC(unsigned char);
void AddModbusTxCRCComm2(unsigned char);
void AllRelaysOff(void);                // Turns off all relays including comm state relay
void Analog(unsigned char chan);        // Read analog channel for RF4 and RF8
void AnalogInRF16(unsigned char chan);	 //MPH Read analog in channel for RF16
void AnalogOutRF16(unsigned char chan); //MPH write analog out channel for RF16
void AssembleDevicePacket(signed char); 
void BuildSlavePacket(void);
void BuildSlavePacket4G(void);
void BuildMasterPacket(void);
void BuildModbusPacket(unsigned char type);
void CheckCommTimers(void);             // Checks the 100mS comm times for each unit
void CheckRepeater4G(unsigned char);    // repeater code
void CheckRepeaterClassic(void);        // repeater code
void CalcRxCRC(void);
void CalcTxCRC(unsigned char);
void CheckDeviceData(signed char);
void CheckModbusPacket(void);
void CheckRFPacket(void);
unsigned char CheckRFPacketType(void);
unsigned char CheckRxCRC(unsigned char);   
unsigned char CheckModbusRxCRC(void);
unsigned char CheckPacket(void);
void ClearAllRegs(void);                // Clears all result registers, mainly for config changes
void ClearOutputs(void);
void ClearPacketCounts(void);
void ClearWDT(void);
void DecodeRF4G(void);
void DecodeRFClassic(void);
void DecodeRFClassicMasterResponse(void);
void DecodeRF4GMasterResponse(void);
void DefaultConfig(void);
void DemoRelays(void); 
void DisableInterrupts(void);
void DisableUsart1(void);
void DisableUsart2(void);
void EnableInterrupts(void);
void EnableTimer0(void);
void EnableUsart1(void);
void EnableUsart2(void);
unsigned char EECheck(void);            // Verifies EE mem is not corrupt
unsigned char EERead(unsigned int);     // Reads a byte
void EEReadConfig(void);                // reads all configuration data from EEProm to ram
void EEWrite(unsigned int, unsigned char);// Writes a byte
void EEWriteConfig(void);               // Writes all config memory to EE - takes 2.5 secs
void EEWriteCRC(void);                  // Adds CRC to EE 
void ForceBit(unsigned int, unsigned char); 
signed char GetNextEnabledDevice(signed char);
unsigned char GetRelayData(unsigned char);// Gets the relay data to send to a slave based on config tables
unsigned char GetModbusBit(unsigned int); // Retrieves a single bit; may be coil or input, really the same    
unsigned int GetModbusRegister(unsigned int);
void GreenOff(void);
void GreenOn(void);
void HighPriInterrupts(void);
void InitAnalogOut(void);               // Sets the 5608 to defaults
void InitAnalogOutVals(void);
void InitChip(void);
void InitTimer0(void);
void InitUsart1(unsigned char);
void InitUsart2(unsigned char);
void InitVars(void);
void NoComms(void);
void OverrideExpired(unsigned char);
void PollDevices(void);                     // Sequencially polls devices per config table.      
void ReadInputs(void);
void RedOff(void);
void RedOn(void);
void RelayOn(unsigned char);            // Immediately turns on a predefined relay, 0= comm relay, 1-8 = output relays
void RelayOff(unsigned char);           // Immediately turns on a predefined relay
void RelaysOff(void);                   // Turns all relays except comm state relay off
void RestartModbusRx(void);
void RestartRfRx(void);
void RS485Off(void);
void SetupRadInt(void);
void SetupXstream(void);
void SetupXtend(void);
void SpecialMode(void);
unsigned char SPITransmit(unsigned char);//Transmit SPI data 
void TestRelays(void);
void TimerExpired(unsigned char);
void Trips(void);                       // 8 modes similar to pump control    
void UpdateAnalogs(void);               // Updates all analog inputs
void UpdateCommsRelay(void);            // Handles the comms relay states
void UpdateMasterAnalogs(void);         // Updates analog output values from registers
void UpdateMasterRelays(void);          // Updates relays from config tables (if we are master)..   
void UpdatePowerOnTime(void);           // Updates / stores runtime 
void UpdateRxLED(void);                 // Updates flashing LED if no data arriving
void UpdateTimers(void);                // Bumps all the mS timers             
void UserRegBitControl(void);           // Uses unit 29 for MB bit control
void WriteAnalogOut(unsigned char);     // Writes an analog output channel
void WriteModbusRegister(unsigned int); 
void WaitASec(void);
void YellowOff(void);
void YellowOn(void);


void stuff(void);

union wordy 
      {
      unsigned int big;                 // Method to break words into 2 chars....
      unsigned char byte[2];
      };

volatile struct 
    {
    unsigned INTSENABLED:1;
    unsigned NEWRS232:1;
    unsigned NEWRF:1;
    unsigned CONFIGCHANGED:1;
    unsigned NETWORKSTATE:1;            // True for good response from all units
    unsigned COMMRELAYTOG:1;
    unsigned REGSCLEAR:1;
    unsigned NOCOMMLEDTOG:1;
    } oddbits;

volatile struct 
    {
    unsigned SAVEANANOW:1;
    unsigned WRITENEWEECRC:1;
    unsigned SPECTRUMFULL:1;
    unsigned TRIPSENABLED:1;
    unsigned :4;
    } oddbits2;

volatile struct
    {
    unsigned PULS1:1;
    unsigned PULS2:1;
    unsigned PULS3:1;
    unsigned PULS4:1;
    unsigned PULS5:1;
    unsigned PULS6:1;
    unsigned PULS7:1;
    unsigned PULS8:1;
    } pulsebits;
/*
volatile struct                         // For trips
    {
    unsigned CALL1:1;
    unsigned CALL2:1;
    unsigned CALL3:1;
    unsigned CALL4:1;
    unsigned CALL5:1;
    unsigned CALL6:1;
    unsigned CALL7:1;
    unsigned CALL8:1;
    } callbits;
*/

union wordy pcbtemperature;				//MPH int that holds pcb temp from LM61
union wordy RSSI;						//MPH int that holds RSSI xtend signal strength
union wordy analog[8];					//MPH array for intermediate analog  channels

union wordy dcvoltage;                  // Result of analog channel 9 - scaled to 10 * voltage

union wordy anaout1;                    // Value to be written out - 0 to 1023
union wordy anaout2;                    // Value to be written out - 0 to 1023
union wordy anaout3;                    // Value to be written out - 0 to 1023
union wordy anaout4;                    // Value to be written out - 0 to 1023
union wordy anaout5;                    // Value to be written out - 0 to 1023
union wordy anaout6;                    // Value to be written out - 0 to 1023
union wordy anaout7;                    // Value to be written out - 0 to 1023
union wordy anaout8;                    // Value to be written out - 0 to 1023
unsigned char baudrate;                 // for RAdInt LMR interface 
unsigned char callbits;                 // Calls for trips    
unsigned char crclow;
unsigned char crchigh;
union wordy   commfailoverride;         // Must = CFOKEY to operate
unsigned char inputport;                // Rotated and flipped, so bit 0 = contact 1, 0 = open, 1 = closed ie matches connector
unsigned char ismrfbaudrate;            // For Xtend only..
unsigned char ismmultipackets;          // For Xtend only..
unsigned char fillbits;                 // Fill or drain operation 
union wordy   keyuptime;                // For RadInt interface....
union wordy   keydowntime;              // For RadInt interface....
unsigned char millisec;                 // Millisec counter driven from int
unsigned char modbusid;
unsigned char modbusbaudrate;           // Used for PC interface - only active 30+ secs after power up    
union wordy   nocommtime;               // Time, in 10 second increments to a 'no comm' condition
unsigned char radiotype;                // RADIOXSTREAM, RADIOXTEND or RADIOLMR
union wordy   relayimage;
union wordy   rs232gaptime;             // For RadInt interface....
unsigned char specialmode;              // Any special programs we are running
unsigned char txpacketsize;
union wordy   transmitrate;             // mS between master transmitting a packet
union wordy   txdelay;                  // MPH04-03-06  mS delay before transmit to accomodate key down of squelch.
union wordy   tron[8];                  // Trip set points
union wordy   troff[8];                 // Trip set points
union wordy   usersnocommlimit;         // and users setting. Value is 10*usersnocommlimit to give 10secs to 7.5 days
unsigned char usersmodbusoverride;      // and users setting
unsigned char modbussilenttime;
union wordy   mbaddress;                // The 16 bit fake modbus address to access
union wordy   mbnumber;                 // The number of registers to access
union wordy   mbdata;                   // Actual data written during a write command
union wordy   lowtanklevel;
union wordy   hightanklevel;
union wordy   goodpackets[32];          // # of good received packets - wraps at 0xFFFF
                                        // 10 = pcb tamperature, 11 = RSSI (last 3 up converted to 12 bit)    

#pragma udata global_vars1
unsigned char srcdig[32][8];            // Array of digital source bytes. MS 5 bits = source ID, LS 3 bits = source channel
#pragma udata global_vars2
unsigned char srcana[32][8];            // Array of ana source bytes. MS 5 bits = source ID, LS 3 bits = source channel
#pragma udata global_vars3
unsigned char res4gbits;                // These hold the input values of this board always used since 5.1 Cannot use array any more  
union wordy   res4ganas[11];            // as resdigbits and resanalog would be too big (they are still used by master only). 9 = dc volatge, 
unsigned char srccon[32];               // Array of configuration source bytes. Bit 0 = 1 for enabled, 0 disabled. Bit 2 = 1 for total control mode
unsigned char configid;                 // 0 for master, 1 to 255 for slave 

unsigned char repeater_target[32];		// Repeater target for each id that the master may send. (targets = 1-31 , repeater_target[0] used for temp storage)


unsigned char rxpacket[PACKETBUFFSIZE]; // Matches txpacket
unsigned char txpacket[PACKETBUFFSIZE]; //[0] constant, packet version 'C'
                                        //[1] packet number, incs each packet
                                        //[2] Target unit being spoken to.
                                        //[3] Digital states 0-7 (read and commanded)
                                        //[4] Analog ch 1 LSB
                                        //[5] Analog ch 2 LSB 
                                        //[6] Analog ch 3 LSB
                                        //[7] Analog ch 4 LSB
                                        //[8] Analog ch 5 LSB
                                        //[9] Analog ch 6 LSB
                                        //[10]Analog ch 7 LSB
                                        //[11]Analog ch 8 LSB
                                        //[12]Analog ch 9 (DC voltage) LSB
                                        //[13]Analog ch 1/2/3/4 MS 2 bits (bit0&1 ch 4)
                                        //[14]Analog ch 5/6/7/8 MS 2 bits (bit0&1 ch 8)
                                        //[15]Bits 0&1 LS bits of DC voltage. Bit 2 AC state. Bits 7-3 spare
                                        //[16] CRC checksum LSB
                                        //[17] CRC checksum MSB     
#pragma udata global_vars4
unsigned char rs232inbuffer[250]; 
unsigned char rs232inpointer;
unsigned char rs232inbuffersize;
unsigned char pulseenable;
union wordy   spareMBReg1;

#pragma udata global_vars5      
unsigned char rs232outbuffer[250];
unsigned char rs232outpointer;
unsigned char rs232outbuffersize;
unsigned char txpointer;                // For the RF transmit data     
unsigned char rxpointer;                // For RF rx data         
#pragma udata global_vars6
union wordy   oldunit31anas[8];         // Used by the SPMODEANASTORE routines
unsigned int  timer[LASTTIMER];
unsigned int  resdigbits[32];
unsigned char overridetimers[32];       // Seconds for each units modbus regs to be overridden
unsigned char oldunit31digs;
unsigned char mbscanID[4];
unsigned char mbscanBaud[4];
unsigned char mbscanFunc[4];
unsigned char mbscanDOTime[4];
union wordy   mbscanReg[4];
unsigned char unitschannels;            // Physical number of channels this unit has, stored in EEPROM

#pragma udata global_vars7              // Keep this chunk 16 bit aligned 
union wordy   resanalog[32][9];
union wordy   totcontrolanalog[32][9];  // For total control override mode
union wordy   nocommtimers[32];         // 16 bit in 10 sec incs.

//#pragma udata global_vars12

unsigned char totcontrolrelays[32];     // For total control override mode
union wordy   mbscanDiv[4];
union wordy   mbscanDefault[4];
unsigned char mbscanPollTime[4];

unsigned char target;
unsigned char hoppattern;               // Stored in EEPROM
union wordy   serialnumber;             // Units unique S/N, stored in EEPROM 
union wordy   saveanastime;             // Seconds until an attempted analog save
union wordy   storeanadelay;            // Shortest time before EE save (see SPMODEANASTORE)
union wordy   runhours;                 // Approx. run time
unsigned int  poweronsecs;              // Seconds running, reset every hour
unsigned char powerupbaudsecs;          // Seconds after power up before we switch to custom baudrate
unsigned char powerupbaudcomms;         // Flag indicates good comms during PU...
unsigned char pollsuspend;              // Seconds before resuming polling......
union wordy   brownouthigh;             // Trip level for start running again 
union wordy   brownoutlow;              // Trip level to stop running 
union wordy   spareMBReg2;
union wordy   spareMBReg3;

unsigned char mbscanRate;
unsigned int  mbscanDOTimers[4];
union wordy   mbscanResult[4];
unsigned char mbscanpolltimer;
union wordy   mbpulselevel;
union wordy   savetripstime;
unsigned char paddy;
union wordy   userregs[8];

void main(void)
{
unsigned char x;
unsigned char cycle;

    ClearWDT();
    InitChip();
    DefaultConfig();
    AllRelaysOff();
    RedOff();
    GreenOff();
    YellowOff();
    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        {
        PORTBbits.RB3 = 1;              //MPH Modbus port Red led off for modbus port - turn on when data received 
        PORTFbits.RF0 = 1;	            //MPH Modbus port Green led off for modbus port - turned on when transmitting
        }    
    InitUsart1(BAUD9600);               // RS232/485
    RS485Off();
    ClearWDT();
    InitUsart2(BAUD9600);               // Xstream
    InitAnalogOut();                    // Have to wait for it to be come stable before init.
    AllRelaysOff();
    InitTimer0();
    EnableTimer0();
    EnableInterrupts();
    ClearWDT();
    ClearAllRegs();
    InitAnalogOut();                    // Have to wait for it to become stable before init.
    InitAnalogOutVals();
    DefaultConfig();
    x = EECheck();
    if (x != UC 0x00)
        {
        DefaultConfig();
        EEWriteConfig();
        }
    InitVars();
    EEReadConfig();
                                        // Setups just transmit so uart ints dont need to be running
    if (radiotype == UC RADIOXSTREAM) 
        SetupXstream();
    else
    if (radiotype == UC RADIOXTEND)
        SetupXtend();
    else
        {	
        if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
	        InitUsart2(baudrate); //init RF16 second port
    	else
            SetupRadInt();
        }
    EnableUsart1();                     // RS232 & Modbus
    EnableUsart2();                     // RF    
    GreenOff();

    if (unitschannels == UC 16) 
        {                               // 16 channel brownout levels...
        brownouthigh.big = 188;         // On at 9.97 Volts.....
        brownoutlow.big = 140;          // Stop at 7.33 Volts...
        }
    else
        {                               // 4/8 channel brownout....
        brownouthigh.big = 204;         // On at 9.97 Volts.....
        brownoutlow.big = 150;          // Stop at 7.33 Volts...
        }

    dcvoltage.big = 300;

    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        PORTAbits.RA5 = 0;// Disable RS485 transmitter
    PORTCbits.RC0 = 0;                  // Disable RS485 TX

while (1)
    {
    ClearWDT();
    if (dcvoltage.big < brownoutlow.big)
         {
         ClearOutputs();
     
         timer[BROWNOUTTIM] = 1000;
         while (timer[BROWNOUTTIM] != UI 0x0000)
            {
            ClearWDT();
            UpdateAnalogs();
            for (x = 0; x < UC 250; x++)//Waste time for A-D conversions 
                {
                YellowOn();
                RedOn();
                GreenOn();
                YellowOff();
                RedOff();
                GreenOff();    
                }
            UpdateTimers();
            if (dcvoltage.big < brownouthigh.big) // On at 9.97 Volts.....
                timer[BROWNOUTTIM] = 1000;
            }
         }

    if (oddbits.CONFIGCHANGED == UC 1)
        {
        ClearAllRegs();
        oddbits.CONFIGCHANGED = 0;
        }
            
    if ((overridetimers[configid] == UC 0x00) || ((srccon[configid] & UC 0x02) == UC 0x02))
        {
        ReadInputs();
        UpdateAnalogs();
        }

    UpdateTimers();

    if (configid == UC 0x00)            // If we are the system Master..........
        {
        if (timer[TXTIMER] == UI 0x0000)
            {
            if (specialmode != UC SPMODENONE)
                SpecialMode();
            if (oddbits2.TRIPSENABLED)
                Trips();                     // 8 addition tank control / transducer fail detects 
            if (spareMBReg1.big == UI 29)    // Routine to cater to AVG flatpanel shortcomings    
                UserRegBitControl();
            BuildMasterPacket();
            GreenOn();
            txpointer = UC 0;
            txpacketsize = 17;               // added V5.1
            PIE3bits.TX2IE = 1; 	            // MPH enable USART2 transmit interrupt
            timer[TXTIMER] = UI transmitrate.big;

            RestartRfRx();
            if (goodpackets[0].big != 0xFFFF)
                goodpackets[0].big++;
            else
                oddbits2.SPECTRUMFULL = 1;
            }
        CheckCommTimers();
        if ((oddbits.NETWORKSTATE == UC 1) || (commfailoverride.big == UI CFOKEY))
            {
            UpdateMasterRelays();
            UpdateMasterAnalogs();
            }
        else
            ClearOutputs();
        }

    if (oddbits.NEWRF == UC 1)
        CheckRFPacket();

    if (oddbits.NEWRS232 == UC 1)
        {
        YellowOn();  
        CheckModbusPacket();
        }

    if (nocommtime.big == UI 0x00)      // V2.2 Catch case where masters relays were driven by master signals and comms failed 
        {                               // used to cause relay chatter
        if (configid != UC 0x00)
            NoComms();
        else
        if (commfailoverride.big != UI CFOKEY)
            NoComms();
        }

    UpdateCommsRelay();

    UpdateRxLED();

    UpdatePowerOnTime();

    if (pollsuspend == UI 0x00)       // Disable polls if other comms are using comm1 
        {
        PollDevices();
        } 

    cycle++;
    if (unitschannels == UC 16) 
        {
        if (cycle > UC 2)
            cycle = 1;
        AnalogOutRF16(cycle);
        }
    else
        {
        if (cycle > UC 8)
            cycle = 1;
        WriteAnalogOut(cycle);
        }
    }
}


void ClearPacketCounts(void)
{
unsigned int temp;
    for (temp = UI 0; temp < UI 32; temp++)
        goodpackets[temp].big = UI 0x00;
}


void UpdatePowerOnTime(void)
{
    if (poweronsecs > UI 3599)
        {
        runhours.big++;
        DisableUsart1();
        DisableUsart2();
        EEWrite(608, runhours.byte[lo]);
        EEWrite(609, runhours.byte[hi]);
        EEWriteCRC();
        EnableUsart1();
        EnableUsart2();
        poweronsecs = 0;
        }
}


void UserRegBitControl(void)
{
    if (GetModbusRegister(840) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x01;
    else
        resdigbits[29] = resdigbits[29] & 0xFE;
    if (GetModbusRegister(841) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x02;
    else
        resdigbits[29] = resdigbits[29] & 0xFD;
    if (GetModbusRegister(842) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x04;
    else
        resdigbits[29] = resdigbits[29] & 0xFB;
    if (GetModbusRegister(843) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x08;
    else
        resdigbits[29] = resdigbits[29] & 0xF7;
    if (GetModbusRegister(844) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x10;
    else
        resdigbits[29] = resdigbits[29] & 0xEF;
    if (GetModbusRegister(845) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x20;
    else
        resdigbits[29] = resdigbits[29] & 0xDF;
    if (GetModbusRegister(846) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x40;
    else
        resdigbits[29] = resdigbits[29] & 0xBF;
    if (GetModbusRegister(847) != UI 0x00)
        resdigbits[29] = resdigbits[29] | 0x80;
    else
        resdigbits[29] = resdigbits[29] & 0x7F;
}

void Trips(void)                        // Run 8 tank control trips using Unit 30 overrides.
{
unsigned char chan;
unsigned int level;
unsigned char box;

    chan = srcana[30][0];               // First extract the measured level for first trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[0].big)
        callbits = callbits | 0x01;
    if (level < troff[0].big)
        callbits = callbits & 0xFE;

    chan = srcana[30][1];               // Extract the measured level for second trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[1].big)
        callbits = callbits | 0x02;
    if (level < troff[1].big)
        callbits = callbits & 0xFD;

    chan = srcana[30][2];               // 3rd trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[2].big)
        callbits = callbits | 0x04;
    if (level < troff[2].big)
        callbits = callbits & 0xFB;

    chan = srcana[30][3];               // 4th trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[3].big)
        callbits = callbits | 0x08;
    if (level < troff[3].big)
        callbits = callbits & 0xF7;

    chan = srcana[30][4];               // 5th trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[4].big)
        callbits = callbits | 0x10;
    if (level < troff[4].big)
        callbits = callbits & 0xEF;

    chan = srcana[30][5];               // 6th trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[5].big)
        callbits = callbits | 0x20;
    if (level < troff[5].big)
        callbits = callbits & 0xDF;

    chan = srcana[30][6];               // 5th trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[6].big)
        callbits = callbits | 0x40;
    if (level < troff[6].big)
        callbits = callbits & 0xBF;

    chan = srcana[30][7];               // 5th trip....
    box = chan;
    chan = chan & 0x07;                 // LS bits are channel...
    box = box / UC 8;                   // Pull out top 5 bits for box ID
    level = resanalog[box][chan].big;
    if (level > tron[7].big)
        callbits = callbits | 0x80;
    if (level < troff[7].big)
        callbits = callbits & 0x7F;

    chan = fillbits ^ callbits;

//    resdigbits[30] = resdigbits[30] ^ chan;

    if ((chan & 0x01) == UC 0x01)
        resdigbits[30] = resdigbits[30] | 0x01;
    else
        resdigbits[30] = resdigbits[30] & 0xFE;
    if ((chan & 0x02) == UC 0x02)
        resdigbits[30] = resdigbits[30] | 0x02;
    else
        resdigbits[30] = resdigbits[30] & 0xFD;
    if ((chan & 0x04) == UC 0x04)
        resdigbits[30] = resdigbits[30] | 0x04;
    else
        resdigbits[30] = resdigbits[30] & 0xFB;
    if ((chan & 0x08) == UC 0x08)
        resdigbits[30] = resdigbits[30] | 0x08;
    else
        resdigbits[30] = resdigbits[30] & 0xF7;
    if ((chan & 0x10) == UC 0x10)
        resdigbits[30] = resdigbits[30] | 0x10;
    else
        resdigbits[30] = resdigbits[30] & 0xEF;
    if ((chan & 0x20) == UC 0x20)
        resdigbits[30] = resdigbits[30] | 0x20;
    else
        resdigbits[30] = resdigbits[30] & 0xDF;
    if ((chan & 0x40) == UC 0x40)
        resdigbits[30] = resdigbits[30] | 0x40;
    else
        resdigbits[30] = resdigbits[30] & 0xBF;
    if ((chan & 0x80) == UC 0x80)
        resdigbits[30] = resdigbits[30] | 0x80;
    else
        resdigbits[30] = resdigbits[30] & 0x7F;
}


void SpecialMode(void)
{
static unsigned char stage; 
static unsigned char toggle;
static union wordy oldlowtanklevel;
static union wordy oldhightanklevel;
unsigned char relaybits;
unsigned char pump;
unsigned char chan;
unsigned int level;
unsigned char box;
unsigned char x;
union wordy eeint;
union wordy hightrip;
union wordy lowtrip;

    if ((specialmode == UC SPMODEDIGPUMP) 
     || (specialmode == UC SPMODEANAPUMP)  // Special analog pump modes.....
     || (specialmode == UC SPMODEANAPUMPINPUT)) // Special analog input pump mode.....
        {
        if (specialmode == UC SPMODEANAPUMPINPUT) // Copy over trip levels either from stored settings 
            {                               // or from analog inputs aimed at 31[1] and 31[2]                
            chan = srcana[31][1];           // First extract the high trip level....
            box = chan;
            chan = chan & 0x07;             // LS861 bits are channel...
            box = box / UC 8;               // Pull out top 5 bits for box ID
            hightrip.big = resanalog[box][chan].big;
            chan = srcana[31][2];           // Low trip level....
            box = chan;
            chan = chan & 0x07;             // LS bits are channel...
            box = box / UC 8;               // Pull out top 5 bits for box ID
            lowtrip.big = resanalog[box][chan].big;
            }
        else
            {
            hightrip.big = hightanklevel.big;   // Set trip levels for control
            lowtrip.big = lowtanklevel.big;
            if (oldlowtanklevel.big != lowtanklevel.big) // See if we need to begin 'save to EE' process
               {
               oldlowtanklevel.big = lowtanklevel.big;   // Save most recent setting
               saveanastime.big = storeanadelay.big;     // start save timer
               }
            if (oldhightanklevel.big != hightanklevel.big)
               {
               oldhightanklevel.big = hightanklevel.big;    // Save most recent setting
               saveanastime.big = storeanadelay.big;     // start save timer
               }
            if (oddbits2.SAVEANANOW == UC 1)             // There has not been a change in hi/lo trip points for 2 mins....
               {                                         // so save any regs that differ from EE....
               oddbits2.SAVEANANOW = UC 0;               // Fixed 5.2
               DisableUsart1();
               DisableUsart2();
               EEWrite(582, lowtanklevel.byte[lo]);       
               EEWrite(583, lowtanklevel.byte[hi]);       
               EEWrite(584, hightanklevel.byte[lo]);       
               EEWrite(585, hightanklevel.byte[hi]);  
               EEWriteCRC();      
               EnableUsart1();
               EnableUsart2();
               }
            }
        relaybits = GetRelayData(31);
        if ((specialmode == UC SPMODEANAPUMP)
          ||(specialmode == UC SPMODEANAPUMPINPUT))
            {   
            chan = srcana[31][0];           // First extract the measured level....
            box = chan;
            chan = chan & 0x07;             // LS bits are channel...
            box = box / UC 8;               // Pull out top 5 bits for box ID
            level = resanalog[box][chan].big;
            if (relaybits != UC 0x00)
                relaybits = LEVELERROR;
            else
            if (lowtrip.big > hightrip.big)
                relaybits = LEVELERROR;
            else
            if (level > hightrip.big)
                relaybits = LEVELFULL;
            else
            if (level < lowtrip.big)
                relaybits = LEVELEMPTY;
            else
                relaybits = LEVELLOW;
            }
        switch(stage)
            {
            case SPSTAGEINIT:
                {
                pump = OFF;    
                if((relaybits == UC LEVELFULL)||
                   (relaybits == UC LEVELLOW))
                    {
                    stage = SPSTAGEDISCHARGE;    
                    }
                else
                if (relaybits == UC LEVELEMPTY)  //
                    {
                    stage = SPSTAGEFILL;    
                    pump = ON;
                    if (toggle == UC 0x00)
                        toggle = 0xFF;
                    else
                        toggle = 0x00;
                    }
                else
                   stage = SPSTAGEERROR;    
                break;
                }
            case SPSTAGEFILL:
                {
                if(relaybits == UC LEVELFULL)
                    {
                    stage = SPSTAGEDISCHARGE;
                    pump = OFF;
                    }
                else
                    pump = ON;
                break;
                }
            case SPSTAGEDISCHARGE:
                {
                if(relaybits == UC LEVELEMPTY)
                    {
                    stage = SPSTAGEFILL;
                    pump = ON;
                    if (toggle == UC 0x00)
                        toggle = 0xFF;
                    else
                        toggle = 0x00;
                    }
                else
                    pump = OFF;
                break;    
                }
            case SPSTAGEERROR:          // See if we must remain in error mode
                {
                if (((relaybits & 0x03) == UC LEVELERROR)//level error reported
                 || (relaybits > UC 3)) // Another shutdown input is active            
                    pump = OFF;
                else
                    stage = SPSTAGEINIT;
                break;
                }
            }
                    //Always perform error check.....
        if (((relaybits & 0x03) == UC LEVELERROR)//level error reported
          || (relaybits > UC 3)) // Another shutdown input is active            
                {
                stage = SPSTAGEERROR;
                pump = OFF;
                }    
 
        if (pump == UC ON)
            {
            resdigbits[31] = resdigbits[31] | 0x01;
            if (toggle == UC 0xFF)
                {
                resdigbits[31] = resdigbits[31] | 0x04;
                resdigbits[31] = resdigbits[31] & 0xF7;
                }
            else
                {
                resdigbits[31] = resdigbits[31] | 0x08;
                resdigbits[31] = resdigbits[31] & 0xFB;
                }
            }
       else
            resdigbits[31] = resdigbits[31] & 0xF2;

       if (stage == UC SPSTAGEERROR)
            resdigbits[31] = resdigbits[31] | 0x02;
       else
            resdigbits[31] = resdigbits[31] & 0xFD;
        }                               //End of special analog & digital pump modes.....

    if (specialmode == UC SPMODEANASTORE) // Also stores dig in bits (4.2 on)
        {
        for (x = UC 0; x < UC 8; x++)   // If any analog31 has changed store it and restart timer...
            {
            if (oldunit31anas[x].big != resanalog[31][x].big)       // 590 = stored ana31[0]lo
                {
                oldunit31anas[x].big = resanalog[31][x].big;
                }
            }
        if (oldunit31digs != resdigbits[31]) // If diginbits[31] has changed store it and restart timer
            {
            oldunit31digs = resdigbits[31];
            saveanastime.big = storeanadelay.big;  
            } 
        if (oddbits2.SAVEANANOW == UC 1)// There has not been a change in analog31 regs for 2 mins....
            {                           // so save any regs that differ from EE....
            oddbits2.SAVEANANOW = UC 0;
            for (x = UC 0; x < UC 8; x++)
                { 
                eeint.byte[lo] = EERead(590 + (2 * x));
                eeint.byte[hi] = EERead(591 + (2 * x));
                if  (eeint.big != resanalog[31][x].big)                 // 590 = stored ana31[0]lo
                    {                                                   // 591 = stored ana31[0]hi
                    DisableUsart1();
                    DisableUsart2();
                    EEWrite(590 + (2 * x), resanalog[31][x].byte[lo]);  // ...     
                    EEWrite(591 + (2 * x), resanalog[31][x].byte[hi]);  // 604 = stored ana31[7]lo    
                    EnableUsart1();
                    EnableUsart2();
                    oddbits2.WRITENEWEECRC = UC 1;                      // 605 = stored ana31[7]hi
                    }
                }
            relaybits = EERead(743);                                    // 743 = stored diginbits[31]
            if (relaybits != resdigbits[31])
                {
                DisableUsart1();
                DisableUsart2();
                EEWrite(743, resdigbits[31]);
                EnableUsart1();
                EnableUsart2();
                oddbits2.WRITENEWEECRC = UC 1;                      
                } 
            
            if (oddbits2.WRITENEWEECRC == UC 1)
                {
                DisableUsart1();
                DisableUsart2();
                EEWriteCRC();    
                EnableUsart1();
                EnableUsart2();
                }
            }
        }
}


void UpdateRxLED(void)
{
    if ((nocommtime.big == UI 0) && (configid != UC 0x00))
        {                               // Do the 'no comms' flash
        if (timer[NOCOMMLEDTOGGLETIM] == UC 0)
            {
            if (oddbits.NOCOMMLEDTOG == UC 1)
                {
                oddbits.NOCOMMLEDTOG = 0;
                RedOff();
                }
            else
                {
                oddbits.NOCOMMLEDTOG = 1;
                RedOn();
                }
            timer[NOCOMMLEDTOGGLETIM] = UI 1500;
            }
        }
}


void NoComms(void)
{
    AllRelaysOff();
    InitAnalogOutVals();
    InitAnalogOut();
    oddbits.NETWORKSTATE = 0;   
    if (oddbits.REGSCLEAR == UC 0)
        {
        ClearAllRegs();    
        oddbits.REGSCLEAR = 1;
        }
}

void ClearOutputs(void)                 // Put outputs into an 'off' state, used when network is down.
{
    RelaysOff();
    InitAnalogOutVals();
    InitAnalogOut();
}


void CheckCommTimers(void)
{
unsigned char x;
unsigned char allok;
unsigned char chan;
unsigned char justmaster;
allok = 0xFF;
justmaster = 0xFF;
    for (x = 1; x < UC 32; x++)
        {
        if ((srccon[x] & 0x01) == UC 0x01)
            {
            justmaster = 0x00;
            if (nocommtimers[x].big == UI 0x00)        
                {
                allok = 0x00;
                resdigbits[x] = 0;
                for (chan = 0; chan < UC 9; chan++)// Include DC voltage...
                    resanalog[x][chan].big = UI 0x0000;
                }
            }
        }
    if (justmaster == UC 0xFF)          // Ensures we dont go to comm fail if just master enabled
        {
        nocommtime.big = 2;
        }
    if (allok == UC 0xFF)
        oddbits.NETWORKSTATE = 1;
    else
        oddbits.NETWORKSTATE = 0;
}

void UpdateCommsRelay(void)
{
static char tog;
    if  (nocommtime.big == UI 0x00)
        {
        RelayOff(0);
        oddbits.NETWORKSTATE = 0;
        }
    else
    if (oddbits.NETWORKSTATE == UC 1)
        {
        RelayOn(0);
        }
    else
    if (timer[COMMRELAYTOGGLETIM] == UC 0)
        {
        if (oddbits.COMMRELAYTOG == UC 1)
            {
            oddbits.COMMRELAYTOG = 0;
            RelayOn(0);
            }
        else
            {
            oddbits.COMMRELAYTOG = 1;
            RelayOff(0);
            }
        timer[COMMRELAYTOGGLETIM] = UI 1000;
        }
}

void ClearAllRegs(void)
{
unsigned char x;
unsigned char chan;
    for (x=0; x < UC 31; x++)
        {
        resdigbits[x] = 0;
        for (chan = 0; chan < UC 9; chan++)        // Include DC voltage...
            resanalog[x][chan].big = UI 0x0000;
        }
    for (x=0; x < UC 8; x++)
        {
        for (chan = 0; chan < UC 8; chan++)        // No Voltage - these have been loaded by remote master (if our ID > 31)
            res4ganas[chan].big = UI 0x0000;
        }
        res4gbits = 0;
}


void DefaultConfig(void)
{
unsigned char x;
unsigned char box;

    for (x = 0; x < UC 32; x++)         // Default to slave 1 
        {
        srccon[x] = 0;
        }
    srccon[1] = 0x01;
  
    for (x = 0; x < UC 8; x++)          // Set masters source as slave 1
        {
        srcdig[0][x] = x + 8;
        srcana[0][x] = x + 8;
        }
    for (box = 1; box < UC 32; box++)   // Set all slaves to be sourced from master
        {
        for (x = 0; x < UC 8; x++)
            {
            srcdig[box][x] = x;
            srcana[box][x] = x;
            }    
        } 

	for (x=0;x< UC 32;x++) repeater_target[x] = 0;	//MPH initialize repeater targets - all zero, so no repeaters.

    configid = 1;                           // Default address slave 1
    modbusid = 0;                           // Users Modbus ID disabled
    usersnocommlimit.big = 3;
    usersmodbusoverride = 10;
    modbussilenttime = 40;
    specialmode = SPMODENONE; 
    hightanklevel.big = 678;
    lowtanklevel.big = 345;
    hoppattern = 0x05;
    serialnumber.big = 0x0000;
    storeanadelay.big = 120;
    runhours.big = 0;
    poweronsecs = 1800;                 // Start at 30 mins, to balence out PU / PD's
    baudrate = BAUD9600;
    radiotype = RADIOXTEND;	            
    keyuptime.big = 1;
    keydowntime.big = 1;
    rs232gaptime.big = 4;
    transmitrate.big = UI 500;	        // default 500ms for 2 deep repeating 
    txdelay.big = UI 20;                // default 20mS for master delay before next transmit (       
    commfailoverride.big = 0;
    ismrfbaudrate = 1;                  // Start off at 120,000 BPS                      
    ismmultipackets = 8;                // actual packets = ismmultipackets + 1
    modbusbaudrate = BAUD9600;
    oddbits2.TRIPSENABLED = 1;      // @@@
    tron[0].big = 250;
    tron[1].big = 350;
    tron[2].big = 450;
    tron[3].big = 550;
    tron[4].big = 650;
    tron[5].big = 750;
    tron[6].big = 850;
    tron[7].big = 950;
    troff[0].big = 180;
    troff[1].big = 180;
    troff[2].big = 180;
    troff[3].big = 180;
    troff[4].big = 180;
    troff[5].big = 180;
    troff[6].big = 180;
    troff[7].big = 180;
    fillbits = 0x00;
    mbscanID[0] = 0;
    mbscanID[1] = 0;
    mbscanID[2] = 0;
    mbscanID[3] = 0;
    mbscanBaud[0] = 3;
    mbscanBaud[1] = 3;
    mbscanBaud[2] = 3;
    mbscanBaud[3] = 3;
    mbscanFunc[0] = 3;
    mbscanFunc[1] = 3;
    mbscanFunc[2] = 3;
    mbscanFunc[3] = 3;
    mbscanDOTime[0] = 3;
    mbscanDOTime[1] = 3;
    mbscanDOTime[2] = 3;
    mbscanDOTime[3] = 3;
    mbscanPollTime[0] = 5;
    mbscanPollTime[1] = 5;
    mbscanPollTime[2] = 5;
    mbscanPollTime[3] = 5;
    mbscanReg[0].big = 16;
    mbscanReg[1].big = 17;
    mbscanReg[2].big = 18;
    mbscanReg[3].big = 19;
    mbscanDiv[0].big = 1;
    mbscanDiv[1].big = 1;
    mbscanDiv[2].big = 1;
    mbscanDiv[3].big = 1;
    mbscanDefault[0].big = 0;
    mbscanDefault[1].big = 0;
    mbscanDefault[2].big = 0;
    mbscanDefault[3].big = 0;
    mbscanRate = 10;
    mbpulselevel.big = 350;
}

void UpdateMasterRelays(void)
{
unsigned char temp;
unsigned char box;
unsigned char x;
   
    if ((srccon[0] & 0x02) == UC 0x02)  // If in total control mode..... 
        {
        temp = totcontrolrelays[0];
        for (x = 0; x < UC 8; x++)
            {
            if ((temp & 0x01) == UC 0x01)
                RelayOn(x+1);
            else
                RelayOff(x+1);
            temp = temp / 2;
            }
        }
    else
        {                               // Normal routing mode....        
        for (x = 0; x < UC 8; x++)      // For the eight relays...
            {
            box = srcdig[0][x];
            box = box / UC 8;               //Pull out top 5 bits for box ID
            temp = resdigbits[box];
            box = srcdig[0][x];
            box = box & 0x07;
            while (box != UC 0x00)
                {
                box--;
                temp = temp / UC 2;
                }
            if ((temp & UC 0x01) == UC 0x01)
                RelayOn(x + 1);
            else
                RelayOff(x + 1);
            }
        }
}

void UpdateMasterAnalogs(void)
{
unsigned char box;
unsigned char chan;
unsigned char x;

if ((srccon[0] & 0x02) == UC 0x02)  // If in total control mode..... 
    {
    anaout1.big = totcontrolanalog[0][0].big;
    anaout2.big = totcontrolanalog[0][1].big;
    anaout3.big = totcontrolanalog[0][2].big;
    anaout4.big = totcontrolanalog[0][3].big;
    anaout5.big = totcontrolanalog[0][4].big;
    anaout6.big = totcontrolanalog[0][5].big;
    anaout7.big = totcontrolanalog[0][6].big;
    anaout8.big = totcontrolanalog[0][7].big;
    }
else
    {                               // Normal routing mode....        
	   for (x = 0; x < UC 8; x++)      // For the eight analog outputs...
	   {
	   chan = srcana[0][x];
	   box = chan;
	   chan = chan & 0x07;             // LS bits are channel...
	   box = box / UC 8;               // Pull out top 5 bits for box ID
	   switch(x)
	       {
	       case 0:
	           anaout1.big = resanalog[box][chan].big;
	           break;
	       case 1:
	           anaout2.big = resanalog[box][chan].big;
	           break;
	       case 2:
	           anaout3.big = resanalog[box][chan].big;
	           break;
	       case 3:
	           anaout4.big = resanalog[box][chan].big;
	           break;
	       case 4:
	           anaout5.big = resanalog[box][chan].big;
	           break;
	       case 5:
	           anaout6.big = resanalog[box][chan].big;
	           break;
	       case 6:
	           anaout7.big = resanalog[box][chan].big;
	           break;
	       case 7:
	           anaout8.big = resanalog[box][chan].big;
	           break;
	       default:
	           break;
	       }
 	   }
    }
}

 
void RestartRfRx(void)
{
unsigned char x;
    for (x = 0; x < UC PACKETBUFFSIZE; x++)
        rxpacket[x] = 0x99;
    rxpointer = 0x00;
    oddbits.NEWRF = 0;
    RedOff();
}


void CheckRepeater4G(unsigned char type)               // arrive with type 2=M->S, 3=S->M
{
unsigned char x,y;
    if (type == UC 2)                                  // from master?
        {
        if ((rxpacket[0] < UC 32) &&                   // Only support 1-31 for source repeater ID. Target can be 1-255  
            (repeater_target[rxpacket[0]] > UC 0))     // if configured as repeater target then translate and retransmit
            {
            for (x = 0; x < UC 17; x++)
	            txpacket[x] = rxpacket[x];
	         txpacket[0] = repeater_target[rxpacket[0]];
            CalcTxCRC(17);
            txpacketsize = 17;
            timer[RFSLAVETXTIMEOUT] = txdelay.big;    // Have to wait before responding, to allow key down time
            }
        }
    if (type == UC 3)                                 // from a slave , maybe a repeater's target
        {
        x = rxpacket[0];
        y = 0;
        while ((y < UC 31) && (x!= UC 0)) 
            {
            y++;
            if (repeater_target[y] == x)
               x = 0;                                 // y is the master id for x;
            }
        if (x == UC 0)                                // its from a repeaters target.
            {
            for (x = 0; x < UC 19; x++)
                txpacket[x] = rxpacket[x];
            txpacket[0] = y;                          // use master id of last repeater xmit
            CalcTxCRC(19);
            txpacketsize = 19;
            timer[RFSLAVETXTIMEOUT] = txdelay.big;    // Have to wait before responding, to allow key down time
            }
        }
}


void CheckRepeaterClassic(void)                        // MPH - repeater code
{
unsigned char x,y;

    if ((rxpacket[2] > UC 0) && (rxpacket[2] < UC 32)) //from master
        {
        if (repeater_target[rxpacket[2]] > UC 0)      // if configured as repeater target  then translate and retransmit
            {
            for (x = 0; x < UC 18; x++)
	            txpacket[x] = rxpacket[x];
	         txpacket[2] = repeater_target[rxpacket[2]];
            CalcTxCRC(18);
            txpacketsize = 18;
            timer[RFSLAVETXTIMEOUT] = txdelay.big;    //MPH-040506 Have to wait before responding, to allow key down time
            }
        }
    if (rxpacket[2] > UC 32)                          // from a slave , maybe a repeater's target
        {
        x = rxpacket[2] - UC 32;
        y = 0;
        while ((y < UC 31) && (x!= UC 0)) 
            {
            y++;
            if (repeater_target[y] == x) x = 0; // y is the master id for x;
            }
	     if (x == UC 0)                                // its from a repeaters target.
            {
            for (x = 0; x < UC 18; x++)
                txpacket[x] = rxpacket[x];
            txpacket[2] = y + 32;    // use master id of last repeater xmit
            CalcTxCRC(18);
            timer[RFSLAVETXTIMEOUT] = txdelay.big;    //MPH-040506 Have to wait before responding, to allow key down time
            }
        }
}

unsigned char CheckRFPacketType(void)  // Returns 0 for unknown, 1 for classic, 2 for 4G M->S, 3 for 4G S->M. Assumes CRC is correct
{
unsigned char x;
   if (rxpointer == UC 18)             // Classic length?
      {
      if (rxpacket[0] == VERSION)      // Current packet version?
         {                             // If we are a slave, see a good packet not to us or to master log as good master packet            
         if ((configid != UC 0x00) && 
             (rxpacket[2] != UC 0x00) &&
             (rxpacket[2] != configid))
            goodpackets[0x00].big++;
         return(1);
         }
      }
   x = rxpacket[1] & 192;
   if (rxpointer == UC 17)             // 4G M->S length?
      {
      if (x == UC 192)
         return(2);                    
      }
   if (rxpointer == UC 19)             // 4G S->M length?
      {
      if (x == UC 64)
         return(3);                    
      }
   return(0x00);                       // Who knows?
}


void CheckRFPacket(void)                // Verifies contents of received packet
{
unsigned char result;
unsigned char x;

      oddbits.NEWRF = 0;
      x = CheckRxCRC(rxpointer);

      if (x != UC 0x00)                   // Bad C/S?
         {
         RestartRfRx();
         timer[TXTIMER] = UI txdelay.big; // Effectively wait for a quiet time before we start trying (only occurs if we are the master)....
         return;                  
         }              
      
      x = CheckRFPacketType();            // Recognise packet?
      if (x == UC 0x00)                   // No - dont know what it is
         {
         RestartRfRx();
         timer[TXTIMER] = UI txdelay.big; // Effectively wait for a quiet time before we start trying (only occurs if we are the master)....
         return;                  
         }              
      if (x == UC 1)                      // Classic
         {                                
         if ((configid != UC 0x00)        // If we are a slave, see a good packet not to us or to master log as good master packet            
          && (rxpacket[2] != UC 0x00) 
          && (rxpacket[2] != configid))
            goodpackets[0x00].big++;
         if ((configid != UC 0x00)        // We are a slave but not the target, check for repeater mode 
          && (rxpacket[2] != configid))
            {
            CheckRepeaterClassic();       // if this is a slave , MPH - repeater hook
            RestartRfRx();
            return;
            }
         if ((configid != UC 0x00) && (rxpacket[2] == configid)) // For us?  @@@ AND not >31!
            {
            DecodeRFClassic();
            nocommtime.big = usersnocommlimit.big;
            BuildSlavePacket();
            txpacketsize = 18;
            timer[RFSLAVETXTIMEOUT] = UI txdelay.big;    // Have to wait before responding, to allow key down time
            RestartRfRx();
            goodpackets[configid].big++;
            return;
           }  
         if (configid == UC 0x00)
            {
            DecodeRFClassicMasterResponse();
            return;
            }
         RestartRfRx();                   // Should never get here but just in case
         return;
         }   
      if (x == UC 2)                      // 4G M->S
         {   
         if ((configid != UC 0x00)        // If we are a slave, see a good packet not to us or to master log as good master packet            
          && (rxpacket[0] != UC 0x00) 
          && (rxpacket[0] != configid))
            goodpackets[0x00].big++;
         if ((configid != UC 0x00)        // We are a slave but not the target, check for repeater mode 
          && (rxpacket[0] != configid))
            {
            CheckRepeater4G(2);           // if this is a slave repeater hook
            RestartRfRx();
            return;
            }
         if ((configid != UC 0x00) && (rxpacket[0] == configid)) // For us?
            {
            DecodeRF4G();
            nocommtime.big = usersnocommlimit.big;
            BuildSlavePacket4G();
            txpacketsize = 19;
            timer[RFSLAVETXTIMEOUT] = UI txdelay.big;    // Have to wait before responding, to allow key down time
            RestartRfRx();
            goodpackets[configid].big++;
            return;
           }  
         if (configid == UC 0x00)
            {
//            DecodeRF4G(); //@@@@@@
            return;
            }
         RestartRfRx();                   // Should never get here but just in case
         return;
         }     
      if (x == UC 3)                      // 4G S->M
         {
         if ((configid != UC 0x00)        // If we are a slave, see a good packet not to us or to master log as good master packet            
          && (rxpacket[0] != UC 0x00) 
          && (rxpacket[0] != configid))
            goodpackets[0x00].big++;
         if ((configid != UC 0x00)        // We are a slave but not the target, check for repeater mode 
          && (rxpacket[0] != configid))
            CheckRepeater4G(3);
         if (configid == UC 0x00)
            {
            DecodeRF4GMasterResponse();   // We are the master - maybe its for us!
            }
         }
      RestartRfRx();
}
 

void DecodeRF4G(void)                                 // Everything we need to reply is specified in rebuffer...
{
unsigned char mode;                                   // The master packet can request 16 different modes.
unsigned char i;
union wordy anatemp;                                    
unsigned short x;
unsigned short anoffset;         
//union shorty mbdata;                                  // Only used for writes
//union shorty mbaddress;                               // Only used for writes
//union shorty correction;                              // factor for converting 10 to 16 bit
   for (x = 0; x < UC 17; x++)                          // pre fill for functions with unused data in the reply
      txpacket[x] = 0x00;
   mode = rxpacket[1] & 0x0F;                           // Only write to relays if mode is 0
   if (mode == UC 0x00)                                 // Ignore modes 1-3 as 4/16 units dont have the hardware 
      {
      if ((rxpacket[1] & 0x20) == UC 0x20)              // If network state is OK activate output registers......    
         {
         oddbits.NETWORKSTATE = 1;
         i = rxpacket[2];                               // Get relay 'command' for 8 relays
         if ((i & 0x01) == UC 0x01)                     // Update relays first.....            
            RelayOn(1);
         else
            RelayOff(1);
         if ((i & 0x02) == UC 0x02)
            RelayOn(2);
         else
            RelayOff(2);
         if ((i & 0x04) == UC 0x04)               
            RelayOn(3);
         else
            RelayOff(3);
         if ((i & 0x08) == UC 0x08)
            RelayOn(4);
         else
            RelayOff(4);
         if ((i & 0x10) == UC 0x10)               
            RelayOn(5);
         else
            RelayOff(5);
         if ((i & 0x20) == UC 0x20)
            RelayOn(6);
         else
            RelayOff(6);
         if ((i & 0x40) == UC 0x40)               
            RelayOn(7);
         else
            RelayOff(7);
         if ((i & 0x80) == UC 0x80)
            RelayOn(8);
         else
            RelayOff(8);      

         anaout1.byte[lo] = rxpacket[3];                 // Analogs. 4G arrive as 12 bit, present we have 10 bit out
         anaout1.byte[hi] = rxpacket[11];
         anaout1.byte[hi] = anaout1.byte[hi] & UC 0x0F;
         anaout1.big = anaout1.big / UI 4;               // 12->10 bit
         anaout2.byte[lo] = rxpacket[4];                 
         anaout2.byte[hi] = rxpacket[11];
         anaout2.byte[hi] = anaout2.byte[hi] >> 4;
         anaout2.byte[hi] = anaout2.byte[hi] & UC 0x0F;
         anaout2.big = anaout2.big / UI 4;               // 12->10 bit
         anaout3.byte[lo] = rxpacket[5];                 
         anaout3.byte[hi] = rxpacket[12];
         anaout3.byte[hi] = anaout3.byte[hi] & UC 0x0F;
         anaout3.big = anaout3.big / UI 4;               // 12->10 bit
         anaout4.byte[lo] = rxpacket[6];                 
         anaout4.byte[hi] = rxpacket[12];
         anaout4.byte[hi] = anaout4.byte[hi] >> 4;
         anaout4.byte[hi] = anaout4.byte[hi] & UC 0x0F;
         anaout4.big = anaout4.big / UI 4;               // 12->10 bit
         anaout5.byte[lo] = rxpacket[7];                 
         anaout5.byte[hi] = rxpacket[13];
         anaout5.byte[hi] = anaout5.byte[hi] & UC 0x0F;
         anaout5.big = anaout5.big / UI 4;               // 12->10 bit
         anaout6.byte[lo] = rxpacket[8];                 
         anaout6.byte[hi] = rxpacket[13];
         anaout6.byte[hi] = anaout6.byte[hi] >> 4;
         anaout6.byte[hi] = anaout6.byte[hi] & UC 0x0F;
         anaout6.big = anaout6.big / UI 4;               // 12->10 bit
         anaout7.byte[lo] = rxpacket[9];                 
         anaout7.byte[hi] = rxpacket[14];
         anaout7.byte[hi] = anaout7.byte[hi] & UC 0x0F;
         anaout7.big = anaout7.big / UI 4;               // 12->10 bit
         anaout8.byte[lo] = rxpacket[10];                 
         anaout8.byte[hi] = rxpacket[14];
         anaout8.byte[hi] = anaout8.byte[hi] >> 4;
         anaout8.byte[hi] = anaout8.byte[hi] & UC 0x0F;
         anaout8.big = anaout8.big / UI 4;               // 12->10 bit

         }  
      else
         {
         oddbits.NETWORKSTATE = 0;                       // Network down, so set to default output
         ClearOutputs();
         }
      }
/*      
      for (x = 0; x < UC 17; x++)                        // pre fill for functions with unused data in the reply
         txpacket[x] = 0x00;
      txpacket[0] = rxpacket[0];                         // Build RFScada 4G reply to mode 0 packet. Echo ID   
      txpacket[1] = rxpacket[1] & 0x0F;                  // Echo command
      txpacket[1] = txpacket[1] | 0x70;                  // Add status bits - clear M->S bit   
      i = rxpacket[0];                                   // Will need box ID
//@@@      txpacket[2] = resdigbits[i];
      txpacket[2] = res4gbits;
      txpacket[3] = 0x00;                                // No more digs
      txpacket[4] = 0x00;

//@@@@ put res4ganas instead of resanalog[....
      anatemp.big = resanalog[i][0].big;                 // An1
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[5] = anatemp.byte[lo];
      txpacket[13] = anatemp.byte[hi];
      anatemp.big = resanalog[i][1].big;                 // An2
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[6] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[13] = txpacket[13] | anatemp.byte[hi];
      anatemp.big = resanalog[i][2].big;                 // An3   
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[7] = anatemp.byte[lo];
      txpacket[14] = anatemp.byte[hi];
      anatemp.big = resanalog[i][3].big;                 // An4
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[8] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[14] = txpacket[14] | anatemp.byte[hi];
      anatemp.big = resanalog[i][4].big;                 // An5
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[9] = anatemp.byte[lo];
      txpacket[15] = anatemp.byte[hi];
      anatemp.big = resanalog[i][5].big;                 // An6
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[10] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[15] = txpacket[15] | anatemp.byte[hi];
      anatemp.big = resanalog[i][6].big;                 // An7
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[11] = anatemp.byte[lo];
      txpacket[16] = anatemp.byte[hi];
      anatemp.big = resanalog[i][7].big;                 // An8
      anatemp.big = anatemp.big * UI 4;                  // Have to bump our reading x4   
      txpacket[12] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[16] = txpacket[16] | anatemp.byte[hi];
   }
   if (mode == UC 1) ;                                   // Dont support these modes yet
   if (mode == UC 2) ;
   if (mode == UC 3) ;
*/


/*
           
   comm2txbuffer[0] = comm2rxbuffer[0];            // Build RFScada 4G reply. Echo ID   
   comm2txbuffer[1] = comm2rxbuffer[1] & 0x0F;     // Echo command
   comm2txbuffer[1] = comm2txbuffer[1] | 0x70;     // Add status bits   

                                                   // Digs 4G Spec V1.2 fixed dig locations...
   mbdata.big = GetModbusRegister(DIGINIMAGE1);
   comm2txbuffer[2] = mbdata.byte[hi];              
   mbdata.big = GetModbusRegister(DIGINIMAGE2);
   comm2txbuffer[3] = mbdata.byte[lo];            
   comm2txbuffer[4] = mbdata.byte[hi];              

   if (mode < 4)                                      // Return analogs 
      {
      anoffset = mode * 8;                            // Can handle modes by using analog source offset 
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset); // First see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
         mbdata.big = GetModbusRegister(ANINRAW + anoffset); // Reported 1st analog
         mbdata.big = mbdata.big / 16;                   // Convert 16 bits to 12    
         if (mode == 0)                                  // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); 
            if ((correction.byte[lo] & UC 0x01) == UC 0x01)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[5] = mbdata.byte[lo];
      comm2txbuffer[13] = mbdata.byte[hi];
      comm2txbuffer[13] = comm2txbuffer[13] & 0x0F;
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset + 1); // Analog 2 - first see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset + 1); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
          mbdata.big = GetModbusRegister(ANINRAW + anoffset + 1); // Reported 2nd analog
          mbdata.big = mbdata.big / 16;                     
          if (mode == 0)                                  // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); // Does not work?
            if ((correction.byte[lo] & UC 0x02) == UC 0x02)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[6] = mbdata.byte[lo];
      mbdata.byte[hi] = mbdata.byte[hi] * 16;         // Move into upper 4 bits
      comm2txbuffer[13] = comm2txbuffer[13] | mbdata.byte[hi];
      
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset + 2); // Analog 3 - first see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset + 2); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
         mbdata.big = GetModbusRegister(ANINRAW + anoffset + 2); // Reported 3rd analog
         mbdata.big = mbdata.big / 16;                      
         if (mode == 0)                                  // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); // Does not work?
            if ((correction.byte[lo] & UC 0x04) == UC 0x04)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[7] = mbdata.byte[lo];
      comm2txbuffer[14] = mbdata.byte[hi];
      comm2txbuffer[14] = comm2txbuffer[14] & 0x0F;
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset + 3); // Analog 4 - first see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset + 3); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
         mbdata.big = GetModbusRegister(ANINRAW + anoffset + 3); // Reported 4th analog
         mbdata.big = mbdata.big / 16;                     
         if (mode == 0)                                   // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); // Does not work?
            if ((correction.byte[lo] & UC 0x08) == UC 0x08)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[8] = mbdata.byte[lo];
      mbdata.byte[hi] = mbdata.byte[hi] * 16;         
      comm2txbuffer[14] = comm2txbuffer[14] | mbdata.byte[hi];
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset + 4); // Analog 5 - first see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset + 4); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
         mbdata.big = GetModbusRegister(ANINRAW + anoffset + 4); // Reported 5th analog
         mbdata.big = mbdata.big / 16;                  
         if (mode == 0)                                  // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); // Does not work?
            if ((correction.byte[lo] & UC 0x10) == UC 0x10)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[9] = mbdata.byte[lo];
      comm2txbuffer[15] = mbdata.byte[hi];
      comm2txbuffer[15] = comm2txbuffer[15] & 0x0F;
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset + 5); // Analog 6 - first see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset + 5); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
         mbdata.big = GetModbusRegister(ANINRAW + anoffset + 5); // Reported 6th analog
         mbdata.big = mbdata.big / 16;                      
         if (mode == 0)                                  // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); // Does not work?
            if ((correction.byte[lo] & UC 0x20) == UC 0x20)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[10] = mbdata.byte[lo];
      mbdata.byte[hi] = mbdata.byte[hi] * 16;        
      comm2txbuffer[15] = comm2txbuffer[15] | mbdata.byte[hi];
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset + 6); // Analog 7 - first see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset + 6); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
         mbdata.big = GetModbusRegister(ANINRAW + anoffset + 6); // Reported 7th analog
         mbdata.big = mbdata.big / 16;                  
         if (mode == 0)                                  // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); // Does not work?
            if ((correction.byte[lo] & UC 0x40) == UC 0x40)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[11] = mbdata.byte[lo];
      comm2txbuffer[16] = mbdata.byte[hi];
      comm2txbuffer[16] = comm2txbuffer[16] & 0x0F;
      mbdata.big = GetModbusRegister(ANIDISPRES + anoffset + 7); // Analog 8 - first see if its pulse counting input
      if (mbdata.big == 14)   
         { 
         mbdata.big = GetModbusRegister(ANINSCALED + anoffset + 7); // Reported 1st analog
         mbdata.big = mbdata.big & 0xFFF;                    // Bound to limit of 4G protocol 4095  
         }
      else
         {
        mbdata.big = GetModbusRegister(ANINRAW + anoffset + 7); // Reported 8th analog
         mbdata.big = mbdata.big / 16;                      
         if (mode == 0)                                   // If in1-8 set for 4G dig mode have to invert level.
            {
            correction.big = GetModbusRegister(IN18MODE); // Does not work?
            if ((correction.byte[lo] & UC 0x80) == UC 0x80)
               {
               if (mbdata.big > 1500)
                  mbdata.big = 0;
               else
                  mbdata.big = 3000;
               }
            }
         }
      comm2txbuffer[12] = mbdata.byte[lo];
      mbdata.byte[hi] = mbdata.byte[hi] * 16;        
      comm2txbuffer[16] = comm2txbuffer[16] | mbdata.byte[hi];
      }
   
   if (mode == 4)                                     // Write up to 5 MB registers
      {
      x = comm2rxbuffer[2];                           // x num of regs to write
      comm2txbuffer[2] = comm2rxbuffer[2];
      mbaddress.byte[lo] = comm2rxbuffer[3];          // start address
      mbaddress.byte[hi] = comm2rxbuffer[4];
      i = 5;                                          // reg index
      while ((x > 0) && (x < 6))                      // can write 1 to 5 regs
         {
         mbdata.byte[lo] = comm2rxbuffer[i];
         mbdata.byte[hi] = comm2rxbuffer[i + 1];
         WriteModbusRegister(mbaddress, mbdata);       
         x--;    
         mbaddress.big++;
         i = i + 2;   
         }
      }

   if (mode == 5)                                     // Read 7 consecutive MB registers
      {
      mbaddress.byte[lo] = comm2rxbuffer[2];
      mbaddress.byte[hi] = comm2rxbuffer[3];
      mbdata.big = GetModbusRegister(mbaddress.big);
      comm2txbuffer[2] = mbdata.byte[lo];              
      comm2txbuffer[3] = mbdata.byte[hi];            
      mbaddress.big++;
      mbdata.big = GetModbusRegister(mbaddress.big);
      comm2txbuffer[4] = mbdata.byte[lo];              
      comm2txbuffer[5] = mbdata.byte[hi];            
      mbaddress.big++;
      mbdata.big = GetModbusRegister(mbaddress.big);
      comm2txbuffer[6] = mbdata.byte[lo];              
      comm2txbuffer[7] = mbdata.byte[hi];            
      mbaddress.big++;
      mbdata.big = GetModbusRegister(mbaddress.big);
      comm2txbuffer[8] = mbdata.byte[lo];              
      comm2txbuffer[9] = mbdata.byte[hi];            
      mbaddress.big++;
      mbdata.big = GetModbusRegister(mbaddress.big);
      comm2txbuffer[10] = mbdata.byte[lo];              
      comm2txbuffer[11] = mbdata.byte[hi];            
      mbaddress.big++;
      mbdata.big = GetModbusRegister(mbaddress.big);
      comm2txbuffer[12] = mbdata.byte[lo];              
      comm2txbuffer[13] = mbdata.byte[hi];            
      mbaddress.big++;
      mbdata.big = GetModbusRegister(mbaddress.big);
      comm2txbuffer[14] = mbdata.byte[lo];              
      comm2txbuffer[15] = mbdata.byte[hi];            
      comm2txbuffer[16] = 0x00;            
      }

   if (mode == 6)                                  // Read 4G status
      {
      mbdata.big = GetModbusRegister(MBSITENAME);
      comm2txbuffer[2] = mbdata.byte[lo];              
      comm2txbuffer[3] = mbdata.byte[hi];            
      mbdata.big = GetModbusRegister(MBSITENAME + 1);
      comm2txbuffer[4] = mbdata.byte[lo];              
      comm2txbuffer[5] = mbdata.byte[hi];            
      mbdata.big = GetModbusRegister(MBFIRMWARE);
      comm2txbuffer[6] = mbdata.byte[lo];              
      comm2txbuffer[7] = mbdata.byte[hi];            
      mbdata.big = GetModbusRegister(MBSERIALNUM);
      comm2txbuffer[8] = mbdata.byte[lo];              
      comm2txbuffer[9] = mbdata.byte[hi];            
      mbdata.big = GetModbusRegister(MBPOWERTIME);
      comm2txbuffer[10] = mbdata.byte[lo];              
      comm2txbuffer[11] = mbdata.byte[hi];            
      mbdata.big = GetModbusRegister(RF4GOPTIONS);
      comm2txbuffer[12] = mbdata.byte[lo];              
      comm2txbuffer[13] = mbdata.byte[hi];            
      comm2txbuffer[14] = 32;                      // 32 channel               
      comm2txbuffer[15] = 0;            
      comm2txbuffer[16] = 0;              
      }
*/

}




void DecodeRF4GMasterResponse(void)                // We are a master and this should be a reply to us 
{
   if (rxpacket[0] == target)                      // If its a response to our ping and in
      {
      if (((rxpacket[1] & 0xCF) == UC 0x40))       // bit 7 clear, bit 6 set and mode is zero (4GA 1-8) process...
         {                                         // We wont process modes 1,2 & 3 sionce we dont have mem etc.
         if (((overridetimers[target] == UC 0x00)) || // If not overwritten by Modbus....
              ((srccon[target] & 0x02) == UC 0x02))   // or that box is in total control mode....
            {   
            resdigbits[target]=rxpacket[2];        // [3] Digital states 0-7 (read and commanded)
            resanalog[UI target][0].byte[lo] = rxpacket[5];// Analog ch 1 LSB
            resanalog[UI target][1].byte[lo] = rxpacket[6];// Analog ch 2 LSB 
            resanalog[UI target][2].byte[lo] = rxpacket[7];// Analog ch 3 LSB
            resanalog[UI target][3].byte[lo] = rxpacket[8];// Analog ch 4 LSB
            resanalog[UI target][4].byte[lo] = rxpacket[9];// Analog ch 5 LSB
            resanalog[UI target][5].byte[lo] = rxpacket[10];// Analog ch 6 LSB
            resanalog[UI target][6].byte[lo] = rxpacket[11];// Analog ch 7 LSB
            resanalog[UI target][7].byte[lo] = rxpacket[12];// Analog ch 8 LSB
            resanalog[UI target][0].byte[hi] = rxpacket[13] & 0x0F;  
            resanalog[UI target][1].byte[hi] = rxpacket[13] / UC 16;
            resanalog[UI target][2].byte[hi] = rxpacket[14] & 0x0F;  
            resanalog[UI target][3].byte[hi] = rxpacket[14] / UC 16;
            resanalog[UI target][4].byte[hi] = rxpacket[15] & 0x0F;  
            resanalog[UI target][5].byte[hi] = rxpacket[15] / UC 16;
            resanalog[UI target][6].byte[hi] = rxpacket[16] & 0x0F;  
            resanalog[UI target][7].byte[hi] = rxpacket[16] / UC 16;
            }
          timer[TXTIMER] = UI txdelay.big;   // received a good packet - now wait txdelay time (KeyDown) for squelch to stop
          nocommtime.big = usersnocommlimit.big;
          nocommtimers[target].big = usersnocommlimit.big;
          oddbits.REGSCLEAR = 0;
          if (oddbits2.SPECTRUMFULL == UC 0)
             goodpackets[UI target].big++;
          }
      }
     RestartRfRx();
}



void DecodeRFClassicMasterResponse(void)
{
 rxpacket[2] = rxpacket[2] - 0x20;
 if (rxpacket[2] == target)      // If our response is from our target + 32 process....
   {  
   if (((overridetimers[target] == UC 0x00)) || // If not overwritten by Modbus....
        ((srccon[target] & 0x02) == UC 0x02))   // or that box is in total control mode....
      {   
      resdigbits[target]=rxpacket[3]; // [3] Digital states 0-7 (read and commanded)
      resanalog[UI target][0].byte[lo] = rxpacket[4];//[4] Analog ch 1 LSB
      resanalog[UI target][1].byte[lo] = rxpacket[5];//[5] Analog ch 2 LSB 
      resanalog[UI target][2].byte[lo] = rxpacket[6];//[6] Analog ch 3 LSB
      resanalog[UI target][3].byte[lo] = rxpacket[7];//[7] Analog ch 4 LSB
      resanalog[UI target][4].byte[lo] = rxpacket[8];//[8] Analog ch 5 LSB
      resanalog[UI target][5].byte[lo] = rxpacket[9];//[9] Analog ch 6 LSB
      resanalog[UI target][6].byte[lo] = rxpacket[10];//[10]Analog ch 7 LSB
      resanalog[UI target][7].byte[lo] = rxpacket[11];//[11]Analog ch 8 LSB
      resanalog[UI target][8].byte[lo] = rxpacket[12];//[12]Analog ch 9 (DC voltage) LSB
      resanalog[UI target][0].byte[hi] = rxpacket[13] / UC 64;//[13]Analog ch 1/2/3/4 MS 2 bits (bit0&1 ch 4)
      resanalog[UI target][1].byte[hi] = rxpacket[13] / UC 16;
      resanalog[UI target][1].byte[hi] = resanalog[UI target][1].byte[hi] & 0x03;
      resanalog[UI target][2].byte[hi] = rxpacket[13] / UC 4;
      resanalog[UI target][2].byte[hi] = resanalog[UI target][2].byte[hi] & 0x03;
      resanalog[UI target][3].byte[hi] = rxpacket[13];
      resanalog[UI target][3].byte[hi] = resanalog[UI target][3].byte[hi] & 0x03;
      resanalog[UI target][4].byte[hi] = rxpacket[14] / UC 64;//[14]Analog ch 5/6/7/8 MS 2 bits (bit0&1 ch 8)
      resanalog[UI target][5].byte[hi] = rxpacket[14] / UC 16;
      resanalog[UI target][5].byte[hi] = resanalog[UI target][5].byte[hi] & 0x03;
      resanalog[UI target][6].byte[hi] = rxpacket[14] / UC 4;
      resanalog[UI target][6].byte[hi] = resanalog[UI target][6].byte[hi] & 0x03;
      resanalog[UI target][7].byte[hi] = rxpacket[14];
      resanalog[UI target][7].byte[hi] = resanalog[UI target][7].byte[hi] & 0x03;
      resanalog[UI target][8].byte[hi] = rxpacket[15] & 0x03; //[15]Bits 0&1 LS bits of DC voltage. 
      }
    timer[TXTIMER] = UI txdelay.big;   // received a good packet - now wait txdelay time (KeyDown) for squelch to stop
    nocommtime.big = usersnocommlimit.big;
    nocommtimers[target].big = usersnocommlimit.big;
    oddbits.REGSCLEAR = 0;
    if (oddbits2.SPECTRUMFULL == UC 0)
       goodpackets[UI target].big++;
    }
  RestartRfRx();
}


void DecodeRFClassic(void)
{                               // Must be a slave and its for us...
        if ((rxpacket[15] & 0x08) == UC 0x08)
            {
            oddbits.NETWORKSTATE = 1;
            if ((rxpacket[3] & 0x01) == UC 0x01)// Update relays first.....            
                RelayOn(1);
            else
                RelayOff(1);
            if ((rxpacket[3] & 0x02) == UC 0x02)
                RelayOn(2);
            else
                RelayOff(2);
            if ((rxpacket[3] & 0x04) == UC 0x04)               
                RelayOn(3);
            else
                RelayOff(3);
            if ((rxpacket[3] & 0x08) == UC 0x08)
                RelayOn(4);
            else
                RelayOff(4);
            if ((rxpacket[3] & 0x10) == UC 0x010)               
                RelayOn(5);
            else
              RelayOff(5);
             if ((rxpacket[3] & 0x20) == UC 0x20)
              RelayOn(6);
            else
            RelayOff(6);
            if ((rxpacket[3] & 0x40) == UC 0x40)               
                RelayOn(7);
            else
                RelayOff(7);
            if ((rxpacket[3] & 0x80) == UC 0x80)
                RelayOn(8);
            else
                RelayOff(8);            
            anaout1.byte[lo] = rxpacket[4];
            anaout2.byte[lo] = rxpacket[5];
            anaout3.byte[lo] = rxpacket[6];
            anaout4.byte[lo] = rxpacket[7];
            anaout5.byte[lo] = rxpacket[8];
            anaout6.byte[lo] = rxpacket[9];
            anaout7.byte[lo] = rxpacket[10];
            anaout8.byte[lo] = rxpacket[11];
            anaout1.byte[hi] = rxpacket[13];
            anaout1.byte[hi] = anaout1.byte[hi] / UC 64;
            anaout2.byte[hi] = rxpacket[13];
            anaout2.byte[hi] = anaout2.byte[hi] / UC 16;
            anaout2.byte[hi] = anaout2.byte[hi] & 0x03;
            anaout3.byte[hi] = rxpacket[13];
            anaout3.byte[hi] = anaout3.byte[hi] / UC 4;
            anaout3.byte[hi] = anaout3.byte[hi] & 0x03;
            anaout4.byte[hi] = rxpacket[13];
            anaout4.byte[hi] = anaout4.byte[hi] & 0x03;
            anaout5.byte[hi] = rxpacket[14];
            anaout5.byte[hi] = anaout5.byte[hi] / UC 64;
            anaout6.byte[hi] = rxpacket[14];
            anaout6.byte[hi] = anaout6.byte[hi] / UC 16;
            anaout6.byte[hi] = anaout6.byte[hi] & 0x03;
            anaout7.byte[hi] = rxpacket[14];
            anaout7.byte[hi] = anaout7.byte[hi] / UC 4;
            anaout7.byte[hi] = anaout7.byte[hi] & 0x03;
            anaout8.byte[hi] = rxpacket[14];
            anaout8.byte[hi] = anaout8.byte[hi] & 0x03;
            }    
        else
            {
            oddbits.NETWORKSTATE = 0;   // Network down, so set to default output
            ClearOutputs();
            }
}



unsigned char CheckRxCRC(unsigned char length)          
{
unsigned char tempchar;
unsigned char temp;
unsigned char y;
unsigned int crc;
unsigned int tempint;
    if (length < UC 3)     
        return(0xFC);  
    crc = 0xFFFF;
    for (temp = UC 0; temp < UC length - 2; temp++)
        {
        tempchar = rxpacket[temp];
        tempint = tempchar;
        crc = crc ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc;
            crc = crc /  UI 2;
            if (tempint & 1 == 1)
                crc = crc ^ 0xA001;
            }
         }
    crclow = crc;
    crc = crc >> 8;
    crchigh = crc; 
    if (crclow != UC rxpacket[length - 2])      // Should match with what arrived   
        return(0xFE);
    if (crchigh != UC rxpacket[length - 1])
        return (0xFD);   
    return(0x00);                               // Good Packet!
}


unsigned char GetRelayData(unsigned char dest)
{
unsigned char temp;
unsigned char box;
unsigned char x;
unsigned char result;
    if ((srccon[dest] & 0x02) == UC 0x02)// If in total control mode...
        return(totcontrolrelays[dest]);
    result = 0;
    for (x = 0; x < UC 8; x++)          // For the eight target relays...
    {
    result = result / UC 2;
    box = srcdig[dest][x];
    box = box / UC 8;                   // Pull out top 5 bits for source box ID
    temp = resdigbits[box];
    box = srcdig[dest][x];
    box = box & 0x07;
    while (box != UC 0x00)
        {
        box--;
        temp = temp / UC 2;
        }
    if ((temp & UC 0x01) == UC 0x01)
        result = result | 0x80;
    }
    return(result);
}

/*
void BuildMasterPacketOrig(void)            // Insert data and generate c/s
{
unsigned char temp;
unsigned char tempchar;
unsigned char y;
union wordy crc;
unsigned int tempint;

    for (y = 0; y < UC 35; y++)         // Emergency escape method if bad config. data 
        { 
        target++;
        if (target > UC 31)             // Wrap at 31
            target = 1;
        temp = srccon[target];
        if ((temp & 0x01) == UC 0x01)
            y = 50;
        }
    if (y == UC 35)
        target = 0;                     // Nothing configured

    txpacket[0] = VERSION;
    txpacket[1] = txpacket[1] + 1;
    txpacket[2] = target;                 
    for (temp = UC 3; temp < UC 18; temp++)  // Clear rest of packet
        txpacket[temp] = 0x00;
    txpacket[3] = GetRelayData(target);         
    stuff();
    txpacket[12] = dcvoltage.byte[lo];
    txpacket[15] = dcvoltage.byte[hi] & 0x03;// Set AC OK bit
    if ((oddbits.NETWORKSTATE == UC 1) || (commfailoverride.big == UI CFOKEY))
        txpacket[15] = txpacket[15] | 0x08;
    crc.big = 0xFFFF;
    for (temp = UC 0; temp < UC 18 - 2; temp++)
        {
        tempchar = txpacket[temp];
        tempint = tempchar;
        crc.big = crc.big ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc.big;
            crc.big = crc.big / UI 2;
            if (tempint & 1 == 1)
                crc.big = crc.big ^ 0xA001;
            }
         }
    txpacket[16] = crc.byte[lo];
    txpacket[17] = crc.byte[hi];    
}
                                        //[0] constant, packet version 'C'
                                        //[1] packet number, incs each packet
                                        //[2] Target unit being spoken to.
                                        //[3] Digital states 0-7 (read and commanded)
                                        //[4] Analog ch 1 LSB
                                        //[5] Analog ch 2 LSB 
                                        //[6] Analog ch 3 LSB
                                        //[7] Analog ch 4 LSB
                                        //[8] Analog ch 5 LSB
                                        //[9] Analog ch 6 LSB
                                        //[10]Analog ch 7 LSB
                                        //[11]Analog ch 8 LSB
                                        //[12]Analog ch 9 (DC voltage) LSB
                                        //[13]Analog ch 1/2/3/4 MS 2 bits (bit0&1 ch 4)
                                        //[14]Analog ch 5/6/7/8 MS 2 bits (bit0&1 ch 8)
                                        //[15]Bits 0&1 LS bits of DC voltage. Bit 2 AC power state. Bit 3 network state. Bits 7-4 spare
                                        //[16] CRC checksum LSB
                                        //[17] CRC checksum MSB     
*/ 

/*

void Assemble4GPoll(unsigned int device, unsigned char type)   // Builds a packet for the next lucky device
{                                                              // Sets/clears rf4gpolling flag so multiple polls can be called to 1 unit
unsigned char x, temp, y;
   for (x=2; x < 16; x++)
      comm2txbuffer[x] = 0;                                    // Clear buffer.....  
   x = GetModbusRegister(MBCONFIGTABLE + (CONFSZ  * device) + DEVREGTYPE);              // Get requested poll type....
   x = x & 0x07;
   if (x != POLL4G)                                          // Multi-poll poll?
      {
      if (rf4gpolling == 0)                                  // Completed last multi poll?
         rf4gpolling = x - POLL4G;                           // Start new one
      else
         rf4gpolling--;
      }
   else                                                      // Not multi poll so clear flag
      {
      rf4gpolling = 0;
      }         
   x = UC device;                          // Make device number unit number
   comm2txbuffer[0] = x + 1;               // 4G ID is 1 higher than device number
   comm2txbuffer[1] = 192 + rf4gpolling;   // 4G M -> S & bit 6 always set then add poll type
   temp = GetModbusRegister(COMMSTATEGLOBAL); // Get commfail state
   y = GetModbusRegister(COMMFAILOVERRIDE);   // override enable....
   if ((temp == 2) || (y == 1))
      comm2txbuffer[1] = comm2txbuffer[1] | 0x20;
   Load8Relays(x + 1);                     // 4G ID is 1 higher than device number
   AddModbusTxCRCComm2(UC 15);
   comm2txbuffersize = 16;
}
*/

void BuildMasterPacket(void)            // Insert data and generate c/s. 4G with V5.1
{
unsigned char temp, x;
unsigned char tempchar;
unsigned char y;
union wordy crc;
unsigned int tempint;

    for (y = 0; y < UC 35; y++)         // Emergency escape method if bad config. data 
        { 
        target++;
        if (target > UC 31)             // Wrap at 31
            target = 1;
        temp = srccon[target];
        if ((temp & 0x01) == UC 0x01)
            y = 50;
        }
    if (y == UC 35)
        target = 0;                                      // Nothing configured
    for (x = UC 2; x < UC 16; x++)
      txpacket[x] = 0;                                   // Clear buffer.....  
    txpacket[0] = target;
    txpacket[1] = 192;                                   // 4G M -> S & bit 6 always set. Poll type basic only
    if ((oddbits.NETWORKSTATE == UC 1) || (commfailoverride.big == UI CFOKEY)) // Restored V5.6
        txpacket[1] = txpacket[1] | 0x20;
    txpacket[2] = GetRelayData(target);         
    stuff();

   AddModbusTxCRCComm2(UC 15);
}


void AddModbusTxCRCComm2(unsigned char packetsize)
{
unsigned char tempchar;
unsigned char temp;
unsigned char y;
union wordy crc;
unsigned int tempint;
    crc.big = 0xFFFF;
    for (temp = UC 0; temp < packetsize; temp++)
        {
        tempchar = txpacket[temp];
        tempint = tempchar;
        crc.big = crc.big ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc.big;
            crc.big = crc.big / UI 2;
            if ((tempint & UI 1) == UI 1)
                crc.big = crc.big ^ 0xA001;
            }
         }
    txpacket[temp] = crc.byte[lo];
    temp++;
    txpacket[temp] = crc.byte[hi];
}


void stuff(void)
{
unsigned int inty;
unsigned char box;
unsigned char chan;
unsigned char x;
unsigned char tempbyte;

    for (x = 0; x < UC 8; x++)      // For the eight analog outputs...
    {
    chan = srcana[target][x];
    box = chan;
    chan = chan & 0x07;             // LS bits are channel...
    box = box / UC 8;               // Pull out top 5 bits for box ID
    if ((srccon[target] & 0x02) == UC 0x02) // Easy if in total control mode....
        {
        txpacket[3 + x] = totcontrolanalog[target][x].byte[lo];
        tempbyte = totcontrolanalog[target][x].byte[hi];
        }
    else                            // Normal routing....
        {
        txpacket[3 + x] = resanalog[box][chan].byte[lo];
        tempbyte = resanalog[box][chan].byte[hi];
        }
    switch(x)
        {
        case 0:
            txpacket[11] = tempbyte;
            break;
        case 1:
            txpacket[11] = txpacket[11] | (tempbyte * 16);
            break;
        case 2:
            txpacket[12] = tempbyte;
            break;
        case 3:
            txpacket[12] = txpacket[12] | (tempbyte * 16);
            break;
        case 4:
            txpacket[13] = tempbyte;     
            break;
        case 5:
            txpacket[13] = txpacket[13] | (tempbyte * 16);
            break;
        case 6:
            txpacket[14] = tempbyte;
            break;
        case 7:
            txpacket[14] = txpacket[14] | (tempbyte * 16);
            break;
        default:
            break;
        }
    }
}


void BuildSlavePacket4G(void)
{
unsigned char mode;                                   // The master packet can request 16 different modes.
unsigned char i;
union wordy anatemp;                                    
unsigned short x;
unsigned short anoffset;         
   for (x = 0; x < UC 17; x++)                          // pre fill for functions with unused data in the reply
      txpacket[x] = 0x00;
   mode = rxpacket[1] & 0x0F;                           // Only write to relays if mode is 0
   if (mode == UC 0x00)                                 // Ignore modes 1-3 as 4/16 units dont have the hardware 
      {
      for (x = 0; x < UC 17; x++)                        // pre fill for functions with unused data in the reply
         txpacket[x] = 0x00;
      txpacket[0] = rxpacket[0];                         // Build RFScada 4G reply to mode 0 packet. Echo ID   
      txpacket[1] = rxpacket[1] & 0x0F;                  // Echo command
      txpacket[1] = txpacket[1] | 0x60;                  // Add status bits - clear M->S bit. 5.2 cleared bit 4   
      i = rxpacket[0];                                   // Will need box ID
      txpacket[2] = res4gbits;
      txpacket[3] = 0x00;                                // No more digs
      txpacket[4] = 0x00;
      anatemp.big = res4ganas[0].big;                    // An1
      txpacket[5] = anatemp.byte[lo];
      txpacket[13] = anatemp.byte[hi];
      anatemp.big = res4ganas[1].big;                    // An2
      txpacket[6] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[13] = txpacket[13] | anatemp.byte[hi];
      anatemp.big = res4ganas[2].big;                    // An3   
      txpacket[7] = anatemp.byte[lo];
      txpacket[14] = anatemp.byte[hi];
      anatemp.big = res4ganas[3].big;                    // An4
      txpacket[8] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[14] = txpacket[14] | anatemp.byte[hi];
      anatemp.big = res4ganas[4].big;                    // An5
      txpacket[9] = anatemp.byte[lo];
      txpacket[15] = anatemp.byte[hi];
      anatemp.big = res4ganas[5].big;                    // An6
      txpacket[10] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[15] = txpacket[15] | anatemp.byte[hi];
      anatemp.big = res4ganas[6].big;                    // An7
      txpacket[11] = anatemp.byte[lo];
      txpacket[16] = anatemp.byte[hi];
      anatemp.big = res4ganas[7].big;                    // An8
      txpacket[12] = anatemp.byte[lo];
      anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
      anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
      txpacket[16] = txpacket[16] | anatemp.byte[hi];   
   }
   if (mode == UC 1) ;                                   // Dont support these modes yet
   if (mode == UC 2) ;
   if (mode == UC 3) ;
   CalcTxCRC(19);
}



void BuildSlavePacket(void)
{
unsigned char temp;
union wordy anatemp;                                    
   
    txpacket[0] = VERSION;
    txpacket[1] = rxpacket[1];
    txpacket[2] = configid + 0x20;                          // Response is our ID + 32                 
    txpacket[3] = res4gbits;                                // digbits[configid];
    anatemp.big = res4ganas[0].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[4] = anatemp.byte[lo];                         // An1
    anatemp.big = res4ganas[1].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[5] = anatemp.byte[lo];                         // An2
    anatemp.big = res4ganas[2].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[6] = anatemp.byte[lo];                         // An3
    anatemp.big = res4ganas[3].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[7] = anatemp.byte[lo];                         // An4
    anatemp.big = res4ganas[4].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[8] = anatemp.byte[lo];                         // An5
    anatemp.big = res4ganas[5].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[9] = anatemp.byte[lo];                         // An6
    anatemp.big = res4ganas[6].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[10] = anatemp.byte[lo];                        // An7
    anatemp.big = res4ganas[7].big;
    anatemp.big = anatemp.big / 4;                          // 12->10 bit   
    txpacket[11] = anatemp.byte[lo];                        // An8
    txpacket[12] = dcvoltage.byte[lo];
    temp = res4ganas[0].byte[hi] / 4;                       // Pack 2 bits ana1
    txpacket[13] = temp;           
    txpacket[13] = txpacket[13] * 4;                       // Slide up                           
    temp = res4ganas[1].byte[hi] / 4;                       // Pack 2 bits ana2
    txpacket[13] = txpacket[13] | temp;                                    
    txpacket[13] = txpacket[13] * 4;                       // Slide up                           
    temp = res4ganas[2].byte[hi] / 4;                       // Pack 2 bits ana3
    txpacket[13] = txpacket[13] | temp;                                    
    txpacket[13] = txpacket[13] * 4;                       // Slide up                           
    temp = res4ganas[3].byte[hi] / 4;                       // Pack 2 bits ana4
    txpacket[13] = txpacket[13] | temp;
                                    
    temp = res4ganas[4].byte[hi] / 4;                       // Pack 2 bits ana5
    txpacket[14] = temp;           
    txpacket[14] = txpacket[14] * 4;                       // Slide up                           
    temp = res4ganas[5].byte[hi] / 4;                       // Pack 2 bits ana6
    txpacket[14] = txpacket[14] | temp;                                    
    txpacket[14] = txpacket[14] * 4;                       // Slide up                           
    temp = res4ganas[6].byte[hi] / 4;                       // Pack 2 bits ana7
    txpacket[14] = txpacket[14] | temp;                                    
    txpacket[14] = txpacket[14] * 4;                       // Slide up                           
    temp = res4ganas[7].byte[hi] / 4;                       // Pack 2 bits ana8
    txpacket[14] = txpacket[14] | temp;                                    
  
    txpacket[15] = dcvoltage.byte[hi] & 0x03;
    txpacket[15] = txpacket[15] | 0x04; // Turn on AC OK bit for compat with 2 ch units
    CalcTxCRC(18);
}


void BuildSlavePacketMessedUp(void)
{
unsigned char temp;
union wordy anatemp;                                    
/*
unsigned char tempchar;
unsigned char y;
union wordy crc;
unsigned int tempint;
*/

    txpacket[0] = VERSION;
    txpacket[1] = rxpacket[1];
    txpacket[2] = configid + 0x20;      // Response is our ID + 32                 
    txpacket[3] = res4gbits;                           // digbits[configid];
    anatemp.big = res4ganas[0].big;                    // An1
    txpacket[4] = anatemp.byte[lo];
    txpacket[13] = anatemp.byte[hi];
    txpacket[13] = txpacket[13] * UC 64;              // Get MSB bits of analogs 1 - 4    
    txpacket[5] = resanalog[UI configid][1].byte[lo]; //analog[1].byte[lo];
    anatemp.big = res4ganas[1].big;                    // An2
    txpacket[6] = anatemp.byte[lo];
    anatemp.byte[hi] = anatemp.byte[hi] * 16;          // Put MS Bits into top half
    anatemp.byte[hi] = anatemp.byte[hi] & 0xF0;
    txpacket[13] = txpacket[13] | anatemp.byte[hi];
  // txpacket[6] = resanalog[UI configid][2].byte[lo]; //analog[2].byte[lo];


    txpacket[7] = resanalog[UI configid][3].byte[lo]; //analog[3].byte[lo];
    txpacket[8] = resanalog[UI configid][4].byte[lo]; //analog[4].byte[lo];
    txpacket[9] = resanalog[UI configid][5].byte[lo]; //analog[5].byte[lo];
    txpacket[10] = resanalog[UI configid][6].byte[lo]; //analog[6].byte[lo];
    txpacket[11] = resanalog[UI configid][7].byte[lo]; //analog[7].byte[lo];
    txpacket[12] = resanalog[UI configid][8].byte[lo]; //dcvoltage.byte[lo];
/*
    temp = resanalog[UI configid][1].byte[hi] * UC 16; //analog[1].byte[hi] * UC 16;
    temp = temp & 0x30;
    txpacket [13] = txpacket[13] | temp;
    temp = resanalog[UI configid][2].byte[hi] * UC 4; //analog[2].byte[hi] * UC 4;
    temp = temp & 0x0C;
    txpacket [13] = txpacket[13] | temp;
    temp = resanalog[UI configid][3].byte[hi] & 0x03; //analog[3].byte[hi] & 0x03;
    txpacket [13] = txpacket[13] | temp;
    txpacket[14] = resanalog[UI configid][4].byte[hi]; //analog[4].byte[hi];
    txpacket[14] = txpacket[14] * UC 64;// Get MSB bits of analogs 5-8   
    temp = resanalog[UI configid][5].byte[hi] * UC 16; //analog[5].byte[hi] * UC 16;
    temp = temp & 0x30;
    txpacket [14] = txpacket[14] | temp;
    temp = resanalog[UI configid][6].byte[hi] * UC 4; //analog[6].byte[hi] * UC 4;
    temp = temp & 0x0C;
    txpacket [14] = txpacket[14] | temp;
    temp = resanalog[UI configid][7].byte[hi] & 0x03; //analog[7].byte[hi] & 0x03;
    txpacket [14] = txpacket[14] | temp;
    txpacket[15] = resanalog[UI configid][8].byte[hi] & 0x03; //dcvoltage.byte[hi] & 0x03;
    txpacket[15] = txpacket[15] | 0x04; // Turn on AC OK bit for compat with 2 ch units
*/
    CalcTxCRC(18);
}


void CalcTxCRC(unsigned char ps)
{
unsigned char temp;
unsigned char tempchar;
unsigned char y;
union wordy crc;
unsigned int tempint;
    if (ps < UC 3)
       return;  
    crc.big = 0xFFFF;
    for (temp = UC 0; temp < UC ps - 2; temp++)
        {
        tempchar = txpacket[temp];
        tempint = tempchar;
        crc.big = crc.big ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc.big;
            crc.big = crc.big / UI 2;
            if (tempint & 1 == 1)
                crc.big = crc.big ^ 0xA001;
            }
         }
    txpacket[ps - 2] = crc.byte[lo];
    txpacket[ps - 1] = crc.byte[hi];  
}


void UpdateTimers(void)
{
static unsigned char tensecs;
static unsigned char oldmillisec;
static unsigned int old1000millisec;
unsigned int x;
unsigned char c;
    if (oldmillisec == millisec)
        return;
    oldmillisec = millisec;
    for (x = UI 0; x < UI LASTTIMER; x++)// First millisec timers...
        {
        if (timer[x] != UI 0x0000)
            {
            timer[x]--;
            if (timer[x] == UI 0x0000)
                TimerExpired(UC x);
            }    
        }
    old1000millisec++;
    if (old1000millisec > UI 999)       // Now second timers..
        {
        old1000millisec = 0;
        for (c = UC 0; c < UC 32; c++)
            {
//            if (nocommtimers[c] != UC 0x00)    3.2 now every 10 secs
//                nocommtimers[c]--;
            if (overridetimers[c] != UC 0x00)
                {
                overridetimers[c]--;
                if (overridetimers[c] == UC 0x00)
                    OverrideExpired(c);
                }
            }
        if (saveanastime.big != UI 0x00)
            {
            saveanastime.big--;
            if (saveanastime.big == UI 0x00)
                oddbits2.SAVEANANOW = 1;
            else
                oddbits2.SAVEANANOW = 0;
            }
        if (savetripstime.big != UI 0x00)
            {
            savetripstime.big--;
            if (savetripstime.big == UI 0x00)
               EEWriteConfig();
            }
        if (powerupbaudsecs != UC 0x00)
            {
            powerupbaudsecs--;
            if (powerupbaudsecs == UC 0x00)  // Just expired?
                {
                if (powerupbaudcomms == UC 0x00) // If nothing came @ default 9600 baud then switch...
                    {
                    InitUsart1(modbusbaudrate);
                    EnableUsart1();              
                    powerupbaudcomms = 123;
                    }
                }
            }  
        if (mbscanDOTimers[0] != UI 0x00) 
            mbscanDOTimers[0]--;
        else
            mbscanResult[0] = mbscanDefault[0];
        if (mbscanDOTimers[1] != UI 0x00)
            mbscanDOTimers[1]--;
        else
            mbscanResult[1] = mbscanDefault[1];
        if (mbscanDOTimers[2] != UI 0x00)
            mbscanDOTimers[2]--;
        else
            mbscanResult[2] = mbscanDefault[2];
        if (mbscanDOTimers[3] != UI 0x00)
            mbscanDOTimers[3]--;
        else
            mbscanResult[3] = mbscanDefault[3];
        if (mbscanpolltimer != UC 0x00) mbscanpolltimer--;
        poweronsecs++;
        if (pollsuspend != UC 0x00) pollsuspend--;
        tensecs++;
        if (tensecs > UC 9)
            {
            tensecs = 0;
            if (nocommtime.big != UI 0x00)
                nocommtime.big--;
            for (c = UC 0; c < UC 32; c++)
               {
               if (nocommtimers[c].big != UI 0x0000)
                   nocommtimers[c].big--;
               }
          
            }    
        }
}

void OverrideExpired(unsigned char unit)
{
unsigned char temp;
    totcontrolrelays[unit] = 0x00;      // Clear total control outputs as override has expired
    for (temp = 0; temp < UC 9; temp++)
         totcontrolanalog[unit][temp].big = 0x0000; 

    if (unit == configid)               // Exit if it was our unit being overwritten - we will generate new values
        return;
    if ((unit == UC 31)                 // Exit if we are in the special hold and store mode
     && (specialmode == UC SPMODEANASTORE))
        return;
    temp = srccon[unit];
    if ((temp & 0x01) != UC 0x01)       // If it is not enabled then clear readings. If enabled new live values will replace old mb ones
        { 
        resdigbits[unit] = 0x00;
        for (temp = 0; temp < UC 9; temp++)
            resanalog[unit][temp].big = 0x0000; 
        }
}       


void TimerExpired(unsigned char tim)
{
    switch (tim)
    {
    case REDONTIMER:
     //   PORTBbits.RB0 = 1;
//        timer[REDOFFTIMER] = 1000;
        break;

    case REDOFFTIMER:
       // PORTBbits.RB0 = 0;
        timer[REDONTIMER] = 10;
        break;

    case YELONTIMER:
        PORTBbits.RB2 = 1;
//        timer[YELOFFTIMER] = 1000;
        break;

    case YELOFFTIMER:
        PORTBbits.RB2 = 0;
        timer[YELONTIMER] = 50;
        break;

    case GREENONTIMER:
       // PORTBbits.RB1 = 1;
        timer[GREENOFFTIMER] = 250;
        break;

    case GREENOFFTIMER:
       // PORTBbits.RB1 = 0;
        timer[GREENONTIMER] = 30;
        break;
    case MODBUSTIMEOUT:
        oddbits.NEWRS232 = 1;
        if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
            PORTBbits.RB3 = 1;	// red led off for modbus port - turn on when data received 
        break;

    case RFRXTIMEOUT:
         oddbits.NEWRF = 1;             // Flag new data...
        break;
    
    case RFSLAVETXTIMEOUT:              // Now time to start replying to master pkt 
        {
        txpointer = UC 0;
        PIE3bits.TX2IE = 1; 	          // MPH enable USART2 transmit interrupt
        break;
        }

    case TX2485TIMER:                   // Backup timer for 485 driver () 
        {
        if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
            PORTAbits.RA5 = 0; // Disable RS485 TX (radio network)
        PORTBbits.RB1 = 1;				// Green led off;
        break;
        }

    case TX1485TIMER:                   // Backup timer for 485 driver (pc network) 
        {
        PORTCbits.RC0 = 0;              // Disable RS485 TX
        if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
            PORTFbits.RF0 = 1; // Green led off;
        break;
        }
    }
}


void EnableInterrupts(void)
{
    RCONbits.IPEN = 1;                  // enable priority irq's (default is compatibility mode)
    INTCONbits.GIE = 1;                 // Global int. enable high priority
    INTCONbits.PEIE = 1;                // Global Peripheral int. disable low priority
    INTCON2bits.TMR0IP = 1;             // high priority
    IPR1bits.RCIP = 1;                  // high priority
    IPR3bits.RC2IP = 1;                 // high priority
//    PIE3bits.RC2IE = 1;
    oddbits.INTSENABLED = 1;            // Set our global flag
} 

void DisableInterrupts(void)
{
    INTCONbits.GIE = 0;                 // Global int. disable
    INTCONbits.PEIE = 0;                // Disable peripheral ints.
    oddbits.INTSENABLED = 0;
}

void InitTimer0(void)
{
    T0CON = 0x88;			            // timer on and  no prescaler
    TMR0H = 0xEC;
   	TMR0L = 0x87;			            // Should be 1mS@20MHz less int. overhead
    INTCONbits.TMR0IF = 0;	            // Clear int pending reg. just in case its set
}
 
void EnableTimer0(void)
{   
    INTCONbits.TMR0IE = 1;		// Enable timer 0 overflow interrupt
} 
 
void DisableTimer0(void)
{   
    INTCONbits.TMR0IE = 0;  	// Disable timer 0 overflow interrupt
}

void ClearWDT(void)
{
    _asm
    CLRWDT
    _endasm
}

#pragma code HiPriVector=0x208          // Interrupt vector off by 0x200 for boot block area	
//#pragma code HiPriVector=0x08      // Normal Interrupt vector	
void atHighPriVector(void)
{
_asm
 GOTO HighPriInterrupts
_endasm
}
#pragma code

//#pragma interrupt HighPriInterrupts  

//ORIG #pragma interrupt HighPriInterrupts  save=section(".tmpdata"),section("MATH_DATA"),PROD // 
#pragma interrupt HighPriInterrupts 

void HighPriInterrupts() // All high priority interrupts here........
{
static unsigned char temp;
    if (INTCONbits.TMR0IF == UC 1)      // Timer0 interrupt?            
	    {                               // 65535 - 5000 = 60535  0xEC77 but 0xEC87 to allow for overhead
	    TMR0H = 0xEC;
     	TMR0L = 0x87;                   
        INTCONbits.TMR0IF = 0;          // Clear int. flag
        millisec++;                     // Inc. mS count 
        }
    
	if (PIE1bits.RC1IE)                  // RCIE Only if int is enabled......
        {
        if (PIR1bits.RC1IF == UC 1)	//RCIF
            {
            if (RCSTA1bits.OERR) 
                {                       // overrun error
                RCSTA1bits.CREN = 0;	// clear error
                RCSTA1bits.CREN = 1;	// restart receiver
                temp = RCREG1;          // Flush buff
                }
            else
                {                       // Must be good if we get here......
                rs232inbuffer[rs232inpointer] = RCREG1;// read data and place in buffer
                rs232inpointer++;           
                if (rs232inbuffer[0] == UC RFSCADAID)
                    timer[MODBUSTIMEOUT] = UI 100;// Override ms trash timer if its our special ID
	            else
                    timer[MODBUSTIMEOUT] = UI modbussilenttime; // mS until Rx packet gets trashed
                }
                if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
                    PORTBbits.RB3 = 0;	// red led on for modbus port - turned aff when Modbustimeout expires
            }
        }

    if (PIE3bits.RC2IE)                 // Only if int is enabled......
        {
        if (PIR3bits.RC2IF == UC 1)
            {
            if (RCSTA2bits.OERR) 
                {                       // overrun error
                RCSTA2bits.CREN = 0;    // clear error
                RCSTA2bits.CREN = 1;    // restart receiver
                temp = RCREG2;          // Flush buf
                }
            else
                {                       // Must be good if we get here......
                rxpacket[rxpointer] = RCREG2;// read data and place in buffer
                if (rxpointer < UC 19)  // 5.0 Prevent buffer overruns......
                    rxpointer++;

                if (rs232gaptime.big < chartime35[baudrate]) 
                    rs232gaptime.big = UI chartime35[baudrate]; // force to 3.5 char times before processing.
                timer[RFRXTIMEOUT] = UI rs232gaptime.big;// (was hardcoded at 3) mS until Rx packet gets trashed
                RedOn();
                }
            } 
        }

	// MPH - USART2 transmit interrupt
	if (PIE3bits.TX2IE) //RF port
      {
	   if (PIR3bits.TX2IF)
            {
		   	if (txpointer < UC txpacketsize)    // Packet size varies depending on protocol 
                {
		   	    if (txpointer == UC 0)
		            {
                  if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
                     PORTAbits.RA5 = 1;	        
                  PORTBbits.RB1 = 0;				// Green led on;
                  }
		        TXREG2 = txpacket[txpointer];
		        txpointer++;
              timer[TX2485TIMER] = 15;// Backup timer in case we miss transmit interrupt for some reason         
  		        }
            else
                {
		        while (TXSTA2bits.TRMT == UC 0)
                    {}	                        // wait to make sure transmitter is empty 
		        PIE3bits.TX2IE = 0;               // disable TX2 interrupt
                if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
                    PORTAbits.RA5 = 0;// disable RS485 TX
		        PORTBbits.RB1 = 1;      // Green led OFF
		        }
		    }
        }

	// MPH - USART1 transmit interrupt
	if (PIE1bits.TX1IE) // modbus port
        {
	    if (PIR1bits.TX1IF)
            {
            if (rs232outpointer <= rs232outbuffersize)
                {
		   	    if (rs232outpointer == UC 0)
		            {
		   	      PORTCbits.RC0 = 1;  // enable RS485 TX
                  if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
                     PORTFbits.RF0 = 0;				// Green led on;
                  }
                TXREG1 = rs232outbuffer[rs232outpointer];
                rs232outpointer++;
                timer[TX1485TIMER] = 15;// Backup timer in case we miss transmit interrupt for some reason         
		        }
            else
                {
		          while (TXSTA1bits.TRMT == UC 0) {}	// wait to make sure transmitter is empty 
		          PIE1bits.TX1IE = 0; 			      // disable TX2 interrupt
                PORTCbits.RC0 = 0;				      // disable RS485 TX
                if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
                    PORTFbits.RF0 = 1;				   // Green led off;
		        }
		    }
        }
}


void EEWriteCRC(void)
{
unsigned int crc;
unsigned int tempint;
unsigned int bigx;
unsigned char tempchar;
unsigned char y;
    crc = 0xFFFF;
    for (bigx = UI 0; bigx < UI EESIZE; bigx++)
        {
        tempchar = EERead(bigx);
        tempint = tempchar;
        crc = crc ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc;
            crc = crc >> 1;
            if (tempint & 1 == 1)
                crc = crc ^ 0xA001;
            }
         }
    crclow = crc;
    crc = crc >> 8;
    crchigh = crc;
    EEWrite(EESIZE, crclow);
    EEWrite(EESIZE + 1, crchigh);
    oddbits2.WRITENEWEECRC = 0;
}

void EEWriteConfig(void)                // Writes all config memory to EE - takes 2.5 secs
{
unsigned char id;                   
unsigned char x;
unsigned int crc;
unsigned int tempint;
unsigned int bigx;
unsigned char tempchar;
unsigned char y;
    for (id = 0; id < UC 32; id++)
        {
        if ((id & 0x01) == UC 0x01)
            {
            YellowOn();
            ClearWDT();
            }
        else
            YellowOff();
        for (x = 0; x < UC 8; x++)
            {
            EEWrite(((UI 8 * id) + UI x), srcdig[id][x]);
            EEWrite(((UI 8 * id) + UI x + UI 256), srcana[id][x]);
            }    	
        EEWrite((id + UI 512), srccon[id]);
//        EEWrite((id + UI 544), srctimeout[id]); not used
        }
    EEWrite(544, usersnocommlimit.byte[lo]);
    EEWrite(545, usersnocommlimit.byte[hi]);
    EEWrite(576, configid);
    EEWrite(577, modbusid);
    EEWrite(579, usersmodbusoverride);
    EEWrite(580, modbussilenttime);
    ClearWDT();
    EEWrite(581, specialmode);
    EEWrite(582, lowtanklevel.byte[lo]);
    EEWrite(583, lowtanklevel.byte[hi]);
    EEWrite(584, hightanklevel.byte[lo]);
    EEWrite(585, hightanklevel.byte[hi]);
    ClearWDT();
    EEWrite(586, hoppattern);
    EEWrite(587, serialnumber.byte[lo]);
    EEWrite(588, serialnumber.byte[hi]);
    EEWrite(589, ismmultipackets);  
 // 590 = stored ana31[0]lo
 // 591 = stored ana31[0]hi
 // ...
 // 604 = stored ana31[7]lo
 // 605 = stored ana31[7]hi
    EEWrite(606, storeanadelay.byte[lo]);
    EEWrite(607, storeanadelay.byte[hi]);
    EEWrite(608, runhours.byte[lo]);
    EEWrite(609, runhours.byte[hi]);

    EEWrite(610, baudrate);
    EEWrite(611, radiotype);
    EEWrite(612, keyuptime.byte[lo]);
    EEWrite(613, keyuptime.byte[hi]);
    ClearWDT();
    EEWrite(614, keydowntime.byte[lo]);
    EEWrite(615, keydowntime.byte[hi]);
    EEWrite(616, rs232gaptime.byte[lo]);
    EEWrite(617, rs232gaptime.byte[hi]);
    EEWrite(618, transmitrate.byte[lo]);
    EEWrite(619, transmitrate.byte[hi]);
    EEWrite(620, commfailoverride.byte[lo]);
    EEWrite(621, commfailoverride.byte[hi]);
    EEWrite(622, ismrfbaudrate);

    for (x = 0; x < UC 31; x++)
        EEWrite(623 + (UI x),repeater_target[x]);	//MPH - repeater code
    if (txdelay.big < UI 20)                // Limit delay
        txdelay.big = 20;

    EEWrite(654, txdelay.byte[lo]);			//MPH_040306
    EEWrite(655, txdelay.byte[hi]);			//MPH_040306
    EEWrite(656, modbusbaudrate);			// 3.9
    EEWrite(657, pulseenable);              // 4.0
    EEWrite(658, spareMBReg1.byte[lo]);     // 4.0
    EEWrite(659, spareMBReg1.byte[hi]);     // 4.0
    EEWrite(660, spareMBReg2.byte[lo]);     // 4.0
    EEWrite(661, spareMBReg2.byte[hi]);     // 4.0
    EEWrite(662, spareMBReg3.byte[lo]);     // 4.0
    EEWrite(663, spareMBReg3.byte[hi]);     // 4.0
    EEWrite(664, tron[0].byte[lo]);          // 4.1
    EEWrite(665, tron[0].byte[hi]);          // 4.1
    EEWrite(666, tron[1].byte[lo]);          // 4.1
    EEWrite(667, tron[1].byte[hi]);          // 4.1
    EEWrite(668, tron[2].byte[lo]);          // 4.1
    EEWrite(669, tron[2].byte[hi]);          // 4.1
    EEWrite(670, tron[3].byte[lo]);          // 4.1
    EEWrite(671, tron[3].byte[hi]);          // 4.1
    EEWrite(672, tron[4].byte[lo]);          // 4.1
    EEWrite(673, tron[4].byte[hi]);          // 4.1
    EEWrite(674, tron[5].byte[lo]);          // 4.1
    EEWrite(675, tron[5].byte[hi]);          // 4.1
    EEWrite(676, tron[6].byte[lo]);          // 4.1
    EEWrite(677, tron[6].byte[hi]);          // 4.1
    EEWrite(678, tron[7].byte[lo]);          // 4.1
    EEWrite(679, tron[7].byte[hi]);          // 4.1
    EEWrite(680, troff[0].byte[lo]);         // 4.1
    EEWrite(681, troff[0].byte[hi]);         // 4.1
    EEWrite(682, troff[1].byte[lo]);         // 4.1
    EEWrite(683, troff[1].byte[hi]);         // 4.1
    EEWrite(684, troff[2].byte[lo]);         // 4.1
    EEWrite(685, troff[2].byte[hi]);         // 4.1
    EEWrite(686, troff[3].byte[lo]);         // 4.1
    EEWrite(687, troff[3].byte[hi]);         // 4.1
    EEWrite(688, troff[4].byte[lo]);         // 4.1
    EEWrite(689, troff[4].byte[hi]);         // 4.1
    EEWrite(690, troff[5].byte[lo]);         // 4.1
    EEWrite(691, troff[5].byte[hi]);         // 4.1
    EEWrite(692, troff[6].byte[lo]);         // 4.1
    EEWrite(693, troff[6].byte[hi]);         // 4.1
    EEWrite(694, troff[7].byte[lo]);         // 4.1
    EEWrite(695, troff[7].byte[hi]);         // 4.1
    EEWrite(696, fillbits);                  // 4.1
    EEWrite(697, oddbits2.TRIPSENABLED);     // 4.1
    EEWrite(698, mbscanID[0]);               // 4.2
    EEWrite(699, mbscanID[1]);               // 4.2
    EEWrite(700, mbscanID[2]);               // 4.2
    EEWrite(701, mbscanID[3]);               // 4.2
    EEWrite(702, mbscanBaud[0]);             // 4.2
    EEWrite(703, mbscanBaud[1]);             // 4.2
    EEWrite(704, mbscanBaud[2]);             // 4.2
    EEWrite(705, mbscanBaud[3]);             // 4.2
    EEWrite(706, mbscanFunc[0]);             // 4.2
    EEWrite(707, mbscanFunc[1]);             // 4.2
    EEWrite(708, mbscanFunc[2]);             // 4.2
    EEWrite(709, mbscanFunc[3]);             // 4.2
    EEWrite(710, mbscanDOTime[0]);           // 4.2
    EEWrite(711, mbscanDOTime[1]);           // 4.2
    EEWrite(712, mbscanDOTime[2]);           // 4.2
    EEWrite(713, mbscanDOTime[3]);           // 4.2
    EEWrite(714, mbscanReg[0].byte[lo]);     // 4.2
    EEWrite(715, mbscanReg[0].byte[hi]);     // 4.2
    EEWrite(716, mbscanReg[1].byte[lo]);     // 4.2
    EEWrite(717, mbscanReg[1].byte[hi]);     // 4.2
    EEWrite(718, mbscanReg[2].byte[lo]);     // 4.2
    EEWrite(719, mbscanReg[2].byte[hi]);     // 4.2
    EEWrite(720, mbscanReg[3].byte[lo]);     // 4.2
    EEWrite(721, mbscanReg[3].byte[hi]);     // 4.2
    EEWrite(722, mbscanDefault[0].byte[lo]); // 4.2
    EEWrite(723, mbscanDefault[0].byte[hi]); // 4.2
    EEWrite(724, mbscanDefault[1].byte[lo]); // 4.2
    EEWrite(725, mbscanDefault[1].byte[hi]); // 4.2
    EEWrite(726, mbscanDefault[2].byte[lo]); // 4.2
    EEWrite(727, mbscanDefault[2].byte[hi]); // 4.2
    EEWrite(728, mbscanDefault[3].byte[lo]); // 4.2
    EEWrite(729, mbscanDefault[3].byte[hi]); // 4.2
    EEWrite(730, mbscanDiv[0].byte[lo]);     // 4.2
    EEWrite(731, mbscanDiv[0].byte[hi]);     // 4.2
    EEWrite(732, mbscanDiv[1].byte[lo]);     // 4.2
    EEWrite(733, mbscanDiv[1].byte[hi]);     // 4.2
    EEWrite(734, mbscanDiv[2].byte[lo]);     // 4.2
    EEWrite(735, mbscanDiv[2].byte[hi]);     // 4.2
    EEWrite(736, mbscanDiv[3].byte[lo]);     // 4.2
    EEWrite(737, mbscanDiv[3].byte[hi]);     // 4.2
    EEWrite(738, mbscanPollTime[0]);         // 4.2
    EEWrite(739, mbscanPollTime[1]);         // 4.2
    EEWrite(740, mbscanPollTime[2]);         // 4.2
    EEWrite(741, mbscanPollTime[3]);         // 4.2
    EEWrite(742, mbscanRate);                // 4.2
   // 743 = saved resdigbits[31]             // 4.2
    EEWrite(744, mbpulselevel.byte[lo]);     // 5.0
    EEWrite(745, mbpulselevel.byte[hi]);     // 5.0
    EEWriteCRC();
    YellowOff();
}

unsigned char EECheck(void)
{
unsigned int crc;
unsigned int tempint;
unsigned int bigx;
unsigned char tempchar;
unsigned char y;

   crc = 0xFFFF;
    for (bigx = UI 0; bigx < UI EESIZE; bigx++)
        {
        tempchar = EERead(bigx);
        tempint = tempchar;
        crc = crc ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc;
            crc = crc >> 1;
            if (tempint & 1 == 1)
                crc = crc ^ 0xA001;
            }
         }
    crclow = crc;
    crc = crc >> 8;
    crchigh = crc;
    if (EERead(EESIZE) != UC crclow)
        return(0xFF);
    if (EERead(EESIZE + 1) != UC crchigh)
        return(0xFE);
    return(0x00);
}


void EEReadConfig(void)                 // reads configuration data from EEProm to ram
{                                       // 1st 256 bytes digs, next 256 ans, 32 config, 32 timeout    
unsigned char id;                       // 3.2 546-575 and 578 empty........
unsigned char x;
    for (id = 0; id < UC 32; id++)
        {
        for (x = 0; x < UC 8; x++)
            {
            srcdig[id][x] = EERead((UI 8 * id) + UI x);
            srcana[id][x] = EERead((UI 8 * id) + UI x + UI 256);
            }
        srccon[id] = EERead(id + UI 512);
//        srctimeout[id] = EERead(id + UI 544); not used
        }
    configid = EERead(576);
    modbusid = EERead(577);

    usersnocommlimit.byte[lo] = EERead(544);
    usersnocommlimit.byte[hi] = EERead(545);

    if (usersnocommlimit.big == UI 0x00)
        usersnocommlimit.big = 3;       // Default 30 secs
    
    usersmodbusoverride = EERead(579);
    if (usersmodbusoverride == UC 0x00)      //@@@ enable 0 for sticky writes
        usersmodbusoverride = 10;

    modbussilenttime = EERead(580);
    if (modbussilenttime <= UC 0x03)
        modbussilenttime = 40;

    specialmode = EERead(581);
    lowtanklevel.byte[lo] = EERead(582);
    lowtanklevel.byte[hi] = EERead(583);
    hightanklevel.byte[lo] = EERead(584);
    hightanklevel.byte[hi] = EERead(585);
    hoppattern = EERead(586);
    serialnumber.byte[lo] = EERead(587);
    serialnumber.byte[hi] = EERead(588);
    ismmultipackets = EERead(589);
    if (specialmode == UC SPMODEANASTORE)
        {
        for (x = UC 0; x < UC 8; x++)
            { 
            resanalog[31][x].byte[lo] = EERead(590 + (2 * x));
            resanalog[31][x].byte[hi] = EERead(591 + (2 * x));
            }
        resdigbits[31] = EERead(743); 
        } 
 // 590 = stored ana31[0]lo
 // 591 = stored ana31[0]hi
 // ...
 // 604 = stored ana31[7]lo
 // 605 = stored ana31[7]hi
    storeanadelay.byte[lo] = EERead(606);
    storeanadelay.byte[hi] = EERead(607);
    runhours.byte[lo] = EERead(608);
    runhours.byte[hi] = EERead(609);
    baudrate = EERead(610);
    radiotype = EERead(611);
    keyuptime.byte[lo] = EERead(612);
    keyuptime.byte[hi] = EERead(613);
    keydowntime.byte[lo] = EERead(614);
    keydowntime.byte[hi] = EERead(615);
    rs232gaptime.byte[lo] = EERead(616);
    rs232gaptime.byte[hi] = EERead(617);
    transmitrate.byte[lo] = EERead(618);
    transmitrate.byte[hi] = EERead(619);
    commfailoverride.byte[lo] = EERead(620);
    commfailoverride.byte[hi] = EERead(621);
    ismrfbaudrate = EERead(622);

    for (x = 0; x < UC 31; x++)
        repeater_target[x] = EERead(623 + UI x);	//MPH - repeater code

    txdelay.byte[lo] = EERead(654);	//MPH_040306
    txdelay.byte[hi] = EERead(655);	//MPH_040306
    modbusbaudrate = EERead(656);   // 3.9
    pulseenable = EERead(657);      // 4.0
    spareMBReg1.byte[lo] = EERead(658);     // 4.0
    spareMBReg1.byte[hi] = EERead(659);     // 4.0
    spareMBReg2.byte[lo] = EERead(660);     // 4.0
    spareMBReg2.byte[hi] = EERead(661);     // 4.0
    spareMBReg3.byte[lo] = EERead(662);     // 4.0
    spareMBReg3.byte[hi] = EERead(663);     // 4.0
    tron[0].byte[lo] = EERead(664);          // 4.1
    tron[0].byte[hi] = EERead(665);          // 4.1
    tron[1].byte[lo] = EERead(666);          // 4.1
    tron[1].byte[hi] = EERead(667);          // 4.1
    tron[2].byte[lo] = EERead(668);          // 4.1
    tron[2].byte[hi] = EERead(669);          // 4.1
    tron[3].byte[lo] = EERead(670);          // 4.1
    tron[3].byte[hi] = EERead(671);          // 4.1
    tron[4].byte[lo] = EERead(672);          // 4.1

    tron[4].byte[hi] = EERead(673);          // 4.1
    tron[5].byte[lo] = EERead(674);          // 4.1
    tron[5].byte[hi] = EERead(675);          // 4.1
    tron[6].byte[lo] = EERead(676);          // 4.1
    tron[6].byte[hi] = EERead(677);          // 4.1
    tron[7].byte[lo] = EERead(678);          // 4.1
    tron[7].byte[hi] = EERead(679);          // 4.1
    troff[0].byte[lo] = EERead(680);         // 4.1
    troff[0].byte[hi] = EERead(681);         // 4.1
    troff[1].byte[lo] = EERead(682);         // 4.1
    troff[1].byte[hi] = EERead(683);         // 4.1
    troff[2].byte[lo] = EERead(684);         // 4.1
    troff[2].byte[hi] = EERead(685);         // 4.1
    troff[3].byte[lo] = EERead(686);         // 4.1
    troff[3].byte[hi] = EERead(687);         // 4.1
    troff[4].byte[lo] = EERead(688);         // 4.1
    troff[4].byte[hi] = EERead(689);         // 4.1
    troff[5].byte[lo] = EERead(690);         // 4.1
    troff[5].byte[hi] = EERead(691);         // 4.1
    troff[6].byte[lo] = EERead(692);         // 4.1
    troff[6].byte[hi] = EERead(693);         // 4.1
    troff[7].byte[lo] = EERead(694);         // 4.1
    troff[7].byte[hi] = EERead(695);         // 4.1
    fillbits = EERead(696);                  // 4.1
    oddbits2.TRIPSENABLED = EERead(697);     // 4.1
    mbscanID[0] = EERead(698);                  // 4.2
    mbscanID[1] = EERead(699);                  // 4.2
    mbscanID[2] = EERead(700);                  // 4.2
    mbscanID[3] = EERead(701);                  // 4.2
    mbscanBaud[0] = EERead(702);                // 4.2
    mbscanBaud[1] = EERead(703);                // 4.2
    mbscanBaud[2] = EERead(704);                // 4.2
    mbscanBaud[3] = EERead(705);                // 4.2
    mbscanFunc[0] = EERead(706);                // 4.2
    mbscanFunc[1] = EERead(707);                // 4.2
    mbscanFunc[2] = EERead(708);                // 4.2
    mbscanFunc[3] = EERead(709);                // 4.2
    mbscanDOTime[0] = EERead(710);              // 4.2
    mbscanDOTime[1] = EERead(711);              // 4.2
    mbscanDOTime[2] = EERead(712);              // 4.2
    mbscanDOTime[3] = EERead(713);              // 4.2
    mbscanReg[0].byte[lo] = EERead(714);        // 4.2
    mbscanReg[0].byte[hi] = EERead(715);        // 4.2
    mbscanReg[1].byte[lo] = EERead(716);        // 4.2
    mbscanReg[1].byte[hi] = EERead(717);        // 4.2
    mbscanReg[2].byte[lo] = EERead(718);        // 4.2
    mbscanReg[2].byte[hi] = EERead(719);        // 4.2
    mbscanReg[3].byte[lo] = EERead(720);        // 4.2
    mbscanReg[3].byte[hi] = EERead(721);        // 4.2
    mbscanDefault[0].byte[lo] = EERead(722);    // 4.2
    mbscanDefault[0].byte[hi] = EERead(723);    // 4.2
    mbscanDefault[1].byte[lo] = EERead(724);    // 4.2
    mbscanDefault[1].byte[hi] = EERead(725);    // 4.2
    mbscanDefault[2].byte[lo] = EERead(726);    // 4.2
    mbscanDefault[2].byte[hi] = EERead(727);    // 4.2
    mbscanDefault[3].byte[lo] = EERead(728);    // 4.2
    mbscanDefault[3].byte[hi] = EERead(729);    // 4.2
    mbscanDiv[0].byte[lo] = EERead(730);        // 4.2
    mbscanDiv[0].byte[hi] = EERead(731);        // 4.2
    mbscanDiv[1].byte[lo] = EERead(732);        // 4.2
    mbscanDiv[1].byte[hi] = EERead(733);        // 4.2
    mbscanDiv[2].byte[lo] = EERead(734);        // 4.2
    mbscanDiv[2].byte[hi] = EERead(735);        // 4.2
    mbscanDiv[3].byte[lo] = EERead(736);        // 4.2
    mbscanDiv[3].byte[hi] = EERead(737);        // 4.2
    mbscanPollTime[0] =  EERead(738);           // 4.2
    mbscanPollTime[1] =  EERead(739);           // 4.2
    mbscanPollTime[2] =  EERead(740);           // 4.2
    mbscanPollTime[3] =  EERead(741);           // 4.2
    mbscanRate = EERead(742);                   // 4.2
   // 743 = saved resdigbits[31]                // 4.2
    mbpulselevel.byte[lo] = EERead(744);        // 5.0
    mbpulselevel.byte[hi] = EERead(745);        // 5.0
}


void EEWrite(unsigned int address, unsigned char data)
{
unsigned char intstate; 
   if (EERead(address) == data)          // Dont bother if the same 
      return;
    EECON1 = 0;
    EEADRH = address / UI 256; 
    EEADR = (address & 0xff);
    EEDATA = data;
    EECON1bits.WREN = 1;

    if (oddbits.INTSENABLED == UC 1)    // Save state of ints so only re-enable if they were active
        {
        intstate = 0xFF;
        DisableInterrupts();
        }
    else
        intstate = 0x00;
    EECON2 = 0x55;	
    EECON2 = 0xAA;                      
    EECON1bits.WR = 1;
    if (intstate == 0xFF)
        EnableInterrupts();
    while (EECON1bits.WR == UC 1)
        ;
    EECON1bits.WREN = 0;
}
/*
void EEWriteOld(unsigned int address, unsigned char data)
{
unsigned char intstate; 
    EECON1 = 0;
    EEADRH = address / UI 256; 
    EEADR = (address & 0xff);
    EEDATA = data;
    EECON1bits.WREN = 1;

    if (oddbits.INTSENABLED == UC 1)    // Save state of ints so only re-enable if they were active
        {
        intstate = 0xFF;
        DisableInterrupts();
        }
    else
        intstate = 0x00;
    EECON2 = 0x55;	
    EECON2 = 0xAA;                      
    EECON1bits.WR = 1;
    if (intstate == 0xFF)
        EnableInterrupts();
    while (EECON1bits.WR == UC 1)
        ;
    EECON1bits.WREN = 0;
}
*/
unsigned char EERead(unsigned int address)
{
    EEADRH = address / UI 256;          // Get high add...
    EEADR = (address & 0xff);           // low add..
    EECON1 = 0;                         // reset control reg
    EECON1bits.RD = 1;                  // read it 
	return(EEDATA);
}

void InitAnalogOut(void)
{
    PORTCbits.RC1 = 0;                  // Select chip
    SPITransmit(0x80);                  // CTRL0 - all defaults
    SPITransmit(0x00);
    SPITransmit(0x81);                  // CTRL1 - all defaults, normal, slow
    SPITransmit(0x00);
    PORTCbits.RC1 = 1;
}


void InitAnalogOutVals(void)
{
    anaout1.big = 0x00;
    anaout2.big = 0x00; 
    anaout3.big = 0x00;
    anaout4.big = 0x00;
    anaout5.big = 0x00;
    anaout6.big = 0x00;
    anaout7.big = 0x00;
    anaout8.big = 0x00;
}


void WriteAnalogOut(unsigned char chan)
{
union wordy bignum;
    switch (chan)
    {
    case 1:
    bignum.big = anaout1.big;
    break;
    case 2:
    bignum.big = anaout2.big;
    bignum.big = bignum.big | 0x0400;
    break;
    case 3:
    bignum.big = anaout3.big;
    bignum.big = bignum.big | 0x0800;
    break;
    case 4:
    bignum.big = anaout4.big;
    bignum.big = bignum.big | 0x0C00;
    break;
    case 5:
    bignum.big = anaout5.big;
    bignum.big = bignum.big | 0x1000;
    break;
    case 6:
    bignum.big = anaout6.big;
    bignum.big = bignum.big | 0x1400;
    break;
    case 7:
    bignum.big = anaout7.big;
    bignum.big = bignum.big | 0x1800;
    break;
    case 8:
    bignum.big = anaout8.big;
    bignum.big = bignum.big | 0x1C00;
    break;
    default:
    break;
    }
    bignum.big = bignum.big * UI 4;
    PORTCbits.RC1 = 0;                  // Select chip
    SPITransmit(bignum.byte[hi]);
    SPITransmit(bignum.byte[lo]);
    PORTCbits.RC1 = 1;
}


void AnalogOutRF16(unsigned char chan)
{
unsigned char temp;
union wordy bignum;

    switch(chan)
        {
        case 1:
/* V5.5 Not needed anymore since now anaout is a 12 bit number....
            bignum.big = anaout1.big * UI 4;
            if (bignum.big > UI 3072)                   // So fs = 4095 instead of 4092 
                bignum.big = bignum.big + 3;
            else
            if (bignum.big > UI 2048)
                bignum.big = bignum.big + 2;
            else
            if (bignum.big > UI 1024)
                bignum.big = bignum.big + 1;
*/
            bignum.big = anaout1.big;
            PORTFbits.RF1 = 0;                           // Select chip
            temp = bignum.byte[hi] & UC 0x0F;
            SPITransmit (temp | UC 0x30);                // Analog out 1 goes through OUTA on DAC , 1x gain , unbuffered
            SPITransmit (bignum.byte[lo]);
            PORTFbits.RF1 = 1;
        break;
        case 2:
/* V5.5 Not needed anymore since now anaout is a 12 bit number....
            bignum.big = anaout2.big * UI 4;                // So fs = 4095 instead of 4092
            if (bignum.big > UI 3072)
                bignum.big = bignum.big + 3;
            else
            if (bignum.big > UI 2048)
                bignum.big = bignum.big + 2;
            else
            if (bignum.big > UI 1024)
                bignum.big = bignum.big + 1;
*/
            bignum.big = anaout2.big;
            PORTFbits.RF1 = 0;                           // Select chip
            temp = bignum.byte[hi] & UC 0x0F;
            SPITransmit (temp | UC 0xB0);                // Analog out 2 goes through OUTB on DAC , 1x gain , unbuffered
            SPITransmit (bignum.byte[lo]);
            PORTFbits.RF1 = 1;
            break;
 
       default:
           break;
       }
}


unsigned char SPITransmit(unsigned char d)
{
unsigned char result;
    SSPBUF = d;                         // send data
    while ((SSPSTAT & 0x01)== UC 0)
        ;                               // delay until spi data is out/in
    result = SSPBUF;                    // read data from buffer
	return(result);                     // return data
}


void RelaysOff()
{
unsigned char x;
    for (x = UC 1; x < UC 9; x++)
        RelayOff(x);
}    

void AllRelaysOff()
{
unsigned char x;
    for (x = UC 0; x < UC 9; x++)
        RelayOff(x);
}    

void RelayOn(unsigned char relnum)
{
    switch (relnum)
    {
    case 0:
    PORTGbits.RG0 = 1;
    relayimage.byte[hi] = relayimage.byte[hi] | 0x01;
    break;
    case 1:
    PORTDbits.RD1 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x01;
    break;
    case 2:
    PORTDbits.RD0 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x02;
    break;
    case 3:
    PORTDbits.RD3 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x04;
    break;
    case 4:
    PORTDbits.RD2 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x08;
    break;
    case 5:
    PORTDbits.RD5 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x10;
    break;
    case 6:
    PORTDbits.RD4 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x20;
    break;
    case 7:
    PORTDbits.RD7 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x40;
    break;
    case 8:
    PORTDbits.RD6 = 1;
    relayimage.byte[lo] = relayimage.byte[lo] | 0x80;
    break;
    }
}

void RelayOff(unsigned char relnum)
{
    switch (relnum)
    {
    case 0:
    PORTGbits.RG0 = 0;
    relayimage.byte[hi] = relayimage.byte[hi] & 0xFE;
   break;
    case 1:
    PORTDbits.RD1 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0xFE;
    break;
    case 2:
    PORTDbits.RD0 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0xFD;
    break;
    case 3:
    PORTDbits.RD3 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0xFB;
    break;
    case 4:
    PORTDbits.RD2 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0xF7;
    break;
    case 5:
    PORTDbits.RD5 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0xEF;
    break;
    case 6:
    PORTDbits.RD4 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0xDF;
    break;
    case 7:
    PORTDbits.RD7 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0xBF;
    break;
    case 8:
    PORTDbits.RD6 = 0;
    relayimage.byte[lo] = relayimage.byte[lo] & 0x7F;
    break;
    }
}



void ReadInputs(void)
{
unsigned int inty;
    if (unitschannels == UC 16)
        {
        inputport = ~PORTE;                        // physical portE is active low, inputport logical data is active hi
        }
    else if (unitschannels == UC 42)
        {
            inputport = ~PORTE; // physical portE is active low, inputport logical data is active hi
            if (res4ganas[0].big < UI mbpulselevel.big)              // Mimic dig 5-8 based on ana 1 - 4
        //    if (resanalog[inty][0].big < UI mbpulselevel.big)      // Mimic dig 5-8 based on ana 1 - 4
                inputport = inputport | 0x10;       // set dig.
            else
                inputport = inputport & 0xEF;       // clear dig.    
            if (res4ganas[1].big < UI mbpulselevel.big)     
                inputport = inputport | 0x20;       // set dig.
            else
                inputport = inputport & 0xDF;       // clear dig.    
            if (res4ganas[2].big < UI mbpulselevel.big)     
                inputport = inputport | 0x40;       // set dig.
            else
                inputport = inputport & 0xBF;       // clear dig.    
            if (res4ganas[3].big < UI mbpulselevel.big)     
                inputport = inputport | 0x80;       // set dig.
            else
                inputport = inputport & 0x7F;       // clear dig.    
        }
    else
        {
	    if (PORTE & 0x80)
	        inputport = inputport & 0xFE;
	    else
	        inputport = inputport | 0x01;
	    if (PORTE & 0x40)
	        inputport = inputport & 0xFD;
	    else
	        inputport = inputport | 0x02;
	    if (PORTE & 0x20)
	        inputport = inputport & 0xFB;
	    else
	        inputport = inputport | 0x04;
	    if (PORTE & 0x10)
	        inputport = inputport & 0xF7;
	    else
	        inputport = inputport | 0x08;
	    if (unitschannels == UC 8)
	        {
	        if (PORTE & 0x08)
	            inputport = inputport & 0xEF;
	        else
	            inputport = inputport | 0x10;
	        if (PORTE & 0x04)
	            inputport = inputport & 0xDF;
	        else
	            inputport = inputport | 0x20;
	        if (PORTE & 0x02)
	            inputport = inputport & 0xBF;
	        else
	            inputport = inputport | 0x40;
	        if (PORTE & 0x01)
	            inputport = inputport & 0x7F;
	        else
	            inputport = inputport | 0x80;
	        }
	    else
	        inputport = inputport & 0x0F;   // Must be RF4
        }
    res4gbits = inputport;                         // Will be used if we are a slave
    resdigbits[0] = inputport;                     // Will only be used if we are a master
}


void InitVars(void)
{
unsigned char x;
unsigned int i;
    inputport = 0x00;
    modbusid = 0x00;
    rxpointer = 0;
    txpointer = 0;
    specialmode = SPMODENONE;
    for (x = 0; x < UC 32; x++)
        {
        resdigbits[x] = 0;
        for (i = 0; i < UI 9; i++)
            resanalog[x][i].big = UI 0x0000;
        nocommtimers[x].big = 0;
        }  
    res4gbits = 0;
    for (x = 0 ; x < UC 11; x++)
      res4ganas[x].big = UI 0x0000;
    oddbits.NETWORKSTATE = UC 0x00;  
    relayimage.big = 0x00;
    powerupbaudsecs = 60;
    powerupbaudcomms = 0;
    pollsuspend = 30;  
}


void InitChip(void)
{
unsigned char temp;
    INTCON = 0x00;                      //disable all irq's

//MPH - added detect of RA4 - OPT1 to 5V indicates RF16
    TRISC = 0x5F;                       // First test for 4/8 or 16 channel....
    TRISF = 0x10;                       // needed for 16 / 4V2 difference        
    CMCON = 0x07;                       // Have to do htis to enable dig i/o on PORTF
    ADCON1 = 0x0F;                      // ...and this

    if ((PORTAbits.RA4) && (PORTAbits.RA6 == UC 0x00) && (PORTFbits.RF4 == UC 0x00))
        {                                   //16 channel 
        TRISA = 0x5F;   
        TRISB = 0xF0;
        TRISC = 0x96;
        TRISD = 0x00;
        TRISE = 0xFF;
        TRISF = 0xF4;   // V1.1 board
        TRISG = 0x14;
        ADCON1 = 0x1B;                  // 4 A2D channels , channel 3 is VREF+ external
        unitschannels = UC 16;
        }
	else	
    if ((PORTAbits.RA4) && (PORTAbits.RA6 == UC 0x00) && (PORTFbits.RF4 == UC 0x01))
        {                                   //4V2 channel 
        TRISA = 0x50;   
        TRISB = 0x00;
        TRISC = 0x96;
        TRISD = 0x00;
        TRISE = 0x0F;
        TRISF = 0x10;   
        TRISG = 0x14;
        ADCON1 = 0x1B;                  // 4 A2D channels , channel 3 is VREF+ external
        unitschannels = UC 42;
        }
	else	
        {
		TRISC = 0x82;                       // First test for 4 or 8 channel....
	    if (PORTCbits.RC1)
		    {                               // 8 channel
		    TRISA = 0x7F;   
		    TRISB = 0x18;
		    TRISC = 0x90;
		    TRISD = 0x00;
		    TRISE = 0xFF;
		    TRISF = 0xFF;
		    TRISG = 0x14;
		    ADCON1 = 0x06;                  // 9 channels 5V ref
		    unitschannels = UC 8;
		    }
		else
		    {                               // 4 channel
		    TRISA = 0x2F;   
		    TRISB = 0x08;
		    TRISC = 0x82;
		    TRISD = 0x00;
		    TRISE = 0xF0;
		    TRISF = 0x0F;
		    TRISG = 0x04;
		    ADCON1 = 0x16;                  // 9 channels external Vref
		    unitschannels = UC 4;
		    }
        }
    CMCON	= 0x07;                     // RF3-6 for Dig in not comparator mode
    PSPCON = 0;                         // no parallel port controls

    ADCON0 = 0x01;                      // A2D on
    ADCON2 = 0x82;                      // Right justified osc/32 speed

	CCP1CON = 0;
	TMR2 = 0;
	PR2 = 0xFF;
	CCPR1L = 0x7F;
	CCP1CON = 0x2C;
	T2CONbits.TMR2ON = 0;	            // pwm off 
	T2CONbits.T2CKPS1 = 1;	            // prescaler (Fosc/4)/16 = minimum period

	                // Init timer1 used to calculate spacing between characters received by usart1
	T1CON = 0xB0;	// initialize timer1 to 16bit access and prescale = (Fosc/4)/8 (25Mhz tick = 1.28uS) (1.28uS * 782 == 1mS )

                	// Init timer3 used to calculate spacing between characters received by usart2
	T3CON = 0xB0;	// initialize timer1 to 16bit access and prescale = (Fosc/4)/8 (25Mhz tick = 1.28uS) (1.28uS * 782 == 1mS )

                        // initialize SPI
	SSPCON1 = 0x22;		// enable, idle low, and fosc/16			//MPH - enable serial , idle low,  master Fosc/64
	SSPSTAT = 0x40;		// sample at middle, tx data on rising edge //MPH - input sampled in middle, Trans occurs on active to idle state (falling), 
}



void DisableUsart1(void)
{
unsigned char temp;
	PIE1bits.RC1IE = 0; 	                // disable USART receiver interrupt
	PIE1bits.TX1IE = 0; 	                // disable USART2 transmitter interrupt
    temp = RCREG1;                      // Flush anything
}

void EnableUsart1(void)
{
unsigned char temp;
   temp = RCREG1;                      // Flush anything
	PIE1bits.RC1IE = 1;                 // Ensable USART receiver interrupt
	PIE1bits.TX1IE = 1;                 // Enable USART transmitter interrupt
// 3.5 was disabled 	PIE1bits.TX1IE = 0;                 // Dont use USART transmitter interrupt
}
/*
void InitUsart1Old(void)
{
unsigned char temp;
    PIE1bits.RC1IE = 0;                 // Disable Rx interrupt
    PIE1bits.TX1IE = 0;                 // Disable Tx interrupt
    SPBRG1 = 0x81;                      // Start at 9600 baud
    TXSTA1 = 0x24;                      
    RCSTA1 = 0x90;
    temp = RCREG1;                      // dummy reads to clear buffers
    temp = RCREG1;                     
//    PIE1bits.RC1IE = 1;                  //enable USART1 receiver interrupt
}
*/

void InitUsart1(unsigned char baud)
{
unsigned char temp;
    PIE1bits.RC1IE = 0;                 // Disable Rx interrupt
    PIE1bits.TX1IE = 0;                 // Disable Tx interrupt
    switch (baud)
        {	// Fosc = 20MHz
        case BAUD1200: 
            SPBRG1 = 0xFF;	//baud = 1220.7 - error=1.7%
            TXSTA1 = 0x20;	
            break;
        case BAUD2400:
            SPBRG1 = 0x81;
            TXSTA1 = 0x20;	
            break;
        case BAUD4800:
            SPBRG1 = 0x40;
            TXSTA1 = 0x20;	
            break;
        case BAUD9600:
            SPBRG1 = 0x81;
            TXSTA1 = 0x24;	
            break;
        case BAUD19200:
            SPBRG1 = 0x40;
            TXSTA1 = 0x24;	
            break;
        default:
            SPBRG1 = 0x81; // default at 9600
            TXSTA1 = 0x24;	
			baud = BAUD9600;
            break;
        }
    RCSTA1 = 0x90;	
//@@@    TXREG1 = 0x00;                      // Spit something out to init port
    temp = RCREG1;
    temp = RCREG1;
}


void DisableUsart2(void)
{
	PIE3bits.RC2IE = 0; 	            //disable USART2 receiver interrupt
	PIE3bits.TX2IE = 0; 	            //disable USART2 transmitter interrupt
}

void EnableUsart2(void)
{
unsigned char temp;
    temp = RCREG2;                      // Clears RC2IF    
	PIE3bits.RC2IE = 1; 	            // enable USART2 receiver interrupt
}

void InitUsart2(unsigned char baud)
{
    PIE3bits.RC2IE = 0;                 // disable USART2 receiver interrupt
    PIE3bits.TX2IE = 0;                 // disable USART2 transmitter interrupt

//MPH 04/03/06
    switch (baud)
        {	// Fosc = 20MHz
        case BAUD1200: 
            SPBRG2 = 0xFF;	//baud = 1220.7 - error=1.7%
            TXSTA2 = 0x20;	
            break;
        case BAUD2400:
            SPBRG2 = 0x81;
            TXSTA2 = 0x20;	
            break;
        case BAUD4800:
            SPBRG2 = 0x40;
            TXSTA2 = 0x20;	
            break;
        case BAUD9600:
            SPBRG2 = 0x81;
            TXSTA2 = 0x24;	
            break;
        case BAUD19200:
            SPBRG2 = 0x40;
            TXSTA2 = 0x24;	
            break;
        default:
            SPBRG2 = 0x81; // default at 9600
            TXSTA2 = 0x24;	
			baud = BAUD9600;
            break;
        }
    RCSTA2 = 0x90;	
    TXREG2 = 0x00;                      // Spit something out to init port

	if (rs232gaptime.big < chartime35[baud])
        rs232gaptime.big = UI chartime35[baud]; // force to 3.5 char times before processing.
}


void RS485Off(void)                     // Turns off red led and clears on/off timers
{
    PORTCbits.RC0 = 0;
}
    
void RedOff(void)                       // Turns off red led and clears on/off timers
{
    PORTBbits.RB0 = 1;
    timer[REDONTIMER] = 0;       
    timer[REDOFFTIMER] = 0;       
}

void YellowOff(void)                    // Turns off led and clears on/off timers
{
    PORTBbits.RB2 = 1;
    timer[YELONTIMER] = 0;       
    timer[YELOFFTIMER] = 0;       
}

void GreenOff(void)                     // Turns off led and clears on/off timers
{
    PORTBbits.RB1 = 1;
    timer[GREENONTIMER] = 0;       
    timer[GREENOFFTIMER] = 0;       
}

void RedOn(void)                       // Turns on red led and clears on/off timers
{
    PORTBbits.RB0 = 0;
    timer[REDONTIMER] = 0;       
    timer[REDOFFTIMER] = 0;       
}

void YellowOn(void)                    // Turns on led and clears on/off timers
{
    PORTBbits.RB2 = 0;
    timer[YELONTIMER] = 0;       
    timer[YELOFFTIMER] = 0;       
}

void GreenOn(void)                     // Turns on led and clears on/off timers
{
    PORTBbits.RB1 = 0;
    timer[GREENONTIMER] = 0;       
    timer[GREENOFFTIMER] = 0;       
}

void SetupXstream(void)
{                   
unsigned char temp;
    RedOff();
    GreenOff();
    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        PORTAbits.RA5 = 1;				//MPH - enable RS485 transmitter
    YellowOn();
    WaitASec(); 
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = '+';                      // Send "+++"
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = '+';                      
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = '+';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    WaitASec();
    YellowOff();

    for (temp = UC 0; temp < UC 5; temp++)
        {
        while (TXSTA2bits.TRMT == UC 0)
            ;
        TXREG2 = xtreamstring[temp];
        }
    while (TXSTA2bits.TRMT == UC 0)
       ;

    TXREG2 = 'A';                       // Hop pattern 
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'T';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'H';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'P';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x30 + hoppattern;         // Xtend wants ascii hex
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x0D;    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    
    for (temp = UC 5; temp < UC XTREAMSTRINGSIZE; temp++)
        {
        while (TXSTA2bits.TRMT == UC 0)
            ;
        TXREG2 = xtreamstring[temp];
        }
    WaitASec();

    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        {
        while (TXSTA2bits.TRMT == UC 0)	
            PORTAbits.RA5 = 0;				
        }
}

      
void SetupXtend(void)
{                   
unsigned char temp;
    RedOff();
    GreenOff();
    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        PORTAbits.RA5 = 1;				//MPH - enable RS485 transmitter
    YellowOn();
    WaitASec(); 
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = '+';                      // Send "+++"
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = '+';                      
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = '+';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    WaitASec();
    YellowOff();

    for (temp = UC 0; temp < UC 5; temp++)//Set back to defaults.....
        {
        while (TXSTA2bits.TRMT == UC 0)
            ;
        TXREG2 = xtendstring[temp];
        }

    TXREG2 = 'A';                       // Hop pattern 
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'T';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'H';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'P';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x30 + hoppattern;         // Xtend wants ascii hex
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x0D;    
    while (TXSTA2bits.TRMT == UC 0)
        ;
  
    TXREG2 = 'A';                       // RF Baud rate 
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'T';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'B';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'R';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x30 + ismrfbaudrate;      // Xtend wants ascii hex
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x0D;    
    while (TXSTA2bits.TRMT == UC 0)
        ;

    TXREG2 = 'A';                       // Multiple transmit packets  
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'T';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'M';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 'T';    
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x30 + ismmultipackets;   // Xtend wants ascii hex
    while (TXSTA2bits.TRMT == UC 0)
        ;
    TXREG2 = 0x0D;    
    while (TXSTA2bits.TRMT == UC 0)
        ;

      for (temp = UC 5; temp < UC XTENDSTRINGSIZE; temp++)
        {
        while (TXSTA2bits.TRMT == UC 0)
            ;
        TXREG2 = xtendstring[temp];
        }
    WaitASec();

    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        {
        while (TXSTA2bits.TRMT == UC 0)	//MPH
        PORTAbits.RA5 = 0;				//MPH - disable RS485 transmitter
        }
}



/*          
Special config packet...... Holds commands from RFScada to configure baud rate, DTR/DSR etc for LMR radio
If special ID is not recognised whole packet is passed straight to the radio
[0]  ID always 'A'
[1]  ID always 'l'
[2]  ID always 'i'
[3]  ID always 's'
[4]  Baud rate   0=1200, 1=2400. 3=4800, 4=9600, 5=19200
[5]  Keyup time in mS lo byte 
[6]  Keyup time in mS hi byte 
[7]  Keydown time in mS lo byte 
[8]  Keydown time in mS hi byte 
[9]  RS232 gap time in mS lo byte. Time a gap must exist before deciding its a complete packet 
[10] RS232 gap time in mS hi byte 
[11] Spare
[12] Spare
[13] Spare
[14] Spare
[15] Spare
[16] ID always 't'
[17] ID always 'a'
[18] ID always 'i'
[19] ID always 'r'
*/
void SetupRadInt(void)
{                   
unsigned char temp;
    RedOff();
    GreenOff();
    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        PORTAbits.RA5 = 1;				//MPH - enable RS485 transmitter
    YellowOn();
    WaitASec(); 
    YellowOff();

    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 'A';                       // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 'l';                       // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 'i';                       // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 's';                       // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = baudrate;                  // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = keyuptime.byte[lo];       
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = keyuptime.byte[hi];       
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = keydowntime.byte[lo];     
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = keydowntime.byte[hi];                       
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = rs232gaptime.byte[lo];
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = rs232gaptime.byte[hi];
    while (TXSTA2bits.TRMT == UC 0)
            ;
    for (temp = UC 0x00; temp < UC 5; temp++) // 5 spare config bytes
        {
        while (TXSTA2bits.TRMT == UC 0)
            ;
        TXREG2 = 0x99;                     
        }
    
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 't';                       // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 'a';                       // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 'i';                       // ID
    while (TXSTA2bits.TRMT == UC 0)
            ;
    TXREG2 = 'r';                       // ID
    YellowOn();
    WaitASec();
    YellowOff();

    if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
        {
        while (TXSTA2bits.TRMT == UC 0)	//MPH
        PORTAbits.RA5 = 0;				//MPH - disable RS485 transmitter
        }
}

 
void WaitASec(void)
{
unsigned char loop;

    for (loop = UC 0; loop < UC 4; loop++)
        {
        ClearWDT();
        while (millisec != UC 0x00)
            ;
        while (millisec != UC 0xFA)
            ;
        }

}


void DemoRelays(void)
{
    if (analog[0].big > UI 100)
        RelayOn(0);
    else
        RelayOff(0);

    if (analog[0].big > UI 200)
        RelayOn(1);
    else
        RelayOff(1);
    if (analog[0].big > UI 300)
        RelayOn(2);
    else
        RelayOff(2);
    if (analog[0].big > UI 400)
        RelayOn(3);
    else
        RelayOff(3);
    if (analog[0].big > UI 500)
        RelayOn(4);
    else
        RelayOff(4);
    if (analog[0].big > UI 600)
        RelayOn(5);
    else
        RelayOff(5);
    if (analog[0].big > UI 700)
        RelayOn(6);
    else
        RelayOff(6);
    if (analog[0].big > UI 800)
        RelayOn(7);
    else
        RelayOff(7);
    if (analog[0].big > UI 900)
        RelayOn(8);
   else
        RelayOff(8);
}


void CheckModbusPacket()                // Verifies contents of received packet
{                                       // Command 0x02, 0x03, 0x4, 0x06 & 0x10 only commands supported
unsigned char result;
    oddbits.NEWRS232 = 0;
    result = CheckModbusRxCRC();
    if (result != UC 0x00)              
        {                               // Bad C/S - quit
        RestartModbusRx(); 
        YellowOff();
        return;
        }
    result = rs232inbuffer[1];
    if ((result != UC 0x01)             // Read coils
      &&(result != UC 0x02)             // Read bit inputs
      &&(result != UC 0x03)             // Read holding regs
      &&(result != UC 0x04)             // Read input regs
      &&(result != UC 0x05)             // Write Single Coil
      &&(result != UC 0x06)             // Write single reg.
      &&(result != UC 0x10))            // Write multiple registers
        {
        RestartModbusRx();
        YellowOff();
        return;
        }

    if (((rs232inbuffer[0] == modbusid) && (modbusid != UC 0x00))
        || (rs232inbuffer[0] == UC RFSCADAID))
        {
        mbaddress.byte[hi] = rs232inbuffer[2];
        mbaddress.byte[lo] = rs232inbuffer[3];
        mbnumber.byte[hi] = rs232inbuffer[4];
        mbnumber.byte[lo] = rs232inbuffer[5];
        BuildModbusPacket(result);
        if (powerupbaudsecs != UC 0x00) 
            powerupbaudcomms = 0xFF;      // Set flags for good comms during PU...
        pollsuspend = 30;                 // Shutdown polling until our MB comms are over
        RestartModbusRx();
        YellowOff();
        }
   // If get here a good MB packet but not for us has arrived. 
   // Assume its a response to one of our polls, if polling is disabled delete packet
   if ((mbscanID[0] == UC 0x00)
    && (mbscanID[1] == UC 0x00) 
    && (mbscanID[2] == UC 0x00) 
    && (mbscanID[3] == UC 0x00)) 
      {
      RestartModbusRx();
      YellowOff();
      }
}


unsigned char CheckModbusRxCRC(void)
{
unsigned char tempchar;
unsigned char temp;
unsigned char y;
union wordy crc;
unsigned int tempint;

    crc.big = 0xFFFF;
    for (temp = UC 0; temp < rs232inpointer - UC 2; temp++)
        {
        tempchar = rs232inbuffer[temp];
        tempint = tempchar;
        crc.big = crc.big ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc.big;
            crc.big = crc.big / UI 2;
            if (tempint & 1 == 1)
                crc.big = crc.big ^ 0xA001;
            }
         }
    if (rs232inbuffer[temp] != crc.byte[lo])
        return(0xFF);
    temp++;
    if (rs232inbuffer[temp] != crc.byte[hi])
        return(0xFE);
    return(0x00);
}


void BuildModbusPacket(unsigned char type)
{
unsigned char paddy1;            // Needed to force inty over page boundary
unsigned char temp;
unsigned char x;
unsigned char test;
unsigned char bitty;
union wordy inty;  
     if ((type == UC 1) || (type == UC 2))         // Command 1 & 2 response...Read discrete inputs or coils really the same
        {                                          // May be up to 2000 packed as bits    
        test = 0;                       
        rs232outbuffer[0] = rs232inbuffer[0];      //modbusid;
        rs232outbuffer[1] = type;                  // 0x02;
        //temp = mbnumber.byte[lo];
        inty.big = mbnumber.byte[lo];
        inty.big = inty.big - UI 1;     // Number of bytes to return = 1 + (mbnumber-1)/8
        inty.big = inty.big >> 3;
        inty.big++;
        temp = inty.byte[lo];
        rs232outbuffer[2] = temp;
        for (x = 0; x <= temp; x++)      // Clear output buffer
            {
            rs232outbuffer[3 + x] = 0x00;
            }
        x = 3;
        bitty = 0x01;
        while (mbnumber.big != UI 0x0000)
            {
            if (GetModbusBit(mbaddress.big))
                rs232outbuffer[x] = rs232outbuffer[x] | bitty;
            bitty = bitty << 1; 
            if (bitty == UC 0x00)        // If we have done 8 bits reset bit mask and move to next byte in response
                {
                bitty = 0x01;            // Ready for next byte
                x++;
                }
            mbnumber.big--;
            mbaddress.big++;
            }
        if (bitty != UC 0x01)              // Stops us bumping x if # regs are a muliple of 8    
            x++;
        AddModbusTxCRC(x);
        x++;
        rs232outbuffersize = x;
        rs232outpointer = 0x00;         // Start transmitting
		  PIE1bits.TX1IE = 1;             // MPH  enable TX2 interrupt
        }
    else
    if (type == UC 3)                   // Command 3 read multiple registers response...
        {
        test = 0;
        rs232outbuffer[0] = rs232inbuffer[0]; //modbusid;
        rs232outbuffer[1] = 0x03;
        temp = mbnumber.byte[lo];    
        rs232outbuffer[2] = temp * UC 2;
        x = 3;
        while (temp != UC 0x00)
            {
            inty.big = GetModbusRegister(mbaddress.big + UI test);
            rs232outbuffer[x] = inty.byte[hi]; 
            test++;
            x++;
            rs232outbuffer[x] = inty.byte[lo];
            x++;
            temp--;
            }
        AddModbusTxCRC(x);
        x = x + 1;
        rs232outbuffersize = x;
        rs232outpointer = 0x00;         // Start transmitting
		  PIE1bits.TX1IE = 1;             // MPH  enable TX2 interrupt
        }
    else
    if (type == UC 4)                   // Command 4 response...
        {
        test = 0;
        rs232outbuffer[0] = rs232inbuffer[0]; //modbusid;
        rs232outbuffer[1] = 0x04;
        temp = mbnumber.byte[lo];
        rs232outbuffer[2] = temp * UC 2;
        x = 3;
        while (temp != UC 0x00)
            {
            inty.big = GetModbusRegister(mbaddress.big + UI test);
            rs232outbuffer[x] = inty.byte[hi];
            test++;
            x++;
            rs232outbuffer[x] = inty.byte[lo];
            x++;
            temp--;
            }
        AddModbusTxCRC(x);
        x = x + 1;
        rs232outbuffersize = x;
        rs232outpointer = 0x00;         // Start transmitting
        PIE1bits.TX1IE = 1; 			   //MPH  enable TX2 interrupt
        }
    else
	 if (type == UC 5)
        {					// Command 5 force single coil. Coils are numbered by bit, so coil 3 = MB 0 bit 3.
        rs232outbuffer[0] = rs232inbuffer[0];       // Standard reply
        rs232outbuffer[1] = 5;
        rs232outbuffer[2] = rs232inbuffer[2];
        rs232outbuffer[3] = rs232inbuffer[3];
        rs232outbuffer[4] = rs232inbuffer[4];
        rs232outbuffer[5] = rs232inbuffer[5];
        mbaddress.byte[hi] = rs232inbuffer[2];
        mbaddress.byte[lo] = rs232inbuffer[3];
        mbdata.byte[hi] = rs232inbuffer[4];
        mbdata.byte[lo] = rs232inbuffer[5];
        if (mbdata.big == UI 0xFF00)               // Coil on 
           ForceBit(mbaddress.big, 1);
        else
        if (mbdata.big == UI 0x0000)               // Coil off 
           ForceBit(mbaddress.big, 0);
        AddModbusTxCRC(6);
        rs232outbuffersize = 7;
        rs232outpointer = 0x00;                    // Start transmitting
        PIE1bits.TX1IE = 1; 			               // enable TX2 interrupt
      }
    else
/*	 if (type == UC 15)
        {					// Command 15 force multiple coils. Coils are numbered by bit, so coil 17 = MB 1 bit 1.
        rs232outbuffer[0] = rs232inbuffer[0];       // Have to be careful as bits to write may cross target register boundaries
        rs232outbuffer[1] = 5;
        rs232outbuffer[2] = rs232inbuffer[2];
        rs232outbuffer[3] = rs232inbuffer[3];
        rs232outbuffer[4] = rs232inbuffer[4];
        rs232outbuffer[5] = rs232inbuffer[5];
        mbaddress.byte[hi] = rs232inbuffer[2];
        mbaddress.byte[lo] = rs232inbuffer[3];
        mbdata.byte[hi] = rs232inbuffer[4];
        mbdata.byte[lo] = rs232inbuffer[5];
        if (mbdata.big == UI 0xFF00)               // Coil on 
           ForceBit(mbaddress.big, 1);
        else
        if (mbdata.big == UI 0x0000)               // Coil off 
           ForceBit(mbaddress.big, 0);
        AddModbusTxCRC(6);
        rs232outbuffersize = 7;
        rs232outpointer = 0x00;                    // Start transmitting
        PIE1bits.TX1IE = 1; 			               // enable TX2 interrupt
      }
    else
*/
    if (type == UC 6)                   // Command 6 write single register response...
        {
        test = 0;
        rs232outbuffer[0] = rs232inbuffer[0]; //modbusid;  
        rs232outbuffer[1] = 6;          // Always a fixed 'echoed' response...
        rs232outbuffer[2] = rs232inbuffer[2];
        rs232outbuffer[3] = rs232inbuffer[3];
        rs232outbuffer[4] = rs232inbuffer[4];
        rs232outbuffer[5] = rs232inbuffer[5];
   
        mbaddress.byte[hi] = rs232inbuffer[2]; 
        mbaddress.byte[lo] = rs232inbuffer[3]; 
        mbdata.byte[hi] = rs232inbuffer[4];
        mbdata.byte[lo] = rs232inbuffer[5];

        WriteModbusRegister(mbaddress.big);
        AddModbusTxCRC(6);
        rs232outbuffersize = 7;
        rs232outpointer = 0x00;           // Start transmitting        
        PIE1bits.TX1IE = 1;               // MPH  enable TX2 interrupt
        }
    else
    if (type == UC 16)                  // Command 16 write multiple registers response...
        {
        test = 0;
        rs232outbuffer[0] = rs232inbuffer[0]; //modbusid;   // Always a fixed 'echoed' response...
        rs232outbuffer[1] = 0x10;
        rs232outbuffer[2] = rs232inbuffer[2];
        rs232outbuffer[3] = rs232inbuffer[3];
        rs232outbuffer[4] = rs232inbuffer[4];
        rs232outbuffer[5] = rs232inbuffer[5];
        
        temp = mbnumber.byte[lo];    
       
        x = 0;
        test = 0;
        while (temp != UC 0x00)
            {
            mbdata.byte[hi] = rs232inbuffer[7 + test];
            mbdata.byte[lo] = rs232inbuffer[8 + test];
            WriteModbusRegister(mbaddress.big + UI x);
            x++;
            test = test + UC 2;
            temp--;
            }
        AddModbusTxCRC(6);
        rs232outbuffersize = 7;
        rs232outpointer = 0x00;           // Start transmitting        
	     PIE1bits.TX1IE = 1; 			      // MPH  enable TX2 interrupt
        }
}

void ForceBit(unsigned int add, unsigned char level)  // Sets or clears one bit in MB array. Bit # is 16x MB register array!
{
unsigned int x;
unsigned int finaladd;
unsigned int bitt;
unsigned int bits;
   finaladd = add / UI 16;                            // Get MB register
   bitt = add % UI 16;                                // register bit
   if (level == UC 1)                                 // Force on?
      {
      bits = 1;
      bits = bits << bitt;
      x = GetModbusRegister(finaladd);
      x = x | bits;
      mbdata.big = x;
      WriteModbusRegister(finaladd);
      return;
      }
   if (level == UC 0x00)                              // Force off?
      {
      bits = 0xFFFF;
      x = 1 << bitt;
      bits = bits ^ x;
      x = GetModbusRegister(finaladd);
      x = x & bits;
      mbdata.big = x;
      WriteModbusRegister(finaladd);
      }
}


unsigned char GetModbusBit(unsigned int addr) // Retrieves a single bit; may be coil or input, really the same    
{                                             // Each real MB reg is 16 bit, so can read up to 4095 16 bit regs as a bit  
//unsigned char temp;                             
unsigned char bitt;
unsigned int x, addd;
   bitt = (addr % 16);                        // get bit 
   addd = addr / UI 16; // - (addr % 16);                 // reg add. ie coil/input 18 -> MB Reg 1, bit 3  
//   addd = 
   x = GetModbusRegister(addd);
   x = x >> bitt;                             // slide reg down to get bit of interest  
   if ((x & 0x01) == UI 0x01)
      return(0xFF);
   else
      return(0x00);
}
     
/* orig
unsigned char GetModbusBit(unsigned int addr) // Retrieves a single bit; may be coil or input, really the same    
{                                             // Assume every 10th reg is dig input register, with 8 packed bits  
unsigned char temp;                           // For 'coils' or 'inputs' use digin reg, 9th bit is comm state  
unsigned char bitt;
unsigned int x, addd;
   if (addr > UI 575)                         // out of range
      return(0x00);
   bitt = (addr % 10);                        // get bit 
   addd = addr - (addr % 10);                 // reg add. ie 10-17 -> 10, 230-217 -> 21  
   x = GetModbusRegister(addd);
   x = x >> bitt;                             // slide reg down to get bit of interest  
   if ((x & 0x01) == UI 0x01)
      return(0xFF);
   else
      return(0x00);
}
*/



void WriteModbusRegister(unsigned int address)
{
unsigned char temp;
unsigned int inty;
unsigned char add;
union wordy w; 

    if (address < UI 320)
        {
         inty = address / UI 10;         // get unit ID
         if ((address % 10) == UI 0x00)  // Is it a digital register?
            {
            address = address / UI 10;
            temp = UC address;
            if ((srccon[temp] & 0x02) == UC 0x02) 
                totcontrolrelays[temp] = mbdata.byte[lo];
            else
                resdigbits[temp] = mbdata.byte[lo];
            }
        else
            {
            address = address % UI 10;      // Get ana. res. index from channel #
            address--; 
            if ((srccon[UC inty] & 0x02) == UC 0x02) 
                totcontrolanalog[inty][address].big = mbdata.big;
            else
                resanalog[inty][address].big = mbdata.big; 
            }
        overridetimers[inty] = usersmodbusoverride;
        return;
        }
    
    if (address < UI 448)                    
        {                               // Digital config
        address = address - UI 320;
        temp = UC address;
        add = UC address;
        temp = temp / UC 4;
        add = add & 0x03;
        add = add * UC 2;
        srcdig[temp][add] = mbdata.byte[lo];
        srcdig[temp][add + 1] = mbdata.byte[hi];
        return;
        }

    if (address < UI 576)
        {                               // Analog config
        address = address - UI 448;
        temp = UC address;
        add = UC address;
        temp = temp / UC 4;
        add = add & 0x03;
        add = add * UC 2;
        srcana[temp][add] = mbdata.byte[lo];
        srcana[temp][add + 1] = mbdata.byte[hi];
        return;
        }
      
    if (address < UI 608)               // Box config...    
        {                   
        address = address - UI 576;
        temp = UC address;
        srccon[temp] = mbdata.byte[lo];
        return;
        }
    if (address == UI 608)              // Units ID
        {                   
        configid = mbdata.byte[lo];
        oddbits.CONFIGCHANGED = 1;
        return;
        }
    if (address == UI 611)              // Users Modbus ID
        {                   
        modbusid = mbdata.byte[lo];
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 612)              // Users no comm limit time
        {                   
        usersnocommlimit.byte[lo] = mbdata.byte[lo];
        usersnocommlimit.byte[hi] = mbdata.byte[hi];
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 613)              // Users override limit time
        {                   
        usersmodbusoverride = mbdata.byte[lo];
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 614)              // Modbus silent time time
        {                   
        modbussilenttime = mbdata.byte[lo];
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 615)              // Special function register
        {                   
        specialmode = mbdata.byte[lo];
        oddbits.CONFIGCHANGED = 1;
        return;
        }
   if (address == UI 616)              // Low tank setting
        {                   
        lowtanklevel.big = mbdata.big;
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 617)               // High tank setting
        {                   
        hightanklevel.big = mbdata.big;
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 618)               // Commfailoverride key location
        {                   
        commfailoverride.big = mbdata.big;
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address < UI 651)               // 619 - 650 repeater targets
        {                              // But repeater_target[0] is used for something else so start at [1] 
        repeater_target[UI address - UI 618] = mbdata.byte[lo]; //MPH - repeater code , uses lo byte of each register only
        oddbits.CONFIGCHANGED = 1;
        return;
       }

   if (address == UI 800)               // Clear spectrum analyzer
        {
        ClearPacketCounts();
        oddbits2.SPECTRUMFULL = 0;
        return;
        }
// 800 - 831 spectrum analyzer
// 832 Network state
// 833 to 839 gap

   if ((address > UI 839) && (address < UI 848)) // User registers
        {
        userregs[address - UI 840].big = mbdata.big;
        return;
        }

    if  ((address >= UI 1000) &&        // Protected area.....
         (address <= UI 1014))          
        {
        if (timer[LOCKTIMER] == UI 0x0000)
           return;                
        oddbits.CONFIGCHANGED = 1;
        switch (address)
          {
            case 1000:                  // Hop pattern
            {   
            hoppattern = mbdata.byte[lo];
            break;
            }
            case 1001:                  // S/N
            {                   
            serialnumber.big = mbdata.big;
            break;
            }
            case 1002:                  // Physical channels
            {                   
                ;                       // Read only; generated by boards h/w 
                break;
            }
            case 1004:                  // Fastest user EEPROM update rate 
            {                   
            storeanadelay.big = mbdata.big;
            break;
            }
            case 1005:                  // Run hours.... 
            {                   
            runhours.big = mbdata.big;
            break;
            }
            case 1006:                  // Radiotype 
            {                   
            radiotype= mbdata.byte[lo];
            break;    
            }
            case 1007:              
            {                   
            baudrate = mbdata.byte[lo];
            break;    
            }
            case 1008: 
            {                   
            keyuptime.big = mbdata.big;
            break;    
            }
            case 1009:  
            {                   
            keydowntime.big = mbdata.big;
            break;    
            }
            case 1010:              
            {                   
            rs232gaptime.big = mbdata.big;
            break;    
            }
            case 1011:              
            {                   
            transmitrate.big = mbdata.big;
            break;    
            }
            case 1012:              
            {                   
            ismrfbaudrate = mbdata.byte[lo];
            break;    
            }
            case 1013:              
            {                   
            ismmultipackets = mbdata.byte[lo];
            break;    
            }
            case 1014:              
            {                   
            txdelay.big = mbdata.big;	//MPH04-03-06 
            break;    
            }
          }  
        return;
        }
   if (address == UI 1015)               // modbusbaudrate (PC interface)
        {                   
        modbusbaudrate = mbdata.byte[lo];
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 1016)               // pulse enable bits
        {
        pulseenable = mbdata.byte[lo];
        oddbits.CONFIGCHANGED = 1;
        return;
        }
   if (address == UI 1017)               // Spare regs (tank scaling?)
        {                   
        spareMBReg1.big = mbdata.big;
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 1018)               // Spare regs (tank scaling?)
        {                   
        spareMBReg2.big = mbdata.big;
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 1019)                // Spare regs (tank scaling?)
        {                   
        spareMBReg3.big = mbdata.big;
        oddbits.CONFIGCHANGED = 1;
        return;
        }

   if (address == UI 1028)                // Trips enabled flag
      {
      if (mbdata.big != oddbits2.TRIPSENABLED)
         {
         if (mbdata.big == UI 1)
            oddbits2.TRIPSENABLED = 1;
         else
            oddbits2.TRIPSENABLED = 0;
         oddbits.CONFIGCHANGED = 1;
         savetripstime.big = SAVETRIPSECS;
         }
      return;
      }
   if (address == UI 1029)         // Trip fill / drain bits
      {
      if (fillbits != mbdata.byte[lo])
         {
         fillbits = mbdata.byte[lo];
         oddbits.CONFIGCHANGED = 1;
         savetripstime.big = SAVETRIPSECS;
         }
      return;
      }
 
   if ((address > UI 1029) && (address < UI 1038))         // Trip on points.....
      {
      if (tron[address - UI 1030].big != mbdata.big)
         {
         tron[address - UI 1030].big = mbdata.big;
         oddbits.CONFIGCHANGED = 1;
         savetripstime.big = SAVETRIPSECS;
         }
      return;
      } 
   if ((address > UI 1037) && (address < UI 1046))         // Trip off points.....
      {
      if (troff[address - UI 1038].big != mbdata.big)
         {
         troff[address - UI 1038].big = mbdata.big;
         oddbits.CONFIGCHANGED = 1;
         savetripstime.big = SAVETRIPSECS;
         }
      return;
      } 

   if  ((address >= UI 1046) &&         // MB scanning setup.....
         (address <= UI 1079))          
        {
        oddbits.CONFIGCHANGED = 1;
        switch (address)
          {
          case 1046: mbscanRate = mbdata.byte[lo]; break;                  // 4.2
          case 1047: mbscanID[0] = mbdata.byte[lo]; break;
          case 1048: mbscanID[1] = mbdata.byte[lo]; break;
          case 1049: mbscanID[2] = mbdata.byte[lo]; break;
          case 1050: mbscanID[3] = mbdata.byte[lo]; break;
          case 1051: {                     
                     mbscanBaud[0] = BAUD9600;                             // default to 9600
                     if (mbdata.big == UI 1200) mbscanBaud[0] = BAUD1200; 
                     if (mbdata.big == UI 2400) mbscanBaud[0] = BAUD2400; 
                     if (mbdata.big == UI 4800) mbscanBaud[0] = BAUD4800; 
                     if (mbdata.big == UI 9600) mbscanBaud[0] = BAUD9600; 
                     if (mbdata.big == UI 19200) mbscanBaud[0] = BAUD19200; 
                     break;
                     }
          case 1052: {                     
                     mbscanBaud[1] = BAUD9600;                             // default to 9600
                     if (mbdata.big == UI 1200) mbscanBaud[1] = BAUD1200; 
                     if (mbdata.big == UI 2400) mbscanBaud[1] = BAUD2400; 
                     if (mbdata.big == UI 4800) mbscanBaud[1] = BAUD4800; 
                     if (mbdata.big == UI 9600) mbscanBaud[1] = BAUD9600; 
                     if (mbdata.big == UI 19200) mbscanBaud[1] = BAUD19200; 
                     break;
                     }
          case 1053: {                     
                     mbscanBaud[2] = BAUD9600;                             // default to 9600
                     if (mbdata.big == UI 1200) mbscanBaud[2] = BAUD1200; 
                     if (mbdata.big == UI 2400) mbscanBaud[2] = BAUD2400; 
                     if (mbdata.big == UI 4800) mbscanBaud[2] = BAUD4800; 
                     if (mbdata.big == UI 9600) mbscanBaud[2] = BAUD9600; 
                     if (mbdata.big == UI 19200) mbscanBaud[2] = BAUD19200; 
                     break;
                     }
          case 1054: {                     
                     mbscanBaud[3] = BAUD9600;                             // default to 9600
                     if (mbdata.big == UI 1200) mbscanBaud[3] = BAUD1200; 
                     if (mbdata.big == UI 2400) mbscanBaud[3] = BAUD2400; 
                     if (mbdata.big == UI 4800) mbscanBaud[3] = BAUD4800; 
                     if (mbdata.big == UI 9600) mbscanBaud[3] = BAUD9600; 
                     if (mbdata.big == UI 19200) mbscanBaud[3] = BAUD19200; 
                     break;
                     }
          case 1055: mbscanFunc[0] = mbdata.byte[lo]; break;                // 4.2
          case 1056: mbscanFunc[1] = mbdata.byte[lo]; break;                // 4.2
          case 1057: mbscanFunc[2] = mbdata.byte[lo]; break;                // 4.2
          case 1058: mbscanFunc[3] = mbdata.byte[lo]; break;                // 4.2
          case 1059: 
                     { 
                     mbdata.big = mbdata.big / 10; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanDOTime[0] = mbdata.byte[lo];
                     break;              
                     }
          case 1060: 
                     { 
                     mbdata.big = mbdata.big / 10; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanDOTime[1] = mbdata.byte[lo];
                     break;              
                     }
          case 1061: 
                     { 
                     mbdata.big = mbdata.big / 10; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanDOTime[2] = mbdata.byte[lo];
                     break;              
                     }
          case 1062: 
                     { 
                     mbdata.big = mbdata.big / 10; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanDOTime[3] = mbdata.byte[lo];
                     break;              
                     }
          case 1063: 
                     { 
                     mbdata.big = mbdata.big / 100; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanPollTime[0] = mbdata.byte[lo];
                     break;              
                     }
          case 1064: 
                     { 
                     mbdata.big = mbdata.big / 100; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanPollTime[1] = mbdata.byte[lo];
                     break;              
                     }
          case 1065: 
                     { 
                     mbdata.big = mbdata.big / 100; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanPollTime[2] = mbdata.byte[lo];
                     break;              
                     }
          case 1066: 
                     { 
                     mbdata.big = mbdata.big / 100; 
                     if (mbdata.big > UI 255) mbdata.big = 255;
                     if (mbdata.big < UI 1) mbdata.big = 1;
                     mbscanPollTime[3] = mbdata.byte[lo];
                     break;              
                     }
          case 1067: mbscanReg[0].big = mbdata.big; break;               
          case 1068: mbscanReg[1].big = mbdata.big; break;               
          case 1069: mbscanReg[2].big = mbdata.big; break;               
          case 1070: mbscanReg[3].big = mbdata.big; break;               
          case 1071: mbscanDefault[0].big = mbdata.big; break;               
          case 1072: mbscanDefault[1].big = mbdata.big; break;               
          case 1073: mbscanDefault[2].big = mbdata.big; break;               
          case 1074: mbscanDefault[3].big = mbdata.big; break;               
          case 1075: mbscanDiv[0].big = mbdata.big; break;
          case 1076: mbscanDiv[1].big = mbdata.big; break;
          case 1077: mbscanDiv[2].big = mbdata.big; break;
          case 1078: mbscanDiv[3].big = mbdata.big; break;
          case 1079: {
                     if (mbdata.big < UI 4096)
                        mbpulselevel.big = mbdata.big; 
                     break;
                     }
          }
        } 

    if (address == UI 3318)
        {
        if (mbdata.big == UI 1234)
            DefaultConfig();
        if (mbdata.big == UI 5678)
            {
            DisableUsart1();
            DisableUsart2();
            EEWriteConfig();
            InitVars();
            EEReadConfig();
            EnableUsart1();
            EnableUsart2();
            Reset();
            }
        return;
        }

    if (address == UI 3297)             // Top secret lock
        {
        if (mbdata.big == UI 13159)     // This key unlocks factory functions...
            timer[LOCKTIMER] = 2000;
        return;
        }
    if (address == UI 2974)             // Top secret - enables boot block
        {
        if (timer[LOCKTIMER] == UI 0x0000)
            return;
        if (mbdata.big == UI NEWFWKEY)  // The key
            EEWrite(1023, 0xFF);        // Its all over, will enter boot mode on next power up    
        return;
        }
}


unsigned int GetModbusRegister(unsigned int address)
{
unsigned char temp;
unsigned int inty;
unsigned char add;
    if (address < UI 320)
        {
        if ((address % 10) == UI 0x00)  // Is it a digital register?
            {
            inty = 0x0000;                  // For good comms bit
            address = address / UI 10;
            add = UC address;
            if (add == UC 0x00)
                {
                inty = 0x100;           // always good comms from master...
                }
            else
            if (nocommtimers[add].big != UI 0x0000)
                inty = 0x100;
            inty = inty + resdigbits[add];
            // inty = inty + res4gbits;
            return(inty);
            }
        inty = address / UI 10;         // get unit ID
        address = address % UI 10;      // Get ana. res. index from channel #
        address--; 
        return (resanalog[inty][address].big); 
        //return (res4ganas[address].big); 
        }
    if (address < UI 448)                    
        {                               // Digital config
        address = address - UI 320;
        temp = UC address;
        add = UC address;
        temp = temp / UC 4;
        add = add & 0x03;
        add = add * UC 2;
        inty = UI srcdig[temp][add+1];
        inty = inty * UI 256;
        inty = inty + UI srcdig[temp][add];
        return(inty);
        }
    if (address < UI 576)
        {                               // Analog config
        address = address - UI 448;
        temp = UC address;
        add = UC address;
        temp = temp / UC 4;
        add = add & 0x03;
        add = add * UC 2;
        inty = UI srcana[temp][add+1];
        inty = inty * UI 256;
        inty = inty + UI srcana[temp][add];
        return(inty);
        }
    if (address < UI 608)               // Box config...    
        {                   
        address = address - UI 576;
        temp = UC address;
        inty = UI srccon[temp];
        return(inty);
        }
    if (address == UI 608)              // Units ID
        {
        inty = UI configid;
        return(inty);
        }
    if (address == UI 609)              // Present state of output relays
        return(relayimage.big);
    if (address == UI 610)              // Network condition
        {
        if (nocommtime.big == UI 0x00)
            return(0);                  // Lost comms....
        if (oddbits.NETWORKSTATE == UC 0)// We are OK but problem somewhere
            return(1);
        else    
            return(2);                  // Must be good
        }
  
    if (address == UI 611)              // Users Modbus address
        return(modbusid);

    if (address == UI 612)               // Users no comm limit time
        return(usersnocommlimit.big);

    if (address == UI 613)               // Users modbus override limit time
        return(usersmodbusoverride);
 
    if (address == UI 614)              // Users modbus silent limit time
        return(modbussilenttime);
    if (address == UI 615)              // Users special program
        return(specialmode);
    if (address == UI 616)              // Tank setting
        return(lowtanklevel.big);
    if (address == UI 617)              // Tank setting
        return(hightanklevel.big);
    if (address == UI 618)              // CFO setting
        return(commfailoverride.big);


    if (address < UI 650)               // repeater targets
        {                               // But repeater_target[0] is used for something else so start at [1] 
        return(UI repeater_target[UI address - UI 618]); //MPH - repeater code , uses lo byte of each register only
        }
     
    if (address < UI 800)               // Repeater targets presently unused....   
        return(0x00);
  
    if (address < UI 832)               // 800 = packets transmitted by master, 801 to 831 good packets received at master 
        {
        address = address - UI 800;
        return(goodpackets[UI address].big);
        }

  if (address == UI 832)                // Network condition
        {
        if (nocommtime.big == UI 0x00)
            return(0);                  // Lost comms....
        if (oddbits.NETWORKSTATE == UC 0)// We are OK but problem somewhere
            return(1);
        else    
            return(2);                  // Must be good
        }
// 833 to 839 gap
    if ((address > UI 839) && (address < UI 848)) // User registers
        {
        return(userregs[address - 840].big);
        }

    if (address == UI 1000) return(hoppattern);
    if (address == UI 1001) return(serialnumber.big);
    if (address == UI 1002) return(unitschannels);
    if (address == UI 1003) return(SWVERSION);
    if (address == UI 1004) return(storeanadelay.big);
    if (address == UI 1005) return(runhours.big);
    if (address == UI 1006) return(radiotype);
    if (address == UI 1007) return(baudrate);
    if (address == UI 1008) return(keyuptime.big);
    if (address == UI 1009) return(keydowntime.big);
    if (address == UI 1010) return(rs232gaptime.big);
    if (address == UI 1011) return(transmitrate.big);
    if (address == UI 1012) return(ismrfbaudrate);
    if (address == UI 1013) return(ismmultipackets);
    if (address == UI 1014) return(txdelay.big);		//MPH04-03-06
    if (address == UI 1015) return(modbusbaudrate);
    if (address == UI 1016) return(pulseenable);        // 	
    if (address == UI 1017) return(spareMBReg1.big);        // spares (for tank level scaling?)
    if (address == UI 1018) return(spareMBReg2.big);        // spares (for tank level scaling?)
    if (address == UI 1019) return(spareMBReg3.big);        // spares (for tank level scaling?)
 
    if (address == UI 1020)         // Present level of analog output 1 (may not physically be there)
        return(anaout1.big);
    if (address == UI 1021)         // Present level of analog output 2 (may not physically be there)
        return(anaout2.big);
    if (address == UI 1022)         // Present level of analog output 3 (may not physically be there)
        return(anaout3.big);
    if (address == UI 1023)         // Present level of analog output 4 (may not physically be there)
        return(anaout4.big);
    if (address == UI 1024)         // Present level of analog output 5 (may not physically be there)
        return(anaout5.big);
    if (address == UI 1025)         // Present level of analog output 6 (may not physically be there)
        return(anaout6.big);
    if (address == UI 1026)         // Present level of analog output 7 (may not physically be there)
        return(anaout7.big);
    if (address == UI 1027)         // Present level of analog output 8 (may not physically be there)
        return(anaout8.big);
    if (address == UI 1028)         // Trips enabled flag
        return(UI oddbits2.TRIPSENABLED);
    if (address == UI 1029)         // Trip fill / drain bits
        return(UI fillbits);
    if (address == UI 1030) return(UI tron[0].big);       // Trip on points.....
    if (address == UI 1031) return(UI tron[1].big);
    if (address == UI 1032) return(UI tron[2].big);
    if (address == UI 1033) return(UI tron[3].big);
    if (address == UI 1034) return(UI tron[4].big);
    if (address == UI 1035) return(UI tron[5].big);
    if (address == UI 1036) return(UI tron[6].big);
    if (address == UI 1037) return(UI tron[7].big);
    if (address == UI 1038) return(UI troff[0].big);      // Trip off points.....
    if (address == UI 1039) return(UI troff[1].big);
    if (address == UI 1040) return(UI troff[2].big);
    if (address == UI 1041) return(UI troff[3].big);
    if (address == UI 1042) return(UI troff[4].big);
    if (address == UI 1043) return(UI troff[5].big);
    if (address == UI 1044) return(UI troff[6].big);
    if (address == UI 1045) return(UI troff[7].big);
    if (address == UI 1046) return(mbscanRate);
    if (address == UI 1047) return(mbscanID[0]);
    if (address == UI 1048) return(mbscanID[1]); 
    if (address == UI 1049) return(mbscanID[2]); 
    if (address == UI 1050) return(mbscanID[3]);
    if (address == UI 1051)
         {
         if (mbscanBaud[0] == UC BAUD1200) return(1200);
         if (mbscanBaud[0] == UC BAUD2400) return(2400);
         if (mbscanBaud[0] == UC BAUD4800) return(4800);
         if (mbscanBaud[0] == UC BAUD9600) return(9600);
         if (mbscanBaud[0] == UC BAUD19200) return(19200);
         }
    if (address == UI 1052)
         {
         if (mbscanBaud[1] == UC BAUD1200) return(1200);
         if (mbscanBaud[1] == UC BAUD2400) return(2400);
         if (mbscanBaud[1] == UC BAUD4800) return(4800);
         if (mbscanBaud[1] == UC BAUD9600) return(9600);
         if (mbscanBaud[1] == UC BAUD19200) return(19200);
         }
    if (address == UI 1053)
         {
         if (mbscanBaud[2] == UC BAUD1200) return(1200);
         if (mbscanBaud[2] == UC BAUD2400) return(2400);
         if (mbscanBaud[2] == UC BAUD4800) return(4800);
         if (mbscanBaud[2] == UC BAUD9600) return(9600);
         if (mbscanBaud[2] == UC BAUD19200) return(19200);
         }
    if (address == UI 1054)
         {
         if (mbscanBaud[3] == UC BAUD1200) return(1200);
         if (mbscanBaud[3] == UC BAUD2400) return(12400);
         if (mbscanBaud[3] == UC BAUD4800) return(4800);
         if (mbscanBaud[3] == UC BAUD9600) return(9600);
         if (mbscanBaud[3] == UC BAUD19200) return(19200);
         }
    if (address == UI 1055) return(mbscanFunc[0]);             // 3 or 4
    if (address == UI 1056) return(mbscanFunc[1]);
    if (address == UI 1057) return(mbscanFunc[2]); 
    if (address == UI 1058) return(mbscanFunc[3]); 
    if (address == UI 1059) return(UI 10 * UI mbscanDOTime[0]);      // dropout time 10 to 2550 seconds 
    if (address == UI 1060) return(UI 10 * UI mbscanDOTime[1]); 
    if (address == UI 1061) return(UI 10 * UI mbscanDOTime[2]); 
    if (address == UI 1062) return(UI 10 * UI mbscanDOTime[3]); 
    if (address == UI 1063) return(UI 100 * UI mbscanPollTime[0]);   // Poll time 100mS to 25.5 seconds
    if (address == UI 1064) return(UI 100 * UI mbscanPollTime[1]); 
    if (address == UI 1065) return(UI 100 * UI mbscanPollTime[2]); 
    if (address == UI 1066) return(UI 100 * UI mbscanPollTime[3]); 
    if (address == UI 1067) return(mbscanReg[0].big);             
    if (address == UI 1068) return(mbscanReg[1].big);              
    if (address == UI 1069) return(mbscanReg[2].big);            
    if (address == UI 1070) return(mbscanReg[3].big);            
    if (address == UI 1071) return(mbscanDefault[0].big);               
    if (address == UI 1072) return(mbscanDefault[1].big);              
    if (address == UI 1073) return(mbscanDefault[2].big);           
    if (address == UI 1074) return(mbscanDefault[3].big);            
    if (address == UI 1075) return(mbscanDiv[0].big);
    if (address == UI 1076) return(mbscanDiv[1].big);
    if (address == UI 1077) return(mbscanDiv[2].big);
    if (address == UI 1078) return(mbscanDiv[3].big);
    if (address == UI 1079) return(mbpulselevel.big);
    if ((address > UI 1099) && (address < UI 1174))// Repeater targets presently unused.... 
       return(0x00);
    return(0x99);   
}

/* Modbus Map 
ead with Modbus command 0x03
0   Unit 0  Bits 0-7 Digital Inputs, Bit 8 = COMM OK, Bit 9 = Enabled
1   Unit 0  Analog 1 
2   Unit 0  Analog 2 
3   Unit 0  Analog 3 
4   Unit 0  Analog 4 
5   Unit 0  Analog 5 
6   Unit 0  Analog 6 
7   Unit 0  Analog 7 
8   Unit 0  Analog 8 
9   Unit 0  DC Voltage
10  Unit 1  Bits 0-7 Digital Inputs, Bit 8 = COMM OK, Bit 9 = Enabled
11  Unit 1  Analog 1 
12  Unit 1  Analog 2 
13  Unit 1  Analog 3 
14  Unit 1  Analog 4 
15  Unit 1  Analog 5 
16  Unit 1  Analog 6 
17  Unit 1  Analog 7 
18  Unit 1  Analog 8 
19  Unit 1  DC Voltage
......  etc up to 
310 Unit 31 Bits 0-7 Digital Inputs, Bit 8 = COMM OK, Bit 9 = Enabled
311 Unit 31  Analog 1 
312 Unit 31  Analog 2 
313 Unit 31  Analog 3 
314 Unit 31  Analog 4 
315 Unit 31  Analog 5 
316 Unit 31  Analog 6 
317 Unit 31  Analog 7 
318 Unit 31  Analog 8 
319 Unit 31  DC Voltage

320 Unit  0 Relay 1 & 2 digital source byte, LS byte = Relay 1; MS 5 bits = source ID, LS 3 bits = source channel
321 Unit  0 Relay 3 & 4          "                 "
322 Unit  0 Relay 5 & 6          "                 "
323 Unit  0 Relay 7 & 8          "                 "
324 Unit  1 Relay 1 & 2 digital source byte, LS byte = Relay 1; MS 5 bits = source ID, LS 3 bits = source channel
325 Unit  1 Relay 3 & 4          "                 "
326 Unit  1 Relay 5 & 6          "                 "
327 Unit  1 Relay 7 & 8          "                 "
..... 
444 Unit 31 Relay 1 & 2          "                 "
445 Unit 31 Relay 3 & 4          "                 "
446 Unit 31 Relay 5 & 6          "                 "
447 Unit 31 Relay 7 & 8          "                 "

448 Unit  0 Analog 1 & 2 output source bytes, LS byte = Analog 1; MS 5 bits = source ID, LS 3 bits = source channel
449 Unit  0 Analog 3 & 4        "                   "
450 Unit  0 Analog 5 & 6        "                   "
451 Unit  0 Analog 7 & 8        "                   "
452 Unit  1 Analog 1 & 1        "                   "
....
572 Unit 31 Analog 1 & 2 output source bytes, LS byte = Analog 1; MS 5 bits = source ID, LS 3 bits = source channel
573 Unit 31 Analog 3 & 4        "                   "
574 Unit 31 Analog 5 & 6        "                   "
575 Unit 31 Analog 7 & 8        "                   "

576 Unit  1 Configuration Register. Bit 0 = 1 for enabled, 0 disabled. Bit 1 = 0 for normal, 1 for total control
577 Unit  2                     "                   "
....
607 Unit 31 Configuration Register. Bit 0 = 1 for enabled, 0 disabled
608 Configuration ID    0 - 31. 
609 Relay image
610 Network state. 2 = OK, 1 = Network down, this link OK, 0 = Lost comms. Read only.
611 Modbus ID 0 = none, 1 to 255 users ID. We also always respond to Modbus address RFSCADAID
612 Timeout in seconds before resetting to default state after loss of RF. Default = 10
613 Timeout in seconds before reverting to normal register update after Modbus override stops
614 Modbus silent time in mS. Handles breaks in packets caused by modems etc
615 Special program we are running, 0 = normal
616 Low tank level 0 - 1022
617 High tank level 1 - 1023
618 commfailoverride                    // Requires matching CFOKEY to activate       

619.....649   Repeater mode target.
619 Repeater target for Unit 1. 0 = repeater disabled for unit 1
620 Repeater target for Unit 2. 0 = repeater disabled for unit 2
621 Repeater target for Unit 3. 0 = repeater disabled for unit 3
622 Repeater target for Unit 4. 0 = repeater disabled for unit 4
623 Repeater target for Unit 5. 0 = repeater disabled for unit 5
624 Repeater target for Unit 6. 0 = repeater disabled for unit 6
625 Repeater target for Unit 7. 0 = repeater disabled for unit 7
626 Repeater target for Unit 8. 0 = repeater disabled for unit 8
627 Repeater target for Unit 9. 0 = repeater disabled for unit 9
628 Repeater target for Unit 10. 0 = repeater disabled for unit 10
629 Repeater target for Unit 11. 0 = repeater disabled for unit 11
630 Repeater target for Unit 12. 0 = repeater disabled for unit 12
631 Repeater target for Unit 13. 0 = repeater disabled for unit 13
632 Repeater target for Unit 14. 0 = repeater disabled for unit 14
633 Repeater target for Unit 15. 0 = repeater disabled for unit 15
634 Repeater target for Unit 16. 0 = repeater disabled for unit 16
635 Repeater target for Unit 17. 0 = repeater disabled for unit 17
636 Repeater target for Unit 18. 0 = repeater disabled for unit 18
637 Repeater target for Unit 19. 0 = repeater disabled for unit 19
638 Repeater target for Unit 20. 0 = repeater disabled for unit 20
639 Repeater target for Unit 21. 0 = repeater disabled for unit 21
640 Repeater target for Unit 22. 0 = repeater disabled for unit 22
641 Repeater target for Unit 23. 0 = repeater disabled for unit 23
642 Repeater target for Unit 24. 0 = repeater disabled for unit 24
643 Repeater target for Unit 25. 0 = repeater disabled for unit 25
644 Repeater target for Unit 26. 0 = repeater disabled for unit 26
645 Repeater target for Unit 27. 0 = repeater disabled for unit 27
646 Repeater target for Unit 28. 0 = repeater disabled for unit 28
647 Repeater target for Unit 29. 0 = repeater disabled for unit 29
648 Repeater target for Unit 30. 0 = repeater disabled for unit 30
649 Repeater target for Unit 31. 0 = repeater disabled for unit 31

650.....799   Repeater mode target for units 32 to 181.
650 Repeater target for Unit 32. 0 = repeater disabled for unit 32
651 Repeater target for Unit 33. 0 = repeater disabled for unit 33
.............
799 Repeater target for Unit 181 0 = repeater disabled for unit 181
 
800  
800 # Tx Packets from master. Write anything to clear all packet counts.
801 # good Rx Packets from ID 1
802 # good Rx Packets from ID 2
803 # good Rx Packets from ID 3
804 # good Rx Packets from ID 4
805 # good Rx Packets from ID 5
....
831 # good Rx Packets from ID 31

1000 Hop pattern 0-6; 0-9 for XTEnd
1001 Serial Number
1002 Physical Channels in unit
1003 Software version 12 = 1.2 etc
1004 EEPROM Fastest update rate 
1005 Run hours
1006 radiotype          Following for RadInt.....
1007 baudrate
1008 keyuptime
1009 keydowntime
1010 rs232gaptime
1011 transmitrate 
 
1100.....1173   Repeater mode targets for units 182 - 255.
1100 Repeater target for Unit 182. 0 = repeater disabled for unit 182
1101 Repeater target for Unit 183. 0 = repeater disabled for unit 183
ditto
1172 Repeater target for Unit 254. 0 = repeater disabled for unit 254
1173 Repeater target for Unit 255. 0 = repeater disabled for unit 255


3318 Write 1234 to restore to default settings. 
     Write 5678 to copy all settings to EEPROM
     Write 1638 to enable boot block programming (writes 0xFF to EEPROM 0x03FF)

*/

 

void AddModbusTxCRC(unsigned char ps)
{
unsigned char tempchar;
unsigned char temp;
unsigned char y;
union wordy crc;
unsigned int tempint;

    crc.big = 0xFFFF;
    for (temp = UC 0; temp < ps; temp++)
        {
        tempchar = rs232outbuffer[temp];
        tempint = tempchar;
        crc.big = crc.big ^ tempint;
        for (y = UC 0; y < UC 8; y++)
            {
            tempint = crc.big;
            crc.big = crc.big / UI 2;
            if (tempint & 1 == 1)
                crc.big = crc.big ^ 0xA001;
            }
         }
    rs232outbuffer[temp] = crc.byte[lo];
    temp++;
    rs232outbuffer[temp] = crc.byte[hi];
}

void RestartModbusRx(void)
{
unsigned char x;
    for (x = 0; x < UC 250; x++)
        rs232inbuffer[x] = 0x00;
    rs232inpointer = 0x00;
    rs232inbuffersize = 0x00;    
    oddbits.NEWRS232 = 0;
}

void UpdateAnalogs(void)               // Update and copy analog results to results array and modbus array
{                                      // Since 5.0 can now be any ID to 255, so no longer use analog array but rather res4ganas
unsigned int inty;
static unsigned char chan;
static unsigned char flowbit8;
static union wordy flow8;
unsigned char x;

    chan++; 
    if (chan > UC 10)		// channels analog in 1-8 , channel 9=dcvoltage , channel 10 = temperature
        chan = 1;
    if (unitschannels == UC 16)
        {
         if (chan < UC 9) AnalogInRF16(chan);
		   switch (chan) 
            {
            case 1:
         //       AnalogInRF16(1);
                if ((pulseenable & 0x01) == UC 0x01)
                    {
                    if (analog[chan-1].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS1)
                        {
                        pulsebits.PULS1 = x;
                        res4ganas[chan-1].big++;
                        if (res4ganas[chan-1].big > UI 4095)
                           res4ganas[chan-1].big = 0;
                        }
                    }
                else   
                    res4ganas[0].big = analog[0].big; 
                break;
            case 2:
//                AnalogInRF16(chan);
                if ((pulseenable & 0x02) == UC 0x02)
                    {
                    if (analog[chan-1].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS2)
                        {
                        pulsebits.PULS2 = x;
                        res4ganas[chan-1].big++;
                        if (res4ganas[chan-1].big > UI 4095)
                           res4ganas[chan-1].big = 0;
                        }
                    }
                else    
                    res4ganas[chan-1].big = analog[chan-1].big; 
                break;

            case 3:
//                AnalogInRF16(chan);
                if ((pulseenable & 0x04) == UC 0x04)
                    {
                    if (analog[chan-1].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS3)
                        {
                        pulsebits.PULS3 = x;
                        res4ganas[chan-1].big++;
                        if (res4ganas[chan-1].big > UI 4095)
                           res4ganas[chan-1].big = 0;
                        }
                    }
                else    
                    res4ganas[chan-1].big = analog[chan-1].big; 
                break;

            case 4:
//                   AnalogInRF16(chan);
                   if ((pulseenable & 0x08) == UC 0x08)
                        {
                        if (analog[chan-1].big > UI mbpulselevel.big)
                           x = 1;
                        else
                           x = 0;    
                        if (x != UC pulsebits.PULS4)
                           {
                           pulsebits.PULS4 = x;
                           res4ganas[chan-1].big++;
                           if (res4ganas[chan-1].big > UI 4095)
                              res4ganas[chan-1].big = 0;
                           }
                       }
                   else    
                       res4ganas[chan-1].big = analog[chan-1].big; 
                    //resanalog[inty][chan-1].big = analog[chan-1].big;    
                  break;
            
            case 5:
                if (mbscanID[0] != UC 0x00)     // If MB scanning is enabled override analog
                   res4ganas[chan-1].big = mbscanResult[0].big;
                else
                  {
//                  AnalogInRF16(chan);
                  if ((pulseenable & 0x10) == UC 0x10)
                       {
                     if (analog[chan-1].big > UI mbpulselevel.big)
                           x = 1;
                     else
                           x = 0;    
                     if (x != UC pulsebits.PULS5)
                           {
                           pulsebits.PULS5 = x;
                           res4ganas[chan-1].big++;
                           if (res4ganas[chan-1].big > UI 4095)
                              res4ganas[chan-1].big = 0;                           
                           }
                        }
                  else    
                     res4ganas[chan-1].big = analog[chan-1].big; 
                  }
                break;

            case 6:
                if (mbscanID[1] != UC 0x00)     // If MB scanning is enabled override analog
                    res4ganas[chan-1].big = mbscanResult[1].big;
//resanalog[inty][chan-1].big = mbscanResult[1].big;
                else
                {
//                AnalogInRF16(chan);
                if ((pulseenable & 0x20) == UC 0x20)
                    {
                    if (analog[chan-1].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS6)
                        {
                        pulsebits.PULS6 = x;
                        res4ganas[chan-1].big++;
                        if (res4ganas[chan-1].big > UI 4095)
                           res4ganas[chan-1].big = 0;  
                        }
                    }
                else    
                    res4ganas[chan-1].big = analog[chan-1].big; 
                }
                break;

            case 7:
                if (mbscanID[2] != UC 0x00)     // If MB scanning is enabled override analog
                   res4ganas[chan-1].big = mbscanResult[2].big; 
                  //resanalog[inty][chan-1].big = mbscanResult[2].big;
                else
                {
//                AnalogInRF16(chan);
                if ((pulseenable & 0x40) == UC 0x40)
                    {
                    if (analog[chan-1].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS7)
                        {
                        pulsebits.PULS7 = x;
                        res4ganas[chan-1].big++;
                        if (res4ganas[chan-1].big > UI 4095)
                           res4ganas[chan-1].big = 0;
                        }
                    }
                else    
                    res4ganas[chan-1].big = analog[chan-1].big; 
                }
                break;

            case 8:
                if (mbscanID[3] != UC 0x00)     // If MB scanning is enabled override analog
                    res4ganas[chan-1].big = mbscanResult[3].big;
                  // resanalog[inty][chan-1].big = mbscanResult[3].big;
                else
                {
//                AnalogInRF16(chan);
                if ((pulseenable & 0x80) == UC 0x80)
                    {
                    if (analog[chan-1].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS8)
                        {
                        pulsebits.PULS8 = x;
                        res4ganas[chan-1].big++;
                        if (res4ganas[chan-1].big > UI 4095)
                           res4ganas[chan-1].big = 0;
                        }
                    }
                else    
                    res4ganas[chan-1].big = analog[chan-1].big; 
                }
                break;

            case 9:	// dc voltage , channel AN0
                ADCON0 = 0x01;
                for (x = UC 0; x < UC 10; x++)
                    ;        
                ADCON0 = 0x03;
                while (ADCON0 & 0x02)
                    ;
                dcvoltage.byte[hi] = ADRESH;
                dcvoltage.byte[lo] = ADRESL;
  //              resanalog[inty][chan-1].big = dcvoltage.big;
                res4ganas[chan-1].big = dcvoltage.big;
                break;
            case 10: // pcb temperature , channel AN1
                ADCON0 = 0x05;
                for (x = UC 0; x < UC 10; x++)
                    ;        
                ADCON0 = 0x07;
                while (ADCON0 & 0x02)
                    ;
                pcbtemperature.byte[hi] = ADRESH;
                pcbtemperature.byte[lo] = ADRESL;
   //          resanalog[inty][chan-1].big = pcbtemperature.big;
                res4ganas[chan-1].big = pcbtemperature.big;
                break;
            case 11: // RSSI , channel AN2
                ADCON0 = 0x09;
                for (x = UC 0; x < UC 10; x++)
                    ;        
                ADCON0 = 0x0B;
                while (ADCON0 & 0x02)
                    ;
                RSSI.byte[hi] = ADRESH;
                RSSI.byte[lo] = ADRESL;
                //resanalog[inty][chan-1].big = RSSI.big;	// need to increase size of resanalog
                res4ganas[chan-1].big = RSSI.big;	// need to increase size of resanalog
                break;

            default:
                AnalogInRF16(chan);
                // SHOULD NEVER HAPPEN resanalog[inty][chan-1].big = analog[chan-1].big;    
                break;
            }
        }
    else 
    if (unitschannels == UC 42) // Swapped compared to the 16ch, which were already backwards
        {                       // Plus....temp & sig strength swapped to further confuse.... 
        switch (chan) 
            {
            case 1:
                AnalogInRF16(8);
                if ((pulseenable & 0x01) == UC 0x01)
                    {
                    if (analog[0].big > UI mbpulselevel.big)  // 350
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS1)
                        {
                        pulsebits.PULS1 = x;
                 //       resanalog[inty][0].big++;
                        res4ganas[0].big++;
                        if (res4ganas[0].big > UI 4095)
                           res4ganas[0].big++;
                   //     if (resanalog[inty][0].big > UI 1023)
                     //       resanalog[inty][0].big = 0;
                        }
                    }
                else  
                    res4ganas[0].big = analog[0].big;
//                    resanalog[inty][0].big = analog[0].big;    
            break;
            case 2:
                AnalogInRF16(7);
                if ((pulseenable & 0x02) == UC 0x02)
                    {
                    if (analog[1].big > UI mbpulselevel.big) 
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS2)
                        {
                        pulsebits.PULS2 = x;
                  //      resanalog[inty][1].big++;
                    //    if (resanalog[inty][1].big > UI 1023)
                      //      resanalog[inty][1].big = 0;
                        res4ganas[1].big++;
                        if (res4ganas[1].big > UI 4095)
                           res4ganas[1].big++;
                        }
                    }
                else    
                    res4ganas[1].big = analog[1].big;
                //    resanalog[inty][1].big = analog[1].big;    
            break;
            case 3:
                AnalogInRF16(6); 
                if ((pulseenable & 0x04) == UC 0x04)
                    {
                    if (analog[2].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS3)
                        {
                        pulsebits.PULS3 = x;
                 //       resanalog[inty][2].big++;
                   //     if (resanalog[inty][2].big > UI 1023)
                     //       resanalog[inty][2].big = 0;
                        res4ganas[2].big++;
                        if (res4ganas[2].big > UI 4095)
                           res4ganas[2].big++;
                        }
                    }
                else  
                    res4ganas[2].big = analog[2].big;
//                    resanalog[inty][2].big = analog[2].big;    
            break;
            case 4:
                AnalogInRF16(5);
                if ((pulseenable & 0x08) == UC 0x08)
                    {
                    if (analog[3].big > UI mbpulselevel.big)
                        x = 1;
                    else
                        x = 0;    
                    if (x != UC pulsebits.PULS4)
                        {
                        pulsebits.PULS4 = x;
             //           resanalog[inty][3].big++;
               //         if (resanalog[inty][3].big > UI 1023)
                 //           resanalog[inty][3].big = 0;
                        res4ganas[3].big++;
                        if (res4ganas[3].big > UI 4095)
                           res4ganas[3].big++;
                        }
                    }
                else    
                    res4ganas[3].big = analog[3].big;
//                    resanalog[inty][3].big = analog[3].big;     
            break;
            case 5:                         // Unused
                if (mbscanID[0] != UC 0x00)     // If MB scanning is enabled override analog
                 res4ganas[4].big = mbscanResult[0].big;
//                 resanalog[inty][4].big = mbscanResult[0].big;
                else
                   res4ganas[4].big = 0;
//                 resanalog[inty][4].big = 0;    
            break;

            case 6:                         // Signal strength
                 if (mbscanID[1] != UC 0x00)     // If MB scanning is enabled override analog
                   res4ganas[5].big = mbscanResult[1].big;
                 else
                    {                    
                    AnalogInRF16(2);
                    res4ganas[5].big = analog[6].big;    
                    } 
            break;
            case 7:                         // Temperature
                 if (mbscanID[2] != UC 0x00)     // If MB scanning is enabled override analog
                   res4ganas[6].big = mbscanResult[2].big;
                else
                    {                    
                    AnalogInRF16(3);
                    res4ganas[6].big = analog[5].big;   
                    } 
             break;  
          
            case 8:
                  if (mbscanID[3] != UC 0x00)     // If MB scanning is enabled override analog
                   res4ganas[7].big = mbscanResult[3].big;
                else
                   res4ganas[7].big = dcvoltage.big; // For 4 channel can use an8 for DC Voltage   
            break;
                       
            case 9:
                AnalogInRF16(4);
                dcvoltage.big = analog[4].big;
       //         resanalog[inty][8].big = dcvoltage.big;    
                res4ganas[8].big = dcvoltage.big;    
            break;         

            default:
                break;
            }
        }
    else //unitschannel== 4 or 8
        {
        Analog(chan);
        if (chan < UC 10)   // There is no chan '10' for 4/8 chan boards
            {
            if (chan == UC 9) 
                resanalog[inty][chan-1].big = dcvoltage.big;    
            else
                {  
//                resanalog[inty][chan-1].big = analog[chan-1].big;    
                res4ganas[chan-1].big = analog[chan-1].big;    // repeat this for 42 & 16 chan ver above   
                }
            }
        }
   resanalog[0][0].big = res4ganas[0].big;
   resanalog[0][1].big = res4ganas[1].big;
   resanalog[0][2].big = res4ganas[2].big;
   resanalog[0][3].big = res4ganas[3].big;
   resanalog[0][4].big = res4ganas[4].big;
   resanalog[0][5].big = res4ganas[5].big;
   resanalog[0][6].big = res4ganas[6].big;
   resanalog[0][7].big = res4ganas[7].big;
   resanalog[0][8].big = res4ganas[8].big;
}


void AnalogInRF16(unsigned char chan)        // Now 12 bit res
{
unsigned char pcbchan;                       // chan = 1-8 , need to reverse the channels because of hardware layout.
   pcbchan = 8 - chan;
   PORTFbits.RF3 = 0;                        // Select chip
   if ((chan-1) < UC 4)                      // 3.3 fix
      SPITransmit(0x06);                     // clears d2bit and starts conversion
   else
      SPITransmit(0x07);                     // sets d2 bit and starts conversion
   analog[pcbchan].byte[hi] = SPITransmit((chan-1) << UC 6);	// read high nibble bits 11-8
   analog[pcbchan].byte[hi] &= 0x0F;
   analog[pcbchan].byte[lo] = SPITransmit(0x00);    // read low byte bits 7-0
   analog[pcbchan].big = analog[pcbchan].big & 0x0FFF; //  >> 2; // analog[pcbchan].big /= 4 (convert 12bit to 10bit reading) V5.1 12 bit
   PORTFbits.RF3 = 1;               
}



void Analog(unsigned char chan)
{
unsigned char x;
//unsigned char test;

    switch(chan)
    {
    case 1:
        {
        ADCON0 = 0x01;
        for (x = UC 0; x < UC 10; x++)
            ;        
        ADCON0 = 0x03;
        while (ADCON0 & 0x02)
            ;
        analog[0].byte[hi] = ADRESH;
        analog[0].byte[lo] = ADRESL;
        break;
        }
    case 2:
        {
        ADCON0 = 0x05;
        for (x = UC 0; x < UC 10; x++)
            ;        
        ADCON0 = 0x07;
        while (ADCON0 & 0x02)
            ;
        analog[1].byte[hi] = ADRESH;
        analog[1].byte[lo] = ADRESL;
        break;
        }
    case 3:
        {
        ADCON0 = 0x09;
        for (x = UC 0; x < UC 10; x++)
            ;        
        ADCON0 = 0x0B;
        while (ADCON0 & 0x02)
            ;
        analog[2].byte[hi] = ADRESH;
        analog[2].byte[lo] = ADRESL;
        break;
        }
    case 4:
        {
        if (unitschannels == UC 8)      // 8 chan, chan4 = RA3
            {
            ADCON0 = 0x0D;
            for (x = UC 0; x < UC 10; x++)
                ;        
            ADCON0 = 0x0F;
            while (ADCON0 & 0x02)
                ;
            analog[3].byte[hi] = ADRESH;
            analog[3].byte[lo] = ADRESL;
            }
        else
            {                           // 4 chan, chan4 = RA5 
            ADCON0 = 0x11;
            for (x = UC 0; x < UC 10; x++)
                ;        
            ADCON0 = 0x13;
            while (ADCON0 & 0x02)
                ;
            analog[3].byte[hi] = ADRESH;
            analog[3].byte[lo] = ADRESL;
            }
        break;
        }

    case 5:
        {
        if (unitschannels == UC 8)      // 8 chan, chan5 = RA5
            {
            ADCON0 = 0x11;
            for (x = UC 0; x < UC 10; x++)
                ;        
            ADCON0 = 0x13;
            while (ADCON0 & 0x02)
                ;
            analog[4].byte[hi] = ADRESH;
            analog[4].byte[lo] = ADRESL;
            }
        else
            {                           // 4 chan, chan5 = non existant
            analog[4].byte[hi] = 0x00;
            analog[4].byte[lo] = 0x00;
            }    
        break;
        }    

    case 6:                             // on 4 chan is extend sig. strength
        {
        ADCON0 = 0x15;
        for (x = UC 0; x < UC 10; x++)
            ;        
        ADCON0 = 0x17;
        while (ADCON0 & 0x02)
            ;
        analog[5].byte[hi] = ADRESH;
        analog[5].byte[lo] = ADRESL;
        break;
        }
    case 7:                             // on 4 chan is temperature
        {
        ADCON0 = 0x19;
        for (x = UC 0; x < UC 10; x++)
            ;        
        ADCON0 = 0x1B;
        while (ADCON0 & 0x02)
            ;
        analog[6].byte[hi] = ADRESH;
        analog[6].byte[lo] = ADRESL;
        break;
        }
    case 8:
        {
        ADCON0 = 0x1D;
        for (x = UC 0; x < UC 10; x++)
            ;        
        ADCON0 = 0x1F;
        while (ADCON0 & 0x02)
            ;
        analog[7].byte[hi] = ADRESH;
        analog[7].byte[lo] = ADRESL;
        break;
        }

    case 9:
        {
        ADCON0 = 0x21;
        for (x = UC 0; x < UC 10; x++)
            ;        
        ADCON0 = 0x23;
        while (ADCON0 & 0x02)
            ;
        dcvoltage.byte[hi] = ADRESH;
        dcvoltage.byte[lo] = ADRESL;
        break;
        }
    default:
        break;
    }
}

//**************** Following all Poll Device Code    *********/

void PollDevices()                     // Sequencially polls devices per config table.      
{
static unsigned char pollstate;
unsigned char x;
unsigned int i;
static unsigned char enabletime; 
static signed char dev;
   if (pollstate > UC 1) pollstate = 0;   // Keep in range
   if ((pollstate == UI 0)&&              // First stage, select dev, set up serial port, build packet 
       (mbscanpolltimer == UC 0x00))      // and its time....
      {                    
         dev = GetNextEnabledDevice(dev);
         if (dev >= 0)           // If an enabled device found advance through state machine, otherwise
            {                    // we will try to find enabled device next time PollDevices() is called
            x = mbscanBaud[dev];
            if (x < UC BAUD1200) x = BAUD9600;                    // Must prevent baud rates of zero 
            if (x > UC BAUD19200) x = BAUD9600;                   // Must prevent baud rates of zero 
            switch(x)                                          // Set tx driver enable time
               {
               case BAUD1200: enabletime = 10; break;
               case BAUD2400: enabletime = 6; break;
               case BAUD4800: enabletime = 4; break;
               case BAUD9600: enabletime = 3; break;
               case BAUD19200: enabletime = 2; break;
               default:    enabletime = 3; break;
               }
            InitUsart1(x);
            EnableUsart1();              
            AssembleDevicePacket(dev);
            RestartModbusRx();                               // In case something came we did not expect clear input buff              
 //           rs232outpointer = 0x00;                          // Start transmitting
            PORTCbits.RC0 = 1;  // enable RS485 TX
            if ((unitschannels == UC 16) || (unitschannels == UC 42)) 
               PORTFbits.RF0 = 0;				                // Green led on;
//            TXREG1 = rs232outbuffer[rs232outpointer];
//            rs232outpointer++;
            timer[TX1485TIMER] = enabletime;                 // Backup timer in case we miss transmit interrupt for some reason         
            i = mbscanPollTime[dev];                         // Get post poll delay......
            if (i == UI 0) i = 5;                            // in 100mS increments? 
            if (i > UI 50) i = 50;
            timer[POSTPOLLTIM] = 100 * i;                    // load timer with it
            pollstate = 1;                                   // Move to next state
            }
      }
   if (pollstate == UI 1)  // Third stage, stay in this state until post-poll timer expires 
      {
      if (timer[POSTPOLLTIM] == UI 0000)                  // Waited long enough?
         {
         CheckDeviceData(dev);                            // See if any good data came back 
         pollstate = 0;                                   // Restart sequence
         mbscanpolltimer = mbscanRate;                    // set up next poll....
         }
      }
}

void AssembleDevicePacket(signed char device)   // Builds a packet for the next lucky device
{
union wordy bignum;
unsigned char x;
   
   if (device < 4)
      {
      x = mbscanID[device];                                 // Get requested MB ID......
      rs232outbuffer[0] = x;                                // Modbus ID
      x = mbscanFunc[device];                               // Get requested MB ID......
      rs232outbuffer[1] = x;                                // Modbus ID
      bignum.big = mbscanReg[device].big;                   // Get requested MB start address...
      rs232outbuffer[2] = bignum.byte[hi]; 
      rs232outbuffer[3] = bignum.byte[lo]; 
      rs232outbuffer[4] = 0x00;                             // Load # of regs....
      rs232outbuffer[5] = 0x01;                             // Single 16 bit reg? 
//      comm2txbuffer[5] = 0x02;                            // 2x 16 bit registers         
      AddModbusTxCRC(6);
      rs232outbuffersize = 7;
      rs232outpointer = 0x00;         // Start transmitting
		PIE1bits.TX1IE = 1; 			
      }
}


void CheckDeviceData(signed char d)                      // 
{
unsigned char x, conf;
union wordy bignum;
   if (d > 3)
      return;
   x = CheckModbusRxCRC();                      // It will figure out packetsize from pointer value
   if (x == UC 0)                               // Good C/S - but could still be an unexpected packet so check
      {
      if ((rs232inbuffer[0] == mbscanID[d]) &&   // Reply has correct MB ID?
          (rs232inbuffer[1] == mbscanFunc[d]))  // Reply has correct MB function?
         {
         if (rs232inbuffer[2] == UC 2)          // Single 16 bit reg and reply has correct # of bytes?
            {
            bignum.byte[hi] = rs232inbuffer[3];      
            bignum.byte[lo] = rs232inbuffer[4];      
            mbscanResult[d].big = bignum.big;
            if (mbscanDiv[d].big != UI 0x00)
               {
               mbscanResult[d].big = mbscanResult[d].big / mbscanDiv[d].big; 
               }
            mbscanDOTimers[d] = UI 10 * mbscanDOTime[d];  // Reload conmm fail timer
            }
/*
         if (((conf == 1) || (conf == 2)) && (rs232inbuffer[2] == 4)) // 2 x 16 bit regs and reply has correct # of bytes?
            {
            bignum.byte[hi] = rs232inbuffer[3];      
            bignum.byte[lo] = rs232inbuffer[4];      
            mbRam[(2 * d)] = UI bignum.big;                              // Store result 1st word, usually high word
            bignum.byte[hi] = rs232inbuffer[5];      
            bignum.byte[lo] = rs232inbuffer[6];      
            mbRam[(2 * d) + 1] = UI bignum.big;                          // Store 2nd word, usually low word
            devtimers[d] = 10 * GetModbusRegister(MBCONFIGTABLE + (32 * d) + DEVDROPOUT);  // Reload conmm fail timer
            }
*/
         }
      }
}



signed char GetNextEnabledDevice(signed char x)   //  Returns 0 to 127 for enabled device, -1 if none found
{
int y;
   y = 0;
   while(y <= 3)                                    // 4 devices 0 to 3 max
      {
      x++;
      if (x > 3) x = 0;
      if (mbscanID[x] != UC 0x00)                  // MB ID of zero means disabled
         return(x);                                // return 0-3 for enabled
      y++;
      if (y >= 4)                                  // Must have gone thru them all, none enabled
         return(-1);   
      }
	return -1;
}


