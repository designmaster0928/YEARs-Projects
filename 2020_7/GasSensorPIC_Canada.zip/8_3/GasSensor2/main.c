/**
  Generated main.c file from MPLAB Code Configurator

  @Company
    Microchip Technology Inc.

  @File Name
    main.c

  @Summary
    This is the generated main.c using PIC24 / dsPIC33 / PIC32MM MCUs.

  @Description
    This source file provides main entry point for system initialization and application code development.
    Generation Information :
        Product Revision  :  PIC24 / dsPIC33 / PIC32MM MCUs - 1.167.0
        Device            :  PIC24FJ1024GA606
    The generated drivers are tested against the following:
        Compiler          :  XC16 v1.50
        MPLAB 	          :  MPLAB X v5.35
*/

/*
    (c) 2020 Microchip Technology Inc. and its subsidiaries. You may use this
    software and any derivatives exclusively with Microchip products.

    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED
    WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS FOR A
    PARTICULAR PURPOSE, OR ITS INTERACTION WITH MICROCHIP PRODUCTS, COMBINATION
    WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION.

    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE,
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP HAS
    BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE
    FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN
    ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT OF FEES, IF ANY,
    THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.

    MICROCHIP PROVIDES THIS SOFTWARE CONDITIONALLY UPON YOUR ACCEPTANCE OF THESE
    TERMS.
*/

/**
  Section: Included Files
*/
#include "mcc_generated_files/mcc.h"
#include "libpic30.h"
#include <stdbool.h> 
#include <stdio.h>

// Uart-Sensor information //
    // Uart1 - O2 Sensor 
    // Uart2 - CD Sensor
    // Uart3 - ME Sensor
    // Uart4 - Spare Sensor
    // Uart5 - Upstream
    // Uart6 - Downstream

// Uart Data format

    // Master command format: X(Board number:1~3)-X(Sensor number:1~4)-Q(Status:S/Calibrate:C) : ex; 1-1-S
    // Slave response: 
            // O2 Sensor;     "X-X-O2:XXX.XPPM-T:XX.XC-P:XXX.X-OK"
            // INIR Sensor;   "X-X-CD/ME:XXX.XPPM-T:XX.XC-CRC:XXX.X-OK"

volatile unsigned char rx1[100]={0}, bufferfull=0, buffersize=0, i=0, j=0;
bool data_started_flag = false;
bool data_ended_flag = false;

uint16_t sensor_data = 0;
double sensor_temp = 0;

unsigned char hex_equiv[6]={10,11,12,13,14,15};

unsigned char szTemp[20] = "";

uint32_t count=0;

static char slave_number=1;

char Ascii_Hex(char data_ascii) // O2 sensor
{
    if ((data_ascii >= 0x30) && (data_ascii <= 0x39))
    {
        data_ascii -= 0x30; // ASCII code for "0"
    }
    else if ((data_ascii >= 0x61)&&(data_ascii <= 0x66))
    {
        data_ascii = hex_equiv[data_ascii - 0x61]; // Find which hex equivalent is the data we have received
    }
    return data_ascii;
}

char UART1_Read1(void) // O2 sensor
{
    while(!(U1STAbits.URXDA == 1))
    {

    }

    if ((U1STAbits.OERR == 1))
    {
        U1STAbits.OERR = 0;
    }

    return U1RXREG;
}

char UART2_Read1(void)    // ME sensor
{
    while(!(U2STAbits.URXDA == 1))
    {

    }

    if ((U2STAbits.OERR == 1))
    {
        U2STAbits.OERR = 0;
    }

    return U2RXREG;
}

char UART3_Read1(void)    // spare sensor(CD)
{
    while(!(U3STAbits.URXDA == 1))
    {

    }

    if ((U3STAbits.OERR == 1))
    {
        U3STAbits.OERR = 0;
    }

    return U3RXREG;
}

char UART4_Read1(void) // Up stream
{
    while(!(U4STAbits.URXDA == 1))
    {

    }

    if ((U4STAbits.OERR == 1))
    {
        U4STAbits.OERR = 0;
    }

    return U4RXREG;
}

char UART5_Read1(void) // Up stream
{
    while(!(U5STAbits.URXDA == 1))
    {

    }

    if ((U5STAbits.OERR == 1))
    {
        U5STAbits.OERR = 0;
    }

    return U5RXREG;
}

char UART6_Read1(void) // Up stream
{
    while(!(U6STAbits.URXDA == 1))
    {

    }

    if ((U6STAbits.OERR == 1))
    {
        U6STAbits.OERR = 0;
    }

    return U6RXREG;
}

void UART1_Write1(char data)    // spare sensor(CD)
{
    while (U1STAbits.UTXBF == 1)
    {
        
    }   
    U1TXREG = data;
}

void UART1WriteString( uint8_t *str )
{
    uint8_t c;
    while( (c = *str++) )
    UART1_Write1(c);
}

void UART5_Write1(char data)    // spare sensor(CD)
{
    while (U5STAbits.UTXBF == 1)
    {
        
    }   
    U5TXREG = data;
}

void UART5WriteString( uint8_t *str )
{
    char c;
    while( (c = *str++) )
    UART5_Write1(c);
}

void UART6_Write1(char data)    // spare sensor(CD)
{
    while (U6STAbits.UTXBF == 1)
    {
        
    }   
    U6TXREG = data;
}

void UART6WriteString( uint8_t *str )
{
    char c;
    while( (c = *str++) )
    UART6_Write1(c);
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U1RXInterrupt( void )
{
 
    IFS0bits.U1RXIF = 0;   
    
    rx1[i] = UART1_Read1();
    
    if(data_started_flag == false)
    {
        if(rx1[i]=='O')
        {
            data_started_flag = true;
            i=0;        
        }
        else
        {
            i++; 
        }  
    }    
    else
    {
        if(rx1[i]==0x0A)
        {   
            data_ended_flag = true;
            buffersize=i+1;
            i=0;           
        }
        else
        {
            i++;   
        }
    } 
      
   
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U2RXInterrupt( void )
{
    
    //(*UART1_RxDefaultInterruptHandler)();

    IFS1bits.U2RXIF = 0;
    
    rx1[i] = UART2_Read1();
    
    if(data_started_flag == false)
    {
        if(rx1[i]=='b')
        {   
            if(rx1[i-1]=='5')
            {
                data_started_flag = true;
                i=0;
            }
        }
        else
        {
            i++; 
        }    
    }    
    else
    {
        if(rx1[i]=='d')
        {   
            if(rx1[i-1]=='5')
            {
                data_ended_flag = true;
                buffersize=i+1;
                i=0;
            }
        }
        else
        {
            i++;   
        }
    }
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U3RXInterrupt( void )
{
    
    //(*UART1_RxDefaultInterruptHandler)();

    IFS5bits.U3RXIF = 0;
    
    rx1[i] = UART3_Read1();   
    
   
    if(data_started_flag == false)
    {
        if(rx1[i]=='b')
        {   
            if(rx1[i-1]=='5')
            {
                data_started_flag = true;
                i=0;
            }
        }
        else
        {
            i++; 
        }    
    }    
    else
    {
        if(rx1[i]=='d')
        {   
            if(rx1[i-1]=='5')
            {
                data_ended_flag = true;
                buffersize=i+1;
                i=0;
            }
        }
        else
        {
            i++;   
        }
    }
	

    
	
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U4RXInterrupt( void )
{
    
    //(*UART1_RxDefaultInterruptHandler)();

    IFS5bits.U4RXIF = 0;
    
    rx1[i] = UART4_Read1();
    
    if(data_started_flag == false)
    {
        if(rx1[i]=='b')
        {   
            if(rx1[i-1]=='5')
            {
                data_started_flag = true;
                i=0;
            }
        }
        else
        {
            i++; 
        }    
    }    
    else
    {
        if(rx1[i]=='d')
        {   
            if(rx1[i-1]=='5')
            {
                data_ended_flag = true;
                buffersize=i+1;
                i=0;
            }
        }
        else
        {
            i++;   
        }
    }
	
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U5RXInterrupt( void )
{
    IFS6bits.U5RXIF = 0;
    rx1[i] = UART5_Read1();
    
    if(rx1[i]==0x0A)
    {   
        data_ended_flag = true;
        buffersize=i+1;
        i=0;
       
    }
    else
    {
        i++;   
    }
  
}

void __attribute__ ( ( interrupt, no_auto_psv ) ) _U6RXInterrupt( void )
{
    IFS7bits.U6RXIF = 0;    
    rx1[i] = UART6_Read1();
    
    if(rx1[i]==0x0A)
    {   
        data_ended_flag = true;
        buffersize=i+1;        
        i=0;
       
    }
    else
    {
        i++;   
    }
}

void O2_Sensor_Interface(void)
{
  
  //UART1_Write1(0x4D);
  //UART1_Write1(0x20);  
  //UART1_Write1(0x31);
 // UART1_Write1(0x0D);
 // UART1_Write1(0x0A);

  IEC0bits.U1RXIE = 1;
  while((data_ended_flag == false)&&(count<600000)){count++;}
  IEC0bits.U1RXIE = 0;
            
  if(count>=600000)
  {
        UART5WriteString("1-1: There is no Sensor...\r\n");
        count=0;
  }
    
  
  UART5WriteString("1-1: ");
  
  for(j=0; j<buffersize; j++)
  {
    UART5_Write(rx1[j]);
  }      
    
  data_started_flag = false;
  data_ended_flag = false;
  
  for(j=0; j<buffersize; j++)
  {
    rx1[j]=0;
  }
  buffersize=0;
  
  //UART5WriteString("KK\r\n"); 
    
}

void INIR_Sensor1_Interface(void)
{
    IEC1bits.U2RXIE = 1;
    while((data_ended_flag == false)&&(count<600000)){count++;}
    IEC1bits.U2RXIE = 0;
            
    if(count>=600000)
    {
        UART5WriteString("1-2: There is no Sensor...\r\n");
        count=0;
    }
    
    
    for(j=6; j<10; j++)
    {        
        sensor_data = (sensor_data << 4) + Ascii_Hex(rx1[j]);    

    } 
    
    
    sprintf ( (char*)szTemp, "%d\n\r", sensor_data );
    UART5WriteString("1-2: ME-");
    UART5WriteString(szTemp);
    UART5WriteString(" PPM");
    
    
    for(j=26; j<30; j++)
    {
       sensor_data = (sensor_data << 4) + Ascii_Hex(rx1[j]);        
    
    }
    sensor_temp=(sensor_data/10)-273.1;
    sprintf ( (char*)szTemp, "%.1f\n\r", sensor_temp );
    UART5WriteString("  T-");
    UART5WriteString(szTemp);
    UART5WriteString(" C\r\n");     
    
    data_started_flag = false;
    data_ended_flag = false;
    
    for(j=0; j<buffersize; j++)
    {
        rx1[j]=0;
    }
    buffersize=0;
       
}

void INIR_Sensor2_Interface(void)
{
    IEC5bits.U3RXIE = 1;
    while((data_ended_flag == false)&&(count<600000)){count++;}
    IEC5bits.U3RXIE = 0;
            
    if(count>=600000)
    {
        UART5WriteString("1-3: There is no Sensor...\r\n");
        count=0;
    }
      
    
    data_started_flag = false;
    data_ended_flag = false;  
    
    for(j=6; j<10; j++)
    {
        sensor_data = (sensor_data << 4) + Ascii_Hex(rx1[j]);
     
    }    
    
    sprintf ( (char*)szTemp, "%d\n\r", sensor_data );
    UART5WriteString("1-3: CD-");
    UART5WriteString(szTemp);
    UART5WriteString(" PPM");
    
    
    for(j=26; j<30; j++)
    {
        sensor_data = (sensor_data << 4) + Ascii_Hex(rx1[j]);     
    
    }
    sensor_temp=(sensor_data/10)-273.1;
    sprintf ( (char*)szTemp, "%.1f\n\r", sensor_temp );
    UART5WriteString("  T-");
    UART5WriteString(szTemp);
    UART5WriteString(" C\r\n");    
    
    data_started_flag = false;
    data_ended_flag = false;
    
    for(j=0; j<buffersize; j++)
    {
        rx1[j]=0;
    }
    buffersize=0;
    
}

void INIR_Sensor3_Interface(void)
{
    IEC5bits.U4RXIE = 1;  

    while((data_ended_flag == false)&&(count<600000)){count++;}
    IEC5bits.U4RXIE = 0;
            
    if(count>=600000)
    {
        UART5WriteString("1-4: There is no Sensor...\r\n");
        count=0;
    }
    
    
    for(j=6; j<10; j++)
    {
        sensor_data = (sensor_data << 4) + Ascii_Hex(rx1[j]);
     
    } 
 
    sprintf ( (char*)szTemp, "%d\n\r", sensor_data );
    UART5WriteString("1-4: ME-");
    UART5WriteString(szTemp);
    UART5WriteString(" PPM");
    
    for(j=26; j<30; j++)
    {    
        sensor_data = (sensor_data << 4) +Ascii_Hex(rx1[j]);       
         
    }
    sensor_temp=(sensor_data/10)-273.1;
    sprintf ( (char*)szTemp, "%.1f\n\r", sensor_temp );
    UART5WriteString("  T-");
    UART5WriteString(szTemp);
    UART5WriteString(" C\r\n");   
    
    data_started_flag = false;
    data_ended_flag = false;
    
    for(j=0; j<buffersize; j++)
    {
        rx1[j]=0;
    }
    buffersize=0;
    
}

void Device_Initializing(void)
{
    __delay32(400000); // delay in instruction cycles: 100ms delay   
    
    UART5WriteString("Device Initializing...\r\n");    
    
}

int main(void)
{
    SYSTEM_Initialize();
    Device_Initializing();    
    
    while (1)
    {
        
        IEC6bits.U5RXIE = 1;
        while(data_ended_flag == false){}
        IEC6bits.U5RXIE = 0;
        
        data_started_flag = false;
        data_ended_flag = false; 
        
        IEC7bits.U6RXIE = 1; 
        
        if(rx1[0]==0x31)
        {
            switch(rx1[2])
            {
                case 0x31:
                    O2_Sensor_Interface();
                    break;
                case 0x32:
                    INIR_Sensor1_Interface();
                    break;
                case 0x33:
                    INIR_Sensor2_Interface();
                    break;
                case 0x34:
                    INIR_Sensor3_Interface();
                    break;
                default:
                    break;
            } 
        }
        else if(rx1[0]>0x31)
        {
            
            rx1[0]=- 1;
            for(j=0; j<buffersize; j++)
            {
                UART6_Write(rx1[j]);
            }
            
            data_started_flag = false;
            data_ended_flag = false; 
            buffersize=0;
            
            while((data_ended_flag == false)&&(count<600000)){count++;}
            IEC7bits.U6RXIE = 0;
            
            if(count>=600000)
            {
                UART5WriteString("2-There is no Sensor Board...\r\n");
                count=0;
            }
            
        
            rx1[0]=+ 1;
            for(j=0; j<buffersize; j++)
            {
                UART5_Write(rx1[j]);
            }

            data_started_flag = false;
            data_ended_flag = false; 
            buffersize=0;
            
            
        }
        else
        {
                
        }
        
    }

    return 1;
}


