input_image=imread('lena512.bmp');

% input_image = rgb2gray(input_image1);

% input_image=imnoise(input_image1,'speckle',.01);

figure;

imshow(input_image);

n=input('enter the decomposition level=');

[Lo_D,Hi_D,Lo_R,Hi_R] = wfilters('haar');

[c,s]=wavedec2(input_image,n,Lo_D,Hi_D);

disp(' the decomposition vector Output is');

%disp(c);

[thr,nkeep] = wdcbm2(c,s,1.5,3*prod(s(1,:)));

 [compressed_image,TREED,comp_ratio,PERFL2] =wpdencmp(thr,'s',n,'haar','threshold',5,1);

 disp('compression ratio in percentage');

 disp(comp_ratio);

 re_ima1 = waverec2(c,s,'haar'); 

 re_ima=uint8(re_ima1);
 
 
%  colormap(gray(255))
% 
%  subplot(1,3,1);
% 
%  image(input_image);
% 
%  title('input image');
%  axis square
% 
%  subplot(1,3,2);
% 
%  image(compressed_image);
% 
%  title('compressed image');
%  axis square
% 
%  subplot(1,3,3);
% 
%  image(re_ima);
% 
%  title('reconstructed image');
%  axis square