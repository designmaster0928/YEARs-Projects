clc, clear all;
load mask;     
X = imread('lena512.bmp');
[cratio,bpp] = wcompress('c',X,'lena512.wtc','spiht','maxloop',8)

Xc = wcompress('u','lena512.wtc')
delete('lena512.wtc')


colormap(gray(255))
subplot(1,2,1)
image(X)
title('Original image')
axis square
subplot(1,2,2)
image(Xc)
title('Compressed image')
axis square


D = abs(double(X)-double(Xc)).^2;
mse  = sum(D(:))/numel(X)

psnr = 10*log10(255*255/mse)
