# spiht-image-compression
Image Compression Using SPIHT Algorithm.


![spiht gui](https://github.com/SanRam/spiht-image-compression/blob/master/GUI_Spiht_Working/pic.jpg "GUI SPIHT")
