Image Compression Using SPIHT Compression.

Needed software:
Matlab R2013.

How to run:

1. Run GUI_Spiht_working.m file.
2. Use GUI and give necessary parameter
3. Results are obtained in GUI.
4. Compressed file is in same folder with image name with parameters.


