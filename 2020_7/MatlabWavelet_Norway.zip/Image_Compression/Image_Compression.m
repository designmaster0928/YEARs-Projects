clc, clear all;
load mask;     
X1 = imread('hund.jpg');
X =imresize(X1,[512 512]);   

n = size(X,1);
n_log = log2(n); 
level = n_log;

[cratio,bpp] = wcompress('c',X,'CompressX.wtc','spiht','wname','bior4.4','level',level,'maxloop',10);
Xc_1 = wcompress('u','CompressX.wtc');
delete('CompressX.wtc');

[cratio,bpp] = wcompress('c',X,'CompressX.wtc','wdr','wname','bior4.4','level',level,'maxloop',10);
Xc_2 = wcompress('u','CompressX.wtc');
delete('CompressX.wtc');

[cratio,bpp] = wcompress('c',X,'CompressX.wtc','aswdr','wname','bior4.4','level',level,'maxloop',10);
Xc_3 = wcompress('u','CompressX.wtc');
% delete('CompressX.wtc');
% 
% [cratio,bpp] = wcompress('c',X,'CompressX.wtc','spiht','wname','bior4.4','level',level,'maxloop',8);
% Xc_4 = wcompress('u','CompressX.wtc');
% delete('CompressX.wtc');
% 
% [cratio,bpp] = wcompress('c',X,'CompressX.wtc','spiht','wname','bior4.4','level',level,'maxloop',10);
% Xc_5 = wcompress('u','CompressX.wtc');
% delete('CompressX.wtc');
% 
colormap(gray(255))
subplot(1,6,1)
image(X)
title('Original image')
axis square

subplot(1,6,2)
image(Xc_1)
title('Compressed image(spiht)')
axis square

subplot(1,6,3)
image(Xc_2)
title('Compressed image(wdr)')
axis square

subplot(1,6,4)
image(Xc_3)
title('Compressed image(aswdr)')
axis square
% 
% subplot(1,6,5)
% image(Xc_4)
% title('Compressed image(loop=11)')
% axis square
% 
% subplot(1,6,6)
% image(Xc_5)
% title('Compressed image(loop=12)')
% axis square
% 
D_1 = abs(double(X)-double(Xc_1)).^2;
mse_1  = sum(D_1(:))/numel(X)
psnr_1 = 10*log10(255*255/mse_1)

D_2 = abs(double(X)-double(Xc_2)).^2;
mse_2  = sum(D_2(:))/numel(X)
psnr_2 = 10*log10(255*255/mse_2)

D_3 = abs(double(X)-double(Xc_3)).^2;
mse_3  = sum(D_3(:))/numel(X)
psnr_3 = 10*log10(255*255/mse_3)
% 
% D_4 = abs(double(X)-double(Xc_4)).^2;
% mse_4  = sum(D_4(:))/numel(X)
% psnr_4 = 10*log10(255*255/mse_4)
% 
% D_5 = abs(double(X)-double(Xc_5)).^2;
% mse_5  = sum(D_5(:))/numel(X)
% psnr_5 = 10*log10(255*255/mse_5)
