function func_SPIHT_Main
% Matlab implementation of SPIHT (without Arithmatic coding stage)
%
% Main function 
%
% input:    Orig_I : the original image.
%           rate : bits per pixel
% output:   img_spiht 

load mask;     
X = imread('lena512.bmp');
[cratio,bpp] = wcompress('c',X,'lena512.wtc','spiht','maxloop',8)

Xc = wcompress('u','lena512.wtc');
%delete('lena512.wtc')

fprintf('done!\n');

fprintf('-----------   Decoding   ----------------\n');
img_dec = func_SPIHT_Dec();

fprintf('done!\n');
fprintf('-----------   Wavelet Reconstruction   ----------------\n');
img_spiht = func_InvDWT(img_dec, S, Lo_R, Hi_R, level);

fprintf('done!\n');
fprintf('-----------   PSNR analysis   ----------------\n');

imwrite(img_spiht, gray(256), outfilename, 'bmp');

Q = 255;
MSE = sum(sum((img_spiht-Orig_I).^2))/nRow / nColumn;
fprintf('The psnr performance is %.2f dB\n', 10*log10(Q*Q/MSE));



figure;
colormap(gray(255))
subplot(1,3,1);

imshow('lena512.bmp');

title('lena512.bmp');

subplot(1,3,2);

imshow(img_enc);

title('compressed image');

subplot(1,3,3);

imshow(img_spiht);

title('reconstructed image');

