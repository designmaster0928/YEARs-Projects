# Developed by Scott Kurimski
# v1.03b Beta Released 7/16/2020
# Designed for use with Adafruit ItsyBitsy M4

# Provides Analog hardware support
# Used on the transducer (outlet line pressure sensor)
from analogio import AnalogIn

# Board specific pin names
import board

# Basic digital pin support
# Used on: Low/High PSI input, LEDs and Alarm
import digitalio

# Support for pulse based protocols
# Used to control the 5V PWM pump output pin
import pulseio

# Time and timing related functions
import time


# Pressure Setpoint (ADC range 1 - 65535 )
# To calculate the ADC value when using a 1-100 PSI system
# multiple (65535 * the PSI in % of 100) I.E. for 40 PSI do
# (65535 * .4) = 26214  then adjust +/- as needed to meet actual value
# Round to the nearest whole integer
vLPS_ADC = 0    # Low
vHPS_ADC = 0    # High

# Percentage Of Pressure Setpoint when priming pump (Range 1% - 100%)
vLPOPS = 0     # Low
vHPOPS = 0     # High

# Maximum allowable % over Setpoint before pump shuts off ( 100% - 150% )
vMOLS = 0		# Low
vMOHS = 0		# High

# Pump Acceleration / Deceleration Ramp Rate Divisor (Range 1 - 100)
# Lower number = faster acccel/Decel     Higher number = slower accel/Decel
vLRR = 0		# Low
vHRR = 0		# High

# Program Delay
vLPD = 0		# Low
vHPD = 0		# High

# The number of transducer reads per program cycle
vNumReads = 10  # Default = 10 (Recommended 10)

# Sound Alarm if the Outlet PSI < vAlarm_PSI for > vAlarmThreshold in seconds
vAlarm_PSI = 30         # Default = 30 PSI
vAlarmThreshold = 10    # Default = 10 Seconds


# Track program loop time
vStartTime = time.monotonic()
vCurrentTime = 0
vElapsedTime = 0

# Determine Alarm status
vAlarmReset = True
vAlarmStartTime = 0
vAlarmCurrentTime = 0
vAlarmElapsedTime = 0

# Limit initial Pressure Setpoint to the pump one time per pressure cycle
vPrime_Pump = False

# Pressure Setpoint ADC and PSI
vPS_ADC = 0
vPS_PSI = 0

# Max Over Pressure Setpoint
vMSO = 0

# Ramp Rate for Pump Acceration / Deceleration
vRR = 1

# Percentage of Pressure Setpoint converted to a multiplier
vPOPS = 0

# Program Delay
vPD = .15	# Default = .15 (Seconds)


# #############################################################################
# Low PSI Switch & LED - Digital - Pin #7 = Switch Input & Pin #10 = LED Output
# #############################################################################
vLPSI_Pin = digitalio.DigitalInOut(board.D7)
vLPSI_Pin.direction = digitalio.Direction.INPUT
vLPSI_Pin.pull = digitalio.Pull.DOWN

vLPSI_Led = digitalio.DigitalInOut(board.D10)
vLPSI_Led.direction = digitalio.Direction.OUTPUT
# #############################################################################


# #############################################################################
# High PSI Switch & LED - Digital - Pin #9 = Switch Input & Pin #11 = LED Output
# #############################################################################
vHPSI_Pin = digitalio.DigitalInOut(board.D9)
vHPSI_Pin.direction = digitalio.Direction.INPUT
vHPSI_Pin.pull = digitalio.Pull.DOWN

vHPSI_Led = digitalio.DigitalInOut(board.D11)
vHPSI_Led.direction = digitalio.Direction.OUTPUT
# #############################################################################


# #############################################################################
# Low / High Volume Tip Selector Input - Digital - Pin #12 = Switch
# #############################################################################
vLVHV_Pin = digitalio.DigitalInOut(board.D12)
vLVHV_Pin.direction = digitalio.Direction.INPUT
vLVHV_Pin.pull = digitalio.Pull.DOWN
# #############################################################################


# #############################################################################
# Outlet Line Pressure Sensor Input - Analog - PIN #A0 Switch
# #############################################################################

# Autex Transducer 0-100 PSI Stainless Steel -> located on outlet side of pump
# Transducer is rated @ 5v where .5v = 0 PSI and 4.5v = 100 PSI (~.04v/PSI)
# We use Transducer @ 3.3v where .33v = 0 PSI and 2.97v = 100 PSI (~.0264v/PSI)
# ADC range = 6553.5 - 58981.5 which is the equvalent of .33v - 2.97v
# ADC Range = (58981.5 - 6553.5) = 52428

# Outlet Line Pressure Sensor -> Analog Pin A0
vLP = AnalogIn(board.A0)

# Outlet Line Pressure Sensor - ADC variable
vLP_ADC = 0

# Outlet Line Pressure Sensor - PSI variable
vLP_PSI = 0

# Outlet Line Pressure Average - ADC value averaged over vNumReads reads
vLP_ADC_Avg = 0

# Outlet Line Pressure Sensor - Get ADC value
vLP_ADC = vLP.value

# #############################################################################


# #############################################################################
# Alarm Output - Digital - Pin #13 = PIEZO Alarm
# #############################################################################
vAlarm = digitalio.DigitalInOut(board.D13)
vAlarm.direction = digitalio.Direction.OUTPUT
# #############################################################################


# #############################################################################
# Pump Output - Digital PWM - Pin #5
# #############################################################################

# This is a special OUTPUT-only PWM that is level-shifted up to Vhi (5V)
# Outputs 0-5V using an ADC range of 0 - 65535
vPump = pulseio.PWMOut(board.D5, duty_cycle=0)

# Pump Speed - ADC
vPump_Duty_Cycle = 0

# Pump Speed - PSI
vPump_Duty_Cycle_PSI = 0

# Pump Status when printing to screen
vPump_Status = ""

# #############################################################################


# #############################################################################
# Functions
# #############################################################################

def Get_Volume_Setting():

    # Low Volume Selected (Switch is in the down position)
    if vLVHV_Pin.value is False:

        # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        # @@@@@@@@@@@@   ONLY MODIFY VARIABLE VALUES BELOW THIS SECTION   @@@@@@@@@@@@@
        # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

        # Pressure Setpoints (ADC range 1 - 65535 )
        vLPS_ADC = 22650    # Low Default 40 PSI = 26214 adjusted to 22650
        vHPS_ADC = 41500    # High Default 70 PSI = 45874.5 adjusted to 41500

        # Percentage Of Pressure Setpoint when priming pump (Range 1% - 100%)
        vLPOPS = 77     # Low Default = 77% (of the starting ADC Value)
        vHPOPS = 55     # High Default = 55% (of the starting ADC Value)

        # Maximum allowable % over Setpoint before pump shuts off ( 100% - 150% )
        vMOLS = 119		# Low Default = 119%
        vMOHS = 120		# High Default = 120%

        # Pump Acceleration / Deceleration Ramp Rate Divisor (Range 1 - 100)
        # Lower number = faster acccel/Decel     Higher number = slower accel/Decel
        vLRR = 8		# Low Default = 8   (Integer)
        vHRR = 7		# High Default = 7  (Integer)

        # Program Delay
        vLPD = .1		# Low Default = .1 (Seconds)
        vHPD = .1  	    # High Default = .1 (Seconds)


    # High Volume Selected (Switch is in the up position)
    elif vLVHV_Pin.value is True:

        # Pressure Setpoints (ADC range 1 - 65535 )
        vLPS_ADC = 22750    # Low Default 40 PSI = 26214 adjusted to 22750
        vHPS_ADC = 52428    # High Default 80 PSI = 52428 adjusted to 52428

        # Percentage Of Pressure Setpoint when priming pump (Range 1% - 100%)
        vLPOPS = 98     # Low Default = 98% (of the starting ADC Value)
        vHPOPS = 82     # High Default = 82% (of the starting ADC Value)

        # Maximum allowable % over Setpoint before pump shuts off ( 100% - 150% )
        vMOLS = 115		# Low Default = 115%
        vMOHS = 118		# High Default = 118%

        # Pump Acceleration / Deceleration Ramp Rate Divisor (Range 1 - 100)
        # Lower number = faster acccel/Decel     Higher number = slower accel/Decel
        vLRR = 5		# Low Default = 5   (Integer)
        vHRR = 5		# High Default = 5  (Integer)

        # Program Delay
        vLPD = .10		# Low Default = .10 (Seconds)
        vHPD = .10		# High Default = .10 (Seconds)

        # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        # @@@@@@@@@@@@   ONLY MODIFY VARIABLE VALUES ABOVE THIS SECTION   @@@@@@@@@@@@@
        # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

    return vLPS_ADC, vHPS_ADC, vLPOPS, vHPOPS, vMOLS, vMOHS, vLRR, vHRR, vLPD, vHPD


def Get_Line_Pressure():
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # We average the Autex Transducer value over 10 reads and then convert it
    # to a % with a range of 0 - 100% using a maximum ADC range of 52428
    # We then use the % to convert it to a standard ADC value from 0 - 65535
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    vLP_ADC = 0
    vLP_ADC_Avg = 0
    vLP_PSI = 0

    # Average transducer value over 10 reads
    for i in range(1, vNumReads + 1, 1):

        # Retrieve Line Pressure from transducer
        vLP_ADC = vLP.value

        # Add the reads together
        vLP_ADC_Avg = vLP_ADC_Avg + vLP_ADC

        # On the last read generate the average
        if i == vNumReads:
            vLP_ADC = int(round(vLP_ADC_Avg / vNumReads))
            vLP_ADC_Avg = 0

    # Ensure Autex Transducer Min and Max ADC levels are not exceeded
    # If the Transducers value is greater than 58981.5 (3.3v) we correct it
    if vLP_ADC > 58981.5:
        vLP_ADC = 58981.5

    # If the Transducers value is less than 6553.5 (.33v) we correct it
    elif vLP_ADC < 6553.5:
        vLP_ADC = 6553.5

    # Convert Transducer ADC value to standard 16bit ADC values from 0 - 65535
    # To do this we first determine what % of 100 the transducers ADC value is
    # based on it's operating range. We then use the calulated % to determine
    # the 16bit ADC equivalent by multiplying it by 65535
    vLP_ADC = ((vLP_ADC - 6553.5) / 52428) * 65535

    # Convert Transducer ADC value to closest PSI when Range is 0 - 100
    # To determine the closest PSI we use the calculated 16bit ADC value
    # and divided it by the max 16bit ADC value (65535) and finally we then
    # multiple the result by the max PSI value of the transducer (100)
    vLP_PSI = int(round((vLP_ADC / 65535) * 100))
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    return vLP_ADC, vLP_PSI


def Get_Pressure_Setpoint():

    vPS_ADC = 0

    # Low PSI Setpoint
    if vLPSI_Pin.value is True:
        vPS_ADC = vLPS_ADC
        vMSO = vMOLS / 100
        vRR = vLRR
        vLPSI_Led.value = True
        vHPSI_Led.value = False
        vPOPS = vLPOPS / 100
        vPD = vLPD

    # High PSI Setpoint
    elif vHPSI_Pin.value is True:
        vPS_ADC = vHPS_ADC
        vMSO = vMOHS / 100
        vRR = vHRR
        vLPSI_Led.value = False
        vHPSI_Led.value = True
        vPOPS = vHPOPS / 100
        vPD = vHPD

    # Setpoint switch is in the off position
    else:
        vPS_ADC = 0
        vMSO = 0
        vRR = 1
        vLPSI_Led.value = False
        vHPSI_Led.value = False
        vAlarm.value = False
        vPOPS = 0
        vPD = .15

    # Convert Pressure Setpoint ADC value to closest PSI when Range is 0 - 100
    # To determine the closest PSI we use the calculated 16bit ADC value
    # and divided it by the max 16bit ADC value (65535) and finally we then
    # multiple the result by the max PSI value of the Pressure Setpoint (100)
    vPS_PSI = int(round((vPS_ADC / 65535) * 100))

    return vPS_ADC, vPS_PSI, vMSO, vRR, vPOPS, vPD


def Alarm_Reset():
    vAlarmReset = True
    vAlarmCurrentTime = 0
    vAlarmStartTime = 0
    vAlarmElapsedTime = 0
    vAlarm.value = False
    return vAlarmReset, vAlarmCurrentTime, vAlarmStartTime, vAlarmElapsedTime


def Alarm_Fault():
    while vLPSI_Pin.value is True or vHPSI_Pin.value is True:

            print("System In Alarm")

            # Shut Pump Off
            vPump_Duty_Cycle = 0
            vPump.duty_cycle = vPump_Duty_Cycle

            # Turn on both low and high pressure LED and sound Alarm
            vAlarm.value = True
            vLPSI_Led.value = True
            vHPSI_Led.value = True

            # Delay check every .1 seconds
            time.sleep(.1)


def print_status():
    vSetPoint = ""

    if vLPSI_Pin.value:
        vSetPoint = "40 PSI"
    elif vHPSI_Pin.value:
        vSetPoint = "70 PSI"
    else:
        ""

    vPump_Duty_Cycle_PSI = int(round((vPump_Duty_Cycle / 65535) * 100))

    print(vPump_Status, ":   Setpoint = (", vSetPoint, ") [", vPS_PSI, " ADJ PSI]   Pump = (", vPump_Duty_Cycle_PSI, " PSI) [", vPump_Duty_Cycle, " ADC]   Output = (", vLP_PSI, " PSI) [", int(vLP_ADC), " ADC]", vLVHV_Pin.value, sep="")

# #############################################################################


# #############################################################################
# This portion of the program Loops Indefinitely
# #############################################################################

while True:

    # Get Volume Settings
    vLPS_ADC, vHPS_ADC, vLPOPS, vHPOPS, vMOLS, vMOHS, vLRR, vHRR, vLPD, vHPD = Get_Volume_Setting()

    # Get Pressure Setpoint
    vPS_ADC, vPS_PSI, vMSO, vRR, vPOPS, vPD = Get_Pressure_Setpoint()

    # Get Line Pressure
    vLP_ADC, vLP_PSI = Get_Line_Pressure()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Control Pump Speed
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    # Shut Pump Off When ...
    # 1. Pressure Setpoint <= 0
    # 2. Line Pressure ADC > 110% of Pressure Setpoint ADC
    if vPS_ADC <= 0 or vLP_ADC > (vPS_ADC * vMSO):

        vPump_Status = "Pump Off"
        vAlarmReset, vAlarmCurrentTime, vAlarmStartTime, vAlarmElapsedTime = Alarm_Reset()

        if vPrime_Pump is True:
            # Print Status to screen
            print_status()

        vPrime_Pump = False
        vPump_Duty_Cycle = 0
        vPump.duty_cycle = 0


    # Prime Pump for one cycle when the Line Pressure > 0%
    elif vPS_ADC > 0 and not vPrime_Pump:

        vPump_Status = "Prime Pump"
        vAlarmReset, vAlarmCurrentTime, vAlarmStartTime, vAlarmElapsedTime = Alarm_Reset()
        vPrime_Pump = True

        vPump_Duty_Cycle = int(vPS_ADC * vPOPS)
        vPump.duty_cycle = int(vPS_ADC * vPOPS)

        # Print Status to screen
        print_status()

        # Delay Program = vPD (in seconds)
        time.sleep(vPD)


    # Speed Pump Up
    elif vPrime_Pump and (vLP_ADC < vPS_ADC):

        vPump_Status = "Speed Pump Up"

        vIncrease_ADC_By = int(round((vPS_ADC - vLP_ADC) / vRR))

        vPump_Duty_Cycle = vPump_Duty_Cycle + vIncrease_ADC_By

        if vPump_Duty_Cycle > 65535:
            vPump_Duty_Cycle = 65535
        else:
            vPump.duty_cycle = vPump_Duty_Cycle

        # Print Status to screen
        print_status()


        # Sound Alarm if the Outlet PSI = 0 for > vAlarmThreshold in seconds
        if vLP_PSI < vAlarm_PSI:

            if vAlarmReset is True:
                vAlarmStartTime = time.monotonic()
                vAlarmReset = False

            vAlarmCurrentTime = time.monotonic()
            vAlarmElapsedTime = vAlarmCurrentTime - vAlarmStartTime

            if vAlarmElapsedTime > vAlarmThreshold:
                Alarm_Fault()

        # Delay Program = vPD (in seconds)
        time.sleep(vPD)


    # Slow Pump Down
    elif vPrime_Pump and (vLP_ADC > vPS_ADC):

        vPump_Status = "Slow Pump Down"
        vAlarmReset, vAlarmCurrentTime, vAlarmStartTime, vAlarmElapsedTime = Alarm_Reset()

        vDecrease_ADC_By = int(round((vLP_ADC - vPS_ADC) / vRR))

        vPump_Duty_Cycle = vPump_Duty_Cycle - vDecrease_ADC_By

        if vPump_Duty_Cycle <= 0:
            vPump_Duty_Cycle = 0
        else:
            vPump.duty_cycle = vPump_Duty_Cycle

        # Print Status to screen
        print_status()

        # Delay Program = vPD (in seconds)
        time.sleep(vPD)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

    vCurrentTime = time.monotonic()

    vElapsedTime = vCurrentTime - vStartTime

    vStartTime = vCurrentTime



# #############################################################################
# #############################################################################
#
# Program definition and Acronym's
#   Note: All variables and pointers start with a lowercase v
#
#   Delays the Loop time of the program
#   vLPD = Low Pump Delay                   [ Default = .12 ]
#   vHPD = High Pump Delay                  [ Default = .15 ]
#   vPD = Program Delay                     [ Value will be vLPD or vHPD ]
#
#
#   vLVHV   =   Low or High volume tips     [ False = Low Volume Tips   True = High Volume Tips ]
#
#
#   Set Points
#   vLPS_ADC = Low Pressure Setpoint ADC    [ Default = 22000 ]
#                                           [ 40 PSI -> (65535 * .4) = 26214 ]
#                                           [ Adjusted to 22000 to compensate for differences from actual ]
#
#   vHPS_ADC = High Pressure Setpoint ADC   [ Default = 44000 ]
#                                           [ 70 PSI -> (65535 * .7) = 45875 ]
#                                           [ Adjusted to 44000 to compensate for differences from actual ]
#
#	vPS_ADC = Pressure Setpoint ADC         [ Value will be vLPS_ADC or vHPS_ADC ]
#
#	vPS_PSI = Pressure Setpoint PSI			[ Value converted from vPS_ADC ]
#
#
#	Maximum Setpoint Overage
#	vMOLS = Maximum Over Low Setpoint		[ Default = 125% ]
#	vMOHS = Maximum Over High Setpoint		[ Default = 110% ]
#	vMSO = Maximum Setpoint Overage			[ Value will be vMOLS or vMOHS ]
#
#
#	Pump Acceleration / Deceleration Rates
#	vLRR = Low Ramp Rate					[ Default = 8 ]
#	vHRR = High Ramp Rate					[ Default = 10 ]
#	vRR = Ramp Rate							[ Value will be vLRR or vHRR ]
#
#
#   Percentage of the Pressure Setpoint value when priming pump
#	vLPOPS = Low Percentage Of Pressure Setpoint	[ Default = 95 ]
#	vHPOPS = High Percentage Of Pressure Setpoint	[ Default = 50 ]
#   vPOPS = Percentage Of Pressure Setpoint			[ Value will be vLPOPS or vHPOPS ]
#
#
#   Shortened Variable Names
#   vLPSI_ = vLow_Pressure_PSI_
#   vHPSI_ = vHigh_Pressure_PSI_
#	vLP_ = vLine_Pressure_