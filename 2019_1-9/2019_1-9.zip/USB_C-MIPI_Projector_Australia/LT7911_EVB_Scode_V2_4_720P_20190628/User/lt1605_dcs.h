#ifndef _LT1605_DCS_H
#define _LT1605_DCS_H

void InitPanel( void );

#endif
