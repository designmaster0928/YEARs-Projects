#include "include.h"

TIMING g_TimingStr = 
{ 69900//PixelClock/1000
, 888//Htotal
, 800//Hactive
, 24//Hfp
, 22//Hsw
, 42//Hbp
, 1312//Vtotal
, 1280//Vactive
, 16//Vfp
, 2//Vsw
, 14//Vbp
, 1//Hspol
, 1//Vspol
}; 

DPCD g_DpcdSetStr = 
{ 0x0A// 0x14(5.4G)  & 0x0A(2.7G) & 0x06(1.62g)
, 0x02// 0x04(dp 4lane) & 0x02(dp 2lane) & 0x01(dp 1lane)
, 0x00// 0x01(SSC On) & 0x00(SSC Off)
};

MIPI g_MipiSetStr = 
{ Port_4lane//Port_4lane & Port_3lane & Port_2lane & Port_1lane
, NonBurst_SyncPulse_Mode//Burst_Mode & NonBurst_SyncPulse_Mode & NonBurst_SyncEvent_Mode 
, ContinuousClock//ContinuousClock & NonContinuousClock
};

u8 FwVersion[6]={0x00,0x02,0x00,0x02,0x00,0x07};

void Lt7911D_FwVersionSet(void)
{
	BKD2_0C_REG = FwVersion[0];//chip_write_i2c(0xD20C,FwVersion[0]);
	BKD2_0D_REG = FwVersion[1];//chip_write_i2c(0xD20D,FwVersion[1]);
	BKD2_0E_REG = FwVersion[2];//chip_write_i2c(0xD20E,FwVersion[2]);
	BKD2_0F_REG = FwVersion[3];//chip_write_i2c(0xD20F,FwVersion[3]);
	BKD2_10_REG = FwVersion[4];//chip_write_i2c(0xD210,FwVersion[4]);
	BKD2_11_REG = FwVersion[5];//chip_write_i2c(0xD211,FwVersion[5]);
}
void main(void)
{
	g_EdidBlockCalEnable = FALSE;
	
	g_ChipModel = LT7911D;//LT7911D & LT7911
	g_InputType = Typec_Source ;//Typec_Source & Dp_Source
 	g_DisplayMode = VideoCopyMode;//	VideoCopyMode & SideBySideMode
	g_OutputMode = RGB;//	RGB & YUV422 & YUV444
	g_MipiFormat = RGB888;//RGB888 & YUV422_8bit
	g_MipiType = DSI;//DSI & CSI
	
	Lt7911_InitialSteps();
}
/*
һ��20190507_T3 Aaron 
1���޸�Trainningʱ�����Զ�EQ;
2���޸�TR1����������������ֻ��������磻
3���޸�DPCD_Parameter1���������ʱ��
4������BKB0_2C_REG = 0x7f;//7f
*/
