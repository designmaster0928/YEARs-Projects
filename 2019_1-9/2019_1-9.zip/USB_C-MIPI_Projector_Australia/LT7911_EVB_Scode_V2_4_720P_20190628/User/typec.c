//////////////////////////////////////
//Project:   LT8712
//Filename:  main.c
//Version:   V1.0
//Copyright: Lontium
//////////////////////////////////////
#include "include.h"
//#include "TypeC.h"
u8 LonTP,Adsum,danglesum;
bool GoodCRC=FALSE;
bool SendDone=FALSE;
bool SendEN=FALSE;
bool SendStart=FALSE;
bool Receive=FALSE;
bool StartSend=FALSE;
bool StartPakege=TRUE;
bool mux=0;
bool tmp0;
bool FirstAUX=TRUE;
bool PrSwap=FALSE;
bool ReadEn = 0;
bool send_over = 0;
bool nack_loop = 0;
bool loop_send = 0;
bool VDM_en = 0;
extern bool DPEnable;
u8 UFP_DFP=0;
u8 CcRxMsgHeader[2];
u8 TotalData;
u8 DataOrder;
u8 status=0;
u8 five=1;
//u8 firstAUX=1;
u8 done=1;
u8 CRCtime = 0;
u8 LOOP_VDM;
u8 LOOP_ALL;
u8 SendMegFstDataOffset;
u8 SendMegSndDataOffset;
u8 sendtmp,readtmp;
//u8 SendMegTirdDataOffset;
u8 TxSendStatus;
u8 CcStatus;
u8 Status2;
u8 AUXStatus;
u8 loopx; 
u8 MsgType;
u8 NumberRvdData;
u8 steptemp=0;
u8 CcRxRvdDatalenth;
u8 CcRxRvdData[32];
u8 LonTP,Adsum,danglesum;
u8 tp;
u8 LastPG;
u8 SendData;
u8 TypecRXHeadCount;
u8 TypecRXCount;
u8 CcRxMsgHeader[2];
u8 CcRxRvdData[32];
bool SendEN;






u8 BookSourceCapBuffer[6]={0x42,0x10,0x5A,0x68,0x01,0x13};
u8 code CCSendSndData[15][30]={
// 4 Lane DP mode
{0x42,0x10,0x5A,0x68,0x01,0x13},//Request Message	0
{0x4F,0x54,0x41,0x80,0x00,0xff,0x00,0x00,0x00,0x6c,0x00,0x00,0x00,0x00,0x58,0x01,0x12,0x10,0x7B,0x00,0x00,0x51},//1{0x4f,0x34,0x41,0x80,0x00,0xff,0x00,0x00,0x00,0x6c,0x39,0x00,0x00,0x51},//Discover Identity
{0x4F,0x36,0x42,0x80,0x00,0xFF,0x00,0x00,0x01,0xFF,0x00,0x00,0x00,0x00},//2Discover SVID Responder ACK 2
{0x4F,0x28,0x43,0x80,0x01,0xFF,0x05,0x04,0x00,0x00},//3{0x4F,0x28,0x43,0x80,0x01,0xFF,0X05,0X0C,0X00,0x00},//Discover Modes Responder ACK
{0x4F,0x1A,0x44,0x81,0x01,0xFF},//Ox04 -- Enter Mode 4
{0x4F,0x2C,0x50,0x81,0x01,0xFF,0x02,0x00,0x00,0x00},//5/{0x4F,0x2C,0x50,0x81,0x01,0xFF},//0x10 -- DP Status Updata  HPD Low ,No IRQ_HPD
{0x4F,0x1E,0x51,0x81,0x01,0xFF},//0x11 DP Config 6
{0x4F,0x22,0x06,0x81,0x01,0xFF,0x82,0x00,0x00,0x00},//7/{0x4F,0x22,0x06,0x81,0x01,0xFF,0x9A,0x00,0x00,0x00},//0x06 Attention HPD High,No IRQ_HPD   bit7 = hpd high or low
{0x4F,0x22,0x06,0x81,0x01,0xFF,0x82,0x00,0x00,0x00},//8/{0x4F,0x24,0x06,0x81,0x01,0xFF,0x9A,0x01,0x00,0x00},//HPD High, IRQ_HPD	 //send twice
//{0x4F,0x26,0x06,0x81,0x01,0xFF,0X9A,0x01,0x00,0x00}, 
{0x4F,0x22,0x06,0x81,0x01,0xFF,0x02,0x00,0x00,0x00},// 9 */{0x4F,0x22,0x06,0x81,0x01,0xFF,0x1A,0x00,0x00,0x00},//0x06 Attention HPD High,No IRQ_HPD   bit7 = hpd high or low
{0x4F,0x24,0x06,0x81,0x01,0xFF,0x1A,0x01,0x00,0x00},//10 HPD High, IRQ_HPD	 //send twice 10
{0x4F,0x2C,0x50,0x81,0x01,0xFF,0x82,0x00,0x00,0x00},//11{0x4F,0x2C,0x50,0x81,0x01,0xFF},//0x10 -- DP Status Updata  HPD High ,No IRQ_HPD 11
{0x44,0x12,0x5a,0x90,0x01,0x00}, //12
};

////2 Lane DP mode
//{0x42,0x10,0x5A,0x68,0x01,0x13},//Request Message	0
//{0x4F,0x54,0x41,0x80,0x00,0xff,0x00,0x00,0x00,0x6c,0x00,0x00,0x00,0x00,0x58,0x01,0x12,0x10,0x39,0x00,0x00,0x51},//1{0x4f,0x34,0x41,0x80,0x00,0xff,0x00,0x00,0x00,0x6c,0x39,0x00,0x00,0x51},//Discover Identity
//{0x4F,0x36,0x42,0x80,0x00,0xFF,0x00,0x00,0x01,0xFF,0x00,0x00,0x00,0x00},//2Discover SVID Responder ACK 2
//{0x4F,0x28,0x43,0x80,0x01,0xFF,0x05,0x08,0x00,0x00},//3{0x4F,0x28,0x43,0x80,0x01,0xFF,0X05,0X0C,0X00,0x00},//Discover Modes Responder ACK
//// 05 0c  C/D both support; 05 04 Only C type; 05 08 only D type
//{0x4F,0x1A,0x44,0x81,0x01,0xFF},//Ox04 -- Enter Mode 4
//{0x4F,0x2C,0x50,0x81,0x01,0xFF,0x02,0x00,0x00,0x00},//5/{0x4F,0x2C,0x50,0x81,0x01,0xFF},//0x10 -- DP Status Updata  HPD Low ,No IRQ_HPD
//{0x4F,0x1E,0x51,0x81,0x01,0xFF},//0x11 DP Config 6
//{0x4F,0x22,0x06,0x81,0x01,0xFF,0x82,0x00,0x00,0x00},//7/{0x4F,0x22,0x06,0x81,0x01,0xFF,0x9A,0x00,0x00,0x00},//0x06 Attention HPD High,No IRQ_HPD   bit7 = hpd high or low
//{0x4F,0x22,0x06,0x81,0x01,0xFF,0x82,0x00,0x00,0x00},//8/{0x4F,0x24,0x06,0x81,0x01,0xFF,0x9A,0x01,0x00,0x00},//HPD High, IRQ_HPD	 //send twice
////{0x4F,0x26,0x06,0x81,0x01,0xFF,0X9A,0x01,0x00,0x00}, 
//{0x4F,0x22,0x06,0x81,0x01,0xFF,0x02,0x00,0x00,0x00},// 9 */{0x4F,0x22,0x06,0x81,0x01,0xFF,0x1A,0x00,0x00,0x00},//0x06 Attention HPD High,No IRQ_HPD   bit7 = hpd high or low
//{0x4F,0x24,0x06,0x81,0x01,0xFF,0x1A,0x01,0x00,0x00},//10 HPD High, IRQ_HPD	 //send twice 10
//{0x4F,0x2C,0x50,0x81,0x01,0xFF,0x82,0x00,0x00,0x00},//11{0x4F,0x2C,0x50,0x81,0x01,0xFF},//0x10 -- DP Status Updata  HPD High ,No IRQ_HPD 11
//{0x44,0x12,0x5a,0x90,0x01,0x00}, //12
//};

void delay_us(u16 t)
{
	while(t--);
}

void TypecTmpInit(void)
{
	SendEN = 0;
	send_over = 0;
	loop_send = 0;
	nack_loop = 0;
	TypecRXCount=0;
	CcRxRvdDatalenth= 0;
	DPEnable = 0;
	done=1;
	Adsum=0x00;
	SendMegSndDataOffset=0;
	PrSwap=FALSE;
	TotalData =6;
	DataOrder=0;
	Enter_AltMode =0xff;
	GoodCRC=TRUE;
  Attention_Flag =0;
	CcRxRvdData[0]=0xFF;
	CcRxRvdData[1]=0xFF;
	CcRxRvdData[2]=0xFF;
	CcRxRvdData[3]=0xFF;
	CcRxRvdData[4]=0xFF;
	CcRxRvdData[5]=0xFF;
	CcRxRvdData[6]=0xFF;
	CcRxRvdData[7]=0xFF;
	CcRxRvdData[8]=0xFF;
	CcRxRvdData[9]=0xFF;	
	CcRxRvdData[10]=0xFF;
	CcRxRvdData[11]=0xFF;
}

void DccInit(void) {
  BKC1_16_REG	= 0x01;
}	

void UccInit(void) {
	BKC1_8C_REG	= 0x00;
	BKC1_8D_REG = 0x0a;
	BKC1_93_REG = 0x08;
	BKC1_95_REG = 0xa0; 
  BKC1_96_REG	= 0x03;
	BKC1_97_REG = 0x40;
	BKC1_99_REG = 0x01;	
	BKC1_A8_REG = 0x80;
	BKC1_A9_REG = 0x00;
	BKC1_AC_REG = 0x62;
	//UCC RATE SET
	BKC1_9F_REG = 0x68;
	BKC1_A2_REG = 0x34; 
	BKC1_31_REG = 0x12;
	BKC1_32_REG = 0x3C;
	BKC1_33_REG = 0x3D;
	BKC1_34_REG = 0x3E;
	BKC1_35_REG = 0x42;
}

void TypeCInit(void)
{		

	BKB0_0B_REG = 0xC4; 
	BKB0_10_REG = 0xC4;
	BKB0_08_REG = 0xB3;	
	DccInit();
	UccInit();
	BKB0_0B_REG = 0xE5; 
	BKB0_10_REG = 0xC5; 
	TypecTmpInit();		
}

void Send_Message(void)
{
	
		for(SendMegSndDataOffset=0;SendMegSndDataOffset<TotalData;SendMegSndDataOffset++)
		{
		 SendData = CCSendSndData[DataOrder][SendMegSndDataOffset];
		 if(SendMegSndDataOffset==1) {
				danglesum=(Adsum & 0x07) << 1;
				SendData=SendData&0xf1;
				SendData=(SendData|danglesum);
				Adsum++;
		 }
		 BKC1_9A_REG	= SendData;
		}
	BKC1_98_REG = 0x08;	  //mark all data done
	BKC1_98_REG = 0x00;
	BKC1_99_REG = 0x09;
	send_over = 1;
}	
void Send_Request(void)
{
	
		for(SendMegSndDataOffset=0;SendMegSndDataOffset<TotalData;SendMegSndDataOffset++)
		{
		 SendData = BookSourceCapBuffer[SendMegSndDataOffset];
		 if(SendMegSndDataOffset==1) {
				danglesum=(Adsum & 0x07) << 1;
				SendData=SendData&0xf1;
				SendData=(SendData|danglesum);
				Adsum++;
		 }
		 BKC1_9A_REG	= SendData;
		}
	BKC1_98_REG = 0x08;	  //mark all data done
	BKC1_98_REG = 0x00;
	BKC1_99_REG = 0x09;
	send_over = 1;
}	
void Request_Ucc_Fix(void)
{
	u8 i=0;
	for(i=0;i<6;i++)
	{BookSourceCapBuffer[i]=0;}
// 	memset(BookSourceCapBuffer,0x00,6);
	BookSourceCapBuffer[0]=0x42;
	BookSourceCapBuffer[1]=0x10;
	BookSourceCapBuffer[2]=CcRxRvdData[2];
	BookSourceCapBuffer[3]=(CcRxRvdData[3]&0x03)|((CcRxRvdData[2]&0x3f)<<2);
	BookSourceCapBuffer[4]=(((CcRxRvdData[2]&0xc0)>>6)| ((CcRxRvdData[3]&0x03)<<2));
	BookSourceCapBuffer[5]=0x13;
}
void Analysis_Vdm_Msg(void)
{ 
	delay1ms1(5);
  if(MsgType == Vendor_Defined)
   {
	  if(CcRxRvdData[3] & 0x80)//Structured VDM
	  {
		 delay_us(100);	
		 switch  (CcRxRvdData[2]&0x1F)  //Command
		 {
			 
			  case Discover_Identity   : //Discover_SVIDs 
				            DataOrder = 1;
										TotalData = 22;	
										Send_Message();	
										LastPG=Discover_Identity;
										break;
			  case Discover_SVIDs      ://Discover_Modes 
			              DataOrder = 2;
										TotalData = 14;
										Send_Message();	
										break;
			  case Discover_Modes      ://Discover Identity BUSY
			              DataOrder = 3;
										TotalData = 10;
										Send_Message();	
			              break; 
			  case Enter_Mode          ://DP Status Update
			              DataOrder = 4;
										TotalData = 6;
										Send_Message();
			              break;  							  
			  case Exit_Mode           : 
										break;
			  case Attention           :
																	
										break;

			  case DP_Status_Updata	   :
					          if(!Attention_Flag)
										{
			              DataOrder = 5;
										TotalData = 10;
										}
										else
										{
										 DataOrder = 11;
										 TotalData = 10;
										}
										Send_Message();	
										break;					
			  case DP_Config	       : 
			              DataOrder = 6;
										TotalData = 6;
										Send_Message();	
										LastPG=DP_Config;	
										Enter_AltMode =0x01;
										BKA0_30_REG = 0x25;
										break;		
			  case DP_Status_Updata_ACK	       : //DP Config 
																
			                            break;
			
			  default                  : 
																	break;
		 }
//		 switch  (CcRxRvdData[2])  //Command
//		 {
//			 
//			  case DP_Status_Updata	   : 

//																	break;					
//			  case DP_Config_ACK	    : 	 
//			                            							break;		
//		      case DP_Config_NACK	   :		
//																	break;
//			  case DP_Status_Updata_ACK	       : //DP Config 

//																	
//			                            break;
//				
//			  default                  : 
//																	break;
//		 }
	  } 

   }//vendor analysis
}

void UFP_ReadMessage(void)
{		
		if(CcRxRvdDatalenth==0x00) // control message
		{		  
		   //Control Msg	
		   switch 	(MsgType)
		   {
			  case GoodCRC_M      :	  

			               		    break; 
			  case GotoMin        : 
														break;
			  case Accept         : 
			  									
												

														break;
			  case Reject         :
			                      break;
			  case Ping           :	
			                      break;  
			  case PS_RDY         : 	
											
														break;
			  case Get_Source_Cap : 
			                       break;
			  case Get_Sink_Cap   : 
														DataOrder = 12;
														TotalData = 6;
														Send_Message();
			                        break;
			  case DR_Swap        : 
			                        break;
			  case PR_Swap        : 
			
			
			                        break;
			  case VCONN_Swap     :
			                        break;
			  case Wait           : 
			                        break;
			  case Soft_Reset     : 
			                        break;
	    	  default         : 
			                        break;
		   }
		}
	  else
		{		
		    switch 	( MsgType)
		   {
			  case Source_Capabilities   :  
											delay_us(100);
											DataOrder = 0;	//send Request		
											TotalData = 6;

											Request_Ucc_Fix();
//											BKD2_15_REG=0xaa;
//											TR1 = 1;//1
											Send_Request();
											LastPG=Request;
				
											//LastPG=Accept;
											//Send_Message();
											break;
			  case Request               : 
				
			                               break;
			  case BIST                  : 
			                               break; 
			  case Sink_Capabilities     : 

			                               break; 
			  case Vendor_Defined        : 
																		
			                               Analysis_Vdm_Msg();   //xxxmsg = Vendor Defined Msg
			                             
			                               break;
	       default                    : break;
		   }	
		  }			
}

