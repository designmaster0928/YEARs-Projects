//////////////////////////////////////
//Project:   LT8712
//Filename:  interrupt.c
//Version:   V1.0
//Copyright: Lontium
//////////////////////////////////////

#include "include.h"

IDATA bool Training_FALG=0;
IDATA u8  link_rate_now=0x00; 
IDATA u8  link_rate_last=0x00;
IDATA u8  TypecInt=0x00;
IDATA u8  Enter_AltMode;
IDATA bool  Attention_Flag;
IDATA bool EopEn = 0;
bool DPEnable = 0;
extern u8 TypeC_Swap_Flag;
void InterruptTypeC(void)
{
  if(TypecInt & 0x80) 
		{ //CONNECT_CHG
		if(((BKC1_9E_REG&0x0F)!=0x00))
			{	
			BKC1_AF_REG = 0xC1;
			BKB0_12_REG = 0x3c;
			BKDA_A3_REG	= 0x4b;	// rx lane swap 
			BKDA_A4_REG	= 0x05; // 	PN swap
			BKB0_30_REG = 0x46;
		  }
		else 
			{
//			BKA0_48_REG = 0x00;
			TypecTmpInit();
		  }
  }
	
  if(TypecInt&0x40) {   // keycode received		
		
		//delay_us(1);		
		if((BKC1_9C_REG & 0x07) != 0x01)
		{
			BKB0_0B_REG = 0xE5;
		}
		else 
		{
			BKB0_0B_REG = 0xC5;
			BKC1_96_REG	= 0x0B;
			TypecRXCount =0;
		  ReadEn = 1;
		}	
	}
  if(!(TypecInt & 0x20) & ReadEn) { //RX_FIFO_EMPTY
   	do {		 				
		     CcRxRvdData[TypecRXCount]	= BKC1_A3_REG;
				 if(TypecRXCount == 0x01) {
					 CcRxRvdDatalenth = ((CcRxRvdData[1] & 0x70)>>2);
				 }
				 if(TypecRXCount == CcRxRvdDatalenth + 1) {
					 BKC1_96_REG = 0x03;
					 ReadEn = 0;
					 break;
				 }
				 TypecRXCount++;
		     TypecInt = BKC1_B6_REG;
	   } while(!(TypecInt & 0x20));
  }
  if(TypecInt&0x10) { //EOP level
  	BKC1_B6_REG = 0x10;
		MsgType = CcRxRvdData[0] & 0x0f;
		if((!CcRxRvdDatalenth)&&(MsgType == 0x01)) 
			{//good CRC
//			 Enter_AltMode =0x01;
			 loop_send = 1;
		}
		else 
			{
			send_over = 0;
			if(CcRxRvdData[0] != 0x4F) 
				{
				SendEN = 1;
			 }
		}
	}		
  if(TypecInt&0x08) { // CRC_ERR_LEVEL
  }
  if(TypecInt&0x04) { // Send Over
		BKB0_0B_REG = 0xC5;
		if(SendEN) {
			SendEN = 0;
	    UFP_ReadMessage();
	  }
		else if(send_over) { //if(rdy_send_msg) {
			loop_send = 1;
			nack_loop = 1;
		}
  }
}

u8 IRQ_Counter=0x00;
u8 IRQ_FLAG = 0x00;

void InterruptAuxTask(void)
{
	u8 loopx=0;
	u8 rdauxdata = 0;
	//u8 ldnumber=0;
	#if 0
	//////initial//////////
	AuxRxCmd = 0xFF;
	AuxRxCounter = 0;
	for(loopx=0; loopx<16; loopx++)
	{
		AuxRxData[loopx] = 0xFF;
		AuxRxSendData[loopx] = 0xFF;	
	}
	AuxRxAddress[0]=0;
	AuxRxAddress[1]=0;
	AuxRxAddress[2]=0;
	rdauxdata = 0xFF;
	//end initial
	#endif 

 	
	#if 1
	AuxRxCmd = 0xFF;
	AuxRxLength = 0x00;
	rdauxdata = 0xFF;
	AuxRxCounter = BKD0_0F_REG & 0x1F; //5bit -  auxrx_buf_cnt

	rdauxdata = GetRxAuxData();
	AuxRxCmd = rdauxdata  & 0xF0;
	AuxRxAddress[0] = rdauxdata  & 0x0F;		
	AuxRxAddress[1] = GetRxAuxData(); 		
	AuxRxAddress[2] = GetRxAuxData();
	if(AuxRxCounter>=0x04)//in case of "address only"
	{
	  AuxRxLength = GetRxAuxData();
		AuxRxLength = AuxRxLength+1;
		if(AuxRxLength>0x10) //in case of more than 16 bytes
		{
			return; //Error
		}	
	}	
	#endif

//  BKB0_06_REG=AuxRxCmd;
//	BKB0_07_REG=AuxRxCounter;
//	BKB0_08_REG=AuxRxAddress[0];
//	BKB0_09_REG=AuxRxAddress[1];
//	BKB0_0a_REG=AuxRxAddress[2];
//	BKB0_0b_REG=AuxRxLength;

	if(AuxRxCounter>0x04) //TX wr data
	{
		for(loopx=0; loopx<AuxRxLength; loopx++)
		{
			AuxRxData[loopx] = GetRxAuxData();
		}
	}
	switch(AuxRxCmd)
	{
	    #if 1
		case CMD_DPCDW://0x80; Native WR
			WriteDpcd(AuxRxLength);
			SendAckReply();			
		    BKD0_13_REG = 0x00;	 // soft aux send enable;
			break;
		#endif
			
		case CMD_DPCDR://0x90; Native Read
//			#if 0
//			if(AuxRxLength>=0x07)  //300us
//			{
//				#if 1
//				if((AuxRxPreCmd == AuxRxCmd) &&
//				(AuxRxPreAddress[0]==AuxRxAddress[0])&&
//				(AuxRxPreAddress[1]==AuxRxAddress[1])&&
//				(AuxRxPreAddress[2]==AuxRxAddress[2])&&
//				(AuxRxPreLength == AuxRxLength))
//				{
//					SendAckReply();
//					RxAuxSendData(AuxRxLength);	
//				}
//				else
//				{
//					SendDeferReply();
//					ReadDpcd(AuxRxLength);
//					AuxRxPreAddress[0] = AuxRxAddress[0];
//					AuxRxPreAddress[1] = AuxRxAddress[1];
//					AuxRxPreAddress[2] = AuxRxAddress[2];
//					AuxRxPreLength = AuxRxLength;
//				}
//				#endif
//			}
//			#endif
			//TR0 = 1;//enable 300us Time0
			if(AuxRxLength<0x11)//0x08 0x18
			{
				ReadDpcd(AuxRxLength);
				SendAckReply();
				RxAuxSendData(AuxRxLength);
					 // soft aux send enable;	
			}
			BKD0_13_REG = 0x00;	 // soft aux send enable;
			break;

		
		case CMD_I2CW://0x40; MOT=1,I2C-W;address only(WR strat)
			//BK80_CA_REG = AuxRxCounter;//send Counter
			if(AuxRxAddress[2]==0x50)//EDID address
			{
				if(AuxRxLength==1 && AuxRxCounter==0x05)//WR EDID original address
				{
					AuxEdidOffset = AuxRxData[0];
				}
			}
			SendAckReply();			
			BKD0_13_REG = 0x00;	 // soft aux send enable;
			break;
			
		case CMD_I2CR://0x50; MOT=1,I2C-R //address only or address length????
		
 			if(AuxRxAddress[2]==0x50 && AuxRxCounter==0x04 )//read EDID datas
			{
				SendAckReply();	
				WriteLinkEdid();
				
			}
		 	else if(AuxRxAddress[2]==0x50 && AuxRxCounter==0x03 )//addrees only (read strat)
			{
				SendAckReply();
				
			}
			else if(AuxRxAddress[2]==0x3C)//HDCP address
			{
				SendAckReply();
			}
			else
			{
				BKD0_11_REG = AUXNACK;//201 DP	Spec;I2C NACK?:
			}			
			BKD0_13_REG = 0x00;	 // soft aux send enable;
			break;
			
		case CMD_I2CD://0x60;Write-status-update,MOT=1
			SendAckReply();			
			BKD0_13_REG = 0x00;	 // soft aux send enable;
			break;
		#if 1
		case CMD_I2CS://0x10; MOT=0,Address only or again read
			if(AuxRxAddress[2]==0x50 && AuxRxCounter==0x04 )//EDID address
			{
				SendAckReply();
				LastWriteLinkEdid();	
				AuxEdidOffset=0;		
			} 
		    else if(AuxRxAddress[2]==0x50 && AuxRxCounter==0x03)//address only(read stop)
			{
				SendAckReply();
				//LastWriteLinkEdid();
				//BK81_37_REG=0x55;
				AuxEdidOffset=0;		
			}
			else
				SendAckReply();		
			BKD0_13_REG = 0x00;	 // soft aux send enable;				
			break;		
		#endif

		#if 1
		case CMD_I2CLW://0x00;  MOT=0,I2C-over-aux,write done;address only(stop)   
			SendAckReply();
			BKD0_13_REG = 0x00;	 // soft aux send enable;
			break;
/*		case CMD_I2CLR://0x10
			SendAckReply();
			break;		 */
		case CMD_I2CLD://0x20;MOT=0, Write-status-update
			SendAckReply();			
			BKD0_13_REG = 0x00;	 // soft aux send enable;
			break;
		#endif

	}
	//AuxRxPreCmd = AuxRxCmd;
	//AuxRxPreCmd = AuxRxCmd;
}

void Time0InterruptService(void) interrupt 1
{	
	SendDeferReply();//over 300us ,return TX Defer signal;
	TR0 = 1;    //enable Time0
	TH0 = 0xFD;//reloaed 300us
	TL0 = 0xA8;//
	return;
}

void Time1InterruptService(void) interrupt 3
{	
	TR1 = 0;
	TH1 = 0xB1;
	TL1 = 0xE0;
	g_timer1_4scnt++;
	TR1 = 1;
	if(g_timer1_4scnt == 400)
	{
		if(BKB8_B0_REG&0x10)
		{
			g_timer1_4scnt = 0;
			TR1 = 0;
		}
		else
		{
			BKB0_0B_REG = 0xD5;
		}
	}
	return;
}

void InterruptVideotask(void)
{
	BKB0_8D_REG = 0x07;
	//BKB0_8B_REG |=0x70;//GPIO3 Max
	//BKA0_45_REG |=0x20;//GPIO3 GPO
	if(BKD2_20_REG&0x01)
	{
		//BKA0_48_REG |=0x01;
		//BKA0_46_REG =0x06;//Vsync out
		BKD2_1C_REG |=0x01;//Bit[0]set0 :Rg_video_out_int_clr
		BKD2_1C_REG &=0xfe;//Bit[0]set0 :Rg_video_out_int_clr
		FlagVideoOK = 1;
	}
}

void IT1InterruptService(void) interrupt 2
{
  nack_loop = 0;		
	if(BKA0_15_REG & 0x04) { // ucc interrupt flag
		BKA0_A0_REG = 0x04;    // clear flag
  	BKA0_A0_REG = 0x00;
		TypecInt    = BKC1_B6_REG;
		BKC1_B6_REG = 0xEF;
		if(TypecInt!= 0x20)	{
			EA = 0;
			InterruptTypeC();
			EA = 1;
		}
	}
		
	if(DPEnable) 
		{
		if((BKA0_16_REG & 0x80)== 0x80) {  //auxrx_int flag	
			BKA0_A1_REG=0xff;	// clear interrupt 2
   		BKA0_A1_REG=0x7f;
			LastPG=0xFF;
			TH0 = 0xFD;
			TL0 = 0xA8;		
			TR0 = 1;
			InterruptAuxTask();
		  TR0 = 0;
	    TH0 = 0xFD; //reloaed 300us 
		  TL0 = 0xA8; //	
//			BKD2_15_REG=0xaa;
//			TR1 = 1;//1			
		}		
	}
		
	if(BKA0_15_REG&0x01)
	{
		InterruptVideotask();
		BKA0_A0_REG |= 0x01;
		BKA0_A0_REG &= 0xfe;
	}
}

