//////////////////////////////////////
//Project:   LT8712
//Filename:  interrupt.h
//Version:   V1.0
//Copyright: Lontium
//////////////////////////////////////

#ifndef _INTERRUPT_H
#define _INTERRUPT_H
#include "include.h"


extern IDATA bool Training_FALG;
extern IDATA u8  Enter_AltMode;

#endif
