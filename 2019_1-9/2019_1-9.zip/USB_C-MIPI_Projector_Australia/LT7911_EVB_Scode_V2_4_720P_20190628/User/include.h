
#ifndef _INCLUDE_H
#define _INCLUDE_H

/* C51 file*/
#include  "type.h"
#include  "string.h"
#include  "REG51.h"
#include  "stdio.h"
#include  "math.h"

/*user file*/
#include  "edid.h"
#include  "globalV.h"
#include  "lt1605_dcs.h"
#include "typec.h"
#include  "main.h"
#include "Lt7911.h"
#include  "mipi.h"
#include "dp.h"
#include "register.h"
#include "int.h"
#endif

