#ifndef _MAIN_H
#define _MAIN_H

void Lt7911D_FwVersionSet(void);
#endif

