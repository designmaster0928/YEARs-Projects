//////////////////////////////////////
//Project:   LT8712
//Filename:  LT8712.c
//Version:   V1.0
//Copyright: Lontium
//////////////////////////////////////

#include "include.h"
IDATA u8 RxLane0EqValue;
IDATA u8 RxLane1EqValue;
IDATA u8 RxLane2EqValue;
IDATA u8 RxLane3EqValue;
IDATA u8 AuxEdidOffset;
IDATA u8 AuxRxCounter;
IDATA u8 AuxRxData[16];
IDATA u8 AuxRxSendData[16];
IDATA u8 AuxRxCmd;
IDATA u8 AuxRxAddress[3];
IDATA u8 AuxRxLength;
IDATA u8 AuxRxPreCmd;
IDATA u8 AuxRxPreAddress[3];
IDATA u8 AuxRxPreLength;
IDATA u8 FlagInterruptAux;

u8 DPCD_600_VALUE ;
IDATA u8 hardmode_flag;
IDATA u8 lane_count;
IDATA u8 lane_width;
IDATA u8 Training_pattern;
IDATA u8 DPCD101;
IDATA u8 FirstTrain_pattern;
IDATA bool Traindown_Flag ;
IDATA bool Align_Flag ;
IDATA bool Reset_Rx_Flag;
IDATA bool Dpcd107_Write;
IDATA u8 Dpcd202;
static u8 Data_ID;
static u8 Data_0;
static u8 Data_1;
u8 Buf[100]=0x00;
static bool D0,D1,D2,D3,D4,D5,D6,D7;
static bool D8,D9,D10,D11,D12,D13,D14,D15;
static bool D16,D17,D18,D19,D20,D21,D22,D23;
static bool P_0,P_1,P_2,P_3,P_4,P_5;
static unsigned short gsCRC16GenerationCode = 0x8408;
//u8  Edid_default[256];
IDATA bool FlagVideoOK;
extern bool EDID_VAL;

#if 0
void DPCD_Parameter1(u32 Addr, u8 Data)
{
//D855: bit[7]: 0:aux mode; 1:reg mode
//D852: DPCD[19:16]
//D851: DPCD[15:8]
//D850: DPCD[7:0]
//D853: Data
	BKD8_55_REG = 0x80;//Aux reg mode
	BKD8_52_REG = ((Addr>>16)&0x0f);
	BKD8_51_REG = ((Addr>>8)&0xff);
	BKD8_50_REG = (Addr&0xff);
	BKD8_53_REG = Data;
}
#endif
void DPCD_Parameter1(u8 Addr, u8 Data)
{
	BKD8_50_REG = Addr;
	BKD8_53_REG = Data;
}
void delay1ms1(u16 var)
{
	u16 i;
	while(var --)
	{
		for(i=0;i<325;i++);
	}
}

u8 GetRxAuxData(void)
{
	u8 tprddata=0;
	tprddata = BKD0_12_REG;	 //Get aux data
	return tprddata;
}

u8 GetDpcdData(void)
{
	u8 rdlinkdata=0;
	rdlinkdata = BKD8_54_REG;
	return rdlinkdata;
}

void Training_Reset(void)
{
	BK90_03_REG =0xef;//cdr rst
	BK90_0D_REG =0xe0;//Pirst
	BK90_0F_REG =0xbf;//Rx rst
	BK90_0D_REG =0xff;//release PI
	BK90_0F_REG =0xff;//release Rx
	BK90_03_REG =0xff;
}	

void WriteLinkEdid(void)
{
	u8 loopy=0;

	for(loopy=0; loopy<AuxRxLength; loopy++)
	{
		BKD0_11_REG = Edid[loopy+AuxEdidOffset]; //AUX WRITE
	}
	BKD0_13_REG = 0x00;	 // soft aux send enable;
	 AuxEdidOffset= AuxEdidOffset+AuxRxLength;
}

void LastWriteLinkEdid(void)
{
	u8 loopy=0;
	for(loopy=0; loopy<AuxRxLength; loopy++)   //AUX WRITE
	{
		BKD0_11_REG = Edid[loopy+AuxEdidOffset];
	}
	BKD0_13_REG = 0x00;	 // soft aux send enable;
	AuxEdidOffset=0;
}

void SendDeferReply(void)
{
	BKD0_11_REG = AUXDEFER;
	BKD0_13_REG = 0x00;	 // soft aux send enable;
}

void SendAckReply(void)
{
	BKD0_11_REG = AUXACK;
	
}

void RxAuxSendData(u8 lenth)
{
	u8 loopy=0;
	for(loopy=0; loopy<lenth; loopy++)
	{
		BKD0_11_REG = AuxRxSendData[loopy];
	}
   BKD0_13_REG = 0x00;	 // soft aux send enable;
}

void Pattern_Training(void)
{
		if(Training_pattern == 0x01&&(FirstTrain_pattern!=Training_pattern))//lane_width==0x14&&
		{ 
			BKD8_00_REG =0x11;
			DPCD_Parameter1(0x000103,0x00);
			DPCD_Parameter1(0x000104,0x00);
			DPCD_Parameter1(0x000105,0x00);
			DPCD_Parameter1(0x000106,0x00);
			#if Swing_En ==1
			BKD8_19_REG = 0x01;
			#endif
			FirstTrain_pattern =Training_pattern; 
			Training_Reset(); 
			if(g_InputType == Typec_Source)
			{
			//TR1 = 1;//1	
			}
		}
		else if((Training_pattern == 0x02||Training_pattern == 0x03)&&(FirstTrain_pattern!=Training_pattern))//lane_width==0x14&&
		{  
			FirstTrain_pattern =Training_pattern; 
			Training_Reset();
		}
}

//void Eq_Swap(void)
//{
//	if(hardmode_flag==1)  //EQ SWAP FOR normal insert of typeC 
//	{
//		hardmode_flag = 0; 
//		BKD8_5A_REG = (BKDB_C6_REG & 0xf0) | (BKDB_C8_REG & 0x0f); //lane0-1
//		BKD8_5B_REG = BKDB_C9_REG;
//		BKD8_5C_REG = BKDB_C7_REG;
//		BKD8_5D_REG = (BKDB_CA_REG & 0xf0) | (BKDB_CC_REG & 0x0f); //lane2-3
//		BKD8_5E_REG = BKDB_CD_REG;
//		BKD8_5F_REG = BKDB_CB_REG;
//		BKD8_00_REG &=0xef;
//	}
//}

void Rd_Dpcd202(u8 i)
{
	
	Dpcd202 =AuxRxSendData[i]&0x0f;
	

	if(((Dpcd202 !=0x01)&&(Training_pattern == 0x01))||((Dpcd202 !=0x07)&&(Training_pattern == 0x02||Training_pattern == 0x03)))
	{
  	Training_Reset();
	}
	else if((Dpcd202==0x07)&&(Training_pattern == 0x02||Training_pattern == 0x03))
	{
	//Eq_Swap();
	Traindown_Flag =1;
	BKD2_14_REG = 1;
	if(!Dpcd107_Write)
	{
		Dpcd107_Write =1;
		BKB8_3A_REG = 0x40;
		BKB8_3B_REG = 0x50;
		
#if 0	//2ND_CDR			
			BKB8_3A_REG = 0x80;//ssc,2nd cdr  ǿ��
			BKB8_3B_REG = 0x52;
#endif
	}
	BKD8_00_REG = 0x01;
	BKD8_5A_REG = 0x00;
	BKD8_5B_REG = 0x07;
	BKD8_5C_REG = 0x07;
	BKD8_5D_REG = 0x00;
	BKD8_5E_REG = 0x07;
	BKD8_5F_REG = 0x07;

	
	BK90_07_REG = 0xF7;//PCR reset
	BK90_0D_REG = 0xDF;//Pixel Pll reset
	BK90_0D_REG = 0xFF;//Pixel Pll release
	BK90_07_REG = 0xFF;//PCR release
	}

}

void ReadDpcd(u8 lenth)
{	
	u8 loopy=0;
	BKD8_55_REG = 0x80; //en
	BKD8_52_REG = AuxRxAddress[0];//address
	BKD8_51_REG = AuxRxAddress[1];
	BKD8_50_REG = AuxRxAddress[2];


	for(loopy=0; loopy<lenth; loopy++)
	{
		AuxRxSendData[loopy] = GetDpcdData();//read data from DPCD--sgl		
		BKD8_50_REG ++;
		
	}
//	BKD8_55_REG = 0x00; //en
	
	if((AuxRxAddress[0]==0x00)&&(AuxRxAddress[1]==0x02)&&(AuxRxAddress[2]==0x00))  //adjust swing 
	{
		if(lenth>2)
		{
		Rd_Dpcd202(2);
		}
		
	}
	else if((AuxRxAddress[0]==0x00)&&(AuxRxAddress[1]==0x02)&&(AuxRxAddress[2]==0x02))  //adjust swing 
	{
		Rd_Dpcd202(0);
	}	
}


void WriteDpcd(u8 lenth)
{	
	u8 loopy=0;
	u8 data_temp = 0x00;
	BKD8_55_REG  = 0x80;//soft AUX DPCD Read WRITE
	BKD8_52_REG = AuxRxAddress[0];//address
	BKD8_51_REG = AuxRxAddress[1];
	BKD8_50_REG = AuxRxAddress[2];

	for(loopy=0; loopy<lenth; loopy++)
	{
		BKD8_53_REG = AuxRxData[loopy];//Write DPCD data
		BKD8_50_REG ++;
	}
	
//	BKD8_55_REG = 0x00; //en
	
	if((AuxRxAddress[0]==0x00) &&( AuxRxAddress[1]==0x01) && (AuxRxAddress[2]==0x00) )	//DPCD100
	{	
		lane_width=AuxRxData[0];
		Reset_Rx_Flag =1;
		Traindown_Flag =0;
		Align_Flag = 0;
		if (lenth>1)   //0x00101
		{
			DPCD101 = AuxRxData[1];  
			lane_count = DPCD101&0x0f;  //lane count
		}
		if (lenth>2) //0x00102
		{
			Training_pattern =AuxRxData[2]&0x0f;
			Pattern_Training();
		}	   
	}

	else if((AuxRxAddress[0]==0x00) &&( AuxRxAddress[1]==0x01) && (AuxRxAddress[2]==0x01) )	//DPCD101
	{
		
		DPCD101 = AuxRxData[0];  
		lane_count = DPCD101&0x0f;  //lane count 
		if(lenth>1) //0x00102
		{
			Training_pattern =AuxRxData[1]&0x0f; 
			Pattern_Training();			
		}
	 #if Swing_En ==1
	  	if (lenth>=3)
	    {
			if((AuxRxData[2]&0x03)==0x02)
			{
				BKD8_19_REG =0x00;
			}
	  }
	  #endif
  }
	
	else if((AuxRxAddress[0]==0x00) &&( AuxRxAddress[1]==0x01) && (AuxRxAddress[2]==0x02) )	//DPCD102
	{
		Training_pattern=AuxRxData[0]&0x0f;
		Pattern_Training();	
		#if Swing_En ==1	
	  	if (lenth>=2)
			{
			if((AuxRxData[1]&0x03)==0x02)
			{
				BKD8_19_REG =0x00;
			}
	  	}
	  	#endif	
	}

#if Swing_En ==1
	
  	else if((AuxRxAddress[0]==0x00) &&( AuxRxAddress[1]==0x01) && (AuxRxAddress[2]==0x03) ) //DPCD103
	{ 
		if((AuxRxData[0]&0x03)==0x02)
	  	{
			BKD8_19_REG =0x00;
	  	} 
	}
  	#endif

	else if((AuxRxAddress[0]==0x00) &&( AuxRxAddress[1]==0x01) && (AuxRxAddress[2]==0x07) )//DPCD107
	{
		 Dpcd107_Write =1;
		if( AuxRxData[0]&0x10)
		{
			BKB8_3A_REG = 0x80;//ssc,2nd cdr
			BKB8_3B_REG = 0x52;
		}
		else
		{
			BKB8_3A_REG = 0x40;//No ssc, 1st cdr
			BKB8_3B_REG = 0x50;
#if 0	//2ND_CDR			
			BKB8_3A_REG = 0x80;//ssc,2nd cdr  ǿ��
			BKB8_3B_REG = 0x52;
#endif
		}
		if(lenth>1) 
		{
			if((AuxRxData[1])==0x00)
	  	{
				BKD8_50_REG = 0x08;
				BKD8_53_REG = 0x01;
	  	}			
		}
	}
	else if((AuxRxAddress[0]==0x00) &&( AuxRxAddress[1]==0x01) && (AuxRxAddress[2]==0x08) )//DPCD108
	{		 
		if((AuxRxData[0])==0x00)
	  {
				BKD8_50_REG = 0x08;
				BKD8_53_REG = 0x01;
	  }
		else
		{;}		
	}
}


void DP_RxPHY(void)
{
	BKB0_2E_REG = 0x20;//bit3:0 afe_pd<3:0>
}

void DP_RxPLL(void)
{
		//Rx PLL
	BKB0_2C_REG = 0x7f;//7f
	BKB8_16_REG = 0x50;//Band out mode sel HW
	BKB0_21_REG = 0x00;//rxpll pd off
	BKB0_22_REG	= 0xc1;//rxpll_vreg
	BKB0_28_REG = 0x19;//rxpll_vreg25_en
	BK90_0F_REG = 0x7f;
	BK90_0F_REG = 0xff;//rxpll reset
	delay1ms1(15);
	BKB8_14_REG = 0x40;//FM_EN
	delay1ms1(15);
	BKB8_14_REG = 0xc0;//CAL_EN
	delay1ms1(15);
	BKB8_14_REG = 0xe0;//TRAIN_SEL_MODE
	delay1ms1(10);
	BKB8_14_REG = 0xe4;//DP RX mainlink set RxPLL rate
	BKB8_21_REG = 0xe0;//DIV SET = 	1
}

void DP_CDR_PI(void)
{
	//CDR(ssc ON)
	BKB8_3A_REG = 0x80;
	BKB8_3B_REG = 0x52;
	//Rx PI
	BKB0_1F_REG = 0x00;//enbale pi
	BKB0_20_REG = 0x00;//enable pll2pi clk path
	BK90_0D_REG	= 0xe1;//bit4:1 pi_rst<0:3>
	BK90_03_REG	= 0xfe;//bit0 cdr_rst<0>
	BK90_03_REG	= 0x1f;//bit 7:5 cdr_rst<1:3>
	BK90_0F_REG = 0xbf;//bit6 rx_rst
	BK90_0F_REG	= 0xff;//bit6 release rx_rst
	BK90_0D_REG = 0xff;//bit4:1 release pi_rst<0:3>
	BK90_03_REG	= 0xff;//bit 7:5 release cdr_rst<1:3>
}

void AUX(void)
{
	BKA0_32_REG =0xe4; 
	BKD0_00_REG =0x00;
	BKD0_02_REG =0x10;
	BKD0_08_REG =0x0B;//aux_clk_div_num;
	BKD0_09_REG =0x66;
	BKD0_0A_REG =0x0e;
	BKD0_0B_REG =0x71;
	BKA0_30_REG =0x00;// DP_RX_HPD
	
	BK90_10_REG	= 0xEF;
	BK90_10_REG	= 0xFF;
}

void MainLink(void)
{
	BKDA_FC_REG =0x0f;//Odd and even
	BKDA_A3_REG	=0xe4;//rx lane swap 
	BKDA_A4_REG =0x80;//polarity swap
  BKB0_30_REG =0x40;
	BKD8_00_REG =0x11;//EQ hardware mode;HDCP disable

	hardmode_flag = 0;
	Dpcd107_Write =0;
}

void DP_PixelPLL(void)
{
	BKB0_3A_REG = 0xF8;
	BKB0_92_REG = 0x1F;//Pixel clk from PixelPLL
	BKB0_14_REG = 0x38;//b7-6:pixpll pd,b5-3:vreg_en
	BKB0_18_REG = 0x10;//Band out from reg
	BKB0_1A_REG = 0x0A;//iBand currnet setting
}

void DP_Video(void)
{
	BK90_07_REG = 0xf7;//[4]video_pwcr_rst
	BK90_07_REG = 0xff;	
	BKD2_69_REG = 0x05;//[7]rg_n_over_soft
	BKD2_02_REG	= 0x54;//For special condition
	BKD2_67_REG = 0x20;//For special condition
}

void Dp_Audio(void)
{
	BKB0_00_REG=0x00;//Audio PLL normal work
	BKB0_8C_REG=0x77;
	BKB0_8D_REG=0x00;
	BKB0_8E_REG=0x07;
	BKB0_8F_REG=0x77;
	BKD1_10_REG=0x20;
	BKD1_14_REG=0x19;
	BKD1_15_REG=0xC2;
	
	chip_write_i2c(0x9006,0x7f);
	DelayMs(1);
	chip_write_i2c(0x9006,0xFF);
}
void	DpRx_Mvid_Check(void)
{
	u8 Margin =0xF0;
	u32	sum_Mvid0,sum_Mvid1,sum_Mvid2,sum_Mvid3;
	sum_Mvid0	= ((u32)BKD1_CC_REG)<<16;
	sum_Mvid0	= sum_Mvid0+((u32)BKD1_CD_REG)<<8;
	sum_Mvid0	=	sum_Mvid0+((u32)BKD1_CE_REG&Margin)<<0;
	
	sum_Mvid1	= ((u32)BKD1_CF_REG)<<16;
	sum_Mvid1	= sum_Mvid1+((u32)BKD1_D0_REG)<<8;
	sum_Mvid1	=	sum_Mvid1+((u32)BKD1_D1_REG&Margin)<<0;
	
	sum_Mvid2	= ((u32)BKD1_D2_REG)<<16;
	sum_Mvid2	= sum_Mvid2+((u32)BKD1_D3_REG)<<8;
	sum_Mvid2	=	sum_Mvid2+((u32)BKD1_D4_REG&Margin)<<0;
	
	sum_Mvid3	= ((u32)BKD1_D5_REG)<<16;
	sum_Mvid3	= sum_Mvid3+((u32)BKD1_D6_REG)<<8;
	sum_Mvid3	=	sum_Mvid3+((u32)BKD1_D7_REG&Margin)<<0;
//	sum_Mvid1	= ((u32)BKD1_CF_REG<<16)+((u32)BKD1_D0_REG<<8)+(u32)BKD1_D1_REG&Margin;
//	sum_Mvid2	= ((u32)BKD1_D2_REG<<16)+((u32)BKD1_D3_REG<<8)+(u32)BKD1_D4_REG&Margin;
//	sum_Mvid3	= ((u32)BKD1_D5_REG<<16)+((u32)BKD1_D6_REG<<8)+(u32)BKD1_D7_REG&Margin;
	
/************the regs just for debug ******************/
//	BKD2_07_REG = (u8)(sum_Mvid0>>16);
//	BKD2_08_REG = (u8)(sum_Mvid0>>8);
//	BKD2_09_REG = (u8)(sum_Mvid0>>0);
//	
//	BKD2_0C_REG = (u8)(sum_Mvid1>>16);
//	BKD2_0D_REG = (u8)(sum_Mvid1>>8);
//	BKD2_0E_REG = (u8)(sum_Mvid1>>0);
//	
//	BKD2_0F_REG = (u8)(sum_Mvid2>>16);
//	BKD2_10_REG = (u8)(sum_Mvid2>>8);
//	BKD2_11_REG = (u8)(sum_Mvid2>>0);
//	
//	BKD2_12_REG = (u8)(sum_Mvid3>>16);
//	BKD2_14_REG = (u8)(sum_Mvid3>>8);
//	BKD2_15_REG = (u8)(sum_Mvid3>>0);
/************the regs just for debug ******************/

	if((sum_Mvid0!=sum_Mvid1)||(sum_Mvid0!=sum_Mvid2)||(sum_Mvid0!=sum_Mvid3)||(sum_Mvid1!=sum_Mvid2)||(sum_Mvid1!=sum_Mvid3)||(sum_Mvid2!=sum_Mvid3))
	{
		BK90_51_REG	= 0xF8;
		BK90_51_REG	= 0xFF;

		BK90_07_REG = 0xf7;
		BK90_0D_REG = 0xDF;
		BK90_0D_REG = 0xFF;//pixelpll reset			
		BK90_07_REG = 0xff;//PCR reset
		BKA0_A0_REG |= 0x01;
		BKA0_A0_REG &= 0xfe;
		BKD2_1C_REG =0xff;//Bit[0]set0 :Rg_video_out_int_clr
		BKD2_1C_REG =0xfe;//Bit[0]set0 :Rg_video_out_int_clr
		delay1ms1(500);
	}
	
}

void DP_Initial(void)
{
	DP_RxPHY();
	DP_RxPLL();
	DP_CDR_PI();
	DP_PixelPLL();
	DP_Video();
	//Dp_Audio();
	AUX();
	MainLink();
}

