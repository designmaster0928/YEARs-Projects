#include "include.h"


void InitTime0Inter(void)
{	
	//TMOD &= 0xF0;
	TMOD = 0x11;//time0 16bit 
	TR0 =0;//disable
	IT1 = 0;//TCON = 0x05;
	TH0 = 0xF7;//reloaed 300us 
	TL0 = 0x40;//
	
	TR1 = 0;//1
	TH1 = 0xB1;
	TL1 = 0xE0;

	IE=0x8e;   //EA=1;EX=1;ET1=0;ET0=1;
	
}

void SystemClk(void)
{
	BK90_62_REG=0x99;//System clk sel 24M
}

void linkAux_TypecEvb(void)
{
	BKC1_AF_REG =0xC3; // vconn
	BKDA_FC_REG =0x0f;//Odd and evern
	BKDA_A3_REG =0xe1;//rx lane swap 
	BKDA_A4_REG =0x05;//polarity swap
	BKB0_30_REG =0x42;

	BKD8_00_REG =0x11;//EQ hardware mode;HDCP disable
	BKB0_12_REG = 0x3e;
	hardmode_flag = 0;
	Dpcd107_Write =0;
}

void HPD_High(void)
{
	BKD0_05_REG|=0x40;	 // AUX HPD
	BKA0_30_REG=0x80; // DP_RX_HPD
	BKC0_06_REG=0x08; //HDMI_RX_HPD
}


void CC_INT(void)
{
	BKA0_90_REG = 0xFB;// disable ucc int mask
	BKB0_05_REG = 0x6F;
	delay1ms1(1);
	BKB0_05_REG = 0xE0;
	delay1ms1(1);
	BKB0_05_REG = 0x2B;//CC TX PHY disable
}

void AUX_INT(void)
{
	  BKD0_05_REG|=0x03;// AUX SOFT MODE
	  BKA0_A1_REG =0xff;
	  BKA0_A1_REG =0x7f;// clear interrupt 2
	  BKA0_91_REG =0x7f;//interupt bit 7: AuxRx_int_mask	
}

void Video_INT(void)
{
	BKD2_19_REG =0x01;//Bit[0]set1 :Rg_video_out_int_en
	BKD2_1C_REG =0xfe;//Bit[0]set0 :Rg_video_out_int_clr
	BKA0_90_REG&=0xfe;//INT0 Mask
	BKA0_A0_REG&=0xfe;//INT0 Clear
}

void  Attention_Send(void)
{
	if(Enter_AltMode==0x01)
	{
		Enter_AltMode =0x00;
		
		if(LastPG == DP_Config) 
		{
		Attention_Flag =1;
		LastPG=Attention;				
		send_over = 0; 		
		}		
		if(LastPG == Attention) 
		{
		delay1ms1(600);
		DataOrder = 7;	//send Request		
		TotalData = 10;
		LastPG=0xFF;
		Send_Message();
		send_over = 0;
		AUX_INT();
		Video_INT();
		HPD_High();				
		DPEnable =1;
		}	
	}
}

void RebulidEdid(void)
{
	if(g_EdidBlockCalEnable)
	{
		EDID_Dtb_Block_Calc(Edid+0x36);
	}
	EDID_CheckSum_Calc(Edid);
}

void DPCD_Parameter(u32 Addr, u8 Data)
{
//D855: bit[7]: 0:aux mode; 1:reg mode
//D852: DPCD[19:16]
//D851: DPCD[15:8]
//D850: DPCD[7:0]
//D853: Data
	BKD8_55_REG = 0x80;//Aux reg mode
	BKD8_52_REG = ((Addr>>16)&0x0f);
	BKD8_51_REG = ((Addr>>8)&0xff);
	BKD8_50_REG = (Addr&0xff);
	BKD8_53_REG = Data;
}

void DPCD_Init(void)
{
	DPCD_Parameter(0x00000,0x12);//DPCD Rev
	DPCD_Parameter(0x00001,g_DpcdSetStr.MaxLinkRate);//Max Lane Rate
	DPCD_Parameter(0x00002,(g_DpcdSetStr.MaxLinkCount|0x80));//Max Lane Count
	DPCD_Parameter(0x00003,g_DpcdSetStr.SSC);//SSC
	DPCD_Parameter(0x00004,0x01);//Receive port
	DPCD_Parameter(0x00005,0x00);//Downstream port
	DPCD_Parameter(0x00006,0x00);//8B10B Code
	DPCD_Parameter(0x00007,0x01);//Downstream count
	DPCD_Parameter(0x00008,0x02);//Local EDID
	DPCD_Parameter(0x00009,0x00);//No care
	DPCD_Parameter(0x0000A,0x00);//No care
	DPCD_Parameter(0x0000B,0x00);//No care
	DPCD_Parameter(0x0000D,0x00);//eDP , No care
	DPCD_Parameter(0x0000E,0x04);//Training Time No care
	DPCD_Parameter(0x0000F,0x00);//No care
	
	DPCD_Parameter(0x00020,0x00);
	DPCD_Parameter(0x00021,0x00);
	DPCD_Parameter(0x00200,0x01);//Sink Count
}

//void PCR_Reset(void)
//{
//	BK90_07_REG = 0xF7;
//	delay1ms1(10);
//	BK90_07_REG = 0xFF;

//	BK90_0D_REG = 0xDF;
//	delay1ms1(10);
//	BK90_0D_REG = 0xFF;	
//}


void SET_GPIO5_HIGH(void)
{
	BKA0_46_REG = 0x80;
	BKB0_8C_REG = 0x77;
	BKA0_48_REG = 0x04; //High
}

void SET_GPIO5_LOW(void)
{
	BKA0_46_REG = 0x80;
	BKB0_8C_REG = 0x77;
	BKA0_48_REG = 0x00; //Low
}

void SavePower(void)
{
	//For C/DP Input 
	BK90_51_REG = 0xfc;//disable CDR clock for data lane based on how many lanes you used 
	BK90_57_REG = 0xf9;//disable DPRX main link lane based on how many lanes you used 
	BK90_58_REG = 0x33;//disable DPRX main link lane cdr clock based on how many lanes you used 
	BK90_5A_REG = 0xfc;//disable HDMI RX Sys_clk and tmds_clk
	BK90_5B_REG = 0x00;//disable HDMI RX...
	BK90_5C_REG = 0x00;//disable HDMI RX...
	BK90_5D_REG = 0x18;//disable HDMI RX and LVDS TX...
	BK90_5E_REG = 0x88;//disable unused MIPITX port...
	BK90_5F_REG = 0x18;//disable unused MIPITX port...
	BK90_61_REG = 0x11;//disable unused MIPITX port...
	
	BKB0_1F_REG = 0x0C;//PD unuse lane PI
	//BKB0_00_REG = 0xc0;//Close Audio
	BKB0_44_REG = 0xc4;//disable port0
	BKB0_55_REG = 0x04;//disable port1
	BKB0_66_REG = 0x04;//disable port2
	
	BKB0_2E_REG = 0x2C;//afe_pd
}
void Lt7911_InitialSteps(void)
{
	u8 Margin =0xF0;
	u8 TM1_EN = 0;
	u16	time1_500ms=0;
	u32	sum_Mvid0,sum_Mvid1,sum_Mvid2,sum_Mvid3;
	
	delay1ms1(200);
	g_timer1_4scnt = 0;
	Lt7911D_FwVersionSet();
	RebulidEdid();
	InitTime0Inter();
	SystemClk();
	SET_GPIO5_HIGH();
	DP_Initial();
	DPCD_Init();
	if(g_InputType == Typec_Source)
		{
			CC_INT();
			TypeCInit();	
			linkAux_TypecEvb();
		}
	else
		{
			EA = 1;
			DPEnable = 1;
			AUX_INT();
			Video_INT();
			HPD_High();	
		}
	while(1)
	{
		if(g_InputType == Typec_Source)
			{
				Attention_Send();
			}
		
		if(Hsync_Release)
			{
				if(FlagVideoOK)
				{
					FlagVideoOK = FALSE;
					Traindown_Flag = FALSE;
					delay1ms1(100);
					MipiInitial();
					Dp_Audio();
					//SavePower();
					SET_GPIO5_LOW();
					DelayMs(200);
					SET_GPIO5_HIGH();
				}
			}
		else
		{
			if(Traindown_Flag)
			{
				TM1_EN = 1;
				delay1ms1(1);
				if(time1_500ms==500)//delay1ms1(500);	
				{
						TM1_EN = 0;
						time1_500ms = 0;
						if((!(BKB8_B0_REG&0x20))&&(BKB8_B0_REG&0x40))//RXPLL Lock but pixpll unlock  20190408
						{
							if(!Hsync_Release)
							{
								BK90_07_REG = 0xf7;
								BK90_0D_REG = 0xDF;
								BK90_0D_REG = 0xFF;//pixelpll reset			
								BK90_07_REG = 0xff;//PCR reset						
							}
						}
						else if(((BKB8_B0_REG&0x20))&&(BKB8_B0_REG&0x40))
						{					
							sum_Mvid0	= ((u32)BKD1_CC_REG)<<16;
							sum_Mvid0	= sum_Mvid0+((u32)BKD1_CD_REG)<<8;
							sum_Mvid0	=	sum_Mvid0+((u32)BKD1_CE_REG&Margin)<<0;
							
							sum_Mvid1	= ((u32)BKD1_CF_REG)<<16;
							sum_Mvid1	= sum_Mvid1+((u32)BKD1_D0_REG)<<8;
							sum_Mvid1	=	sum_Mvid1+((u32)BKD1_D1_REG&Margin)<<0;
							
							sum_Mvid2	= ((u32)BKD1_D2_REG)<<16;
							sum_Mvid2	= sum_Mvid2+((u32)BKD1_D3_REG)<<8;
							sum_Mvid2	=	sum_Mvid2+((u32)BKD1_D4_REG&Margin)<<0;
							
							sum_Mvid3	= ((u32)BKD1_D5_REG)<<16;
							sum_Mvid3	= sum_Mvid3+((u32)BKD1_D6_REG)<<8;
							sum_Mvid3	=	sum_Mvid3+((u32)BKD1_D7_REG&Margin)<<0;

							if((sum_Mvid0!=sum_Mvid1)||(sum_Mvid0!=sum_Mvid2)||(sum_Mvid0!=sum_Mvid3)||(sum_Mvid1!=sum_Mvid2)||(sum_Mvid1!=sum_Mvid3)||(sum_Mvid2!=sum_Mvid3))
							{
									BK90_51_REG	= 0xF0;
									BK90_51_REG	= 0xFF;

									BK90_07_REG = 0xf7;
									BK90_0D_REG = 0xDF;
									BK90_0D_REG = 0xFF;//pixelpll reset			
									BK90_07_REG = 0xff;//PCR reset
		//							delay1ms1(500);						
							}
						}
				}
			}
		}
		if(TM1_EN)
			time1_500ms++;

	}
}