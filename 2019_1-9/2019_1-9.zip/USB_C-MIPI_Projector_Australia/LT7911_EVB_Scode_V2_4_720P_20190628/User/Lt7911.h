#ifndef _LT7911_H
#define _LT7911_H

void DelayMs(u16 var);
void chip_write_i2c(u8 xdata *p ,u8 val);
u8 chip_read_i2c(u8 xdata *p );
void Lt7911_InitialSteps(void);
void DPCD_Parameter(u32 Addr, u8 Data);
#endif
