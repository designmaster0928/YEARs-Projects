#ifndef _MIPI_H
#define _MIPI_H


void MipiInitial(void);

#endif

