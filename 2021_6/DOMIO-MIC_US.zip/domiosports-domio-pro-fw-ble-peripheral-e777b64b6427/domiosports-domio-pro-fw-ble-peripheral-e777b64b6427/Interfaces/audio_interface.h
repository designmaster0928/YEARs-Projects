/**
 * \file audio_interface.h
 * \brief Audio Interface header file.
 *
 * \author Domio Sports
 *
 * Audio Interface - Header definitions file for the interface that
 * handles the audio peripheral.
 *
 * Revisions: none
 *
 * \date Nov. 29, 2018
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

#ifndef AUDIO_INTERFACE_H_
#define AUDIO_INTERFACE_H_

/*==================================================================
 * Includes
 ==================================================================*/

/*==================================================================
 * Defines
 ==================================================================*/

/*==================================================================
 * Typedefs
 ==================================================================*/

typedef enum
{
    AUDIO_INTERFACE_EVT_TX_DATA_REQ,        /* Request for I2S TX buffer */
    AUDIO_INTERFACE_EVT_RX_DATA_REC,   /* I2S RX buffer received */
} audio_interface_evt_type_t;

typedef struct
{
    audio_interface_evt_type_t evt;
    union
    {
        struct
        {
            uint32_t * p_data_to_send;  /* Pointer to buffer that should be filled  */
            uint16_t   number_of_words; /* Buffer size in number of Words (32 bits) */
        } tx_buf_req;
        struct
        {
            uint32_t const * p_data_received;   /* Pointer to buffer that should be filled  */
            uint16_t   number_of_words;         /* Buffer size in number of samples (16 bits) */
        } rx_buf_received;
    } param;
} audio_interface_evt_t;

typedef bool (* audio_interface_handler_t)(audio_interface_evt_t * p_evt);

/*==================================================================
 * Function Prototypes
 ==================================================================*/

void audio_interface_init(audio_interface_handler_t evt_handler);

void audio_interface_start();

void audio_interface_stop();


#endif /* AUDIO_INTERFACE_H_ */
