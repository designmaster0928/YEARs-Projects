/**
 * \file pmic_interface.h
 * \brief Power management IC interface header file.
 *
 * \author Domio Sports
 *
 * PMIC Interface - Power Management IC interface header definitions file.
 *
 * Revisions: none
 *
 * \date Jan. 2, 2019
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

#ifndef PMIC_INTERFACE_H_
#define PMIC_INTERFACE_H_

/*==================================================================
 * Includes
 ==================================================================*/

/*==================================================================
 * Defines
 ==================================================================*/

/*==================================================================
 * Typedefs
 ==================================================================*/

/*==================================================================
 * Function Prototypes
 ==================================================================*/

void pmic_interface_init();

void pmic_interface_shutdown_en();

void pmic_interface_shutdown_dis();

void pmic_interface_task();

bool pmic_interface_check_vin();

bool pmic_interface_check_poweron();

#endif /* PMIC_INTERFACE_H_ */
