/**
 * \file ble_interface.h
 * \brief BLE Interface header file.
 *
 * \author Domio Sports
 *
 * BLE Interface - Header definitions file for the interface with the
 * BLE stack.
 *
 * Revisions: none
 *
 * \date Nov. 5, 2018
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

#ifndef BLE_INTERFACE_H_
#define BLE_INTERFACE_H_

/*==================================================================
 * Includes
 ==================================================================*/

/*==================================================================
 * Defines
 ==================================================================*/

/*
 * BLE connection parameters
 */

// Domio UUID = b86e5f09-7085-49ad-9772-d39df05a367b
#define SERVICE_UUID_BASE   {0x7B, 0x36, 0x5A, 0xF0, 0x9D, 0xD3, 0x72, 0x97, \
    0xAD, 0x49, 0x85, 0x70, 0x09, 0x5F, 0x6E, 0xB8}

#define DOMIC_SERVICE_UUID             0xD0BA
#define DOMIC_AUDIO_CHAR_UUID          0xD0AC
#define DOMIC_CONFIG_CHAR_UUID         0xD0CC

#define CONN_INTERVAL_DEFAULT           (uint16_t)(MSEC_TO_UNITS(15, UNIT_1_25_MS))    /**< Default connection interval used at connection establishment by central side. */

#define CONN_INTERVAL_MIN               (uint16_t)(MSEC_TO_UNITS(7.5, UNIT_1_25_MS))    /**< Minimum acceptable connection interval, in 1.25 ms units. */
#define CONN_INTERVAL_MAX               (uint16_t)(MSEC_TO_UNITS(50, UNIT_1_25_MS))    /**< Maximum acceptable connection interval, in 1.25 ms units. */
#define CONN_SUP_TIMEOUT                (uint16_t)(MSEC_TO_UNITS(4000,  UNIT_10_MS))    /**< Connection supervisory timeout (4 seconds). */
#define SLAVE_LATENCY                   0                                               /**< Slave latency. */

/*==================================================================
 * Typedefs
 ==================================================================*/

/**@brief Domio BLE interface return status type. */
typedef enum
{
	BLE_DOMIO_RET_OK,
	BLE_DOMIO_RET_ERROR,
	BLE_DOMIO_RET_BUSY,
} ble_domio_return_type_t;

/**@brief Domio BLE interface event type. */
typedef enum
{
	BLE_DOMIO_EVT_NOTIF_ENABLED,
	BLE_DOMIO_EVT_NOTIF_DISABLED,
	BLE_DOMIO_EVT_MAX_PAYLOAD_UPDATE,
	BLE_DOMIO_EVT_TRANSMIT_COMPLETED,
	BLE_DOMIO_EVT_TRANSFER_START,
	BLE_DOMIO_EVT_TRANSFER_STOP,
	BLE_DOMIO_EVT_DISCONNECTED,
} ble_domio_evt_type_t;

/**@brief Domio BLE interface Event structure. */
typedef struct
{
	ble_domio_evt_type_t evt_type;		//!< Type of the event. */

	union {
		uint32_t bytes_transfered_cnt;	//!< Number of bytes sent during the transfer*/
		uint16_t max_payload_len;		//!< New maximum size for data payload */
	} payload;
} ble_domio_evt_t;

/**@brief Domio BLE interface event handler type.
 * The BLE interface will call this function when notifications have been enabled/disabled, ....
*/
typedef void (*ble_interface_evt_handler_t)(ble_domio_evt_t);

/*==================================================================
 * Function Prototypes
 ==================================================================*/

void ble_interface_init(ble_interface_evt_handler_t evt_handler);

void ble_interface_adv_start(bool erase_bonds);

void ble_interface_adv_stop();

ble_domio_return_type_t ble_interface_send_notif(uint8_t *data, uint16_t *payload_len);

#endif /* BLE_INTERFACE_H_ */
