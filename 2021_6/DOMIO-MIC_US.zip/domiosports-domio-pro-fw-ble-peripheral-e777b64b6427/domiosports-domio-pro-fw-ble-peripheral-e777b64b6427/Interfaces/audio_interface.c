/**
 * \file audio_interface.c
 * \brief Audio Interface source file.
 *
 * \author Domio Sports
 *
 * Audio Interface - Source implementation file for the interface that
 * handles the audio peripheral.
 *
 * Revisions: none
 *
 * \date Nov. 29, 2018
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

/*==================================================================
 * Includes
 ==================================================================*/

#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include "nrf.h"
#include "nrf_drv_timer.h"
#include "nrf_drv_i2s.h"
#include "nrf_drv_spis.h"
#include "nrf_drv_twi.h"
#include "app_error.h"
#include "mem_manager.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "boards.h" // In order to get Ardunio PIN mapping for DKs

#include "audio_interface.h"

/*==================================================================
 * Private Defines
 ==================================================================*/

#define AUDIO_INTERFACE_I2S_ENABLE		1		// define to select if audio module operates with I2S interface
#define AUDIO_INTERFACE_SPI_ENABLE		0		// define to select if audio module operates with SPI interface
#define AUDIO_INTERFACE_TIMER_ENABLE	0		// define to select if audio module operates with timer simulation interface

#if ((AUDIO_INTERFACE_I2S_ENABLE + AUDIO_INTERFACE_SPI_ENABLE + AUDIO_INTERFACE_TIMER_ENABLE) != 1)
#error "One and only one interface operation method must be selected."
#endif

#if (AUDIO_INTERFACE_I2S_ENABLE == 1)

#define I2S_SAMPLERATE					16000

// I2S Settings
#define AUDIO_INTERFACE_I2S_IRQPriority  APP_IRQ_PRIORITY_LOWEST

// I2S pin mapping
#define AUDIO_INTERFACE_I2S_PIN_MCLK  NRF_DRV_I2S_PIN_NOT_USED
#define AUDIO_INTERFACE_I2S_PIN_BCLK  ARDUINO_9_PIN   /* 20 for nRF52832 DK, 1,11 for 52840 */ /* PC10 of ST Micro NUCLEO-F446RE */
#define AUDIO_INTERFACE_I2S_PIN_LRCLK ARDUINO_11_PIN  /* 23 for nRF52832 DK, 1,12 for 52840 */ /* PA4 of ST Micro NUCLEO-F446RE */
#define AUDIO_INTERFACE_I2S_PIN_RX    ARDUINO_13_PIN  /* 25 for nRF52832 DK, 1,15 for 52840 */ /* PC12 of ST Micro NUCLEO-F446RE */
#define AUDIO_INTERFACE_I2S_PIN_TX    NRF_DRV_I2S_PIN_NOT_USED

#define CONFIG_AUDIO_FRAME_SIZE_MS 5
#define CONFIG_AUDIO_SAMPLING_FREQUENCY 16000
#define CONFIG_AUDIO_FRAME_SIZE_SAMPLES (CONFIG_AUDIO_FRAME_SIZE_MS * CONFIG_AUDIO_SAMPLING_FREQUENCY / 1000)
#define DATA_BUFFER_SIZE         CONFIG_AUDIO_FRAME_SIZE_SAMPLES * 2  // Should match OPUS frame - double buffered - and central!
#endif

#if (AUDIO_INTERFACE_SPI_ENABLE == 1)
#define APP_SPIS_SCK_PIN		ARDUINO_9_PIN   /* 20 for nRF52832 DK, 1,11 for 52840 */ /* PC10 of ST Micro NUCLEO-F446RE */
#define APP_SPIS_MISO_PIN		NRF_DRV_SPIS_PIN_NOT_USED
#define APP_SPIS_MOSI_PIN		ARDUINO_13_PIN  /* 25 for nRF52832 DK, 1,15 for 52840 */ /* PC12 of ST Micro NUCLEO-F446RE */
#define APP_SPIS_CS_PIN			ARDUINO_10_PIN  /* 22 for nRF52832 DK, 1,12 for 52840 */ /* PA4 of ST Micro NUCLEO-F446RE */

#define CONFIG_AUDIO_FRAME_SIZE_MS 10
#define CONFIG_AUDIO_SAMPLING_FREQUENCY 16000
#define CONFIG_AUDIO_FRAME_SIZE_SAMPLES 120u
#define DATA_BUFFER_SIZE         CONFIG_AUDIO_FRAME_SIZE_SAMPLES * 2  // Should match OPUS frame - double buffered - and central!
#endif

#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
#define TIMER_FREQ			16000
#define SIN_FREQ			400
#define NUM_SAMPLES			(TIMER_FREQ/SIN_FREQ)
#endif

#ifndef M_PI
#define M_PI (3.14159265358979323846)
#endif

// voice processor enable/disable pin
#define AUDIO_INTERFACE_PROC_EN_PIN		ARDUINO_11_PIN  /* 23 for nRF52832 DK, 1,13 for 52840 */ /* PA0 of ST Micro NUCLEO-F413ZH */
#define VOICE_PROC_ENABLE()					do { \
		nrf_gpio_pin_set(AUDIO_INTERFACE_PROC_EN_PIN);\
		} while(0);
#define VOICE_PROC_DISABLE()				do { \
		nrf_gpio_pin_clear(AUDIO_INTERFACE_PROC_EN_PIN);\
		} while(0);

/*==================================================================
 * Private Typedefs
 ==================================================================*/

/**@brief Audio Module structure.
 * @details This structure contains control information for the Audio module. */
typedef struct
{
#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
	int16_t data[NUM_SAMPLES];
#endif

#if (AUDIO_INTERFACE_I2S_ENABLE == 1)
	nrf_drv_i2s_config_t       i2s_config;

	struct
	{
	    uint32_t * tx_buffer;
	    uint32_t * rx_buffer;
	    uint32_t   buffer_len;
	} external_i2s_buffer;
#endif

#if (AUDIO_INTERFACE_SPI_ENABLE == 1)
	int16_t *last_data_buffer;
	uint16_t tx_data;
	nrf_drv_spis_config_t spis_config;
#endif

	int16_t data_rx_buffer[DATA_BUFFER_SIZE];

	audio_interface_handler_t audio_evt_handler;
} audio_interface_ctrl_t;

/*==================================================================
 * Private Function Prototypes
 ==================================================================*/

#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
/**
 * @brief Handler for timer events.
 */
void timer_data_event_handler(nrf_timer_event_t event_type, void* p_context);
#endif

#if (AUDIO_INTERFACE_I2S_ENABLE == 1)
static void i2s_data_handler(uint32_t const * p_data_received, uint32_t * p_data_to_send, uint16_t number_of_words);
#endif

#if (AUDIO_INTERFACE_SPI_ENABLE == 1)
/**
 * @brief SPIS user event handler.
 *
 * @param event
 */
void spis_event_handler(nrf_drv_spis_event_t event);
#endif

/*==================================================================
 * Firmware Global Variables
 ==================================================================*/

/*==================================================================
 * File Global Variables
 ==================================================================*/

#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
const nrf_drv_timer_t TIMER_DATA = NRF_DRV_TIMER_INSTANCE(1);
#endif

#if (AUDIO_INTERFACE_SPI_ENABLE == 1)
#define SPIS_INSTANCE 0 /**< SPIS instance index. */
static const nrf_drv_spis_t spis = NRF_DRV_SPIS_INSTANCE(SPIS_INSTANCE);/**< SPIS instance. */
#endif

audio_interface_ctrl_t m_audio_interface_ctrl;

/*==================================================================
 * Function Implementations
 ==================================================================*/

void audio_interface_init(audio_interface_handler_t evt_handler) {
	uint32_t err_code = NRF_SUCCESS;

	m_audio_interface_ctrl.audio_evt_handler = evt_handler;

#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
	uint32_t time_ticks;

    //Configure TIMER_DATA for interrupts at 16kHz.
    nrf_drv_timer_config_t timer_cfg = NRF_DRV_TIMER_DEFAULT_CONFIG;
    err_code = nrf_drv_timer_init(&TIMER_DATA, &timer_cfg, timer_data_event_handler);
    APP_ERROR_CHECK(err_code);

    time_ticks = nrf_drv_timer_us_to_ticks(&TIMER_DATA, 1000000 / TIMER_FREQ);

    nrf_drv_timer_extended_compare(
         &TIMER_DATA, NRF_TIMER_CC_CHANNEL0, time_ticks, NRF_TIMER_SHORT_COMPARE0_CLEAR_MASK, true);

    // populate the sample data array
    for (int i = 0; i < NUM_SAMPLES; i++) {
    	m_audio_interface_ctrl.data[i] = 32767 * sin(i*2*M_PI/NUM_SAMPLES);
    }
#elif (AUDIO_INTERFACE_I2S_ENABLE == 1)
    // Update configuration
    m_audio_interface_ctrl.external_i2s_buffer.tx_buffer     = NULL; // transmission is disabled on mic side
    m_audio_interface_ctrl.external_i2s_buffer.rx_buffer     = (void *)m_audio_interface_ctrl.data_rx_buffer;
    m_audio_interface_ctrl.external_i2s_buffer.buffer_len    = sizeof(m_audio_interface_ctrl.data_rx_buffer);

    // Initialize I2S
    m_audio_interface_ctrl.i2s_config.sck_pin      = AUDIO_INTERFACE_I2S_PIN_BCLK;
    m_audio_interface_ctrl.i2s_config.lrck_pin     = AUDIO_INTERFACE_I2S_PIN_LRCLK;
    m_audio_interface_ctrl.i2s_config.mck_pin      = AUDIO_INTERFACE_I2S_PIN_MCLK;
    m_audio_interface_ctrl.i2s_config.sdout_pin    = AUDIO_INTERFACE_I2S_PIN_TX;
    m_audio_interface_ctrl.i2s_config.sdin_pin     = AUDIO_INTERFACE_I2S_PIN_RX;
    m_audio_interface_ctrl.i2s_config.irq_priority = AUDIO_INTERFACE_I2S_IRQPriority;
//    m_audio_interface_ctrl.i2s_config.mode         = NRF_I2S_MODE_MASTER;
    m_audio_interface_ctrl.i2s_config.mode         = NRF_I2S_MODE_SLAVE; // set to slave to test with ST Micro kit
    nrf_mem_init();
    m_audio_interface_ctrl.i2s_config.format       = NRF_I2S_FORMAT_I2S;
    m_audio_interface_ctrl.i2s_config.alignment    = NRF_I2S_ALIGN_LEFT;
    m_audio_interface_ctrl.i2s_config.sample_width = NRF_I2S_SWIDTH_16BIT;
    m_audio_interface_ctrl.i2s_config.channels     = NRF_I2S_CHANNELS_STEREO;

    m_audio_interface_ctrl.i2s_config.mck_setup    = NRF_I2S_MCK_32MDIV4; // div4 - MCLK 8MHz.
    m_audio_interface_ctrl.i2s_config.ratio        = NRF_I2S_RATIO_512X;  // BCLK = 8 MHz / 512 = 15625 Hz
    // disable MCLK since we are slave for test with ST Micro kit
    m_audio_interface_ctrl.i2s_config.mck_setup    = NRF_I2S_MCK_DISABLED;

    err_code = nrf_drv_i2s_init(&m_audio_interface_ctrl.i2s_config, i2s_data_handler);
    if (err_code != NRF_SUCCESS)
    {
        APP_ERROR_CHECK(err_code);
    }
#elif (AUDIO_INTERFACE_SPI_ENABLE == 1)
    m_audio_interface_ctrl.spis_config.miso_drive   = NRF_DRV_SPIS_DEFAULT_MISO_DRIVE;
    m_audio_interface_ctrl.spis_config.csn_pullup   = NRF_DRV_SPIS_DEFAULT_CSN_PULLUP;
    m_audio_interface_ctrl.spis_config.orc          = SPIS_DEFAULT_ORC;
    m_audio_interface_ctrl.spis_config.def          = SPIS_DEFAULT_DEF;
    m_audio_interface_ctrl.spis_config.irq_priority = SPIS_DEFAULT_CONFIG_IRQ_PRIORITY;

    m_audio_interface_ctrl.spis_config.csn_pin = APP_SPIS_CS_PIN;
    m_audio_interface_ctrl.spis_config.miso_pin = APP_SPIS_MISO_PIN;
    m_audio_interface_ctrl.spis_config.mosi_pin = APP_SPIS_MOSI_PIN;
    m_audio_interface_ctrl.spis_config.sck_pin = APP_SPIS_SCK_PIN;
    m_audio_interface_ctrl.spis_config.mode = NRF_DRV_SPIS_MODE_3;
    m_audio_interface_ctrl.spis_config.bit_order = NRF_DRV_SPIS_BIT_ORDER_LSB_FIRST;

    m_audio_interface_ctrl.last_data_buffer = m_audio_interface_ctrl.data_rx_buffer;
    m_audio_interface_ctrl.tx_data = m_audio_interface_ctrl.spis_config.orc;
#endif

	// configure output for voice processor enable/disable
	nrf_gpio_cfg_output(AUDIO_INTERFACE_PROC_EN_PIN);
	VOICE_PROC_DISABLE();
}

void audio_interface_start() {
#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
	NRF_LOG_DEBUG("Starting audio timer.");
	nrf_drv_timer_enable(&TIMER_DATA);
#elif (AUDIO_INTERFACE_I2S_ENABLE == 1)
	NRF_LOG_DEBUG("Starting audio I2S interface.");
    nrf_drv_i2s_start(
    		m_audio_interface_ctrl.external_i2s_buffer.rx_buffer,
			m_audio_interface_ctrl.external_i2s_buffer.tx_buffer,
			(m_audio_interface_ctrl.external_i2s_buffer.buffer_len / sizeof(uint32_t)),
			0
			);
#elif (AUDIO_INTERFACE_SPI_ENABLE == 1)
    uint32_t err_code = NRF_SUCCESS;

    err_code = nrf_drv_spis_init(&spis, &m_audio_interface_ctrl.spis_config, spis_event_handler);
    if (err_code != NRF_SUCCESS)
    {
        APP_ERROR_CHECK(err_code);
    }

    err_code = nrf_drv_spis_buffers_set(&spis,
    		(uint8_t *)&m_audio_interface_ctrl.tx_data, sizeof(m_audio_interface_ctrl.tx_data),
			(uint8_t *) m_audio_interface_ctrl.last_data_buffer, CONFIG_AUDIO_FRAME_SIZE_SAMPLES*sizeof(*m_audio_interface_ctrl.data_rx_buffer));
    if (err_code != NRF_SUCCESS)
    {
        APP_ERROR_CHECK(err_code);
    }
#endif

	// enable the voice processor
	VOICE_PROC_ENABLE();
}

void audio_interface_stop() {
#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
	nrf_drv_timer_disable(&TIMER_DATA);
#elif (AUDIO_INTERFACE_I2S_ENABLE == 1)
	NRF_LOG_DEBUG("Stopping audio I2S interface.");
    nrf_drv_i2s_stop();
#elif (AUDIO_INTERFACE_SPI_ENABLE == 1)
    uint32_t err_code = NRF_SUCCESS;

    nrf_drv_spis_uninit(&spis);

    err_code = nrf_drv_spis_buffers_set(&spis,
    		(uint8_t *) m_audio_interface_ctrl.last_data_buffer, 0,
			(uint8_t *) m_audio_interface_ctrl.last_data_buffer, 0);
    if (err_code != NRF_SUCCESS)
    {
        APP_ERROR_CHECK(err_code);
    }
#endif

	// disable the voice processor
	VOICE_PROC_DISABLE();
}

/*==================================================================
 * Private Function Implementations
 ==================================================================*/

#if (AUDIO_INTERFACE_TIMER_ENABLE == 1)
void timer_data_event_handler(nrf_timer_event_t event_type, void* p_context)
{
	static uint16_t sample_idx = 0;
	static int16_t sample_val = 0;

    switch (event_type)
    {
        case NRF_TIMER_EVENT_COMPARE0:
//        	m_audio_interface_ctrl.data[sample_idx] = sample_val++;
        	if (++sample_idx >= NUM_SAMPLES) {
//            	NRF_LOG_INFO("Timer event triggered.");
        		sample_idx = 0;
//        		if (m_audio_interface_ctrl.audio_evt_handler != NULL) {
//        			m_audio_interface_ctrl.audio_evt_handler(m_audio_interface_ctrl.data, NUM_SAMPLES);
//        		}

            	audio_interface_evt_t evt;

                evt.evt                                     = AUDIO_INTERFACE_EVT_RX_DATA_REC;
                evt.param.rx_buf_received.p_data_received   = (uint32_t *)m_audio_interface_ctrl.data;
                evt.param.rx_buf_received.number_of_words   = NUM_SAMPLES;

                m_audio_interface_ctrl.audio_evt_handler(&evt);
        	}
            break;

        default:
            //Do nothing.
            break;
    }
}
#endif


#if (AUDIO_INTERFACE_I2S_ENABLE == 1)
static void i2s_data_handler(uint32_t const * p_data_received, uint32_t * p_data_to_send, uint16_t number_of_words)
{
    // Non-NULL value in 'p_data_received' indicates that a new portion of
    // data has been received and should be processed.
    if (p_data_received != NULL)
    {
    	audio_interface_evt_t evt;

        evt.evt                                     = AUDIO_INTERFACE_EVT_RX_DATA_REC;
        evt.param.rx_buf_received.p_data_received   = p_data_received;

        if (m_audio_interface_ctrl.i2s_config.mode == NRF_I2S_MODE_SLAVE) {
#if I2S_SAMPLERATE == 32000
        	// in slave mode we are interfacing with the ST micro kit, which has 32kHz stereo output, so we skip 3 out of 4 samples
        	int16_t *data = (int16_t *)nrf_malloc(number_of_words*sizeof(*data) / 2);
        	for (int i = 0; i < number_of_words / 2; i++) {
        		data[i] = ((int16_t *)p_data_received)[4*i];
        	}
        	evt.param.rx_buf_received.p_data_received = (uint32_t *)data;
            evt.param.rx_buf_received.number_of_words   = number_of_words / 2;
#elif I2S_SAMPLERATE == 16000
        	// in slave mode we are interfacing with the ST micro kit, which has 16kHz stereo output, so we skip 1 out of 2 samples
        	int16_t *data = (int16_t *)nrf_malloc(number_of_words*sizeof(*data) / 2);
        	for (int i = 0; i < number_of_words; i++) {
        		data[i] = ((int16_t *)p_data_received)[2*i];
        	}
        	evt.param.rx_buf_received.p_data_received = (uint32_t *)data;
            evt.param.rx_buf_received.number_of_words   = number_of_words;
#endif // I2S_SAMPLERATE

            m_audio_interface_ctrl.audio_evt_handler(&evt);
            nrf_free((void *)data);
        } else {

            evt.param.rx_buf_received.number_of_words   = 2 * number_of_words;

            m_audio_interface_ctrl.audio_evt_handler(&evt);
        }
    }

    // Non-NULL value in 'p_data_to_send' indicates that the driver needs
    // a new portion of data to send.
    if (p_data_to_send != NULL)
    {
    	// shouldn't reach this point.
        return;
    }
}
#endif


#if (AUDIO_INTERFACE_SPI_ENABLE == 1)
void spis_event_handler(nrf_drv_spis_event_t event)
{
    if (event.evt_type == NRF_DRV_SPIS_XFER_DONE)
    {
//        spis_xfer_done = true;
//        NRF_LOG_INFO(" Transfer completed. Received: %s",(uint32_t)m_rx_buf);
    	int16_t *current_buffer = m_audio_interface_ctrl.last_data_buffer;

        // check which half of the buffer should be used next
        if (m_audio_interface_ctrl.last_data_buffer == m_audio_interface_ctrl.data_rx_buffer) {
        	m_audio_interface_ctrl.last_data_buffer = &m_audio_interface_ctrl.data_rx_buffer[CONFIG_AUDIO_FRAME_SIZE_SAMPLES];
        } else {
        	m_audio_interface_ctrl.last_data_buffer = m_audio_interface_ctrl.data_rx_buffer;
        }
        uint32_t err_code = NRF_SUCCESS;
        err_code = nrf_drv_spis_buffers_set(&spis,
        		(uint8_t*) m_audio_interface_ctrl.last_data_buffer, CONFIG_AUDIO_FRAME_SIZE_SAMPLES*sizeof(*m_audio_interface_ctrl.data_rx_buffer),
    			(uint8_t*) m_audio_interface_ctrl.last_data_buffer, CONFIG_AUDIO_FRAME_SIZE_SAMPLES*sizeof(*m_audio_interface_ctrl.data_rx_buffer));
        if (err_code != NRF_SUCCESS)
        {
            APP_ERROR_CHECK(err_code);
        }

        // in spi mode we are interfacing with the ST micro kit, which has 2 channels output, so we skip every other sample
    	for (int i = 1; i < event.rx_amount / sizeof(*m_audio_interface_ctrl.data_rx_buffer) / 2; i++) {
    		current_buffer[i] = current_buffer[2*i];
    	}

    	audio_interface_evt_t evt;

        evt.evt                                     = AUDIO_INTERFACE_EVT_RX_DATA_REC;
        evt.param.rx_buf_received.p_data_received   = (uint32_t *)current_buffer;
        evt.param.rx_buf_received.number_of_words   = event.rx_amount / sizeof(*m_audio_interface_ctrl.data_rx_buffer) / 2;

        m_audio_interface_ctrl.audio_evt_handler(&evt);
    }
}
#endif
