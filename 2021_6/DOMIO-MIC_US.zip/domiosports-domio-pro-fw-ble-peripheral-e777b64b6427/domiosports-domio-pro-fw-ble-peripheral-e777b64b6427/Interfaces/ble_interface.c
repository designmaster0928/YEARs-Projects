/**
 * \file ble_interface.c
 * \brief BLE Interface source file.
 *
 * \author Domio Sports
 *
 * BLE Interface - Source implementation file for the interface with
 * the BLE stack.
 *
 * Revisions: none
 *
 * \date Nov. 5, 2018
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

/*==================================================================
 * Includes
 ==================================================================*/

#include <stdint.h>
#include "sdk_config.h"
#include "nrf.h"
#include "ble.h"
#include "nordic_common.h"

#include "ble_advertising.h"
#include "ble_advdata.h"
#include "ble_conn_state.h"
#include "ble_srv_common.h"
#include "nrf_sdh.h"
#include "nrf_sdh_ble.h"
#include "nrf_sdh_soc.h"
#include "nrf_ble_gatt.h"
#include "peer_manager.h"
#include "fds.h"

#include "boards.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "ble_interface.h"

/*==================================================================
 * Private Defines
 ==================================================================*/

/*
 * BLE connection parameters
 */

#define DOMIO_CONFIG_MAX_LEN           4

#define BLE_DOMIO_BLE_OBSERVER_PRIO   3

#define SCAN_ADV_LED                    BSP_BOARD_LED_0
#define READY_LED                       BSP_BOARD_LED_1
#define PROGRESS_LED                    BSP_BOARD_LED_2
#define DONE_LED                        BSP_BOARD_LED_3

#define APP_BLE_CONN_CFG_TAG            1                                               /**< A tag that refers to the BLE stack configuration. */
#define APP_BLE_OBSERVER_PRIO           3                                               /**< Application's BLE observer priority. You shouldn't need to modify this value. */
#define L2CAP_HDR_LEN                   4                                               /**< L2CAP header length. */

#define WRITE_MESSAGE_LENGTH   BLE_CCCD_VALUE_LEN    /**< Length of the write message for CCCD. */

#define OPCODE_LENGTH 1 /**< Length of opcode inside a notification. */
#define HANDLE_LENGTH 2 /**< Length of handle inside a notification. */

#define SEC_PARAM_BOND                      1                                       /**< Perform bonding. */
#define SEC_PARAM_MITM                      0                                       /**< Man In The Middle protection not required. */
#define SEC_PARAM_LESC                      0                                       /**< LE Secure Connections not enabled. */
#define SEC_PARAM_KEYPRESS                  0                                       /**< Keypress notifications not enabled. */
#define SEC_PARAM_IO_CAPABILITIES           BLE_GAP_IO_CAPS_NONE                    /**< No I/O capabilities. */
#define SEC_PARAM_OOB                       0                                       /**< Out Of Band data not available. */
#define SEC_PARAM_MIN_KEY_SIZE              7                                       /**< Minimum encryption key size. */
#define SEC_PARAM_MAX_KEY_SIZE              16                                      /**< Maximum encryption key size. */

#define APP_ADV_FAST_INTERVAL               0x0028                                     /**< Fast advertising interval (in units of 0.625 ms. This value corresponds to 25 ms.). */
#define APP_ADV_SLOW_INTERVAL               0x0C80                                     /**< Slow advertising interval (in units of 0.625 ms. This value corrsponds to 2 seconds). */
#define APP_ADV_FAST_TIMEOUT                10                                         /**< The duration of the fast advertising period (in seconds). */
#define APP_ADV_SLOW_TIMEOUT                180                                        /**< The duration of the slow advertising period (in seconds). */

/*==================================================================
 * Private Typedefs
 ==================================================================*/

/**@brief BLE Interface control structure.
 * @details This structure contains control information for the BLE interface. */
typedef struct
{
	uint16_t conn_handle;							//!< Connection handle as provided by the SoftDevice. */
	ble_gatts_char_handles_t audio_char_handles;	//!< Audio data characteristic handles */
	ble_gatts_char_handles_t config_char_handles;	//!< Configurations characteristic handles. */

	ble_uuid_t m_adv_uuids[1];

	pm_peer_id_t m_peer_id;												/**< Device reference handle to the current bonded central. */
	pm_peer_id_t m_whitelist_peers[BLE_GAP_WHITELIST_ADDR_MAX_COUNT];	/**< List of peers currently in the whitelist. */
	uint32_t m_whitelist_peer_cnt;										/**< Number of peers currently in the whitelist. */

	bool disconnect_to_clear_bonds;		//!< Flag indicating if we are disconnecting to erase bonds. */

	ble_interface_evt_handler_t evt_handler;	//!< Application event handler to be called when there is an event related to the BLE module. */
} ble_interface_ctrl_t;

/*==================================================================
 * Private Function Prototypes
 ==================================================================*/

/**@brief Function for handling BLE_GAP_EVT_CONNECTED events.
 * Save the connection handle and GAP role, then discover the peer DB.
 */
static void on_ble_gap_evt_connected(ble_gap_evt_t const * p_gap_evt);

/**@brief Function for handling BLE_GAP_EVT_DISCONNECTED events.
 * Unset the connection handle and terminate the test.
 */
static void on_ble_gap_evt_disconnected(ble_gap_evt_t const * p_gap_evt);

/**@brief Function for handling advertising events.
 *
 * @details This function will be called for advertising events which are passed to the application.
 *
 * @param[in] ble_adv_evt  Advertising event.
 */
static void on_adv_evt(ble_adv_evt_t ble_adv_evt);

/**@brief Function for handling BLE Stack events.
 *
 * @param[in] p_ble_evt  Bluetooth stack event.
 */
static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context);

/**@brief Function for handling events from the GATT library. */
static void gatt_evt_handler(nrf_ble_gatt_t * p_gatt, nrf_ble_gatt_evt_t const * p_evt);

/**@brief Function for initializing services that will be used by the application.
 */
static void services_init(void);

/**@brief Function for initializing the BLE stack.
 *
 * @details Initializes the SoftDevice and the BLE event interrupt.
 */
static void ble_stack_init(void);

/**@brief Function for the Peer Manager initialization.
 */
static void peer_manager_init(void);

/**@brief Function for initializing the Advertising functionality.
 */
static void advertising_init(void);

/**@brief Function for initializing GAP parameters.
 *
 * @details This function sets up all the necessary GAP (Generic Access Profile) parameters of the
 *          device including the device name and the preferred connection parameters.
 */
static void gap_params_init(void);

/**@brief Function for initializing the GATT library. */
static void gatt_init(void);

static void conn_evt_len_ext_set(bool status);

void data_len_ext_set(bool status);

/**@brief   Function for handling BLE events from the SoftDevice.
 *
 * @details This function will handle the BLE events received from the SoftDevice.
 *          If a BLE event is relevant to the BLE interface, then it uses it to update
 *          interval variables and, if necessary, send events to the application.
 *
 * @param[in] p_ble_evt     Pointer to the BLE event.
 * @param     p_context     Pointer to the control structure.
 */
void ble_interface_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context);

/**@brief Function for handling the TX_COMPLETE event.
 */
static void on_tx_complete();

/**@brief Function for handling the Write event.
 *
 * @param[in] p_ble_evt   Event received from the BLE stack.
 */
static void on_write(ble_evt_t const * p_ble_evt);

void nrf_ble_amts_rbc_set(ble_interface_ctrl_t * p_ctx, uint32_t byte_cnt);

/**@brief Fetch the list of peer manager peer IDs.
 *
 * @param[inout] p_peers   The buffer where to store the list of peer IDs.
 * @param[inout] p_size    In: The size of the @p p_peers buffer.
 *                         Out: The number of peers copied in the buffer.
 */
static void peer_list_get(pm_peer_id_t * p_peers, uint32_t * p_size);

/**@brief Clear bond information from persistent storage.
 */
static void delete_bonds(void);

/**@brief Function for handling File Data Storage events.
 *
 * @param[in] p_evt  Peer Manager event.
 * @param[in] cmd
 */
static void fds_evt_handler(fds_evt_t const * const p_evt);

/**@brief Function for handling Peer Manager events.
 *
 * @param[in] p_evt  Peer Manager event.
 */
static void pm_evt_handler(pm_evt_t const * p_evt);

/**@brief Function for handling advertising errors.
 *
 * @param[in] nrf_error  Error code containing information about what went wrong.
 */
static void ble_advertising_error_handler(uint32_t nrf_error);

/**@brief Function for starting the advertising process.
 */
static void advertising_start();

/*==================================================================
 * Firmware Global Variables
 ==================================================================*/

/*==================================================================
 * File Global Variables
 ==================================================================*/

NRF_BLE_GATT_DEF(m_gatt);                   /**< GATT module instance. */
BLE_ADVERTISING_DEF(m_advertising);         /**< Advertising module instance. */

static ble_interface_ctrl_t     m_ble_interface_ctrl;
NRF_SDH_BLE_OBSERVER(m_domio_ble_obs, BLE_DOMIO_BLE_OBSERVER_PRIO, ble_interface_on_ble_evt, NULL);

// Connection parameters requested for connection.
static ble_gap_conn_params_t m_conn_param =
{
    .min_conn_interval = CONN_INTERVAL_MIN,   // Minimum connection interval.
    .max_conn_interval = CONN_INTERVAL_MAX,   // Maximum connection interval.
    .slave_latency     = SLAVE_LATENCY,       // Slave latency.
    .conn_sup_timeout  = CONN_SUP_TIMEOUT     // Supervisory timeout.
};

ble_gap_phys_t  phys = {                       /**< Preferred PHYs. */
	.tx_phys             = BLE_GAP_PHY_2MBPS | BLE_GAP_PHY_1MBPS,
	.rx_phys             = BLE_GAP_PHY_2MBPS | BLE_GAP_PHY_1MBPS
};

/*==================================================================
 * Function Implementations
 ==================================================================*/


void ble_interface_init(ble_interface_evt_handler_t evt_handler) {
	ble_stack_init();
	gap_params_init();
	gatt_init();
	services_init();
	advertising_init();

	peer_manager_init();

	data_len_ext_set(true);
	conn_evt_len_ext_set(true);

	m_ble_interface_ctrl.evt_handler = evt_handler;
	m_ble_interface_ctrl.conn_handle = BLE_CONN_HANDLE_INVALID;

	m_ble_interface_ctrl.disconnect_to_clear_bonds = false;
}

void ble_interface_adv_start(bool erase_bonds) {
	if (erase_bonds == true)
	{
		// get the current number of whitelisted peers (should be maximum 1)
		memset(m_ble_interface_ctrl.m_whitelist_peers, PM_PEER_ID_INVALID, sizeof(m_ble_interface_ctrl.m_whitelist_peers));
		m_ble_interface_ctrl.m_whitelist_peer_cnt = (sizeof(m_ble_interface_ctrl.m_whitelist_peers) / sizeof(pm_peer_id_t));
		peer_list_get(m_ble_interface_ctrl.m_whitelist_peers, &m_ble_interface_ctrl.m_whitelist_peer_cnt);

		// check if there are bonds to erase, otherwise just restart advertising.
		if (m_ble_interface_ctrl.m_whitelist_peer_cnt > 0) {
			if (m_ble_interface_ctrl.conn_handle != BLE_CONN_HANDLE_INVALID) {
				NRF_LOG_INFO("Disconnecting to clear bonds.");
				// we are connected, so disconnect first.
				m_ble_interface_ctrl.disconnect_to_clear_bonds = true;
				uint32_t err_code = sd_ble_gap_disconnect(m_ble_interface_ctrl.conn_handle,
						BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
				APP_ERROR_CHECK(err_code);
			} else {
				NRF_LOG_INFO("Clearing bonds.");
				// stop advertising first
				(void) sd_ble_gap_adv_stop();
				delete_bonds();
				// Advertising is started by PM_EVT_PEERS_DELETE_SUCCEEDED event.
			}
		} else {
			ble_interface_adv_start(false);
		}
	} else {
		// stop advertising first, just in case
		(void) sd_ble_gap_adv_stop();
		advertising_start();
	}
}

void ble_interface_adv_stop() {

}

ble_domio_return_type_t ble_interface_send_notif(uint8_t *data, uint16_t *payload_len) {
	ble_gatts_hvx_params_t const hvx_param =
	{
			.type   = BLE_GATT_HVX_NOTIFICATION,
			.handle = m_ble_interface_ctrl.audio_char_handles.value_handle,
			.p_data = data,
			.p_len  = payload_len,
	};

	uint32_t err_code = sd_ble_gatts_hvx(m_ble_interface_ctrl.conn_handle, &hvx_param);

	if (err_code == NRF_ERROR_RESOURCES)
	{
		// Wait for BLE_GATTS_EVT_HVN_TX_COMPLETE.
		NRF_LOG_DEBUG("GATTS notification queue full.");

		return BLE_DOMIO_RET_BUSY;
	}
	else if (err_code != NRF_SUCCESS)
	{
		NRF_LOG_ERROR("sd_ble_gatts_hvx() failed: 0x%x", err_code);
		return BLE_DOMIO_RET_ERROR;
	}

	return BLE_DOMIO_RET_OK;
}

/*==================================================================
 * Private Function Implementations
 ==================================================================*/


static void services_init(void)
{
	ret_code_t    err_code;
	uint16_t      service_handle;
	uint8_t uuid_type;								//!< UUID type. */
	ble_uuid128_t base_uuid = {SERVICE_UUID_BASE};

	err_code = sd_ble_uuid_vs_add(&base_uuid, &uuid_type);
	APP_ERROR_CHECK(err_code);

	m_ble_interface_ctrl.m_adv_uuids[0].type = uuid_type;
	m_ble_interface_ctrl.m_adv_uuids[0].uuid = DOMIC_SERVICE_UUID;

	// Add service.
	err_code = sd_ble_gatts_service_add(BLE_GATTS_SRVC_TYPE_PRIMARY, &m_ble_interface_ctrl.m_adv_uuids[0], &service_handle);
	APP_ERROR_CHECK(err_code);

	// Add Domio Audio characteristic.
	ble_add_char_params_t domio_audio_params;
	memset(&domio_audio_params, 0, sizeof(domio_audio_params));

	domio_audio_params.uuid              = DOMIC_AUDIO_CHAR_UUID;
	domio_audio_params.uuid_type         = uuid_type;
	domio_audio_params.max_len           = NRF_SDH_BLE_GATT_MAX_MTU_SIZE;
	domio_audio_params.char_props.notify = 1;
	domio_audio_params.cccd_write_access = SEC_OPEN;
	domio_audio_params.is_var_len        = 1;

	err_code = characteristic_add(service_handle, &domio_audio_params, &(m_ble_interface_ctrl.audio_char_handles));
	APP_ERROR_CHECK(err_code);

	// Add Domio Configurations characteristic.
	ble_add_char_params_t domio_config_params;
	memset(&domio_config_params, 0, sizeof(domio_config_params));

	domio_config_params.uuid            = DOMIC_CONFIG_CHAR_UUID;
	domio_config_params.uuid_type       = uuid_type;
	domio_config_params.max_len         = DOMIO_CONFIG_MAX_LEN;
	// allow read and write to send and receive configurations and commands
	domio_config_params.char_props.read = 1;
	domio_config_params.read_access     = SEC_OPEN;
	domio_config_params.char_props.write = 1;
	domio_config_params.write_access     = SEC_OPEN;

	err_code = characteristic_add(service_handle, &domio_config_params, &(m_ble_interface_ctrl.config_char_handles));
	APP_ERROR_CHECK(err_code);
}


static void ble_stack_init(void)
{
	ret_code_t err_code;

	err_code = nrf_sdh_enable_request();
	APP_ERROR_CHECK(err_code);

	// Configure the BLE stack using the default settings.
	// Fetch the start address of the application RAM.
	uint32_t ram_start = 0;
	err_code = nrf_sdh_ble_default_cfg_set(APP_BLE_CONN_CFG_TAG, &ram_start);
	APP_ERROR_CHECK(err_code);

	// Configure number of packets that can be queued per interval
	ble_cfg_t ble_cfg;
	memset(&ble_cfg, 0x00, sizeof(ble_cfg));
	ble_cfg.conn_cfg.conn_cfg_tag = APP_BLE_CONN_CFG_TAG;
	ble_cfg.conn_cfg.params.gatts_conn_cfg.hvn_tx_queue_size = 6;  // Changed from BLE_GATTS_HVN_TX_QUEUE_SIZE_DEFAULT 1

	err_code = sd_ble_cfg_set(BLE_CONN_CFG_GATTS, &ble_cfg, ram_start);
	if (err_code != NRF_SUCCESS)
	{
		NRF_LOG_ERROR("sd_ble_cfg_set() returned %s when attempting to set BLE_CONN_CFG_GATTS.",
				nrf_strerror_get(err_code));
	}

	// Enable BLE stack.
	err_code = nrf_sdh_ble_enable(&ram_start);
	APP_ERROR_CHECK(err_code);

	// Register a handler for BLE events.
	NRF_SDH_BLE_OBSERVER(m_ble_observer, APP_BLE_OBSERVER_PRIO, ble_evt_handler, NULL);
}


static void peer_manager_init(void)
{
	ble_gap_sec_params_t sec_param;
	ret_code_t           err_code;

	err_code = pm_init();
	APP_ERROR_CHECK(err_code);

	memset(&sec_param, 0, sizeof(ble_gap_sec_params_t));

	// Security parameters to be used for all security procedures.
	sec_param.bond           = SEC_PARAM_BOND;
	sec_param.mitm           = SEC_PARAM_MITM;
	sec_param.io_caps        = SEC_PARAM_IO_CAPABILITIES;
	sec_param.oob            = SEC_PARAM_OOB;
	sec_param.min_key_size   = SEC_PARAM_MIN_KEY_SIZE;
	sec_param.max_key_size   = SEC_PARAM_MAX_KEY_SIZE;
	sec_param.kdist_own.enc  = 1;
	sec_param.kdist_own.id   = 1;
	sec_param.kdist_peer.enc = 1;
	sec_param.kdist_peer.id  = 1;

	err_code = pm_sec_params_set(&sec_param);
	APP_ERROR_CHECK(err_code);

	err_code = pm_register(pm_evt_handler);
	APP_ERROR_CHECK(err_code);

	err_code = fds_register(fds_evt_handler);
	APP_ERROR_CHECK(err_code);
}


static void advertising_init(void)
{
	uint32_t               err_code;
	uint8_t                adv_flags;
	ble_advertising_init_t init;

	memset(&init, 0, sizeof(init));

	adv_flags                            = BLE_GAP_ADV_FLAGS_LE_ONLY_GENERAL_DISC_MODE;
	init.advdata.name_type               = BLE_ADVDATA_FULL_NAME;
	init.advdata.include_appearance      = false; // previous configuration before bonding test began
//	init.advdata.include_appearance      = true;
	init.advdata.flags                   = adv_flags;
	init.advdata.uuids_complete.uuid_cnt = sizeof(m_ble_interface_ctrl.m_adv_uuids) / sizeof(m_ble_interface_ctrl.m_adv_uuids[0]);
	init.advdata.uuids_complete.p_uuids  = m_ble_interface_ctrl.m_adv_uuids;

	init.srdata.name_type               = BLE_ADVDATA_FULL_NAME;

	init.config.ble_adv_whitelist_enabled      = true;
	init.config.ble_adv_on_disconnect_disabled = true;
	init.config.ble_adv_directed_enabled       = true;
	init.config.ble_adv_directed_slow_enabled  = true;
	init.config.ble_adv_directed_slow_interval = APP_ADV_FAST_INTERVAL;
	init.config.ble_adv_directed_slow_timeout  = 0;
	init.config.ble_adv_fast_enabled           = true;
	init.config.ble_adv_fast_interval          = APP_ADV_FAST_INTERVAL;
	init.config.ble_adv_fast_timeout           = APP_ADV_FAST_TIMEOUT;
	init.config.ble_adv_slow_enabled           = false;
	init.config.ble_adv_slow_interval          = APP_ADV_SLOW_INTERVAL;
	init.config.ble_adv_slow_timeout           = APP_ADV_SLOW_TIMEOUT;

	init.evt_handler   = on_adv_evt;
	init.error_handler = ble_advertising_error_handler;

	err_code = ble_advertising_init(&m_advertising, &init);
	APP_ERROR_CHECK(err_code);

	ble_advertising_conn_cfg_tag_set(&m_advertising, APP_BLE_CONN_CFG_TAG);
}


static void gap_params_init(void)
{
	ret_code_t              err_code;
	ble_gap_conn_sec_mode_t sec_mode;

	BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);

	err_code = sd_ble_gap_device_name_set(&sec_mode,
			(uint8_t const *)DEVICE_NAME,
			strlen(DEVICE_NAME));
	APP_ERROR_CHECK(err_code);

	err_code = sd_ble_gap_appearance_set(BLE_APPEARANCE_UNKNOWN);
	APP_ERROR_CHECK(err_code);

	err_code = sd_ble_gap_ppcp_set(&m_conn_param);
	APP_ERROR_CHECK(err_code);
}


static void gatt_init(void)
{
	ret_code_t err_code = nrf_ble_gatt_init(&m_gatt, gatt_evt_handler);
	APP_ERROR_CHECK(err_code);

	err_code = nrf_ble_gatt_att_mtu_periph_set(&m_gatt, NRF_SDH_BLE_GATT_MAX_MTU_SIZE);
	APP_ERROR_CHECK(err_code);
}


static void conn_evt_len_ext_set(bool status)
{
	ret_code_t err_code;
	ble_opt_t  opt;

	memset(&opt, 0x00, sizeof(opt));
	opt.common_opt.conn_evt_ext.enable = status ? 1 : 0;

	err_code = sd_ble_opt_set(BLE_COMMON_OPT_CONN_EVT_EXT, &opt);
	APP_ERROR_CHECK(err_code);
}


void data_len_ext_set(bool status)
{
	uint8_t data_length = status ? (247 + L2CAP_HDR_LEN) : (23 + L2CAP_HDR_LEN);
	(void) nrf_ble_gatt_data_length_set(&m_gatt, BLE_CONN_HANDLE_INVALID, data_length);
}


static void on_adv_evt(ble_adv_evt_t ble_adv_evt)
{
	ret_code_t err_code;

	switch (ble_adv_evt)
	{
	case BLE_ADV_EVT_DIRECTED:
		NRF_LOG_INFO("Directed advertising.");
//		err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING_DIRECTED);
//		APP_ERROR_CHECK(err_code);
		break;

	case BLE_ADV_EVT_FAST:
		NRF_LOG_INFO("Fast advertising.");
//		err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING);
//		APP_ERROR_CHECK(err_code);
		break;

	case BLE_ADV_EVT_SLOW:
		NRF_LOG_INFO("Slow advertising.");
//		err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING_SLOW);
//		APP_ERROR_CHECK(err_code);
		break;

	case BLE_ADV_EVT_FAST_WHITELIST:
		NRF_LOG_INFO("Fast advertising with whitelist.");
//		err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING_WHITELIST);
//		APP_ERROR_CHECK(err_code);
		break;

	case BLE_ADV_EVT_SLOW_WHITELIST:
		NRF_LOG_INFO("Slow advertising with whitelist.");
//		err_code = bsp_indication_set(BSP_INDICATE_ADVERTISING_WHITELIST);
//		APP_ERROR_CHECK(err_code);
		break;

	case BLE_ADV_EVT_IDLE:
//		sleep_mode_enter();
		break;

	case BLE_ADV_EVT_WHITELIST_REQUEST:
	{
		ble_gap_addr_t whitelist_addrs[BLE_GAP_WHITELIST_ADDR_MAX_COUNT];
		ble_gap_irk_t  whitelist_irks[BLE_GAP_WHITELIST_ADDR_MAX_COUNT];
		uint32_t       addr_cnt = BLE_GAP_WHITELIST_ADDR_MAX_COUNT;
		uint32_t       irk_cnt  = BLE_GAP_WHITELIST_ADDR_MAX_COUNT;

		err_code = pm_whitelist_get(whitelist_addrs, &addr_cnt,
				whitelist_irks,  &irk_cnt);
		APP_ERROR_CHECK(err_code);
		NRF_LOG_DEBUG("pm_whitelist_get returns %d addr in whitelist and %d irk whitelist",
				addr_cnt, irk_cnt);

		// Apply the whitelist.
		err_code = ble_advertising_whitelist_reply(&m_advertising,
				whitelist_addrs,
				addr_cnt,
				whitelist_irks,
				irk_cnt);
		APP_ERROR_CHECK(err_code);
	} break; //BLE_ADV_EVT_WHITELIST_REQUEST

	case BLE_ADV_EVT_PEER_ADDR_REQUEST:
	{
		pm_peer_data_bonding_t peer_bonding_data;

		// Only Give peer address if we have a handle to the bonded peer.
		if (m_ble_interface_ctrl.m_peer_id != PM_PEER_ID_INVALID)
		{
			err_code = pm_peer_data_bonding_load(m_ble_interface_ctrl.m_peer_id, &peer_bonding_data);
			if (err_code != NRF_ERROR_NOT_FOUND)
			{
				APP_ERROR_CHECK(err_code);

				ble_gap_addr_t * p_peer_addr = &(peer_bonding_data.peer_ble_id.id_addr_info);
				err_code = ble_advertising_peer_addr_reply(&m_advertising, p_peer_addr);
				APP_ERROR_CHECK(err_code);
			}
		}
	} break; //BLE_ADV_EVT_PEER_ADDR_REQUEST

	default:
		break;
	}
}


static void ble_evt_handler(ble_evt_t const * p_ble_evt, void * p_context)
{
	uint32_t              err_code;
	ble_gap_evt_t const * p_gap_evt = &p_ble_evt->evt.gap_evt;

	switch (p_ble_evt->header.evt_id)
	{
	case BLE_GAP_EVT_CONNECTED:
		on_ble_gap_evt_connected(p_gap_evt);
		break;

	case BLE_GAP_EVT_DISCONNECTED:
		on_ble_gap_evt_disconnected(p_gap_evt);
		break;

	case BLE_GAP_EVT_CONN_PARAM_UPDATE:
	{
		NRF_LOG_INFO("Connection interval updated: 0x%x, 0x%x.",
				p_gap_evt->params.conn_param_update.conn_params.min_conn_interval,
				p_gap_evt->params.conn_param_update.conn_params.max_conn_interval);
	} break;

	case BLE_GAP_EVT_CONN_PARAM_UPDATE_REQUEST:
	{
		// Accept parameters requested by the peer.
		ble_gap_conn_params_t params;
		params = p_gap_evt->params.conn_param_update_request.conn_params;
		err_code = sd_ble_gap_conn_param_update(p_gap_evt->conn_handle, &params);
		APP_ERROR_CHECK(err_code);

		NRF_LOG_INFO("Connection interval updated (upon request): 0x%x, 0x%x.",
				p_gap_evt->params.conn_param_update_request.conn_params.min_conn_interval,
				p_gap_evt->params.conn_param_update_request.conn_params.max_conn_interval);
	} break;

	case BLE_GATTS_EVT_SYS_ATTR_MISSING:
	{
		err_code = sd_ble_gatts_sys_attr_set(p_gap_evt->conn_handle, NULL, 0, 0);
		APP_ERROR_CHECK(err_code);
	} break;

	case BLE_GATTC_EVT_TIMEOUT: // Fallthrough.
	case BLE_GATTS_EVT_TIMEOUT:
	{
		NRF_LOG_DEBUG("GATT timeout, disconnecting.");
		err_code = sd_ble_gap_disconnect(m_ble_interface_ctrl.conn_handle,
				BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
		APP_ERROR_CHECK(err_code);
	} break;

	case BLE_EVT_USER_MEM_REQUEST:
	{
		err_code = sd_ble_user_mem_reply(p_ble_evt->evt.common_evt.conn_handle, NULL);
		APP_ERROR_CHECK(err_code);
	} break;

	case BLE_GAP_EVT_PHY_UPDATE:
	{
		ble_gap_evt_phy_update_t const * p_phy_evt = &p_ble_evt->evt.gap_evt.params.phy_update;

		if (p_phy_evt->status == BLE_HCI_STATUS_CODE_LMP_ERROR_TRANSACTION_COLLISION)
		{
			// Ignore LL collisions.
			NRF_LOG_DEBUG("LL transaction collision during PHY update.");
			break;
		}
	} break;

#ifndef S140
	case BLE_GAP_EVT_PHY_UPDATE_REQUEST:
	{
		NRF_LOG_DEBUG("PHY update request.");
		err_code = sd_ble_gap_phy_update(p_ble_evt->evt.gap_evt.conn_handle, &phys);
		APP_ERROR_CHECK(err_code);
	} break;
#endif

#if !defined (S112)
	case BLE_GAP_EVT_DATA_LENGTH_UPDATE_REQUEST:
	{
		ble_gap_data_length_params_t dl_params;

		// Clearing the struct will effectivly set members to @ref BLE_GAP_DATA_LENGTH_AUTO
		memset(&dl_params, 0, sizeof(ble_gap_data_length_params_t));
		err_code = sd_ble_gap_data_length_update(p_ble_evt->evt.gap_evt.conn_handle, &dl_params, NULL);
		APP_ERROR_CHECK(err_code);
	} break;
#endif // !defined (S112)

	default:
		// No implementation needed.
		break;
	}
}


/**@brief Function for handling events from the GATT library. */
static void gatt_evt_handler(nrf_ble_gatt_t * p_gatt, nrf_ble_gatt_evt_t const * p_evt)
{
	switch (p_evt->evt_id)
	{
	case NRF_BLE_GATT_EVT_ATT_MTU_UPDATED:
	{
		NRF_LOG_INFO("ATT MTU exchange completed. MTU set to %u bytes.",
				p_evt->params.att_mtu_effective);

		// notify BLE module of the new MTU
		if (m_ble_interface_ctrl.evt_handler != NULL) {
			ble_domio_evt_t evt;
			evt.evt_type = BLE_DOMIO_EVT_MAX_PAYLOAD_UPDATE;
			evt.payload.max_payload_len =
					p_evt->params.att_mtu_effective - OPCODE_LENGTH - HANDLE_LENGTH;
			m_ble_interface_ctrl.evt_handler(evt);
		}
	} break;

	case NRF_BLE_GATT_EVT_DATA_LENGTH_UPDATED:
	{
		NRF_LOG_INFO("Data length updated to %u bytes.", p_evt->params.data_length);
	} break;
	}
}


/**@brief Function for handling BLE_GAP_EVT_CONNECTED events.
 * Save the connection handle and GAP role, then discover the peer DB.
 */
static void on_ble_gap_evt_connected(ble_gap_evt_t const * p_gap_evt)
{
	ret_code_t err_code;

	m_ble_interface_ctrl.conn_handle = p_gap_evt->conn_handle;

	// Stop advertising.
	(void) sd_ble_gap_adv_stop();

	bsp_board_leds_off();

	if (p_gap_evt->params.connected.role == BLE_GAP_ROLE_PERIPH)
	{
#if defined(S140)
		err_code = sd_ble_gap_phy_request(p_gap_evt->conn_handle, &phys);
		APP_ERROR_CHECK(err_code);
#else
		err_code = sd_ble_gap_phy_update(p_gap_evt->conn_handle, &phys);
		APP_ERROR_CHECK(err_code);
#endif
	}
}


/**@brief Function for handling BLE_GAP_EVT_DISCONNECTED events.
 * Unset the connection handle and terminate the test.
 */
static void on_ble_gap_evt_disconnected(ble_gap_evt_t const * p_gap_evt)
{
	m_ble_interface_ctrl.conn_handle = BLE_CONN_HANDLE_INVALID;

//    NRF_LOG_DEBUG("Disconnected: reason 0x%x.", p_gap_evt->params.disconnected.reason);

	bsp_board_leds_off();

	// notify module that got disconnected
	if (m_ble_interface_ctrl.evt_handler != NULL) {
		ble_domio_evt_t evt;
		evt.evt_type = BLE_DOMIO_EVT_DISCONNECTED;
		m_ble_interface_ctrl.evt_handler(evt);
	}

	// check if we disconnected in order to clear bonds
	if (m_ble_interface_ctrl.disconnect_to_clear_bonds) {
		m_ble_interface_ctrl.disconnect_to_clear_bonds = false;
		ble_interface_adv_start(true);
	} else {
		ble_interface_adv_start(false);
	}
}


void ble_interface_on_ble_evt(ble_evt_t const * p_ble_evt, void * p_context)
{
	switch (p_ble_evt->header.evt_id)
	{
	case BLE_GATTS_EVT_WRITE:
		on_write(p_ble_evt);
		break;

	case BLE_GATTS_EVT_HVN_TX_COMPLETE:
		on_tx_complete();
		break;

	default:
		break;
	}
}


static void on_tx_complete()
{
	if (m_ble_interface_ctrl.evt_handler != NULL) {
		ble_domio_evt_t evt;
		evt.evt_type = BLE_DOMIO_EVT_TRANSMIT_COMPLETED;
		m_ble_interface_ctrl.evt_handler(evt);
	}
}


static void on_write(ble_evt_t const * p_ble_evt)
{
	ble_gatts_evt_write_t const * p_evt_write = &p_ble_evt->evt.gatts_evt.params.write;

	if ((p_evt_write->handle == m_ble_interface_ctrl.audio_char_handles.cccd_handle) && (p_evt_write->len == 2))
	{
		// CCCD written, call the application event handler.
		ble_domio_evt_t evt;

		if (ble_srv_is_notification_enabled(p_evt_write->data))
		{
			evt.evt_type = BLE_DOMIO_EVT_NOTIF_ENABLED;
		}
		else
		{
			evt.evt_type = BLE_DOMIO_EVT_NOTIF_DISABLED;
		}

		m_ble_interface_ctrl.evt_handler(evt);
	}
	else {

		if ((p_evt_write->handle == m_ble_interface_ctrl.config_char_handles.value_handle) && (p_evt_write->len == 2)) {
			// command written, call the application event handler.
			ble_domio_evt_t evt;
			NRF_LOG_INFO("Received command write: %u, %u", p_evt_write->data[0], p_evt_write->data[1]);
			if (p_evt_write->data[0] == 1) {
				evt.evt_type = BLE_DOMIO_EVT_TRANSFER_START;
			} else if (p_evt_write->data[0] == 2) {
				evt.evt_type = BLE_DOMIO_EVT_TRANSFER_STOP;
			}
			m_ble_interface_ctrl.evt_handler(evt);
		}
	}
}


void nrf_ble_amts_rbc_set(ble_interface_ctrl_t * p_ctx, uint32_t byte_cnt)
{
	uint8_t  data[DOMIO_CONFIG_MAX_LEN];
	uint16_t len;

	ble_gatts_value_t value_param;

	memset(&value_param, 0x00, sizeof(value_param));

	len                 = (uint16_t)uint32_encode(byte_cnt, data);
	value_param.len     = len;
	value_param.p_value = data;

	ret_code_t err_code = sd_ble_gatts_value_set(p_ctx->conn_handle,
			p_ctx->config_char_handles.value_handle,
			&value_param);
	if (err_code != NRF_SUCCESS)
	{
		NRF_LOG_ERROR("sd_ble_gatts_value_set() failed: 0x%x", err_code);
	}
}


static void peer_list_get(pm_peer_id_t * p_peers, uint32_t * p_size)
{
	pm_peer_id_t peer_id;
	uint32_t     peers_to_copy;

	peers_to_copy = (*p_size < BLE_GAP_WHITELIST_ADDR_MAX_COUNT) ?
			*p_size : BLE_GAP_WHITELIST_ADDR_MAX_COUNT;

	peer_id = pm_next_peer_id_get(PM_PEER_ID_INVALID);
	*p_size = 0;

	while ((peer_id != PM_PEER_ID_INVALID) && (peers_to_copy--))
	{
		p_peers[(*p_size)++] = peer_id;
		peer_id = pm_next_peer_id_get(peer_id);
	}
}


static void delete_bonds(void)
{
	ret_code_t err_code;

	NRF_LOG_INFO("Erase bonds!");

	err_code = pm_peers_delete();
	APP_ERROR_CHECK(err_code);
}


static void fds_evt_handler(fds_evt_t const * const p_evt)
{
	if (p_evt->id == FDS_EVT_GC)
	{
		NRF_LOG_DEBUG("GC completed\n");
	}
}


static void pm_evt_handler(pm_evt_t const * p_evt)
{
	ret_code_t err_code;

	switch (p_evt->evt_id)
	{
	case PM_EVT_BONDED_PEER_CONNECTED:
	{
		NRF_LOG_INFO("Connected to a previously bonded device.");
	} break;

	case PM_EVT_CONN_SEC_SUCCEEDED:
	{
		NRF_LOG_INFO("Connection secured: role: %d, conn_handle: 0x%x, procedure: %d.",
				ble_conn_state_role(p_evt->conn_handle),
				p_evt->conn_handle,
				p_evt->params.conn_sec_succeeded.procedure);

		m_ble_interface_ctrl.m_peer_id = p_evt->peer_id;
	} break;

	case PM_EVT_CONN_SEC_FAILED:
	{
		/* Often, when securing fails, it shouldn't be restarted, for security reasons.
		 * Other times, it can be restarted directly.
		 * Sometimes it can be restarted, but only after changing some Security Parameters.
		 * Sometimes, it cannot be restarted until the link is disconnected and reconnected.
		 * Sometimes it is impossible, to secure the link, or the peer device does not support it.
		 * How to handle this error is highly application dependent. */
	} break;

	case PM_EVT_CONN_SEC_CONFIG_REQ:
	{
		// Reject pairing request from an already bonded peer.
		pm_conn_sec_config_t conn_sec_config = {.allow_repairing = false};
		pm_conn_sec_config_reply(p_evt->conn_handle, &conn_sec_config);
	} break;

	case PM_EVT_STORAGE_FULL:
	{
		// Run garbage collection on the flash.
		err_code = fds_gc();
		if (err_code == FDS_ERR_BUSY || err_code == FDS_ERR_NO_SPACE_IN_QUEUES)
		{
			// Retry.
		}
		else
		{
			APP_ERROR_CHECK(err_code);
		}
	} break;

	case PM_EVT_PEERS_DELETE_SUCCEEDED:
	{
		NRF_LOG_DEBUG("PM_EVT_PEERS_DELETE_SUCCEEDED");
		ble_interface_adv_start(false);
	} break;

	case PM_EVT_LOCAL_DB_CACHE_APPLY_FAILED:
	{
		// The local database has likely changed, send service changed indications.
		pm_local_database_has_changed();
	} break;

	case PM_EVT_PEER_DATA_UPDATE_SUCCEEDED:
	{
		if (p_evt->params.peer_data_update_succeeded.flash_changed
				&& (p_evt->params.peer_data_update_succeeded.data_id == PM_PEER_DATA_ID_BONDING))
		{
			NRF_LOG_INFO("New Bond, add the peer to the whitelist if possible");
			NRF_LOG_INFO("\tm_whitelist_peer_cnt %d, MAX_PEERS_WLIST %d",
					m_ble_interface_ctrl.m_whitelist_peer_cnt + 1,
					BLE_GAP_WHITELIST_ADDR_MAX_COUNT);
			// Note: You should check on what kind of white list policy your application should use.

			if (m_ble_interface_ctrl.m_whitelist_peer_cnt < BLE_GAP_WHITELIST_ADDR_MAX_COUNT)
			{
				// Bonded to a new peer, add it to the whitelist.
				m_ble_interface_ctrl.m_whitelist_peers[m_ble_interface_ctrl.m_whitelist_peer_cnt++] = m_ble_interface_ctrl.m_peer_id;

				// The whitelist has been modified, update it in the Peer Manager.
				err_code = pm_device_identities_list_set(m_ble_interface_ctrl.m_whitelist_peers, m_ble_interface_ctrl.m_whitelist_peer_cnt);
				if (err_code != NRF_ERROR_NOT_SUPPORTED)
				{
					APP_ERROR_CHECK(err_code);
				}

				err_code = pm_whitelist_set(m_ble_interface_ctrl.m_whitelist_peers, m_ble_interface_ctrl.m_whitelist_peer_cnt);
				APP_ERROR_CHECK(err_code);
			}
		}
	} break;

	case PM_EVT_PEER_DATA_UPDATE_FAILED:
	{
		// Assert.
		APP_ERROR_CHECK(p_evt->params.peer_data_update_failed.error);
	} break;

	case PM_EVT_PEER_DELETE_FAILED:
	{
		// Assert.
		APP_ERROR_CHECK(p_evt->params.peer_delete_failed.error);
	} break;

	case PM_EVT_PEERS_DELETE_FAILED:
	{
		// Assert.
		APP_ERROR_CHECK(p_evt->params.peers_delete_failed_evt.error);
	} break;

	case PM_EVT_ERROR_UNEXPECTED:
	{
		// Assert.
		APP_ERROR_CHECK(p_evt->params.error_unexpected.error);
	} break;

	case PM_EVT_CONN_SEC_START:
	case PM_EVT_PEER_DELETE_SUCCEEDED:
	case PM_EVT_LOCAL_DB_CACHE_APPLIED:
	case PM_EVT_SERVICE_CHANGED_IND_SENT:
	case PM_EVT_SERVICE_CHANGED_IND_CONFIRMED:
	default:
		break;
	}
}


static void ble_advertising_error_handler(uint32_t nrf_error)
{
	APP_ERROR_HANDLER(nrf_error);
}


static void advertising_start() {
	NRF_LOG_INFO("Starting advertising.");

	bsp_board_led_on(SCAN_ADV_LED);

	ret_code_t ret;

	memset(m_ble_interface_ctrl.m_whitelist_peers, PM_PEER_ID_INVALID, sizeof(m_ble_interface_ctrl.m_whitelist_peers));
	m_ble_interface_ctrl.m_whitelist_peer_cnt = (sizeof(m_ble_interface_ctrl.m_whitelist_peers) / sizeof(pm_peer_id_t));

	peer_list_get(m_ble_interface_ctrl.m_whitelist_peers, &m_ble_interface_ctrl.m_whitelist_peer_cnt);

	ret = pm_whitelist_set(m_ble_interface_ctrl.m_whitelist_peers, m_ble_interface_ctrl.m_whitelist_peer_cnt);
	APP_ERROR_CHECK(ret);

	// Setup the device identies list.
	// Some SoftDevices do not support this feature.
	ret = pm_device_identities_list_set(m_ble_interface_ctrl.m_whitelist_peers, m_ble_interface_ctrl.m_whitelist_peer_cnt);
	if (ret != NRF_ERROR_NOT_SUPPORTED)
	{
		APP_ERROR_CHECK(ret);
	}

	if (m_ble_interface_ctrl.m_whitelist_peer_cnt > 0) {
		m_ble_interface_ctrl.m_peer_id = m_ble_interface_ctrl.m_whitelist_peers[0];
		ret = ble_advertising_start(&m_advertising, BLE_ADV_MODE_DIRECTED);
	} else {
		ret = ble_advertising_start(&m_advertising, BLE_ADV_MODE_FAST);
	}
	APP_ERROR_CHECK(ret);
}
