/**
 * \file pmic_interface.c
 * \brief Power management IC interface source file.
 *
 * \author Domio Sports
 *
 * PMIC Interface - Power management IC interface source implementation file.
 *
 * Revisions: none
 *
 * \date Jan. 2, 2019
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

/*==================================================================
 * Includes
 ==================================================================*/

#include "nrf.h"
#include "nrf_drv_twi.h"
#include "nrf_drv_gpiote.h"
#include "nrf_gpio.h"
#include "app_error.h"
#include "nrf_mtx.h"
#include "nrf_delay.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "boards.h" // In order to get Ardunio PIN mapping for DKs

#include "pmic_interface.h"

/*==================================================================
 * Private Defines
 ==================================================================*/

/* TWI instance ID. */
#define TWI_INSTANCE_ID     1

/* Common addresses definition for I2C PMIC. */
#define BQ25120A_ADDR                    (0x6AU)

#define BQ25120A_REG_SSMC                (0x00)
#define BQ25120A_REG_FFM                 (0x01)
#define BQ25120A_REG_TSCFM               (0x02)
#define BQ25120A_REG_FCC                 (0x03)
#define BQ25120A_REG_TPC                 (0x04)
#define BQ25120A_REG_BVC                 (0x05)
#define BQ25120A_REG_SVC                 (0x06)
#define BQ25120A_REG_LSLC                (0x07)
#define BQ25120A_REG_PBC                 (0x08)
#define BQ25120A_REG_IBUC                (0x09)
#define BQ25120A_REG_VBBM                (0x0A)
#define BQ25120A_REG_VDT                 (0x0B)

#define BQ25120A_VAL_SSMC                (0x20) // enables ship-mode
#define BQ25120A_VAL_FCC                 (0xF8) // sets charging current to 300mA
#define BQ25120A_VAL_FFM                 (0x0F) // masks all possible faults
#define BQ25120A_VAL_SVC                 (0xAE) // sets SYS VOUT to 2V
#define BQ25120A_VAL_IBUC                (0x3A) // sets the input limit current to 400mA
#define BQ25120A_VAL_PBC                 (0xC8) // configures PG\ as PG\, after reset enter ship mode, timer WAKE1 = 600ms
#define BQ25120A_VAL_TSCFM               (0x8B)

#define BQ25120A_REG_PBC_WAKE2           (0x01)
#define BQ25120A_REG_PBC_PGB_MR          (0x04)
#define BQ25120A_REG_FFM_VIN_OV          (0x80)


#define DOMIO_PMIC_CD_PIN				12
#define DOMIO_PMIC_PG_PIN				11

#define PMIC_ENABLE()					do { \
		nrf_gpio_pin_set(DOMIO_PMIC_CD_PIN);\
		nrf_delay_us(150);\
		} while(0);
#define PMIC_DISABLE()					do { \
		nrf_gpio_pin_clear(DOMIO_PMIC_CD_PIN);\
		} while(0);

/*==================================================================
 * Private Typedefs
 ==================================================================*/

/*==================================================================
 * Private Function Prototypes
 ==================================================================*/

/**
 * @brief I2C initialization.
 */
void twi_init(void);

/**
 * @brief TWI events handler.
 */
void twi_handler(nrf_drv_twi_evt_t const * p_event, void * p_context);

void pmic_interface_config();

static void pmic_pg_event_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action);

/*==================================================================
 * Firmware Global Variables
 ==================================================================*/

/*==================================================================
 * File Global Variables
 ==================================================================*/

/* TWI instance. */
static const nrf_drv_twi_t m_twi = NRF_DRV_TWI_INSTANCE(TWI_INSTANCE_ID);

nrf_mtx_t p_mtx_i2c;

/*==================================================================
 * Function Implementations
 ==================================================================*/

void pmic_interface_init() {
	uint32_t err_code;

	if (!nrf_drv_gpiote_is_init())
	{
		err_code = nrf_drv_gpiote_init();
		APP_ERROR_CHECK(err_code);
	}

	// configure input for reset (on/off) detection
	nrf_drv_gpiote_in_config_t config = GPIOTE_CONFIG_IN_SENSE_LOTOHI(false);
	config.pull = NRF_GPIO_PIN_PULLUP;
	config.hi_accuracy = true;
	err_code = nrf_drv_gpiote_in_init(DOMIO_PMIC_PG_PIN, &config, pmic_pg_event_handler);
	APP_ERROR_CHECK(err_code);
	// disable PG\ events
	nrf_drv_gpiote_in_event_disable(DOMIO_PMIC_PG_PIN);

	// configure output for PMIC CD\ (chip disable)
	nrf_gpio_cfg_output(DOMIO_PMIC_CD_PIN);
	PMIC_DISABLE();

	twi_init();

	// configure the battery manager outputs
	pmic_interface_config();

	nrf_mtx_init(&p_mtx_i2c);
}

void pmic_interface_shutdown_en() {
	ret_code_t err_code;

	// wait to make sure I2C is not being used (interrupt race)
	while(!nrf_mtx_trylock(&p_mtx_i2c));

	// enable PMIC
	PMIC_ENABLE();

	// reconfigure PMIC in case it was reset
	pmic_interface_config();

	// enable ship mode on PMIC
	while(nrf_drv_twi_is_busy(&m_twi));
	uint8_t reg_ssmc[2] = {BQ25120A_REG_SSMC & 0xFF, BQ25120A_VAL_SSMC & 0xFF};
	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_ssmc, sizeof(reg_ssmc), false);
	APP_ERROR_CHECK(err_code);
	while(nrf_drv_twi_is_busy(&m_twi));

	// check PMIC status
//	while(nrf_drv_twi_is_busy(&m_twi));
//	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_ssmc[0], sizeof(reg_ssmc[0]), true);
//	APP_ERROR_CHECK(err_code);
//	while(nrf_drv_twi_is_busy(&m_twi));
//	err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_ssmc[1], sizeof(reg_ssmc[1]));
//	APP_ERROR_CHECK(err_code);

	// disable DCDC converter
//	while(nrf_drv_twi_is_busy(&m_twi));
//	uint8_t reg_svc[2] = {BQ25120A_REG_SVC & 0xFF, 0x00};
//	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_svc, sizeof(reg_svc), false);
//	APP_ERROR_CHECK(err_code);

	// disable PMIC
	PMIC_DISABLE();

	// release lock on I2C
	nrf_mtx_unlock(&p_mtx_i2c);

	if (pmic_interface_check_vin()) {
		// disable PMIC
		PMIC_DISABLE();

		// enable events on PG\ to detect when VIN is disconnected
		nrf_drv_gpiote_in_event_enable(DOMIO_PMIC_PG_PIN, true);
	}
}

void pmic_interface_shutdown_dis() {
	ret_code_t err_code;

	// wait to make sure I2C is not being used (interrupt race)
	while(!nrf_mtx_trylock(&p_mtx_i2c));

	// re-configure PMIC
	pmic_interface_config();

	// disable ship mode on PMIC
	while(nrf_drv_twi_is_busy(&m_twi));
	uint8_t reg_ssmc[2] = {BQ25120A_REG_SSMC & 0xFF, 0x00};
	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_ssmc, sizeof(reg_ssmc), false);
	APP_ERROR_CHECK(err_code);
	while(nrf_drv_twi_is_busy(&m_twi));

	// wait for I2C to complete
	while(nrf_drv_twi_is_busy(&m_twi));

	// disable PG\ events
	nrf_drv_gpiote_in_event_disable(DOMIO_PMIC_PG_PIN);

	// release lock on I2C
	nrf_mtx_unlock(&p_mtx_i2c);
}

void pmic_interface_task() {
	ret_code_t err_code;

	// make sure I2C is not being used (interrupt race)
	if (nrf_mtx_trylock(&p_mtx_i2c)) {
		// enable PMIC
		PMIC_ENABLE();

//		// check PMIC status and battery level
//		uint8_t reg_ssmc[2] = {BQ25120A_REG_SSMC & 0xFF, BQ25120A_VAL_SSMC & 0xFF};
//		while(nrf_drv_twi_is_busy(&m_twi));
//		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_ssmc[0], sizeof(reg_ssmc[0]), true);
//		APP_ERROR_CHECK(err_code);
//		while(nrf_drv_twi_is_busy(&m_twi));
//		err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_ssmc[1], sizeof(reg_ssmc[1]));
//		APP_ERROR_CHECK(err_code);

		uint8_t reg_vbbm[2] = {BQ25120A_REG_VBBM & 0xFF, 0xFF};
		while(nrf_drv_twi_is_busy(&m_twi));
		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_vbbm[0], sizeof(reg_vbbm[0]), true);
		APP_ERROR_CHECK(err_code);
		while(nrf_drv_twi_is_busy(&m_twi));
		err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_vbbm[1], sizeof(reg_vbbm[1]));
		APP_ERROR_CHECK(err_code);

		// wait for read operation to comlete
		while(nrf_drv_twi_is_busy(&m_twi));

		// disable PMIC
		PMIC_DISABLE();

		// release lock on I2C
		nrf_mtx_unlock(&p_mtx_i2c);
	}
}

bool pmic_interface_check_vin() {
	ret_code_t err_code;

	// enable PMIC
	PMIC_ENABLE();

	// check PMIC status and battery level
	uint8_t reg_ffm = BQ25120A_REG_FFM & 0xFF, val_ffm = 0x00;
	while(nrf_drv_twi_is_busy(&m_twi));
	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_ffm, sizeof(reg_ffm), true);
	APP_ERROR_CHECK(err_code);
	while(nrf_drv_twi_is_busy(&m_twi));
	err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&val_ffm, sizeof(val_ffm));
	APP_ERROR_CHECK(err_code);

	// wait for read operation to comlete
	while(nrf_drv_twi_is_busy(&m_twi));

	// disable PMIC
	PMIC_DISABLE();

	// check is VIN is present (PG or VIN at over voltage)
	return ((val_ffm & BQ25120A_REG_FFM_VIN_OV) || (nrf_gpio_pin_read(DOMIO_PMIC_PG_PIN) == 0));
}

bool pmic_interface_check_poweron() {
	ret_code_t err_code;

	// enable PMIC
	PMIC_ENABLE();

	// check PMIC status and battery level
	uint8_t reg_pbc = BQ25120A_REG_PBC & 0xFF, val_pbc = 0x00;
	while(nrf_drv_twi_is_busy(&m_twi));
	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_pbc, sizeof(reg_pbc), true);
	APP_ERROR_CHECK(err_code);
	while(nrf_drv_twi_is_busy(&m_twi));
	err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&val_pbc, sizeof(val_pbc));
	APP_ERROR_CHECK(err_code);

	// wait for read operation to comlete
	while(nrf_drv_twi_is_busy(&m_twi));

	// disable PMIC
	PMIC_DISABLE();

	return (val_pbc & BQ25120A_REG_PBC_WAKE2);
}

/*==================================================================
 * Private Function Implementations
 ==================================================================*/

void twi_init (void)
{
    ret_code_t err_code;

    const nrf_drv_twi_config_t twi_config = {
       .scl                = ARDUINO_SCL_PIN,
       .sda                = ARDUINO_SDA_PIN,
       .frequency          = NRF_TWI_FREQ_400K,
       .interrupt_priority = APP_IRQ_PRIORITY_LOW,
       .clear_bus_init     = true
    };

    err_code = nrf_drv_twi_init(&m_twi, &twi_config, twi_handler, NULL);
    APP_ERROR_CHECK(err_code);

    nrf_drv_twi_enable(&m_twi);
}

void twi_handler(nrf_drv_twi_evt_t const * p_event, void * p_context)
{
    switch (p_event->type)
    {
        case NRF_DRV_TWI_EVT_DONE:
            if (p_event->xfer_desc.type == NRF_DRV_TWI_XFER_RX)
            {
//                data_handler(m_sample);
            }
            break;
        case NRF_DRV_TWI_EVT_ADDRESS_NACK:
            NRF_LOG_ERROR("I2C Address Nack");
            break;
        case NRF_DRV_TWI_EVT_DATA_NACK:
            NRF_LOG_ERROR("I2C Data Nack");
            break;
        default:
            break;
    }
}

void pmic_interface_config() {
	ret_code_t err_code;
	uint8_t read_val;

	// enable PMIC
	PMIC_ENABLE();

	// read FCC to check if device is already configured
	while(nrf_drv_twi_is_busy(&m_twi));
	uint8_t reg_fcc[2] = {BQ25120A_REG_FCC & 0xFF, BQ25120A_VAL_FCC & 0xFF};
	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_fcc[0], sizeof(reg_fcc[0]), true);
	APP_ERROR_CHECK(err_code);
	while(nrf_drv_twi_is_busy(&m_twi));
	err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&read_val, sizeof(read_val));
	APP_ERROR_CHECK(err_code);
	while(nrf_drv_twi_is_busy(&m_twi));

	if (read_val != reg_fcc[1]) {
		// read all registers to clear any flags
		for (uint8_t reg = 0; reg <= BQ25120A_REG_VDT; reg++) {
			while(nrf_drv_twi_is_busy(&m_twi));
			err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg, sizeof(reg), true);
			APP_ERROR_CHECK(err_code);
			while(nrf_drv_twi_is_busy(&m_twi));
			err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&read_val, sizeof(read_val));
			APP_ERROR_CHECK(err_code);
			while(nrf_drv_twi_is_busy(&m_twi));
		}

		// program all the registers
		while(nrf_drv_twi_is_busy(&m_twi));
		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_fcc, sizeof(reg_fcc), false);
		APP_ERROR_CHECK(err_code);

//	// read PBC register to see if PMIC is already configured
		uint8_t reg_pbc[2] = {BQ25120A_REG_PBC & 0xFF, BQ25120A_VAL_PBC & 0xFF};
//	while(nrf_drv_twi_is_busy(&m_twi));
//	err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_pbc[0], sizeof(reg_pbc[0]), true);
//	APP_ERROR_CHECK(err_code);
//	while(nrf_drv_twi_is_busy(&m_twi));
//	err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&read_val, sizeof(read_val));
//	APP_ERROR_CHECK(err_code);
//
//	if ((read_val & BQ25120A_REG_PBC_PGB_MR) == 0) {
		// PMIC has not been configured yet
		while(nrf_drv_twi_is_busy(&m_twi));
		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_pbc, sizeof(reg_pbc), false);
		APP_ERROR_CHECK(err_code);

		while(nrf_drv_twi_is_busy(&m_twi));
		uint8_t reg_ibuc[2] = {BQ25120A_REG_IBUC & 0xFF, BQ25120A_VAL_IBUC & 0xFF};
		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_ibuc, sizeof(reg_ibuc), false);
		APP_ERROR_CHECK(err_code);

		while(nrf_drv_twi_is_busy(&m_twi));
		uint8_t reg_svc[2] = {BQ25120A_REG_SVC & 0xFF, BQ25120A_VAL_SVC & 0xFF};
		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_svc, sizeof(reg_svc), false);
		APP_ERROR_CHECK(err_code);

		while(nrf_drv_twi_is_busy(&m_twi));
		uint8_t reg_tscfm[2] = {BQ25120A_REG_TSCFM & 0xFF, BQ25120A_VAL_TSCFM & 0xFF};
		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)reg_tscfm, sizeof(reg_tscfm), false);
		APP_ERROR_CHECK(err_code);
//	}
	}

		// wait for I2C operation to comlete
		while(nrf_drv_twi_is_busy(&m_twi));

		// disable PMIC
	PMIC_DISABLE();

	// DEBUG - keep reading SVC register to check if it changes
//	while(true) {
//		while(nrf_drv_twi_is_busy(&m_twi));
//		err_code = nrf_drv_twi_tx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_svc[0], sizeof(reg_svc[0]), true);
//		APP_ERROR_CHECK(err_code);
//		while(nrf_drv_twi_is_busy(&m_twi));
//		err_code = nrf_drv_twi_rx(&m_twi, BQ25120A_ADDR, (uint8_t *)&reg_svc[1], sizeof(reg_svc[1]));
//		APP_ERROR_CHECK(err_code);
//	}

}

static void pmic_pg_event_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action) {
	// check if it is the correct pin and action
	if ((pin == DOMIO_PMIC_PG_PIN) && (action == NRF_GPIOTE_POLARITY_LOTOHI)) {
		// when power good (PG) goes high, meaning VIN has been disconnected, pull CD\ high to go into ship mode
		nrf_delay_ms(500);
		PMIC_ENABLE();
		NRF_LOG_DEBUG("Shutting system down, PG\ -> high.");
	}
}
