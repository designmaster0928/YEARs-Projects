/**
 * \file ble_module.c
 * \brief BLE module source file.
 *
 * \author Domio Sports
 *
 * BLE Module - BLE module source implementation file.
 *
 * Revisions: none
 *
 * \date 2018-11-05
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

/*==================================================================
 * Includes
 ==================================================================*/

#include <stdint.h>
#include "sdk_config.h"
#include "nrf.h"
#include "nordic_common.h"

#include "nrf_mtx.h"

#include "boards.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "ble_interface.h"
#include "ble_module.h"

/*==================================================================
 * Private Defines
 ==================================================================*/

#define SCAN_ADV_LED                    BSP_BOARD_LED_0
#define READY_LED                       BSP_BOARD_LED_1
#define PROGRESS_LED                    BSP_BOARD_LED_2
#define DONE_LED                        BSP_BOARD_LED_3

#define SEND_BUFFER_SIZE		4096

/*==================================================================
 * Private Typedefs
 ==================================================================*/

/**@brief BLE Module structure.
 * @details This structure contains control information for the BLE module. */
typedef struct
{
    bool                     busy;                   //!< busy flag, indicates that the hvx function returned busy and that there are still data to be transfered. */
    uint16_t                 max_payload_len;        //!< Maximum number of bytes which can be sent in one notification. */

    uint8_t send_data_buffer[SEND_BUFFER_SIZE];
    uint16_t sdb_write_idx, sdb_read_idx, sdb_byte_count;

    ble_module_event_handler_t ble_module_event_handler;

    nrf_mtx_t p_mtx_buffer;
} ble_module_ctrl_t;

/*==================================================================
 * Private Function Prototypes
 ==================================================================*/

static void ble_module_send_notif();

/**@brief AMT server event handler. */
static void ble_module_evt_handler(ble_domio_evt_t evt);

/*==================================================================
 * Firmware Global Variables
 ==================================================================*/

/*==================================================================
 * File Global Variables
 ==================================================================*/

static ble_module_ctrl_t     m_ble_module_ctrl;

static bool volatile m_notif_enabled;

/*==================================================================
 * Function Implementations
 ==================================================================*/

void ble_module_init(ble_module_event_handler_t event_handler) {
	//
//    ble_stack_init();
//    gap_params_init();
//    gatt_init();
//    advertising_data_set();
//
//    services_init();
//
//    data_len_ext_set(true);
//    conn_evt_len_ext_set(true);
	ble_interface_init(ble_module_evt_handler);

    m_ble_module_ctrl.sdb_write_idx = 0;
    m_ble_module_ctrl.sdb_read_idx = 0;
    m_ble_module_ctrl.sdb_byte_count = 0;

    m_ble_module_ctrl.ble_module_event_handler = event_handler;

    m_notif_enabled = false;

    nrf_mtx_init(&m_ble_module_ctrl.p_mtx_buffer);
}

void ble_module_connect(bool erase_bond) {
	NRF_LOG_INFO("BLE Audio example started - peripheral.");
	ble_interface_adv_start(erase_bond);
}

void ble_module_start_transfer() {
	//
}

void ble_module_stop_transfer() {
	//
}

void ble_module_send_data(uint8_t *data, uint16_t data_size) {
	// check for valid data parameters
	if ((data != NULL) && (data_size > 0) && m_notif_enabled) {
		// wait until buffer is not being used
		while(!nrf_mtx_trylock(&m_ble_module_ctrl.p_mtx_buffer));

//		uint16_t prev_buff_size = m_ble_module_ctrl.sdb_byte_count;
		// store data in buffer to send when possible
		// check if data fits in the remaining buffer, otherwise discard excess data
		if (data_size > (SEND_BUFFER_SIZE - m_ble_module_ctrl.sdb_byte_count)) {
			NRF_LOG_WARNING("Discarded %u bytes of data", (data_size - (SEND_BUFFER_SIZE - m_ble_module_ctrl.sdb_byte_count)));
			data_size = SEND_BUFFER_SIZE - m_ble_module_ctrl.sdb_byte_count;
		}
		m_ble_module_ctrl.sdb_byte_count += data_size;
		// check if whole data fits at the end of buffer
		uint16_t bytes_end = (data_size > (SEND_BUFFER_SIZE - m_ble_module_ctrl.sdb_write_idx)) ? (SEND_BUFFER_SIZE - m_ble_module_ctrl.sdb_write_idx) : data_size;
		uint16_t bytes_begin = data_size - bytes_end;
		// add data to the end of the buffer
		memcpy(&m_ble_module_ctrl.send_data_buffer[m_ble_module_ctrl.sdb_write_idx], data, bytes_end);
		m_ble_module_ctrl.sdb_write_idx += bytes_end;
		if (m_ble_module_ctrl.sdb_write_idx >= SEND_BUFFER_SIZE) {
			m_ble_module_ctrl.sdb_write_idx = 0;
		}
		if (bytes_begin > 0) {
			// add data to the beginning of the buffer
			memcpy(&m_ble_module_ctrl.send_data_buffer[m_ble_module_ctrl.sdb_write_idx], &data[bytes_end], bytes_begin);
			m_ble_module_ctrl.sdb_write_idx += bytes_begin;
			// check write index just in case
			if (m_ble_module_ctrl.sdb_write_idx >= SEND_BUFFER_SIZE) {
				m_ble_module_ctrl.sdb_write_idx = 0;
			}
		}

//		NRF_LOG_DEBUG("Added %u bytes to BLE module buffer.", (m_ble_module_ctrl.sdb_byte_count - prev_buff_size));

		// release lock on buffer
		nrf_mtx_unlock(&m_ble_module_ctrl.p_mtx_buffer);

		// if there is no ongoing data transfer, start one
		if (!m_ble_module_ctrl.busy) {
			ble_module_send_notif();
		}
	}
}

/*==================================================================
 * Private Function Implementations
 ==================================================================*/


static void ble_module_send_notif()
{
    uint8_t data[256];
    uint16_t payload_len;

    // check if there is data enough to be sent
    if (m_ble_module_ctrl.sdb_byte_count < m_ble_module_ctrl.max_payload_len) {
    	return;
    }

	// wait until buffer is not being used
	while(!nrf_mtx_trylock(&m_ble_module_ctrl.p_mtx_buffer));

    ble_domio_return_type_t err_code = BLE_DOMIO_RET_OK;
    while ((err_code == BLE_DOMIO_RET_OK) && (m_ble_module_ctrl.sdb_byte_count >= m_ble_module_ctrl.max_payload_len))
    {
    	// check if data fits in the payload, otherwise leave extra for future packet
    	payload_len = (m_ble_module_ctrl.sdb_byte_count < m_ble_module_ctrl.max_payload_len) ? m_ble_module_ctrl.sdb_byte_count : m_ble_module_ctrl.max_payload_len;
    	// check if whole data fits at the end of buffer
    	uint16_t bytes_end = (payload_len > (SEND_BUFFER_SIZE - m_ble_module_ctrl.sdb_read_idx)) ? (SEND_BUFFER_SIZE - m_ble_module_ctrl.sdb_read_idx) : payload_len;
    	uint16_t bytes_begin = payload_len - bytes_end;
    	// copy data from end of buffer to payload
    	memcpy(data, &m_ble_module_ctrl.send_data_buffer[m_ble_module_ctrl.sdb_read_idx], bytes_end);
    	if (bytes_begin > 0) {
    		// add data to the beginning of the buffer
    		memcpy(&data[bytes_end], &m_ble_module_ctrl.send_data_buffer[0], bytes_begin);
    	}

    	if (payload_len == 0) {
    		NRF_LOG_DEBUG("Sending empty notification");
    	}

//    	NRF_LOG_DEBUG("Writing GATTS notification %u bytes.", payload_len);
        err_code = ble_interface_send_notif(data, &payload_len);

        if (err_code == BLE_DOMIO_RET_BUSY)
        {
            // Wait for BLE_GATTS_EVT_HVN_TX_COMPLETE.
        	NRF_LOG_DEBUG("BLE interface busy.");
            m_ble_module_ctrl.busy = true;
            break;
        }
        else if (err_code != BLE_DOMIO_RET_OK)
        {
            NRF_LOG_ERROR("Problem sending notification packet.");
        } else {
            // update buffer info and pointer only in case of no errors.
        	m_ble_module_ctrl.sdb_byte_count -= payload_len;
        	m_ble_module_ctrl.sdb_read_idx = (m_ble_module_ctrl.sdb_read_idx + payload_len) % SEND_BUFFER_SIZE;
        }
    }

	// release lock on buffer
	nrf_mtx_unlock(&m_ble_module_ctrl.p_mtx_buffer);
}


static void ble_module_evt_handler(ble_domio_evt_t evt)
{
    switch (evt.evt_type)
    {
        case BLE_DOMIO_EVT_NOTIF_ENABLED:
        {
            NRF_LOG_INFO("Notifications enabled.");

            bsp_board_led_on(READY_LED);
            m_notif_enabled = true;
        } break;

        case BLE_DOMIO_EVT_NOTIF_DISABLED:
        {
            NRF_LOG_INFO("Notifications disabled.");
            bsp_board_led_off(READY_LED);
        } break;

        case BLE_DOMIO_EVT_MAX_PAYLOAD_UPDATE:
        {
            m_ble_module_ctrl.max_payload_len = evt.payload.max_payload_len;
        } break;

        case BLE_DOMIO_EVT_TRANSMIT_COMPLETED:
        {
            if (m_ble_module_ctrl.busy)
            {
            	m_ble_module_ctrl.busy = false;
                ble_module_send_notif();
            }
        } break;

        case BLE_DOMIO_EVT_TRANSFER_START:
        {
        	// received command to start transmission
        	NRF_LOG_INFO("Received command to start transmission.");
        	if (m_ble_module_ctrl.ble_module_event_handler != NULL) {
        		m_ble_module_ctrl.ble_module_event_handler(BLE_MODULE_EVT_DATA_TRANSMIT_START);
        	}
        } break;

        case BLE_DOMIO_EVT_TRANSFER_STOP:
        {
        	// clear transmission buffer
        	m_ble_module_ctrl.busy = false;
        	m_ble_module_ctrl.sdb_write_idx = 0;
        	m_ble_module_ctrl.sdb_read_idx = 0;
        	m_ble_module_ctrl.sdb_byte_count = 0;

        	// received command to stop transmission
        	if (m_ble_module_ctrl.ble_module_event_handler != NULL) {
        		m_ble_module_ctrl.ble_module_event_handler(BLE_MODULE_EVT_DATA_TRANSMIT_STOP);
        	}
        } break;

        case BLE_DOMIO_EVT_DISCONNECTED:
        {
        	// since we got disconnected, start advertising again
//        	ble_interface_adv_start(false);

        	// clear transmission buffer
        	m_ble_module_ctrl.busy = false;
        	m_ble_module_ctrl.sdb_write_idx = 0;
        	m_ble_module_ctrl.sdb_read_idx = 0;
        	m_ble_module_ctrl.sdb_byte_count = 0;

        	// received command to stop transmission
        	if (m_ble_module_ctrl.ble_module_event_handler != NULL) {
        		m_ble_module_ctrl.ble_module_event_handler(BLE_MODULE_EVT_DATA_TRANSMIT_STOP);
        	}
        } break;
    }
}
