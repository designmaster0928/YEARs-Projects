/**
 * \file ble_module.h
 * \brief BLE module header file.
 *
 * \author Domio Sports
 *
 * BLE Module - BLE module header definitions file.
 *
 * Revisions: none
 *
 * \date 2018-11-05
 * \author Rafael Jose Daciuk - rafael@domiosports.com
 */

#ifndef BLE_MODULE_H_
#define BLE_MODULE_H_

/*==================================================================
 * Includes
 ==================================================================*/

/*==================================================================
 * Defines
 ==================================================================*/

/*==================================================================
 * Typedefs
 ==================================================================*/

/**@brief BLE Module event type. */
typedef enum
{
    BLE_MODULE_EVT_DATA_TRANSMIT_START,
	BLE_MODULE_EVT_DATA_TRANSMIT_STOP,
} ble_module_evt_type_t;

/**@brief Audio module data handler type.
 * The Audio module will call this function when there is data
 * available to be processed.
*/
typedef void (*ble_module_event_handler_t)(ble_module_evt_type_t evt_type);

/*==================================================================
 * Function Prototypes
 ==================================================================*/

void ble_module_init(ble_module_event_handler_t event_handler);

void ble_module_connect(bool erase_bond);

void ble_module_start_transfer();

void ble_module_stop_transfer();

void ble_module_send_data(uint8_t *data, uint16_t data_size);

#endif /* BLE_MODULE_H_ */
