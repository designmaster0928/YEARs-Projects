/**
 * \file audio_module.c
 * \brief Audio module source file.
 *
 * \author Domio Sports
 *
 * Audio Module - Audio module for microphone data management source
 * implementation file.
 *
 * Revisions: none
 *
 * \date Nov. 7, 2018
 * \author Rafael Jose Daciuk - rafael@domiosport.com
 */

/*==================================================================
 * Includes
 ==================================================================*/

#include <stdint.h>
#include <stdbool.h>
#include <math.h>

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

#include "audio_module.h"
#include "audio_interface.h"
#include "counter.h"

/*==================================================================
 * Private Defines
 ==================================================================*/

/*==================================================================
 * Private Typedefs
 ==================================================================*/

/**@brief Audio Module structure.
 * @details This structure contains control information for the Audio module. */
typedef struct
{
	audio_module_data_handler_t audio_data_handler;

	// timing debug vars
	uint32_t bytes_rcvd;
} audio_module_ctrl_t;

/*==================================================================
 * Private Function Prototypes
 ==================================================================*/

static bool audio_interface_evt_handler(audio_interface_evt_t * p_evt);

/*==================================================================
 * Firmware Global Variables
 ==================================================================*/

/*==================================================================
 * File Global Variables
 ==================================================================*/

audio_module_ctrl_t m_audio_module_ctrl;

/*==================================================================
 * Function Implementations
 ==================================================================*/

void audio_module_init(audio_module_data_handler_t data_handler) {
	audio_interface_init(audio_interface_evt_handler);

	// set the handler for audio data
    m_audio_module_ctrl.audio_data_handler = data_handler;

    counter_init();
}

void audio_module_start() {
	//
	m_audio_module_ctrl.bytes_rcvd = 0;
	counter_start();
	audio_interface_start();
}

void audio_module_stop() {
	//
	audio_interface_stop();

	uint32_t time_ms      = counter_get();
	uint32_t bit_count    = (m_audio_module_ctrl.bytes_rcvd * 8);
	float throughput_kbps = ((bit_count / (time_ms / 1000.f)) / 1000.f);

	NRF_LOG_INFO("Got %u bytes of audio payload.",
			m_audio_module_ctrl.bytes_rcvd);
	NRF_LOG_INFO("Data Rate: " NRF_LOG_FLOAT_MARKER " Kbps.",
			NRF_LOG_FLOAT(throughput_kbps));
}

/*==================================================================
 * Private Function Implementations
 ==================================================================*/


static bool audio_interface_evt_handler(audio_interface_evt_t * p_evt)
{
    bool ret = false;

    switch (p_evt->evt)
    {
    	// we should only get events with new data
        case AUDIO_INTERFACE_EVT_RX_DATA_REC:
            {
                int16_t *p_data_received = (int16_t *)p_evt->param.rx_buf_received.p_data_received;
                uint16_t num_of_words = p_evt->param.rx_buf_received.number_of_words;

//                if (i2s_config.mode == NRF_I2S_MODE_SLAVE) {
//                	// in slave mode we are interfacing with the ST micro kit, which has 32kHz output, so we skip every other sample
//                	for (int i = 0; i < num_of_words; i++) {
//                		m_i2s_rx_buffer[i] = p_data_received[2*i];
//                	}
//                	if (m_audio_module_ctrl.audio_data_handler != NULL) {
//                		m_audio_module_ctrl.audio_data_handler((int16_t *)m_i2s_rx_buffer, num_of_words);
//                	}
//
//            		m_audio_module_ctrl.bytes_rcvd += num_of_words*2;
//                } else {
//                	for (int i = 0; i < num_of_words; i++) {
//                		m_i2s_rx_buffer[2*i] = p_data_received[2*i];
//                		m_i2s_rx_buffer[2*i + 1] = p_data_received[2*i + 1];
//                		//                	m_i2s_rx_buffer_right[i] = p_data_received[i + 1];
//                	}
//                	if (m_audio_module_ctrl.audio_data_handler != NULL) {
//                		m_audio_module_ctrl.audio_data_handler((int16_t *)m_i2s_rx_buffer, 2 * num_of_words);
//                	}
//
//            		m_audio_module_ctrl.bytes_rcvd += num_of_words*4;
//                }

            	if (m_audio_module_ctrl.audio_data_handler != NULL) {
            		m_audio_module_ctrl.audio_data_handler(p_data_received, num_of_words);
            	}

        		m_audio_module_ctrl.bytes_rcvd += num_of_words*2;
            }
            break;
//        case AUDIO_INTERFACE_EVT_TX_DATA_REQ:
//            // I2S TX buffer values requested
//            {
//                uint16_t * p_buffer  = (uint16_t *) p_evt->param.tx_buf_req.p_data_to_send;
//                uint16_t num_of_words = p_evt->param.rx_buf_received.number_of_words;

//                if (   true ==                      m_ble_nus_max_data_len_has_been_updated
//                    && true ==                      m_ble_nus_connected_to_device_with_NUS
//                    && BLE_CONN_HANDLE_INVALID !=   m_ble_nus.conn_handle)
//                {
//                    // Extract buffer from FIFO
//                    int16_t *  p_decompressed_toplay_frame;
//                    ret_code_t ret_code = nrf_atfifo_get_free(decompressed_toplay_buffer_pointers_fifo, &p_decompressed_toplay_frame, sizeof(p_decompressed_toplay_frame), NULL);
//                    if (NRF_SUCCESS == ret_code)
//                    {
//                        memcpy(p_buffer, p_decompressed_toplay_frame, (num_of_words) * sizeof(uint32_t));
//                        nrf_balloc_free(&m_decompressed_toplay_audio_frame_pool, p_decompressed_toplay_frame);
//                    }
//                    else {
//                        // Set the I2S buffer to all 0's - not sure if this is necessary or not
//                        memset(p_buffer, (uint8_t)0, (num_of_words) * sizeof(uint32_t));
//                    }
//                }
//                else {
//                    // Set the I2S buffer to all 0's - not sure if this is necessary or not
//                    memset(p_buffer, (uint8_t)0, (num_of_words) * sizeof(uint32_t));
//                }
//
//                // Keep playing
//                ret = true;
//            }
//            break;
    }

    return ret;
}
