/**
 * \file audio_module.h
 * \brief Audio module header file.
 *
 * \author Domio Sports
 *
 * Audio Module - Audio module for microphone data management header
 * definitions file.
 *
 * Revisions: none
 *
 * \date Nov. 7, 2018
 * \author Rafael Jose Daciuk - rafael@domiosport.com
 */

#ifndef AUDIO_MODULE_H_
#define AUDIO_MODULE_H_

/*==================================================================
 * Includes
 ==================================================================*/

/*==================================================================
 * Defines
 ==================================================================*/

/*==================================================================
 * Typedefs
 ==================================================================*/

/**@brief Audio module data handler type.
 * The Audio module will call this function when there is data
 * available to be processed.
*/
typedef void (*audio_module_data_handler_t)(int16_t *p_audio_data, uint16_t data_size);

/*==================================================================
 * Function Prototypes
 ==================================================================*/

void audio_module_init(audio_module_data_handler_t data_handler);

void audio_module_start();

void audio_module_stop();

#endif /* AUDIO_MODULE_H_ */
