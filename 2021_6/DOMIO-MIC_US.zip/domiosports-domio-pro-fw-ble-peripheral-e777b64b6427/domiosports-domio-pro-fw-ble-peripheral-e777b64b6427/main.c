/**
 * Copyright (c) 2014 - 2017, Nordic Semiconductor ASA
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form, except as embedded into a Nordic
 *    Semiconductor ASA integrated circuit in a product or a software update for
 *    such product, must reproduce the above copyright notice, this list of
 *    conditions and the following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. Neither the name of Nordic Semiconductor ASA nor the names of its
 *    contributors may be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 * 
 * 4. This software, with or without modification, must only be used with a
 *    Nordic Semiconductor ASA integrated circuit.
 * 
 * 5. Any software provided in binary form under this license must not be reverse
 *    engineered, decompiled, modified and/or disassembled.
 * 
 * THIS SOFTWARE IS PROVIDED BY NORDIC SEMICONDUCTOR ASA "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY, NONINFRINGEMENT, AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL NORDIC SEMICONDUCTOR ASA OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 * GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 */

/*==================================================================
 * Includes
 ==================================================================*/

#include <stdint.h>
#include <string.h>
#include "nordic_common.h"
#include "nrf.h"
#include "nrf_delay.h"
#include "nrf_balloc.h"
#include "app_scheduler.h"
#include "app_timer.h"
#include "app_util.h"
#include "app_util_platform.h"
#include "bsp.h"

#include "nrf_log.h"
#include "nrf_log_ctrl.h"
#include "nrf_log_default_backends.h"

//#include "opus_config.h"
//#include "drv_sgtl5000.h"

#include "nrf_drv_gpiote.h"

#include "pmic_interface.h"
#include "ble_module.h"
#include "audio_module.h"

/*==================================================================
 * Private Defines
 ==================================================================*/

#define DOMIO_CONNECT_BUTTON			BSP_EVENT_KEY_0
#define DOMIO_START_BUTTON				BSP_EVENT_KEY_1
#define DOMIO_PMIC_RESET_PIN			2
#define DOMIO_BLE_RESET_PIN				27	//< 27 is for Mic board

#define DOMIO_RESET_TIMEOUT				APP_TIMER_TICKS(1600)

#define DEAD_BEEF                       0xDEADBEEF                                  /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */

//#define FRAME_BUFFER_COUNT_COMPRESSED   2
//#define FRAME_BUFFER_COUNT_UNCOMPRESSED 4



#define SCHEDULER_QUEUE_LEN  4
#define SCHEDULER_EVENT_SIZE sizeof(m_i2s_audio_event_t)

/*==================================================================
 * Private Typedefs
 ==================================================================*/

typedef struct
{
//    uint8_t * compressed_audio_data_pointer;
//    opus_int32 compressed_audio_data_length;
//    int16_t * uncompressed_audio_data_pointer;

} m_i2s_audio_event_t;

/*==================================================================
 * Private Function Prototypes
 ==================================================================*/

//void frame_compress(void * p_event_data, uint16_t event_size);
//void frame_decompress(void * p_event_data, uint16_t event_size);

void audio_data_handler(int16_t *p_audio_data, uint16_t data_size);

void ble_module_event_handler(ble_module_evt_type_t evt_type);

static void reset_gpiote_event_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action);

void startup_timeout();

void longpress_timeout();

/**@brief Function for assert macro callback.
 *
 * @details This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyse
 *          how your product is supposed to react in case of Assert.
 * @warning On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in] line_num    Line number of the failing ASSERT call.
 * @param[in] p_file_name File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name);


///**@brief Function for handling an event from the Connection Parameters Module.
// *
// * @details This function will be called for all events in the Connection Parameters Module
// *          which are passed to the application.
// *
// * @note All this function does is to disconnect. This could have been done by simply setting
// *       the disconnect_on_fail config parameter, but instead we use the event handler
// *       mechanism to demonstrate its use.
// *
// * @param[in] p_evt  Event received from the Connection Parameters Module.
// */
//static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
//{
//    uint32_t err_code;
//
//    if (p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)
//    {
//        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
//        APP_ERROR_CHECK(err_code);
//    }
//}


///**@brief Function for handling errors from the Connection Parameters module.
// *
// * @param[in] nrf_error  Error code containing information about what went wrong.
// */
//static void conn_params_error_handler(uint32_t nrf_error)
//{
//    APP_ERROR_HANDLER(nrf_error);
//}


///**@brief Function for initializing the Connection Parameters module.
// */
//static void conn_params_init(void)
//{
//    uint32_t               err_code;
//    ble_conn_params_init_t cp_init;
//
//    memset(&cp_init, 0, sizeof(cp_init));
//
//    cp_init.p_conn_params                  = NULL;
//    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
//    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;
//    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;
//    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;
//    cp_init.disconnect_on_fail             = false;
//    cp_init.evt_handler                    = on_conn_params_evt;
//    cp_init.error_handler                  = conn_params_error_handler;
//
//    err_code = ble_conn_params_init(&cp_init);
//    APP_ERROR_CHECK(err_code);
//}


/**@brief Function for putting the chip into sleep mode.
 *
 * @note This function will not return.
 */
static void sleep_mode_enter(void);


/**@brief Function for handling events from the BSP module.
 *
 * @param[in]   event   Event generated by button press.
 */
void bsp_event_handler(bsp_event_t event);


/**@brief Function for initializing buttons and leds.
 *
 * @param[out] p_erase_bonds  Will be true if the clear bonding button was pressed to wake the application up.
 */
static void buttons_leds_init();


/**@brief Function for initializing the nrf log module.
 */
static void log_init(void);


/**@brief Function for placing the application in low power state while waiting for events.
 */
static void power_manage(void);

//static void opus_encoder_configure(void)
//{
//    ASSERT(opus_encoder_get_size(1) == sizeof(m_opus_encoder));
//
//    NRF_LOG_INFO("opus_encoder_get_size(1) = %d", opus_encoder_get_size(1));
//
//    APP_ERROR_CHECK_BOOL(opus_encoder_init(m_opus_encoder_state, CONFIG_AUDIO_SAMPLING_FREQUENCY, 1, OPUS_APPLICATION) == OPUS_OK);
//
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_BITRATE(m_opus_bitrate))                      == OPUS_OK);
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_VBR(m_opus_vbr))                              == OPUS_OK);
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_VBR_CONSTRAINT((m_opus_bitrate != OPUS_AUTO)))== OPUS_OK);
//
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_COMPLEXITY(m_opus_complexity))                == OPUS_OK);
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_SIGNAL(OPUS_SIGNAL_VOICE))                    == OPUS_OK);
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_LSB_DEPTH(16))                                == OPUS_OK);
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_DTX(0))                                       == OPUS_OK);
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_INBAND_FEC(0))                                == OPUS_OK);
//    APP_ERROR_CHECK_BOOL(opus_encoder_ctl(m_opus_encoder_state, OPUS_SET_PACKET_LOSS_PERC(0))                          == OPUS_OK);
//}
//
//static void opus_decoder_configure(void)
//{
//    ASSERT(opus_decoder_get_size(1) == sizeof(m_opus_decoder));
//
//    NRF_LOG_INFO("opus_decoder_get_size(1) = %d", opus_decoder_get_size(1));
//
//    APP_ERROR_CHECK_BOOL(opus_decoder_init(m_opus_decoder_state, CONFIG_AUDIO_SAMPLING_FREQUENCY, 1) == OPUS_OK);
//}
//
//
//void frame_compress(void * p_event_data, uint16_t event_size)
//{
//    opus_int32 compressed_frame_size;
//    uint8_t p_compressed_frame[CONFIG_AUDIO_FRAME_SIZE_BYTES];
//    int16_t *  p_uncompressed_frame;
//
//    APP_ERROR_CHECK_BOOL(event_size == sizeof(m_i2s_audio_event_t));
//
//    // Unzip the struct for the uncompressed frame
//    m_i2s_audio_event_t const * p_i2s_audio_event = (m_i2s_audio_event_t *)p_event_data;
//    p_uncompressed_frame = p_i2s_audio_event->uncompressed_audio_data_pointer;
//
//    compressed_frame_size = opus_encode(m_opus_encoder_state,
//                                        p_uncompressed_frame,
//                                        CONFIG_AUDIO_FRAME_SIZE_SAMPLES,
//                                        p_compressed_frame,
//                                        CONFIG_AUDIO_FRAME_SIZE_BYTES);
//
//    // Free uncompressed frame, as it has been processed
//    nrf_balloc_free(&m_uncompressed_tosend_audio_frame_pool, p_uncompressed_frame);
//
//    // If info transmission was scheduled, send buffer - not handled for now, we assume it will work
//    uint16_t length = (uint16_t)compressed_frame_size;
//    uint32_t ret_val = ble_nus_string_send(&m_ble_nus, p_compressed_frame, &length);
//    if ( (ret_val != NRF_ERROR_INVALID_STATE) && (ret_val != NRF_ERROR_BUSY) && (ret_val != NRF_ERROR_RESOURCES) )
//    {
//        APP_ERROR_CHECK(ret_val);
//    }
//}
//
//
//void frame_decompress(void * p_event_data, uint16_t event_size)
//{
//    uint8_t *  p_compressed_toplay_frame;
//    opus_int32 compressed_frame_size;
//    int16_t *  p_decompressed_toplay_frame;
//    int        decompressed_frame_size;
//
//    APP_ERROR_CHECK_BOOL(event_size == sizeof(m_i2s_audio_event_t));
//
//    // Unzip the struct
//    m_i2s_audio_event_t const * p_i2s_audio_event = (m_i2s_audio_event_t *)p_event_data;
//    p_compressed_toplay_frame = p_i2s_audio_event->compressed_audio_data_pointer;
//    compressed_frame_size = p_i2s_audio_event->compressed_audio_data_length;
//
//    // Allocate uncompressed frame
//    p_decompressed_toplay_frame = nrf_balloc_alloc(&m_decompressed_toplay_audio_frame_pool);
//    if (p_decompressed_toplay_frame == NULL)
//    {
//        NRF_LOG_WARNING("Could not allocate memory for Opus toplay decompression");
//        received_toplay_buffers_missed++;
//        // Free up compressed buffer as it will not be used
//        nrf_balloc_free(&m_compressed_toplay_audio_frame_pool, p_compressed_toplay_frame);
//
//        return;
//    }
//
//    decompressed_frame_size = opus_decode(m_opus_decoder_state, p_compressed_toplay_frame, compressed_frame_size, p_decompressed_toplay_frame, CONFIG_AUDIO_FRAME_SIZE_SAMPLES, 0);
//    // Free compressed frame as it uncompressed already
//    nrf_balloc_free(&m_compressed_toplay_audio_frame_pool, p_compressed_toplay_frame);
//    // Check return of decompression
//    if (decompressed_frame_size != CONFIG_AUDIO_FRAME_SIZE_SAMPLES)
//    {
//        NRF_LOG_ERROR("decompressed_frame_size %d != CONFIG_AUDIO_FRAME_SIZE_SAMPLES %d", decompressed_frame_size, CONFIG_AUDIO_FRAME_SIZE_SAMPLES);
//        nrf_balloc_free(&m_decompressed_toplay_audio_frame_pool, p_decompressed_toplay_frame);
//
//        // If failed, we skip this one - should not be failing though
//        received_toplay_buffers_missed++;
//        return;
//    }
//
//    // Add decompressed toplay pointer to FIFO - I2S handler will extract data from here and free memory
//    ret_code_t ret_code = nrf_atfifo_alloc_put(decompressed_toplay_buffer_pointers_fifo, &p_decompressed_toplay_frame, sizeof(p_decompressed_toplay_frame), NULL);
//    // If return value is no memory, it means the I2S TX is lagging behind. To allow it to catch up, we do not add this buffer to the FIFO
//    if (NRF_ERROR_NO_MEM == ret_code)
//    {
//        received_toplay_buffers_missed++;
//        NRF_LOG_ERROR("No MEMORY in FIFO, skipping this buffer! I2S play is lagging. %d/%d missed", received_toplay_buffers_missed, received_toplay_buffers_total);
//        // Free memory as it will not be used
//        nrf_balloc_free(&m_decompressed_toplay_audio_frame_pool, p_decompressed_toplay_frame);
//    }
//}

/*==================================================================
 * Firmware Global Variables
 ==================================================================*/


/*==================================================================
 * File Global Variables
 ==================================================================*/

APP_TIMER_DEF(PMIC_timer);
APP_TIMER_DEF(startup_timer);
APP_TIMER_DEF(longpress_timer);

static bool system_on = false;
static bool powered_off = false;
static bool timeout = false;

/************************************************************
*   Using Smart Remote 3 configuration files for easy reuse
*   of OPUS integration.
*   NOTE: This should match CENTRAL definitions!
************************************************************/
//
//__ALIGN(4) static uint8_t           m_opus_encoder[OPUS_ENCODER_SIZE];
//static OpusEncoder * const          m_opus_encoder_state = (OpusEncoder *)m_opus_encoder;
//
//__ALIGN(4) static uint8_t           m_opus_decoder[OPUS_DECODER_SIZE];
//static OpusDecoder * const          m_opus_decoder_state = (OpusDecoder *)m_opus_decoder;

/************************************************************
*   Allocate buffers that will be used for compression and
*   decompression. Also define FIFO buffer that will be used
*   to store toplay decompressed buffers for I2S TX requests.
************************************************************/
//
//NRF_BALLOC_DEF(m_compressed_toplay_audio_frame_pool,
//               CONFIG_AUDIO_FRAME_SIZE_BYTES,
//               FRAME_BUFFER_COUNT_COMPRESSED);
//
//NRF_BALLOC_DEF(m_decompressed_toplay_audio_frame_pool,
//               (sizeof(int16_t) * CONFIG_AUDIO_FRAME_SIZE_SAMPLES), /* Size matches m_i2s buffers */
//               FRAME_BUFFER_COUNT_UNCOMPRESSED);
//
//NRF_BALLOC_DEF(m_uncompressed_tosend_audio_frame_pool,
//               (sizeof(int16_t) * CONFIG_AUDIO_FRAME_SIZE_SAMPLES), /* Size matches m_i2s buffers */
//               FRAME_BUFFER_COUNT_UNCOMPRESSED);
//
//// Declare FIFO buffer that will be used to store toplay decompressed buffer pointers.
//NRF_ATFIFO_DEF(decompressed_toplay_buffer_pointers_fifo, int16_t *, FRAME_BUFFER_COUNT_UNCOMPRESSED - 1);
//static volatile uint32_t received_toplay_buffers_total = 0;
//static volatile uint32_t received_toplay_buffers_missed = 0;
//
//static int16_t  m_i2s_tx_buffer[I2S_BUFFER_SIZE];
//static int16_t  m_i2s_rx_buffer[I2S_BUFFER_SIZE];


/*==================================================================
 * Function Implementations
 ==================================================================*/


/**@brief Application main function.
 */
int main(void)
{
    uint32_t err_code;

    // Enable I-Cache.
    NRF_NVMC->ICACHECNF |= NVMC_ICACHECNF_CACHEEN_Msk;

    // Initialize.
    err_code = app_timer_init();
    APP_ERROR_CHECK(err_code);

    APP_SCHED_INIT(SCHEDULER_EVENT_SIZE, SCHEDULER_QUEUE_LEN);

    // wait for PMIC
    nrf_delay_ms(100);

    log_init();

#if CONFIG_STACK_PROFILER_ENABLED
    // Initialize stack profiler.
    stack_profiler_init();
#endif

    buttons_leds_init();

//    // initialize PMIC and add periodic task for battery monitoring
//    pmic_interface_init();
//    app_timer_create(&PMIC_timer, APP_TIMER_MODE_REPEATED, pmic_interface_task);
//    app_timer_start(PMIC_timer, APP_TIMER_TICKS(2000), NULL);
//
//    app_timer_create(&startup_timer, APP_TIMER_MODE_SINGLE_SHOT, startup_timeout);
//    app_timer_start(startup_timer, APP_TIMER_TICKS(1600), NULL);
    app_timer_create(&longpress_timer, APP_TIMER_MODE_SINGLE_SHOT, longpress_timeout);

    // initialize BLE
    ble_module_init(ble_module_event_handler);
//    advertising_init();
//    conn_params_init();

    // initialize audio communication
    audio_module_init(audio_data_handler);

    sd_clock_hfclk_request();

    app_timer_resume();

//    nrf_balloc_init(&m_compressed_toplay_audio_frame_pool);
//    nrf_balloc_init(&m_decompressed_toplay_audio_frame_pool);
//    nrf_balloc_init(&m_uncompressed_tosend_audio_frame_pool);
//
//    NRF_ATFIFO_INIT(decompressed_toplay_buffer_pointers_fifo);
//
//    opus_encoder_configure();
//    opus_decoder_configure();

    NRF_LOG_DEBUG("Main: BLE Audio example started - peripheral.");
    ble_module_connect(false);

    // test I2S
//    audio_module_start();

    // Enter main loop.
    for (;;)
    {
		app_sched_execute();
    	while(NRF_LOG_PROCESS());
		power_manage();
		// make sure we had time to process button on/off before shutting down
//		if (timeout) {
//			if (system_on) {
//				if (powered_off == true) {
//					// wait a while to make sure PMIC is OK
//					nrf_delay_ms(100);
//					pmic_interface_shutdown_dis();
//					powered_off = false;
//				}
//				app_timer_start(PMIC_timer, APP_TIMER_TICKS(2000), NULL);
//			} else {
//				if (powered_off == false) {
//
//					powered_off = true;
//
//					// wait for MR\ to be high to enter ship mode
//					while(nrf_drv_gpiote_in_is_set(DOMIO_PMIC_RESET_PIN) == false);
//					nrf_delay_ms(1000);
//
//					pmic_interface_shutdown_en();
//
//					nrf_delay_ms(2);
//				}
//				// enter sleep mode in case PMIC is connected to charger (it won't turn off until it is disconnected)
//				//			sleep_mode_enter();
//			}
//		}
    }
}

/*==================================================================
 * Private Function Implementations
 ==================================================================*/

void audio_data_handler(int16_t *p_audio_data, uint16_t data_size) {
	//
//	NRF_LOG_DEBUG("Adding %u bytes to BLE module buffer.", data_size*sizeof(*p_audio_data));
	ble_module_send_data((uint8_t *)p_audio_data, data_size*sizeof(*p_audio_data));
}

void ble_module_event_handler(ble_module_evt_type_t evt_type) {
	//
	switch(evt_type) {

	case BLE_MODULE_EVT_DATA_TRANSMIT_START:
	{
		NRF_LOG_INFO("Requesting audio transmission start.");
		audio_module_start();
	} break;

	case BLE_MODULE_EVT_DATA_TRANSMIT_STOP:
	{
		audio_module_stop();
	} break;

	default:
		break;

	}
}

static void reset_gpiote_event_handler(nrf_drv_gpiote_pin_t pin, nrf_gpiote_polarity_t action) {
	// check if it is the correct pin and action
	if ((pin == DOMIO_PMIC_RESET_PIN) && (action == NRF_GPIOTE_POLARITY_HITOLO)) {
		// event for MR (on/off) from PMIC
		// check if event was power on (1.5s)
		if (pmic_interface_check_poweron()) {
			// reset input is asserted for 1.5s, turn system on or off
			if (system_on) {
				// turn system off
				system_on = false;
				NRF_LOG_DEBUG("Request to turn system off.");

				app_timer_stop(PMIC_timer);
			} else {
				// turn system on
				system_on = true;
				NRF_LOG_DEBUG("Request to turn system on.");
			}
		}
	} else if ((pin == DOMIO_BLE_RESET_PIN) && (action == NRF_GPIOTE_POLARITY_HITOLO)) {
		// event for BLE reset (clear bonding), check for longpress
		app_timer_start(longpress_timer, APP_TIMER_TICKS(1500), NULL);
	}
}

void startup_timeout() {
	timeout = true;
}

void longpress_timeout() {
	if (!nrf_gpio_pin_read(DOMIO_BLE_RESET_PIN)) {
		NRF_LOG_DEBUG("Starting re-bonding process.");
		// reset pin is still pressed, clear bonding
		ble_module_connect(true);
	}
}

void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
	app_error_handler(DEAD_BEEF, line_num, p_file_name);
}

static void sleep_mode_enter(void)
{
	uint32_t err_code = bsp_indication_set(BSP_INDICATE_IDLE);
	APP_ERROR_CHECK(err_code);

	// Prepare wakeup buttons.
	err_code = bsp_btn_ble_sleep_mode_prepare();
	APP_ERROR_CHECK(err_code);

	// activate wake up from reset IO
	nrf_gpio_cfg_sense_set(DOMIO_PMIC_RESET_PIN, NRF_GPIO_PIN_SENSE_LOW);

	// Go to system-off mode (this function will not return; wakeup will cause a reset).
	err_code = sd_power_system_off();
	APP_ERROR_CHECK(err_code);
}

void bsp_event_handler(bsp_event_t event)
{
	uint32_t err_code;
	//float current_vol = 0;
	// For now, we are not using any BLE events on the buttons - only used for speaker volume
	switch (event)
	{
	case BSP_EVENT_DISCONNECT:
//            err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
//            if (err_code != NRF_ERROR_INVALID_STATE)
//            {
//                APP_ERROR_CHECK(err_code);
//            }
		break;

	case BSP_EVENT_WHITELIST_OFF:
//            if (m_conn_handle == BLE_CONN_HANDLE_INVALID)
//            {
//                err_code = ble_advertising_restart_without_whitelist(&m_advertising);
//                if (err_code != NRF_ERROR_INVALID_STATE)
//                {
//                    APP_ERROR_CHECK(err_code);
//                }
//            }
		break;

	case DOMIO_CONNECT_BUTTON:
	{
		// Start scanning for peripherals and initiate connection
		// with devices that advertise NUS UUID.
//		NRF_LOG_INFO("BLE Audio example started - peripheral.");
//		ble_module_connect();
	} break;

	case DOMIO_START_BUTTON:
	{
		// Start transfering data
	} break;

	default:
		break;
	}
}

static void buttons_leds_init()
{
	uint32_t err_code = bsp_init(BSP_INIT_LED | BSP_INIT_BUTTONS, bsp_event_handler);
	APP_ERROR_CHECK(err_code);

	if (!nrf_drv_gpiote_is_init())
	{
		err_code = nrf_drv_gpiote_init();
		APP_ERROR_CHECK(err_code);
	}

	// configure input for reset (on/off) detection
	nrf_drv_gpiote_in_config_t reset_pin_config = GPIOTE_CONFIG_IN_SENSE_HITOLO(true);
	reset_pin_config.pull = NRF_GPIO_PIN_PULLUP;
	err_code = nrf_drv_gpiote_in_init(DOMIO_PMIC_RESET_PIN, &reset_pin_config, reset_gpiote_event_handler);
	APP_ERROR_CHECK(err_code);
	// enable IO events
	nrf_drv_gpiote_in_event_enable(DOMIO_PMIC_RESET_PIN, true);

	// configure input for BLE reset (clear bonding) detection
	nrf_drv_gpiote_in_config_t ble_pin_config = GPIOTE_CONFIG_IN_SENSE_HITOLO(true);
	ble_pin_config.pull = NRF_GPIO_PIN_PULLUP;
	err_code = nrf_drv_gpiote_in_init(DOMIO_BLE_RESET_PIN, &ble_pin_config, reset_gpiote_event_handler);
	APP_ERROR_CHECK(err_code);
	// enable IO events
	nrf_drv_gpiote_in_event_enable(DOMIO_BLE_RESET_PIN, true);
}

static void log_init(void)
{
	ret_code_t err_code = NRF_LOG_INIT(app_timer_cnt_get);
	APP_ERROR_CHECK(err_code);

	NRF_LOG_DEFAULT_BACKENDS_INIT();
}

static void power_manage(void)
{
	uint32_t err_code = sd_app_evt_wait();
	APP_ERROR_CHECK(err_code);
}

/**
 * @}
 */
