/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "acoustic_bf.h"
#include <stdlib.h>
#include <string.h>
#include "arm_math.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

  /**
  * @brief   Microphone internal structure definition
  */
typedef struct
{
  uint32_t MicChannels;       /*!< Specifies the number of channels */

  uint32_t PdmBufferSize;     /*!< Specifies the size of the PDM double buffer for 1 microphone and 1 ms in bytes*/

  uint32_t PCM_Sampling_Freq;     /*!< Specifies the desired sampling frequency */

  uint32_t PDM_Clock_Freq;     /*!< Specifies the desired sampling frequency */

  uint32_t DecimationFactor;  /*!< Specifies the PDM to PCM decimation factor */

  uint16_t * PDM_Data;      /*!< Takes track of the external PDM data buffer as passed by the user in the start function*/

}
X_NUCLEO_CCA02M1_HandlerTypeDef;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* Those defines are used to allocate the right amount of RAM depending on the
   maximum number of microphone and frequency desired */
#define MAX_MIC_FREQ                 	  2048  /*KHz*/
#define MAX_AUDIO_IN_CHANNEL_NBR_PER_IF   2

/*Number of millisecond of audio at each DMA interrupt*/
#define N_MS_PER_INTERRUPT               1
#define PDM_FREQ_16K                     2048

/*BSP internal buffer size in half words (16 bits)*/
#define PDM_INTERNAL_BUFFER_SIZE_I2S          ((MAX_MIC_FREQ / 8) * MAX_AUDIO_IN_CHANNEL_NBR_PER_IF * N_MS_PER_INTERRUPT)

/* Audio status definition */
#ifndef AUDIO_OK
#define AUDIO_OK                            ((uint8_t)0)
#endif

#ifndef AUDIO_ERROR
#define AUDIO_ERROR                         ((uint8_t)1)
#endif

#ifndef AUDIO_TIMEOUT
#define AUDIO_TIMEOUT                       ((uint8_t)2)
#endif

#define CHANNEL_DEMUX_MASK                    	0x55

#define MIC_DISTANCE		210 //145 //125 //210		// distance between microphones, in tenths of a milimeter
#define BF_BUFFER_SIZE		(16000/1000)
#define PCM_BUFFER_SIZE		(2*BF_BUFFER_SIZE)
#define I2S_BUFFER_SIZE		(4*16*2*BF_BUFFER_SIZE)

#define AUDIO_CHANNELS_IN 				2
#define AUDIO_IN_SAMPLING_FREQUENCY 	16000

#define INTERPOLATOR_BLOCK_SIZE 16
#define INTERPOLATOR_NUM_TAPS 14
#define INTERPOLATOR_FACTOR 2
#define INTERPOLATOR_STATE_LENGTH (INTERPOLATOR_BLOCK_SIZE + (INTERPOLATOR_NUM_TAPS/INTERPOLATOR_FACTOR) -1)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

#define HTONS(A)  ((((uint16_t)(A) & 0xff00) >> 8) | \
                   (((uint16_t)(A) & 0x00ff) << 8))

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2S_HandleTypeDef hi2s1;
I2S_HandleTypeDef hi2s2;
DMA_HandleTypeDef hdma_spi1_rx;
DMA_HandleTypeDef hdma_spi2_tx;

TIM_HandleTypeDef htim1;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart3;

PCD_HandleTypeDef hpcd_USB_OTG_FS;

/* USER CODE BEGIN PV */

static TIM_HandleTypeDef          TimDividerHandle;

static X_NUCLEO_CCA02M1_HandlerTypeDef X_NUCLEO_CCA02M1_Handler;

static uint16_t I2S_InternalBuffer[PDM_INTERNAL_BUFFER_SIZE_I2S];

//static PDM_Filter_Handler_t *lib_PDM_Filter_Handler_Instance[MAX_AUDIO_IN_CHANNEL_NBR_PER_IF];
//static PDM_Filter_Config_t *lib_PDM_Filter_Config_Instance[MAX_AUDIO_IN_CHANNEL_NBR_PER_IF];

static int16_t VolumeGain[] =
{
  -12,-12,-6,-3,0,2,3,5,6,7,8,9,9,10,11,11,12,12,13,13,14,14,15,15,15,
  16,16,17,17,17,17,18,18,18,19,19,19,19,19,20,20,20,20,21,21,21,21,21,
  22,22,22,22,22,22,23,23,23,23,23,23,23,24,24,24,24,24,24,24,25,25,25,
  25,25,25,25,25,25,26,26,26,26,26,26,26,26,26,27,27,27,27,27,27,27,27,
  27,27,28,28,28,28,28,28,28,28,28,28,28,28,29,29,29,29,29,29,29,29,29,
  29,29,29,29,30,30,30,30,30,30,30,31
};

uint8_t Channel_Demux[128] = {
  0x00, 0x01, 0x00, 0x01, 0x02, 0x03, 0x02, 0x03,
  0x00, 0x01, 0x00, 0x01, 0x02, 0x03, 0x02, 0x03,
  0x04, 0x05, 0x04, 0x05, 0x06, 0x07, 0x06, 0x07,
  0x04, 0x05, 0x04, 0x05, 0x06, 0x07, 0x06, 0x07,
  0x00, 0x01, 0x00, 0x01, 0x02, 0x03, 0x02, 0x03,
  0x00, 0x01, 0x00, 0x01, 0x02, 0x03, 0x02, 0x03,
  0x04, 0x05, 0x04, 0x05, 0x06, 0x07, 0x06, 0x07,
  0x04, 0x05, 0x04, 0x05, 0x06, 0x07, 0x06, 0x07,
  0x08, 0x09, 0x08, 0x09, 0x0a, 0x0b, 0x0a, 0x0b,
  0x08, 0x09, 0x08, 0x09, 0x0a, 0x0b, 0x0a, 0x0b,
  0x0c, 0x0d, 0x0c, 0x0d, 0x0e, 0x0f, 0x0e, 0x0f,
  0x0c, 0x0d, 0x0c, 0x0d, 0x0e, 0x0f, 0x0e, 0x0f,
  0x08, 0x09, 0x08, 0x09, 0x0a, 0x0b, 0x0a, 0x0b,
  0x08, 0x09, 0x08, 0x09, 0x0a, 0x0b, 0x0a, 0x0b,
  0x0c, 0x0d, 0x0c, 0x0d, 0x0e, 0x0f, 0x0e, 0x0f,
  0x0c, 0x0d, 0x0c, 0x0d, 0x0e, 0x0f, 0x0e, 0x0f
};

int32_t                      LeftRecBuff[PCM_BUFFER_SIZE];
int32_t                      RightRecBuff[PCM_BUFFER_SIZE];
int16_t                      BfLeftBuff[BF_BUFFER_SIZE];
int16_t                      BfRightBuff[BF_BUFFER_SIZE];
int16_t                      BfInBuff[2*BF_BUFFER_SIZE];
int16_t                      BfOutBuff[2*PCM_BUFFER_SIZE/2];
int16_t                      I2sBuffer[I2S_BUFFER_SIZE];
uint16_t                     I2sBufferWriteIdx, OutBuffWriteIdx;
int16_t                      BfProcOutBuff[I2S_BUFFER_SIZE];
int16_t                      BfRefOutBuff[I2S_BUFFER_SIZE];
uint32_t                     DmaLeftRecHalfBuffCplt  = 0;
uint32_t                     DmaLeftRecBuffCplt      = 0;
uint32_t                     DmaRightRecHalfBuffCplt = 0;
uint32_t                     DmaRightRecBuffCplt     = 0;

static uint16_t aPDMBuffer[AUDIO_CHANNELS_IN*AUDIO_IN_SAMPLING_FREQUENCY/1000*128/8];

/*Handler and Config structure for BeamForming*/
static AcousticBF_Handler_t  libBeamforming_Handler_Instance;
static AcousticBF_Config_t  lib_Beamforming_Config_Instance;

float uwPrescalerValue = 10000000.0;
volatile static uint32_t timerBefore, timerNow, timerBeforeAudioHz, timerNowAudioHz,
	timerBeforeI2sHz, timerNowI2sHz, counterBf2Now, counterBf2Before;
volatile static float timeBeamforming, timeBeamforming2, timeTotal, timeAudioHz, timeI2sHz;
volatile static uint32_t runSecondStep, runningSecondStep = 0, runningFirstStep = 0;

/*Sampling Rate Conversion related*/
static arm_fir_interpolate_instance_q15 InterpolatorStateCH1, InterpolatorStateCHRef;
static int16_t aCoeffs[]={ 1598,   2226,  -2184,  -4655,   -480,  12782,  24726,  24726,  12782, -480,  -4655,  -2184,   2226,   1598}; /*Filter coefficients of a FIR with fStop ~ Fs/2*/
static int16_t aStateCH1[INTERPOLATOR_STATE_LENGTH], aStateCHRef[INTERPOLATOR_STATE_LENGTH];
static int16_t aUpsamplerIN[INTERPOLATOR_BLOCK_SIZE], aUpsamplerINRef[INTERPOLATOR_BLOCK_SIZE];
static int16_t aUpsamplerOUT[INTERPOLATOR_BLOCK_SIZE * INTERPOLATOR_FACTOR], aUpsamplerOUTRef[INTERPOLATOR_BLOCK_SIZE * INTERPOLATOR_FACTOR];
int16_t BfUpSampleOutBuff[2*BF_BUFFER_SIZE*2];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_I2S1_Init(void);
static void MX_I2S2_Init(void);
/* USER CODE BEGIN PFP */
extern void HAL_TIM_MspPostInit(TIM_HandleTypeDef* htim);

uint8_t BSP_AUDIO_IN_Init(uint32_t AudioFreq, uint32_t BitRes, uint32_t ChnlNbr);
uint8_t BSP_AUDIO_IN_Record(uint16_t* pbuf, uint32_t size);
uint8_t BSP_AUDIO_IN_Stop(void);
uint8_t BSP_AUDIO_IN_Pause(void);
uint8_t BSP_AUDIO_IN_Resume(void);
uint8_t BSP_AUDIO_IN_SetVolume(uint8_t Volume);
uint8_t BSP_AUDIO_IN_PDMToPCM(uint16_t *PDMBuf, uint16_t *PCMBuf);

/* User Callbacks: user has to implement these functions in his code if they are needed. */
/* This function should be implemented by the user application.
   It is called into this driver when the current buffer is filled to prepare the next
   buffer pointer and its size. */
void BSP_AUDIO_IN_TransferComplete_CallBack(void);
void BSP_AUDIO_IN_HalfTransfer_CallBack(void);
void BSP_AUDIO_IN_Error_Callback(void);

static uint8_t AUDIO_IN_Timer_Init(void);
static uint8_t AUDIO_IN_Timer_Start(void);

void AudioApplicationInit();
static inline void AudioApplicationProcess();

/**
* @brief  Init beamforming library
* @param  None
* @retval None
*/
uint32_t BF_Init(void);

/**
* @brief  DeInit beamforming library
* @param  None
* @retval None
*/
void BF_DeInit(void);

/**
* @brief  Initializes four SW interrupt with different priorities
* @param  None
* @retval None
*/
void SW_IRQ_Tasks_Init(void);

/**
 * @brief  Enables SW interrupts
 * @param  None
 * @retval None
 */
void SW_IRQ_Tasks_Enable(void);

/**
 * @brief  Disables SW interrupts
 * @param  None
 * @retval None
 */
void SW_IRQ_Tasks_Disable(void);

/**
 * @brief  First interrupt handler routine
 * @param  None
 * @retval None
 */
void SW_Task1_Callback(void);

/**
 * @brief Throws first SW interrupt
 * @param  None
 * @retval None
 */
void SW_Task1_Start(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_I2S1_Init();
  MX_I2S2_Init();
  /* USER CODE BEGIN 2 */

  /*Initialize Audio Peripherals*/
  if(BSP_AUDIO_IN_Init(AUDIO_IN_SAMPLING_FREQUENCY, 0, AUDIO_CHANNELS_IN)!= AUDIO_OK)
  {
    return AUDIO_ERROR;
  }

	AudioApplicationInit();

  /*Start audio acquisition */
  BSP_AUDIO_IN_Record(aPDMBuffer, 0);

	/*##-2- Start the TIM Base generation in interrupt mode ####################*/
	/* Start Channel1 */
	if(HAL_TIM_Base_Start(&htim2) != HAL_OK)
	{
		/* Starting Error */
		Error_Handler();
		timerNow = 0xaa;
	}
	timerNow = __HAL_TIM_GET_COUNTER(&htim2);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};

  /**Configure the main internal regulator output voltage 
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
//  RCC_OscInitStruct.PLL.PLLM = 4;
//  RCC_OscInitStruct.PLL.PLLN = 200;
  RCC_OscInitStruct.PLL.PLLM = 7;
  RCC_OscInitStruct.PLL.PLLN = 344;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 8;
  RCC_OscInitStruct.PLL.PLLR = 3;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2S_APB1|RCC_PERIPHCLK_I2S_APB2
                              |RCC_PERIPHCLK_CLK48;
  PeriphClkInitStruct.PLLI2S.PLLI2SN = 192;
  PeriphClkInitStruct.PLLI2S.PLLI2SM = 8;
  PeriphClkInitStruct.PLLI2S.PLLI2SR = 2;
  PeriphClkInitStruct.PLLI2S.PLLI2SQ = 4;
  PeriphClkInitStruct.Clk48ClockSelection = RCC_CLK48CLKSOURCE_PLLI2SQ;
  PeriphClkInitStruct.I2sApb2ClockSelection = RCC_I2SAPB2CLKSOURCE_PLLR;
  PeriphClkInitStruct.PLLI2SSelection = RCC_PLLI2SCLKSOURCE_PLLSRC;
  PeriphClkInitStruct.I2sApb1ClockSelection = RCC_I2SAPB1CLKSOURCE_PLLR;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2S1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S1_Init(void)
{

  /* USER CODE BEGIN I2S1_Init 0 */

  /* USER CODE END I2S1_Init 0 */

  /* USER CODE BEGIN I2S1_Init 1 */

  /* USER CODE END I2S1_Init 1 */
  hi2s1.Instance = SPI1;
  hi2s1.Init.Mode = I2S_MODE_MASTER_RX;
  hi2s1.Init.Standard = I2S_STANDARD_MSB;
  hi2s1.Init.DataFormat = I2S_DATAFORMAT_32B;
  hi2s1.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
  if (PDM_FREQ_16K == 1024) {
	hi2s1.Init.AudioFreq = I2S_AUDIOFREQ_32K;//64000;//I2S_AUDIOFREQ_32K;
  } else {
	  hi2s1.Init.AudioFreq = 64000;//I2S_AUDIOFREQ_32K;
  }
  hi2s1.Init.CPOL = I2S_CPOL_HIGH;
  hi2s1.Init.ClockSource = I2S_CLOCK_PLLR;
  hi2s1.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_DISABLE;
  if (HAL_I2S_Init(&hi2s1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S1_Init 2 */

  /* USER CODE END I2S1_Init 2 */

}

/**
  * @brief I2S2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2S2_Init(void)
{

  /* USER CODE BEGIN I2S2_Init 0 */

  /* USER CODE END I2S2_Init 0 */

  /* USER CODE BEGIN I2S2_Init 1 */

  /* USER CODE END I2S2_Init 1 */
  hi2s2.Instance = SPI2;
  hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
  hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
  hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B;
  hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_DISABLE;
  hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_32K;//I2S_AUDIOFREQ_16K;
  hi2s2.Init.CPOL = I2S_CPOL_LOW;
  hi2s2.Init.ClockSource = I2S_CLOCK_PLLR;
  hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_DISABLE;
  if (HAL_I2S_Init(&hi2s2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2S2_Init 2 */

  /* USER CODE END I2S2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_SlaveConfigTypeDef sSlaveConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 1;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_EXTERNAL1;
  sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
  sSlaveConfig.TriggerPolarity = TIM_TRIGGERPOLARITY_RISING;
  sSlaveConfig.TriggerFilter = 0;
  if (HAL_TIM_SlaveConfigSynchronization(&htim1, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 1;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = (uint32_t) ((SystemCoreClock) / uwPrescalerValue) - 1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 0xffffffff; //uwPrescalerValue - 1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 6;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.ep0_mps = DEP0CTL_MPS_64;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = ENABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.battery_charging_enable = ENABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = ENABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/** 
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void) 
{
  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD3_Pin|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USB_PowerSwitchOn_GPIO_Port, USB_PowerSwitchOn_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD1_GPIO_Port, LD1_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PE2 PE3 PE4 PE5 
                           PE6 PE7 PE8 PE10 
                           PE12 PE13 PE14 PE15 
                           PE0 PE1 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5 
                          |GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8|GPIO_PIN_10 
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15 
                          |GPIO_PIN_0|GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : USER_Btn_Pin */
  GPIO_InitStruct.Pin = USER_Btn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USER_Btn_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PF0 PF1 PF2 PF3 
                           PF4 PF5 PF6 PF7 
                           PF8 PF9 PF10 PF11 
                           PF12 PF13 PF14 PF15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3 
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7 
                          |GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 
                          |GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 PC1 PC2 PC4 
                           PC5 PC6 PC7 PC8 
                           PC10 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_4 
                          |GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8 
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA2 PA3 
                           PA6 PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3 
                          |GPIO_PIN_6|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB1 PB2 PB11 
                           PB13 PB15 PB4 PB5 
                           PB6 PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_11 
                          |GPIO_PIN_13|GPIO_PIN_15|GPIO_PIN_4|GPIO_PIN_5 
                          |GPIO_PIN_6|GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PG0 PG1 PG2 PG3 
                           PG4 PG5 PG8 PG9 
                           PG10 PG11 PG12 PG13 
                           PG14 PG15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3 
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_8|GPIO_PIN_9 
                          |GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13 
                          |GPIO_PIN_14|GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD2_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PD10 PD11 PD12 PD13 
                           PD14 PD15 PD0 PD1 
                           PD2 PD3 PD4 PD5 
                           PD6 PD7 */
  GPIO_InitStruct.Pin = GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13 
                          |GPIO_PIN_14|GPIO_PIN_15|GPIO_PIN_0|GPIO_PIN_1 
                          |GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5 
                          |GPIO_PIN_6|GPIO_PIN_7;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_PowerSwitchOn_Pin */
  GPIO_InitStruct.Pin = USB_PowerSwitchOn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(USB_PowerSwitchOn_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_OverCurrent_Pin */
  GPIO_InitStruct.Pin = USB_OverCurrent_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_OverCurrent_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD1_Pin */
  GPIO_InitStruct.Pin = LD1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD1_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/**
* @brief  Initializes audio acquisition recording.
* @param  AudioFreq: Audio frequency to be configured for the peripherals.
* 		  Possible values are 8000, 16000, 32000 or 48000 Hz
* @param  BitRes: Not used.
* @param  ChnlNbr: Number of channels to be recorded.
* @retval AUDIO_OK in case of success, AUDIO_ERROR otherwise
*/
uint8_t BSP_AUDIO_IN_Init(uint32_t AudioFreq, uint32_t BitRes, uint32_t ChnlNbr)
{

	/*Set Structure for internal state*/
	X_NUCLEO_CCA02M1_Handler.MicChannels = ChnlNbr;

	X_NUCLEO_CCA02M1_Handler.PDM_Clock_Freq = PDM_FREQ_16K; /*KHz*/
	X_NUCLEO_CCA02M1_Handler.PCM_Sampling_Freq = AudioFreq;


	X_NUCLEO_CCA02M1_Handler.DecimationFactor = (X_NUCLEO_CCA02M1_Handler.PDM_Clock_Freq * 1000) /
			X_NUCLEO_CCA02M1_Handler.PCM_Sampling_Freq;
	X_NUCLEO_CCA02M1_Handler.PdmBufferSize = (X_NUCLEO_CCA02M1_Handler.PDM_Clock_Freq / 8) * 2 * N_MS_PER_INTERRUPT;

	uint16_t PDM_SPI_Clock = X_NUCLEO_CCA02M1_Handler.PDM_Clock_Freq;

	if (X_NUCLEO_CCA02M1_Handler.MicChannels > 1)
	{
		PDM_SPI_Clock *= 2;  /*Clock to be generated is twice the PDM clock */
		/*Timer Init*/
//		if (AUDIO_IN_Timer_Init() != AUDIO_OK)
//		{
//			return AUDIO_ERROR;
//		}
	}

//	lib_PDM_Filter_Handler_Instance[0] = &PDM1_filter_handler;
//	lib_PDM_Filter_Handler_Instance[1] = &PDM2_filter_handler;
//	lib_PDM_Filter_Config_Instance[0] = &PDM1_filter_config;
//	lib_PDM_Filter_Config_Instance[1] = &PDM2_filter_config;

	return AUDIO_OK;
}

/**
* @brief  Starts audio recording.
* @param  * pbuf: Buffer that will contain 1 ms of PDM for each microphone.
Its dimension must be equal to (in uint16_t words):
((PCM sampling frequency)/1000 * DecimationFactor * Channels)/16
DecimationFactor is equal to 128 for 8000 KHZ sampling frequency, 64 in all the other cases
* @param  size: Not used in this driver.
* @retval AUDIO_OK in case of success, AUDIO_ERROR otherwise
*/
uint8_t BSP_AUDIO_IN_Record(uint16_t * pbuf, uint32_t size)
{

  X_NUCLEO_CCA02M1_Handler.PDM_Data = pbuf;

  if(X_NUCLEO_CCA02M1_Handler.MicChannels != 1)
  {
    if(AUDIO_IN_Timer_Start() != AUDIO_OK)
    {
      return AUDIO_ERROR;
    }
  }

  if(HAL_I2S_Receive_DMA(&hi2s1, I2S_InternalBuffer, X_NUCLEO_CCA02M1_Handler.PdmBufferSize / 2) != HAL_OK)
  {
    return AUDIO_ERROR;
  }
//  if(HAL_SPI_Receive_DMA(&hAudioInSpi, (uint8_t *)I2S_InternalBuffer, X_NUCLEO_CCA02M1_Handler.PdmBufferSize) != HAL_OK)
//  {
//    return AUDIO_ERROR;
//  }

  /* Return 0 if all operations are OK */
  return AUDIO_OK;
}

/**
* @brief  Stops audio recording.
* @param  None
* @retval AUDIO_OK in case of success, AUDIO_ERROR otherwise
*/
uint8_t BSP_AUDIO_IN_Stop(void)
{
	if(HAL_I2S_DMAStop(&hi2s1) != HAL_OK)
	{
		return AUDIO_ERROR;
	}
//	if(HAL_SPI_DMAStop(&hAudioInSpi) != HAL_OK)
//	{
//		return AUDIO_ERROR;
//	}
	/* Return 0 if all operations are OK */
	return AUDIO_OK;
}

/**
* @brief  Controls the audio in volume level.
* @param  Volume: Volume level to be set for the PDM to PCM conversion.
Values must be in the range from -12dB to 51dB
* @retval AUDIO_OK in case of success, AUDIO_ERROR otherwise
*/
uint8_t BSP_AUDIO_IN_SetVolume(uint8_t Volume)
{
	uint32_t index = 0;
	volatile uint32_t error = 0;

	/* Set mic_gain */

//	for(index = 0; index < X_NUCLEO_CCA02M1_Handler.MicChannels; index++)
//	{
//		if (lib_PDM_Filter_Config_Instance[index]->mic_gain != VolumeGain[Volume])
//		{
//			lib_PDM_Filter_Config_Instance[index]->mic_gain = VolumeGain[Volume];
//			error = PDM_Filter_setConfig((PDM_Filter_Handler_t *)lib_PDM_Filter_Handler_Instance[index], lib_PDM_Filter_Config_Instance[index]);
//
//			if(error!=0)
//			{
//				while(1);
//			}
//		}
//	}

	/* Return AUDIO_OK when all operations are correctly done */
	return AUDIO_OK;
}

/**
* @brief  Converts audio format from PDM to PCM.
* @param  PDMBuf: Pointer to PDM buffer data
* @param  PCMBuf: Pointer to PCM buffer data
* @retval AUDIO_OK in case of success, AUDIO_ERROR otherwise
*/

uint8_t BSP_AUDIO_IN_PDMToPCM(uint16_t *PDMBuf, uint16_t *PCMBuf)
{
	uint32_t index = 0;
	uint32_t index_ms = 0;
	uint16_t PDM_Offset = (X_NUCLEO_CCA02M1_Handler.PdmBufferSize / (2 * N_MS_PER_INTERRUPT)) * X_NUCLEO_CCA02M1_Handler.MicChannels;
	uint16_t PCM_Offset = (X_NUCLEO_CCA02M1_Handler.MicChannels * (X_NUCLEO_CCA02M1_Handler.PCM_Sampling_Freq / 1000));

//	for (index_ms = 0; index_ms < N_MS_PER_INTERRUPT; index_ms ++)
//	{
//		for(index = 0; index < X_NUCLEO_CCA02M1_Handler.MicChannels; index++)
//		{
//			PDM_Filter(&((uint8_t*)(PDMBuf))[index + index_ms * PDM_Offset], (uint16_t*)&(PCMBuf[index + index_ms * PCM_Offset]) , lib_PDM_Filter_Handler_Instance[index]);
//		}
//
//	}

	return AUDIO_OK;
}


/**
* @brief  Pauses the audio file stream.
* @param  None
* @retval AUDIO_OK in case of success, AUDIO_ERROR otherwise
*/
uint8_t BSP_AUDIO_IN_Pause(void)
{
	/* Call the Media layer pause function */
	HAL_I2S_DMAPause(&hi2s1);
//	HAL_SPI_DMAPause(&hAudioInSpi);

	/* Return AUDIO_OK when all operations are correctly done */
	return AUDIO_OK;
}

/**
* @brief  Resumes the audio file stream.
* @param  None
* @retval AUDIO_OK in case of success, AUDIO_ERROR otherwise
*/
uint8_t BSP_AUDIO_IN_Resume(void)
{
	/* Call the Media layer pause/resume function */
	HAL_I2S_DMAResume(&hi2s1);
//	HAL_SPI_DMAResume(&hAudioInSpi);

	/* Return AUDIO_OK when all operations are correctly done */
	return AUDIO_OK;
}


/**
 * @brief Rx Transfer completed callbacks. It performs demuxing of the bit-interleaved PDM streams into
byte-interleaved data suitable for PDM to PCM conversion. 1 ms of data for each microphone is
written into the buffer that the user indicates when calling the BSP_AUDIO_IN_Start(...) function.
 * @param hi2s: I2S handle
 * @retval None
 */
void HAL_I2S_RxCpltCallback(I2S_HandleTypeDef *hi2s)
{
	if (hi2s->Instance == SPI1) {
		uint32_t index = 0;

		switch(X_NUCLEO_CCA02M1_Handler.MicChannels){
		case 1:
		{
			uint16_t * DataTempI2S = &I2S_InternalBuffer[X_NUCLEO_CCA02M1_Handler.PdmBufferSize/4] ;
			for(index = 0; index < X_NUCLEO_CCA02M1_Handler.PdmBufferSize/4; index++)
			{
				X_NUCLEO_CCA02M1_Handler.PDM_Data[index] = HTONS(DataTempI2S[index]);
			}
			break;
		}

		case 2:
		{
			uint16_t * DataTempI2S = &(I2S_InternalBuffer[X_NUCLEO_CCA02M1_Handler.PdmBufferSize/2]);
			uint8_t a,b=0;
			for(index=0; index<X_NUCLEO_CCA02M1_Handler.PdmBufferSize/2; index++) {
				a = ((uint8_t *)(DataTempI2S))[(index*2)];
				b = ((uint8_t *)(DataTempI2S))[(index*2)+1];
				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)] = Channel_Demux[a & CHANNEL_DEMUX_MASK] | Channel_Demux[b & CHANNEL_DEMUX_MASK] << 4;;
				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)+1] = Channel_Demux[(a>>1) & CHANNEL_DEMUX_MASK] |Channel_Demux[(b>>1) & CHANNEL_DEMUX_MASK] << 4;
			}
			break;
		}
		default:
		{

			break;
		}

		}

		AudioApplicationProcess();
	}
}

/**
 * @brief Rx Transfer completed callbacks. It performs demuxing of the bit-interleaved PDM streams into
byte-interleaved data suitable for PDM to PCM conversion. 1 ms of data for each microphone is
written into the buffer that the user indicates when calling the BSP_AUDIO_IN_Start(...) function.
 * @param hi2s: I2S handle
 * @retval None
 */
void HAL_I2S_RxHalfCpltCallback(I2S_HandleTypeDef *hi2s)
{
	if (hi2s->Instance == SPI1) {
		uint32_t index = 0;

		switch(X_NUCLEO_CCA02M1_Handler.MicChannels){
		case 1:
		{
			uint16_t * DataTempI2S = I2S_InternalBuffer;
			for(index = 0; index < X_NUCLEO_CCA02M1_Handler.PdmBufferSize/4; index++)
			{
				X_NUCLEO_CCA02M1_Handler.PDM_Data[index] = HTONS(DataTempI2S[index]);
			}
			break;
		}
		case 2:
		{
			uint16_t * DataTempI2S = I2S_InternalBuffer;
			uint8_t a,b=0;
			for(index=0; index<X_NUCLEO_CCA02M1_Handler.PdmBufferSize/2; index++) {
				a = ((uint8_t *)(DataTempI2S))[(index*2)];
				b = ((uint8_t *)(DataTempI2S))[(index*2)+1];
				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)] = Channel_Demux[a & CHANNEL_DEMUX_MASK] |
						Channel_Demux[b & CHANNEL_DEMUX_MASK] << 4;;
				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)+1] = Channel_Demux[(a>>1) & CHANNEL_DEMUX_MASK] |
						Channel_Demux[(b>>1) & CHANNEL_DEMUX_MASK] << 4;
			}
			break;
		}
		default:
		{
			break;
		}

		}

		AudioApplicationProcess();
	}
}


///**
// * @brief Rx Transfer completed callbacks. It performs demuxing of the bit-interleaved PDM streams into
//byte-interleaved data suitable for PDM to PCM conversion. 1 ms of data for each microphone is
//written into the buffer that the user indicates when calling the BSP_AUDIO_IN_Start(...) function.
// * @param hi2s: I2S handle
// * @retval None
// */
//void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
//{
//	if (hspi->Instance == SPI1) {
//		uint32_t index = 0;
//
//		switch(X_NUCLEO_CCA02M1_Handler.MicChannels){
//		case 1:
//		{
//			uint16_t * DataTempI2S = &I2S_InternalBuffer[X_NUCLEO_CCA02M1_Handler.PdmBufferSize/4] ;
//			for(index = 0; index < X_NUCLEO_CCA02M1_Handler.PdmBufferSize/4; index++)
//			{
//				X_NUCLEO_CCA02M1_Handler.PDM_Data[index] = HTONS(DataTempI2S[index]);
//			}
//			break;
//		}
//
//		case 2:
//		{
//			uint16_t * DataTempI2S = &(I2S_InternalBuffer[X_NUCLEO_CCA02M1_Handler.PdmBufferSize/2]);
//			uint8_t a,b=0;
//			for(index=0; index<X_NUCLEO_CCA02M1_Handler.PdmBufferSize/2; index++) {
//				a = ((uint8_t *)(DataTempI2S))[(index*2)];
//				b = ((uint8_t *)(DataTempI2S))[(index*2)+1];
//				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)] = Channel_Demux[a & CHANNEL_DEMUX_MASK] | Channel_Demux[b & CHANNEL_DEMUX_MASK] << 4;;
//				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)+1] = Channel_Demux[(a>>1) & CHANNEL_DEMUX_MASK] |Channel_Demux[(b>>1) & CHANNEL_DEMUX_MASK] << 4;
//			}
//			break;
//		}
//		default:
//		{
//
//			break;
//		}
//
//		}
//
//		AudioApplicationProcess();
//	}
//}
//
///**
// * @brief Rx Transfer completed callbacks. It performs demuxing of the bit-interleaved PDM streams into
//byte-interleaved data suitable for PDM to PCM conversion. 1 ms of data for each microphone is
//written into the buffer that the user indicates when calling the BSP_AUDIO_IN_Start(...) function.
// * @param hi2s: I2S handle
// * @retval None
// */
//void HAL_SPI_RxHalfCpltCallback(SPI_HandleTypeDef *hspi)
//{
//	if (hspi->Instance == SPI1) {
//		uint32_t index = 0;
//
//		switch(X_NUCLEO_CCA02M1_Handler.MicChannels){
//		case 1:
//		{
//			uint16_t * DataTempI2S = I2S_InternalBuffer;
//			for(index = 0; index < X_NUCLEO_CCA02M1_Handler.PdmBufferSize/4; index++)
//			{
//				X_NUCLEO_CCA02M1_Handler.PDM_Data[index] = HTONS(DataTempI2S[index]);
//			}
//			break;
//		}
//		case 2:
//		{
//			uint16_t * DataTempI2S = I2S_InternalBuffer;
//			uint8_t a,b=0;
//			for(index=0; index<X_NUCLEO_CCA02M1_Handler.PdmBufferSize/2; index++) {
//				a = ((uint8_t *)(DataTempI2S))[(index*2)];
//				b = ((uint8_t *)(DataTempI2S))[(index*2)+1];
//				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)] = Channel_Demux[a & CHANNEL_DEMUX_MASK] |
//						Channel_Demux[b & CHANNEL_DEMUX_MASK] << 4;;
//				((uint8_t *)(X_NUCLEO_CCA02M1_Handler.PDM_Data))[(index*2)+1] = Channel_Demux[(a>>1) & CHANNEL_DEMUX_MASK] |
//						Channel_Demux[(b>>1) & CHANNEL_DEMUX_MASK] << 4;
//			}
//			break;
//		}
//		default:
//		{
//			break;
//		}
//
//		}
//
//		AudioApplicationProcess();
//	}
//}

/**
 * @brief Tx Transfer Half completed callbacks
 * @param  hi2s pointer to a I2S_HandleTypeDef structure that contains
 *         the configuration information for I2S module
 * @retval None
 */
void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef *hi2s)
{
	if (hi2s->Instance == SPI3) {
		timerNowI2sHz = __HAL_TIM_GET_COUNTER(&htim2);
		timeI2sHz = (float)(timerNowI2sHz - timerBeforeI2sHz)*(1/uwPrescalerValue); // time in seconds
		timerBeforeI2sHz = timerNowI2sHz;
	}
}

/**
 * @brief Tx Transfer Half completed callbacks
 * @param  hi2s pointer to a I2S_HandleTypeDef structure that contains
 *         the configuration information for I2S module
 * @retval None
 */
void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s)
{
	if (hi2s->Instance == SPI3) {
		timerNowI2sHz = __HAL_TIM_GET_COUNTER(&htim2);
		timeI2sHz = (float)(timerNowI2sHz - timerBeforeI2sHz)*(1/uwPrescalerValue); // time in seconds
		timerBeforeI2sHz = timerNowI2sHz;
	}
}

/**
* @brief  User callback when record buffer is filled.
* @param  None
* @retval None
*/
void BSP_AUDIO_IN_TransferComplete_CallBack(void)
{
	AudioApplicationProcess();
}

/**
* @brief  User callback when record buffer is half filled.
* @param  None
* @retval None
*/
void BSP_AUDIO_IN_HalfTransfer_CallBack(void)
{
	AudioApplicationProcess();
}

/**
* @brief  Audio IN Error callback function
* @param  None
* @retval None
*/
__weak void BSP_AUDIO_IN_Error_Callback(void)
{
  /* This function is called when an Interrupt due to transfer error on or peripheral
  error occurs. */
}

///**
//* @brief I2S error callbacks
//* @param hi2s: I2S handle
//* @retval None
//*/
//void HAL_I2S_ErrorCallback(I2S_HandleTypeDef *hi2s)
//{
//  /* Manage the error generated on DMA FIFO: This function
//  should be coded by user (its prototype is already declared in stm32f4_discovery_audio.h) */
//  if(hi2s->Instance == SPI2)
//  {
//    BSP_AUDIO_IN_Error_Callback();
//  }
//}

///**
//* @brief Audio Timer Init
//* @param None
//* @retval None
//*/
//static uint8_t AUDIO_IN_Timer_Init(void){
//
//	/* USER CODE BEGIN TIM3_Init 0 */
//
//	/* USER CODE END TIM3_Init 0 */
//
//	TIM_SlaveConfigTypeDef sSlaveConfig = {0};
//	TIM_MasterConfigTypeDef sMasterConfig = {0};
//	TIM_OC_InitTypeDef sConfigOC = {0};
//	TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};
//
//	/* USER CODE BEGIN TIM3_Init 1 */
//
//	/* USER CODE END TIM3_Init 1 */
//	TimDividerHandle.Instance = AUDIO_IN_TIMER;
//	TimDividerHandle.Init.Prescaler = 0;
//	TimDividerHandle.Init.CounterMode = TIM_COUNTERMODE_UP;
//	TimDividerHandle.Init.Period = 1;
//	TimDividerHandle.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
//	TimDividerHandle.Init.RepetitionCounter = 0;
//	if (HAL_TIM_Base_Init(&TimDividerHandle) != HAL_OK)
//	{
//		Error_Handler();
//	}
//	if (HAL_TIM_PWM_Init(&TimDividerHandle) != HAL_OK)
//	{
//		Error_Handler();
//	}
//	sSlaveConfig.SlaveMode = TIM_SLAVEMODE_EXTERNAL1;
//	sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
//	sSlaveConfig.TriggerPolarity = TIM_TRIGGERPOLARITY_RISING;
//	sSlaveConfig.TriggerFilter = 0;
//	if (HAL_TIM_SlaveConfigSynchronization(&TimDividerHandle, &sSlaveConfig) != HAL_OK)
//	{
//		Error_Handler();
//	}
//	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
//	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
//	if (HAL_TIMEx_MasterConfigSynchronization(&TimDividerHandle, &sMasterConfig) != HAL_OK)
//	{
//		Error_Handler();
//	}
//	sConfigOC.OCMode = TIM_OCMODE_PWM1;
//	sConfigOC.Pulse = 1;
//	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
//	sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
//	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
//	sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
//	sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
//	if (HAL_TIM_PWM_ConfigChannel(&TimDividerHandle, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
//	{
//		Error_Handler();
//	}
//	sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
//	sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
//	sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
//	sBreakDeadTimeConfig.DeadTime = 0;
//	sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
//	sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
//	sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
//	if (HAL_TIMEx_ConfigBreakDeadTime(&TimDividerHandle, &sBreakDeadTimeConfig) != HAL_OK)
//	{
//		Error_Handler();
//	}
//	/* USER CODE BEGIN TIM3_Init 2 */
//
//	/* USER CODE END TIM3_Init 2 */
//	HAL_TIM_MspPostInit(&TimDividerHandle);
//
//	return AUDIO_OK;
//}

/**
* @brief Audio Timer Start
* @param None
* @retval None
*/
static uint8_t AUDIO_IN_Timer_Start(){

	if(HAL_TIM_IC_Start(&htim1, TIM_CHANNEL_1) != HAL_OK)
	{
		return AUDIO_ERROR;
	}
	/* Start the Output Compare */
	if(HAL_TIM_OC_Start(&htim1, TIM_CHANNEL_2) != HAL_OK)
	{
		return AUDIO_ERROR;
	}
//	if(HAL_TIM_IC_Start(&TimDividerHandle, TIM_CHANNEL_1) != HAL_OK)
//	{
//		return AUDIO_ERROR;
//	}
//	/* Start the Output Compare */
//	if(HAL_TIM_OC_Start(&TimDividerHandle, TIM_CHANNEL_2) != HAL_OK)
//	{
//		return AUDIO_ERROR;
//	}

	return AUDIO_OK;
}

void AudioApplicationInit() {

	/* Enable CRC peripheral to unlock the libraries */
	__CRC_CLK_ENABLE();

//	BSP_AUDIO_IN_SetVolume(10);

	/*Initialize Interpolator*/
	arm_fir_interpolate_init_q15((arm_fir_interpolate_instance_q15 *) &InterpolatorStateCH1, INTERPOLATOR_FACTOR, INTERPOLATOR_NUM_TAPS, aCoeffs, aStateCH1, INTERPOLATOR_BLOCK_SIZE);
	arm_fir_interpolate_init_q15((arm_fir_interpolate_instance_q15 *) &InterpolatorStateCHRef, INTERPOLATOR_FACTOR, INTERPOLATOR_NUM_TAPS, aCoeffs, aStateCHRef, INTERPOLATOR_BLOCK_SIZE);

	BF_DeInit();
	BF_Init();

	SW_IRQ_Tasks_Init();
	SW_IRQ_Tasks_Enable();

	// start timer to measure processor usage
	timerBefore = 0;
	timerNow = 0;
	timeBeamforming = 0;
	timeTotal = 0;
	timeBeamforming2 = 0;
	timerBeforeAudioHz = 0;
	timerNowAudioHz = 0;
	timerBeforeI2sHz = 0;
	timerNowI2sHz = 0;

	I2sBufferWriteIdx = 0;
	OutBuffWriteIdx = 0;
	while(HAL_I2S_GetState(&hi2s2) != HAL_I2S_STATE_READY);
	HAL_I2S_Transmit_DMA(&hi2s2, (uint16_t *)I2sBuffer, I2S_BUFFER_SIZE);
}

static inline void AudioApplicationProcess() {
	// compute time in idle
	timerNow = __HAL_TIM_GET_COUNTER(&htim2);
	timeTotal += (float)(timerNow - timerBefore)*(1/uwPrescalerValue); // time in seconds
	timerBefore = timerNow;

	timerNowAudioHz = timerNow;
	timeAudioHz = (float)(timerNowAudioHz - timerBeforeAudioHz)*(1/uwPrescalerValue); // time in seconds
	timerBeforeAudioHz = timerNowAudioHz;

//	BSP_AUDIO_IN_PDMToPCM((uint16_t * )aPDMBuffer, (uint16_t *)BfInBuff); /* PDM to PCM*/

	uint32_t counterNow, counterBefore;
	counterBefore = timerNow;
	runningFirstStep = 1;
	if(AcousticBF_FirstStep(&((uint8_t *)(aPDMBuffer))[0],&((uint8_t *)(aPDMBuffer))[1], BfOutBuff, &libBeamforming_Handler_Instance))
	{
		runSecondStep = 1;
		SW_Task1_Start();  /* BF Processing Task */
	}
	runningFirstStep = 0;

//	memcpy(&I2sBuffer[I2sBufferWriteIdx], BfOutBuff, 2*BF_BUFFER_SIZE*sizeof(*BfOutBuff));
//	I2sBufferWriteIdx = (I2sBufferWriteIdx + 2*BF_BUFFER_SIZE) % I2S_BUFFER_SIZE;
//	for (int i = 0; i < BF_BUFFER_SIZE; i++) {
//		BfProcOutBuff[OutBuffWriteIdx + i] = ((int16_t *)BfOutBuff)[2*i];
//		BfRefOutBuff[OutBuffWriteIdx + i] = ((int16_t *)BfOutBuff)[2*i + 1];
//	}

	for(int i = 0; i < AUDIO_IN_SAMPLING_FREQUENCY / 1000; i++)
	{
		aUpsamplerIN[i] = BfOutBuff[2 * i];
		aUpsamplerINRef[i] = BfOutBuff[2 * i + 1];
	}
	arm_fir_interpolate_q15(&InterpolatorStateCH1, aUpsamplerIN, (int16_t *)aUpsamplerOUT, INTERPOLATOR_BLOCK_SIZE);
//	arm_fir_interpolate_q15(&InterpolatorStateCHRef, aUpsamplerINRef, (int16_t *)aUpsamplerOUTRef, INTERPOLATOR_BLOCK_SIZE);
	for (int i = 0; i < BF_BUFFER_SIZE; i++) {
//		BfUpSampleOutBuff[4 * i] = aUpsamplerOUT[2 * i];
//		BfUpSampleOutBuff[4 * i + 1] = aUpsamplerOUTRef[2 * i];
//		BfUpSampleOutBuff[4 * i + 2] = aUpsamplerOUT[2 * i + 1];
//		BfUpSampleOutBuff[4 * i + 3] = aUpsamplerOUTRef[2 * i + 1];
//		BfUpSampleOutBuff[4 * i] = aUpsamplerOUT[2 * i];
//		BfUpSampleOutBuff[4 * i + 1] = aUpsamplerOUT[2 * i];
//		BfUpSampleOutBuff[4 * i + 2] = aUpsamplerOUT[2 * i + 1];
//		BfUpSampleOutBuff[4 * i + 3] = aUpsamplerOUT[2 * i + 1];
		I2sBuffer[I2sBufferWriteIdx] = aUpsamplerOUT[2 * i];
		I2sBufferWriteIdx = (I2sBufferWriteIdx + 1) % I2S_BUFFER_SIZE;
		I2sBuffer[I2sBufferWriteIdx] = BfOutBuff[2 * i + 1];
		I2sBufferWriteIdx = (I2sBufferWriteIdx + 1) % I2S_BUFFER_SIZE;
		I2sBuffer[I2sBufferWriteIdx] = aUpsamplerOUT[2 * i + 1];
		I2sBufferWriteIdx = (I2sBufferWriteIdx + 1) % I2S_BUFFER_SIZE;
		I2sBuffer[I2sBufferWriteIdx] = BfOutBuff[2 * i + 1];
		I2sBufferWriteIdx = (I2sBufferWriteIdx + 1) % I2S_BUFFER_SIZE;
		BfProcOutBuff[OutBuffWriteIdx + i] = ((int16_t *)BfOutBuff)[2*i];
		BfRefOutBuff[OutBuffWriteIdx + i] = ((int16_t *)BfOutBuff)[2*i + 1];
	}
//	memcpy(&I2sBuffer[I2sBufferWriteIdx], BfUpSampleOutBuff, sizeof(BfUpSampleOutBuff));
//	I2sBufferWriteIdx = (I2sBufferWriteIdx + sizeof(BfUpSampleOutBuff)/sizeof(*BfUpSampleOutBuff)) % I2S_BUFFER_SIZE;
//	memcpy(&I2sBuffer[I2sBufferWriteIdx], aUpsamplerOUT, sizeof(aUpsamplerOUT));
//	I2sBufferWriteIdx = (I2sBufferWriteIdx + sizeof(aUpsamplerOUT)/sizeof(*aUpsamplerOUT)) % I2S_BUFFER_SIZE;


//	memcpy(&I2sBuffer[I2sBufferWriteIdx], BfInBuff, 2*BF_BUFFER_SIZE*sizeof(*BfInBuff));
//	I2sBufferWriteIdx = (I2sBufferWriteIdx + 2*BF_BUFFER_SIZE) % I2S_BUFFER_SIZE;
//	for (int i = 0; i < BF_BUFFER_SIZE; i++) {
//		BfProcOutBuff[OutBuffWriteIdx + i] = (BfInBuff)[2*i];
//		BfRefOutBuff[OutBuffWriteIdx + i] = (BfInBuff)[2*i + 1];
//	}
	OutBuffWriteIdx = (OutBuffWriteIdx + BF_BUFFER_SIZE) % I2S_BUFFER_SIZE;
	// compute time in processing
	counterNow = __HAL_TIM_GET_COUNTER(&htim2);
	timeBeamforming += (float)(counterNow - counterBefore)*(1/uwPrescalerValue); // time in seconds
	if (runningSecondStep == 1) {
		counterBf2Before += counterNow - counterBefore;
		counterNow = __HAL_TIM_GET_COUNTER(&htim2);
	}
}

uint32_t BF_Init(void)
{

  uint32_t error_value = 0;

  libBeamforming_Handler_Instance.algorithm_type_init=ACOUSTIC_BF_TYPE_STRONG;
//  libBeamforming_Handler_Instance.algorithm_type_init=ACOUSTIC_BF_TYPE_CARDIOID_BASIC;
//  libBeamforming_Handler_Instance.algorithm_type_init=ACOUSTIC_BF_TYPE_CARDIOID_DENOISE;
  libBeamforming_Handler_Instance.ref_mic_enable=ACOUSTIC_BF_REF_ENABLE;
  libBeamforming_Handler_Instance.ptr_out_channels=2;
  libBeamforming_Handler_Instance.data_format=ACOUSTIC_BF_DATA_FORMAT_PDM;
  libBeamforming_Handler_Instance.sampling_frequency=PDM_FREQ_16K;//1280;//2048;//SystemCoreClock/32/2/1000;//
  libBeamforming_Handler_Instance.ptr_M1_channels=2;
  libBeamforming_Handler_Instance.ptr_M2_channels=2;
  libBeamforming_Handler_Instance.delay_enable = 1;
  AcousticBF_getMemorySize(&libBeamforming_Handler_Instance);
  libBeamforming_Handler_Instance.pInternalMemory =(uint32_t *)malloc(libBeamforming_Handler_Instance.internal_memory_size);

  if(libBeamforming_Handler_Instance.pInternalMemory == NULL)
  {
    while(1); /*Error Management*/
  }

  error_value = AcousticBF_Init(&libBeamforming_Handler_Instance);

  /*Error Management*/
  if(error_value != 0)
  {
    while(1); /*Error Management*/
  }

  /*Setup Beamforming dynamic parameters*/
  lib_Beamforming_Config_Instance.algorithm_type = libBeamforming_Handler_Instance.algorithm_type_init;
//  lib_Beamforming_Config_Instance.algorithm_type = ACOUSTIC_BF_TYPE_CARDIOID_BASIC;
  lib_Beamforming_Config_Instance.M2_gain = 0;
  lib_Beamforming_Config_Instance.mic_distance = MIC_DISTANCE;
  lib_Beamforming_Config_Instance.volume = 24;
  error_value = AcousticBF_setConfig(&libBeamforming_Handler_Instance, &lib_Beamforming_Config_Instance);

  if(error_value != 0){
    while(1);    /*Error Management*/
  }

  return error_value;

}

void BF_DeInit(void)
{
  if(libBeamforming_Handler_Instance.pInternalMemory != NULL)
  {
    free(libBeamforming_Handler_Instance.pInternalMemory);
    libBeamforming_Handler_Instance.pInternalMemory = NULL;
  }
}

void SW_IRQ_Tasks_Init(void){

	HAL_NVIC_SetPriority((IRQn_Type)EXTI1_IRQn, 0x0c, 0x0c);
//	NVIC_SetPriority(EXTI1_IRQn, NVIC_EncodePriority(0,0x0c,0x0c));
	HAL_NVIC_EnableIRQ((IRQn_Type)EXTI1_IRQn);

}

void SW_IRQ_Tasks_Enable(void)
{
	HAL_NVIC_EnableIRQ((IRQn_Type)EXTI1_IRQn);
}

void SW_IRQ_Tasks_Disable(void){

	HAL_NVIC_DisableIRQ((IRQn_Type)EXTI1_IRQn);

}

void SW_Task1_Callback(void)
{
	if (runSecondStep == 1) {
		runSecondStep = 0;
		// compute time in idle
		counterBf2Before = __HAL_TIM_GET_COUNTER(&htim2);
		runningSecondStep = 1;
		AcousticBF_SecondStep(&libBeamforming_Handler_Instance);
		runningSecondStep = 0;
		// compute time in processing
		counterBf2Now = __HAL_TIM_GET_COUNTER(&htim2);
		timeBeamforming2 += (float)(counterBf2Now - counterBf2Before)*(1/uwPrescalerValue); // time in seconds

		if (HAL_NVIC_GetPendingIRQ(DMA2_Stream0_IRQn)) {
			runSecondStep = 0;
			runningSecondStep = 0;
			counterBf2Before = __HAL_TIM_GET_COUNTER(&htim2);
		}
	}
}

void SW_Task1_Start(void)
{
	HAL_NVIC_SetPendingIRQ(EXTI1_IRQn);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
