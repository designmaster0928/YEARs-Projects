PCB part number:			PCB-00014-1
Revision:				0
No. of Layers:				4 layer
Insulator Material:			standard FR-4 for all insulator layers
Finished thickness:			0.8mm
Overall dimensions:			46.5x29.2mm
Soldermask: 				Green or don't care
Silkscreen:				White or don't care
Contact finish: 			ENIG
Conductor Weight:			1oz copper on all layers
Minimum copper-copper clearance:	0.125mm
Minimum track width: 			0.125mm
Drill tolerance:			+/- 0.1 mm where not specified
Via types:
	- Drilled:			0.2 finished hole size
	- Drilled:			0.15 finished hole size
	- Via in Pad: 			Components U1 and U2 have vias in pad. They should be plugged with non-conductive material.



Other notes
1. Vias are intentionally tented with solder mask.

2. Any unspecified drill tolerance may be considered as +/-0.1mm.

3. CM may modify solder mask or paste mask layers with design engineering approval to maximize ease of assembly and minimize cost.

4. Any hard corners on the board outline may be rounded, with a suggested radius of 0.5 to 1 mm.

5. Slots from component J1 are all plated. These slots are represented in NC Route file.


Gerber Legend:
PCB-00014-1_Rev0_1-4.rou		- NC route layer 1-4
PCB-00014-1_Rev0-1-4.drl		- NC drill layer 1-4
PCB-00014-1-BOARDOUTLINE_Rev0.art	- Board outline
PCB-00014-1-TOP_Rev0.art		- Copper on top side of board
PCB-00014-1-POWER_Rev0.art		- Copper on inner layer 1
PCB-00014-1-GND_Rev0.art		- Copper on inner layer 2
PCB-00014-1-BOTTOM_Rev0.art		- Copper on bottom side of board
PCB-00014-1-PASTETOP_Rev0.art		- Top side paste mask
PCB-00014-1-PASTEBOTTOM_Rev0.art	- Bottom side paste mask
PCB-00014-1-SILKTOP_Rev0.art		- Silkscreen on top side
PCB-00014-1-SILKBOTTOM_Rev0.art		- Silkscreen on bottom side
PCB-00014-1-SOLDERMASKBOT_Rev0.art	- Soldermask on bottom side
PCB-00014-1-SOLDERMASKTOP_Rev0.art	- Soldermask on top side

Other files:
PCB-00014-1_Rev0_place.txt		- Pick and place file, referenced to symbol origin
PCB-00014-1_Rev0_BOM.xlsx		- Bill of materials
PCB-00014-1_Rev0_fabdwg.pdf		- PCB fabrication detail
pcb-00014-1_rev0_odb.tgz		- compressed ODB++ file