
#include "main.h"
//#include "mcp4161.h"


#int_AD
void  AD_isr(void) 
{

	//value = read_adc(ADC_READ_ONLY);

}

