 
#include <main.h>
#include <MCP4161.c>
#include <flex_lcd.c>

#define ADCCONST 5.0/256	
float value;
unsigned int8 ready;

	
#int_AD
void AD_isr()
{	
	set_adc_channel(0);
	DELAY_US(10);
	value = Read_ADC(ADC_READ_ONLY)*ADCCONST;		
   	ready=1;
}


void main()
{	
	set_tris_a(0b00000001);
	set_tris_b(0b00000000);
	set_tris_c(0b00000000);

	output_b(0x00);
	output_c(0x00);

	setup_adc_ports(sAN0|VSS_VDD);
    setup_adc(ADC_CLOCK_DIV_32);  
   
    setup_wdt(WDT_OFF);
    setup_timer_0(RTCC_INTERNAL);
    setup_timer_1(T1_DISABLED);
    setup_timer_2(T2_DISABLED,0,1);
    setup_ccp1(CCP_OFF);
    setup_comparator(NC_NC_NC_NC);
	
	setup_spi(SPI_MASTER|SPI_L_TO_H|SPI_CLK_DIV_16);

	enable_interrupts(INT_AD);
	enable_interrupts(GLOBAL);

	lcd_init();
	delay_ms(100);
	lcd_gotoxy(3, 1);                 // Go to column 3 row 1
  	lcd_putc("ADC reading:");
  
	MCP4161_init();
	delay_ms(50);
	
	setTap(10);
	
	Read_ADC(ADC_START_ONLY);

    while(true) 
    {
        if(ready==1)
   		{
			lcd_gotoxy(7, 2);
			printf(LCD_PUTC,"%4.2f",value);
		}

		Read_ADC(ADC_START_ONLY);

		
		//output_high(PIN_C5);
		//delay_ms(1000);
		//output_low(PIN_C5);
		//delay_ms(1000);       
    }
} 