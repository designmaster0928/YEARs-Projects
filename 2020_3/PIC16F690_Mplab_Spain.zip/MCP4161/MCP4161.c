
#define MCP4161_MIN 0
#define MCP4161_MAX 256

// Definicion SPI
#DEFINE  CS    PIN_C6				// Pin SPI CS
#DEFINE  SCK   PIN_B6				// Pin SPI SCK
#DEFINE  SDO   PIN_C7				// Pin SPI SCK

void enable() {
	// take the SS pin low to select the chip:
	output_low(CS);
}

void disable() {
	// take the SS pin high to de-select the chip:
	output_high(CS);
}

void MCP4161_init()
{
	disable();
}


void increment() {
	enable();
	
	//  send in the address and value via SPI:
	spi_write(0x04);

	disable();	
}

void decrement() {
	enable();
	
	//  send in the address and value via SPI:
	spi_write(0x08);
	
	disable();
	
}

void initTCON() {
	enable();
	
	//  send in the address and value via SPI:
	spi_write(0x41);
	spi_write(0x0F);
	
	disable();

}

void setTap(int value) {
	enable();

	//  send in the address and value via SPI:
	byte h = 0x03 & (value >> 8);
	byte l = 0x00FF & value;
	
	spi_write(h);
	spi_write(l);

	disable();	
}

