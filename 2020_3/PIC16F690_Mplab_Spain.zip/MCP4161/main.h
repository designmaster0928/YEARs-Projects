#include <16F690.h>
#device adc=8

#FUSES NOWDT                    //No Watch Dog Timer
//#FUSES WDT                        //Watch Dog Timer
//#FUSES INTRC_IO                 //Internal RC Osc, no CLKOUT
#FUSES HS                       // High Speed (Oscilador externo)
#FUSES PROTECT                  //Code protected from reads
#FUSES BROWNOUT               //No brownout reset
#FUSES MCLR                     //Master Clear pin enabled
#FUSES NOCPD                    //No EE protection
#FUSES NOPUT                    //No Power Up Timer
#FUSES NOIESO                   //Internal External Switch Over mode disabled
#FUSES NOFCMEN                  //Fail-safe clock monitor disabled

#use delay(clock=8000000)
//#use rs232(stream=out,baud=9600,parity=E,xmit=PIN_B7,rcv=PIN_B5,bits=8,STOP=1)
#use rs232(baud=115200,parity=N,xmit=PIN_B7,rcv=PIN_B5,bits=8,STOP=1)

// Ponemos todos los contadores de la EEPROM a cero
#rom 0x2100 = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}

// Definicion entradas (interrupcion y AD)
#DEFINE  INT   PIN_A2				// Pin de interrupcion
#DEFINE  ADC   PIN_A0				// Pin de conversion AD

// Define declarations
//#DEFINE  SETL1   PIN_B6				// Encendido y apagado del LED

// Definicion de las salidas
#DEFINE S1 PIN_C1
#DEFINE S2 PIN_C2


#DEFINE CR 0x0d      // ASCII Value for a Carriage Return 


