/****************************************************************************************
 * FileName   :	app_lcd_i2c.h
 * Created on : Jan 29, 2020
 * Description: the header file to use LCD using I2C module.
*****************************************************************************************/
#ifndef APP_LCD_I2C_H_
#define APP_LCD_I2C_H_

/*************************************** libraries **************************************/


/********************************* common header files **********************************/


/******************************** module configurations *********************************/
#define ADAFRUIT_SLAVE_ADDRESS_1    0
#define ADAFRUIT_SLAVE_ADDRESS_2    1
#define ADAFRUIT_SLAVE_ADDRESS_3    2
#define ADAFRUIT_SLAVE_ADDRESS_4    3
#define ADAFRUIT_SLAVE_ADDRESS_5    4
#define ADAFRUIT_SLAVE_ADDRESS_6    5
#define ADAFRUIT_SLAVE_ADDRESS_7    6
#define ADAFRUIT_SLAVE_ADDRESS_8    7

// #define ADA_LCD
#define ESP_LCD

/******************************** function-like macros **********************************/


/****************************** structures, unions, enums *******************************/


/****************************** module classes prototypes *******************************/


/********************************* function prototypes **********************************/
void LCD_init(uint8_t num_of_cols, uint8_t num_of_raws);
void LCD_print_page(const char *raw_1 = "", const char *raw_2 = "",
                    const char *raw_3 = "", const char *raw_4 = "");
void LCD_print_at(char *data, uint8_t row, uint8_t col);
void LCD_clear();
void LCD_blink_at(uint8_t row, uint8_t col);
void LCD_blink_off();
void LCD_blink_on();
void LCD_char_at(uint8_t data, uint8_t row, uint8_t col);

/******************************* extern global variables ********************************/
extern char int_to_ascii_buffer[21];

/****************************** extern global class objects *****************************/


#endif /* APP_LCD_I2C_H_ */
