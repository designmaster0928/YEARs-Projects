#include "app_credintials.h"
#include "app_eeprom.h"
#include <EEPROM.h>

uint16_t addr = 0;
uint16_t flag_addr = 500;
uint16_t dose_addr = 505;
uint8_t initial_data = 0;

/**
 * Function to save adjustable parameters to the eeprom.
 */
void save_to_eeprom()
{
    // commit 512 bytes of ESP flash (for "EEPROM" emulation)
    // this step actually loads the content (512 bytes) of flash into
    // a 512-byte-array cache in RAM
    EEPROM.begin(512);

    // no changes made to flash.
    EEPROM.put(addr, parameters);

    // written to flash
    EEPROM.commit();
    DEBUG_PRINTLN("---------- Save data to EEPROM ----------");
}

/**
 * Function to read adjustable parameters from the eeprom.
 */
void read_from_eeprom()
{
    // commit 512 bytes of ESP8266 flash (for "EEPROM" emulation)
    // this step actually loads the content (512 bytes) of flash into
    // a 512-byte-array cache in RAM
    EEPROM.begin(512);

    // read bytes from "EEPROM"),
    // cast bytes into structure called parameters
    EEPROM.get(addr, parameters);
//    Serial.print("read from eeprom");
//    Serial.print(parameters.parameters.saved_password);
    DEBUG_PRINTLN("---------- Read data from EEPROM ----------");
}

/**
* function to save a flag if it's the first time to use the EEPROM.
*/
void save_falg()
{
    EEPROM.begin(512);
    EEPROM.put(flag_addr, initial_data);
    EEPROM.commit();
    DEBUG_PRINTLN("---------- Save the flag to EEPROM ----------");
}

/**
* function to read the value of the flag to know if it's the first time 
* to use the EEPROM or not.
* @param return the saved value of the flag.
*/
uint8_t read_flag()
{
    EEPROM.begin(512);
    EEPROM.get(flag_addr, initial_data);
    DEBUG_PRINTLN("---------- Read the flag from EEPROM ----------");
    return initial_data;
}

/**
* function to save number of the dose counts.
*/
void save_dose_counts()
{
    EEPROM.begin(512);
    EEPROM.put(dose_addr, dose_counter);
    delay(1);
    EEPROM.commit();
}

/**
* function to read the number of the dose counts.
*/
void read_dose_counts()
{
    EEPROM.begin(512);
    EEPROM.get(dose_addr, dose_counter);
}
