/****************************************************************************************
 * FileName   :	app_control_panel.cpp
 * Created on : Feb 12, 2020
 * Description: the source file for the functions that will control the LCD pages.
*****************************************************************************************/

/*************************************** includes ***************************************/
#include "app_credintials.h"
#include "app_lcd_i2c.h"
#include "app_control_panel.h"
#include "app_eeprom.h"

/*********************************** global variables ***********************************/
unsigned long timer = 0;        /* used to make delays */
/* buffer to get the passwords that user will enter on LCD */
char password_buffer[9] = "00000000";
/* to check if the user entered the correct password or not */
bool incorrect_password = false;
/* to save the digit number that the user will change */
uint8_t password_digit_num = 0;
uint8_t digit = 0;
/* flag to declare if the curser is in a sub-choice or not */
bool change_value = 0;
/* variable to know which page is displayed on the LCD */
uint8_t currentPage;
/* variables to save the current location of the arrow in each page */
uint8_t menu_choice = ChangePassword;
uint8_t dose_choice = Volume;
uint8_t warning_choice = CycleWarningSet;
uint8_t pumps_choice = Pump1;
uint8_t mode_choice = Auto;
uint8_t set_default_choice = Yes;
uint8_t confirm_save_choice = Yes;
/* variable to know the current mode of the steppers */
uint8_t currentMode = Auto;
bool manual_dose = false;

/****************************** module classes definitions ******************************/


/********************************* global class objects *********************************/


/***************************************** ISR ******************************************/


/****************************** static function prototypes ******************************/


/*********************************** callback functions *********************************/


/********************************* function definitions *********************************/
/**
* function to print a full page on the LCD.
* @param pageNum number of the page to be displayed.
*/
void go_to_page(uint8_t pageNum)
{
    LCD_blink_off();
    switch (pageNum)
    {
        case ON_POWER_PAGE:
            LCD_print_page(on_power_page_r1, on_power_page_r2, on_power_page_r3, on_power_page_r4);
            LCD_print_at((char*)firmware_version, 3, 12);
            timer = millis();
            currentPage = ON_POWER_PAGE;
            break;

        case ON_MAIN_PAGE:
            read_status();
            break;

        case ON_PASS_PAGE:
            LCD_print_page(password_page_r1, password_page_r2, password_page_r3, password_page_r4);
            enter_password(2, 6);
            currentPage = ON_PASS_PAGE;
            break;

        case ON_MENU_PAGE:
            LCD_print_page(menu_page_r1, menu_page_r2, menu_page_r3, menu_page_r4);
            currentPage = ON_MENU_PAGE;
            menu_choice = ChangePassword;
            break;

        case ON_NEW_PASS_PAGE:
            LCD_print_page(change_pass_page_r1, change_pass_page_r2, change_pass_page_r3, change_pass_page_r4);
            enter_password(1, 7);
            currentPage = ON_NEW_PASS_PAGE;
            break;

        case ON_RIGHT_PASS_PAGE:
            LCD_print_page(pass_changed_page_r1, pass_changed_page_r2, pass_changed_page_r3, pass_changed_page_r4);
            timer = millis();
            currentPage = ON_RIGHT_PASS_PAGE;
            break;

        case ON_WRONG_PASS_PAGE:
            LCD_print_page(not_match_pass_page_r1, not_match_pass_page_r2, not_match_pass_page_r3, not_match_pass_page_r4);
            timer = millis();
            currentPage = ON_WRONG_PASS_PAGE;
            break;

        case ON_DOSE_PAGE:
            LCD_print_page(dose_page_r1, dose_page_r2, dose_page_r3, dose_page_r4);
            display_values(lcd_dose_values, 14);
            currentPage = ON_DOSE_PAGE;
            break;

        case ON_WARNING_PAGE:
            LCD_print_page(warning_page_r1, warning_page_r2, warning_page_r3, warning_page_r4);
            display_values(lcd_warning_values,14);
            currentPage = ON_WARNING_PAGE;
            break;

        case ON_PUMPS_PAGE:
            LCD_print_page(pumps_page_r1, pumps_page_r2, pumps_page_r3, pumps_page_r4);
            display_values(lcd_pumps_values, 16);
            for (int i = 0 ; i < 4 ; i++)
            {
                if (strcmp(lcd_pumps_values[i], "0000"))
                {
                    parameters.pump_enable[i] = 1;
                    LCD_print_at("1", i, 9);
                }
                else
                {
                    parameters.pump_enable[i] = 0;
                    LCD_print_at("0", i, 9);
                }
                // strcmp(lcd_pumps_values[i], "0000") ? LCD_print_at("1", i, 9) :
                //                                       LCD_print_at("0", i, 9);
            }
            currentPage = ON_PUMPS_PAGE;
            break;

        case ON_MODE_SELECT_PAGE:
            LCD_print_page(mode_page_r1, mode_page_r2, mode_page_r3, mode_page_r4);
            LCD_char_at('>', 0, 0);
            currentPage = ON_MODE_SELECT_PAGE;
            break;

        case ON_MODE_SET_PAGE:
            LCD_print_page(mode_set_page_r1, mode_set_page_r2, mode_set_page_r3, mode_set_page_r4);
            if (mode_choice == Auto)
            {
                currentMode = Auto;
                manual_dose = true;
                LCD_print_at("Automatic", 2, 6);
            }
            else if (mode_choice == Manual)
            {
                currentMode = Manual;
                LCD_print_at("Manual", 2, 7);
            }
            else if (mode_choice == Off)
            {
                currentMode = Off;
                manual_dose = true;
                LCD_print_at("Off", 2, 9);
            }
            currentPage = ON_MODE_SET_PAGE;
            break;

        case ON_CONFIRM_DEFAULT_PAGE:
            LCD_print_page(confirm_default_page_r1, confirm_default_page_r2,
                           confirm_default_page_r3, confirm_default_page_r4);
            currentPage = ON_CONFIRM_DEFAULT_PAGE;
            break;

        case ON_DEFAULT_PAGE:
            LCD_print_page(default_set_page_r1, default_set_page_r2, default_set_page_r3, default_set_page_r4);
            currentPage = ON_DEFAULT_PAGE;
            break;

        case ON_CONFIRM_SAVE_PAGE:
            LCD_print_page(confirm_save_page_r1, confirm_save_page_r2, confirm_save_page_r3, confirm_save_page_r4);
            currentPage = ON_CONFIRM_SAVE_PAGE;
            break;

        case ON_CHANGES_SAVED_PAGE:
            LCD_print_page(changes_saved_page_r1, changes_saved_page_r2, changes_saved_page_r3, changes_saved_page_r4);
            currentPage = ON_CHANGES_SAVED_PAGE;
            break;

        default:
            break;
    }
}

/*======================================================================================*/
/**
* function to print all values of the page on the LCD.
* @param buffer to save the converted values in strings.
* @param col the index to start displaying values in it.
*/
void display_values(char buffer[][10], uint8_t col)
{
    for (int i = 0 ; i < 4 ; i++)
    {
        LCD_print_at(buffer[i], i, col);
    }

    DEBUG_PRINTLN("ALL VALUES");
    DEBUG_PRINTLNDEC(parameters.dose_volume);
    DEBUG_PRINTLNDEC(parameters.dose_speed);
    DEBUG_PRINTLNDEC(parameters.trigger_delay_time);
    DEBUG_PRINTLNDEC(parameters.prime_run_speed);
    DEBUG_PRINTLNDEC(parameters.cycle_warning_set);
    DEBUG_PRINTLNDEC(parameters.cycle_warning_mul);
    DEBUG_PRINTLNDEC(parameters.level_warning[0]);
    DEBUG_PRINTLNDEC(parameters.level_warning[1]);
    DEBUG_PRINTLNDEC(parameters.pump_cal[0]);
    DEBUG_PRINTLNDEC(parameters.pump_cal[1]);
    DEBUG_PRINTLNDEC(parameters.pump_cal[2]);
    DEBUG_PRINTLNDEC(parameters.pump_cal[3]);
    DEBUG_PRINTLNDEC(parameters.pump_enable[0]);
    DEBUG_PRINTLNDEC(parameters.pump_enable[1]);
    DEBUG_PRINTLNDEC(parameters.pump_enable[2]);
    DEBUG_PRINTLNDEC(parameters.pump_enable[3]);
}

/*======================================================================================*/
/**
* function to save the new values that the user entered.
*/
void save_entered_values()
{
    string_to_number(lcd_dose_values, &parameters.dose_volume, &parameters.dose_speed,
                     &parameters.trigger_delay_time, &parameters.prime_run_speed);

    string_to_number(lcd_warning_values, &parameters.cycle_warning_set,
                     &parameters.cycle_warning_mul, &parameters.level_warning[0],
                     &parameters.level_warning[1]);

    string_to_number(lcd_pumps_values, &parameters.pump_cal[0], &parameters.pump_cal[1],
                     &parameters.pump_cal[2], &parameters.pump_cal[3]);
}

/*======================================================================================*/
/**
* function to go from page to another after a delay.
* @param current_page the page that is displayed on the LCD.
* @param next_page the page to be displayed on the LCD after the delay.
* @param delay time to delay and display the next page.
*/
void delay_for_page(uint8_t current_page, uint8_t next_page, unsigned long delay)
{
    if (currentPage == current_page && (millis() - timer >= delay))
    {
        go_to_page(next_page);
    }
}

/*======================================================================================*/
/**
* function to display the status of the application.
*/
void read_status()
{
    number_to_string(lcd_status_1_values, dose_counter, product_level,
                     external_trigger_flag, 0, number_of_status_1_digits);

    // number_to_string(lcd_status_2_values, external_trigger_flag, healthy_flag,
    //                  fault_flag, cycle_warning_flag, number_of_status_2_digits);

    LCD_print_page(main_page_r1, main_page_r2, main_page_r3, main_page_r4);

    // display_values(lcd_status_1_values, 4);
    // display_values(lcd_status_2_values, 18);

    LCD_print_at(lcd_status_1_values[0], 0, 10);
    LCD_print_at(lcd_status_1_values[1], 1, 15);
    // LCD_print_at(lcd_status_1_values[2], 2, 19);

    if (external_trigger_flag == 0xFF)
    {
        LCD_char_at(0xFF, 2, 19);
        // LCD_char_at(external_trigger_flag, 0, 18);
        // LCD_print_at(" L", 0, 19);
    }
    else
    {
        LCD_print_at(lcd_status_1_values[2], 2, 19);
    }

    if (currentMode == Auto)
    {
        LCD_print_at("Auto", 2, 6);
    }
    else if (currentMode == Manual)
    {
        LCD_print_at("Manual", 2, 6);
    }
    if (currentMode == Off)
    {
        LCD_print_at("Off", 2, 6);
    }

    currentPage = ON_MAIN_PAGE;
}

/*======================================================================================*/
/**
* function to ask user to start entering a password.
* @param first_digit_row the row where to display the first digit of the password.
* @param first_digit_col the column where to display the first digit of the password.
*/
void enter_password(uint8_t first_digit_row, uint8_t first_digit_col)
{
    DEBUG_PRINTLN("----------> in enter_password function");
    snprintf(password_buffer, sizeof(password_buffer), "00000000");
    DEBUG_PRINTLN(password_buffer);

    password_digit_num = 1;     /* start entering the password from the first digit */

    LCD_blink_at(first_digit_row, first_digit_col);
}

/*======================================================================================*/
/**
* function to check if the passwords are matching or not and display the result on the LCD.
* @param first_pass , @param second_pass
* passwords to be checked for matching.
* @param size of the 2 passwords.
* @param right_pass_page the page that will be displayed if the passwords are matched.
* @param wrong_pass_page the page that will be displayed if the passwords are not matched.
* @return passwords are matched or not.
*/
bool go_to_check_password(char* first_pass, char* second_pass, uint8_t size,
                          uint8_t right_pass_page, uint8_t wrong_pass_page)
{
    LCD_blink_off();

    if (check_password(first_pass, second_pass, size))
    {
        if (right_pass_page != NO_PAGE)
        {
            go_to_page(right_pass_page);
            timer = millis();
        }
        return true;
    }
    else
    {
        if (wrong_pass_page != NO_PAGE)
        {
            go_to_page(wrong_pass_page);
            timer = millis();
        }
        return false;
    }
}

/*======================================================================================*/
/**
* function to go to the next up or down choice on the LCD.
* @param current_choice to be incremented or decremented.
* @param min_choice the minimum choice that can be reached.
* @param max_choice the maximum choice that can be reached.
* @param operation 1 for moving down and -1 for moving up.
* @param next_arrow_row the new row to display the arrow in it.
* @param next_arrow_col the new column to display the arrow in it.
* @param next_space_row the row to clear the arrow from it.
* @param next_space_col the column to clear the arrow from it.
* @param next_page the page that will be displayed if the choices reached its minimum
*                  or macximum.
* @return the updated choice.
*/
uint8_t go_to_next_choice(uint8_t current_choice, uint8_t min_choice, uint8_t max_choice,
                          int8_t operation,
                          uint8_t next_arrow_row, uint8_t next_arrow_col,
                          uint8_t next_space_row, uint8_t next_space_col,
                          uint8_t next_page,
                          uint8_t next_page_choice_row, uint8_t next_page_choice_col)
{
    if ((operation == UP && (current_choice > min_choice)) ||
        (operation == DOWN && (current_choice < max_choice)))
    {
        current_choice += operation;
        LCD_print_at(" ", next_space_row, next_space_col);
        LCD_print_at(">", next_arrow_row, next_arrow_col);
    }
    else if (next_page != NO_PAGE && current_choice == min_choice)
    {
        go_to_page(next_page);
        LCD_print_at(">", next_page_choice_row, next_page_choice_col);
    }
    else if (next_page != NO_PAGE && current_choice == max_choice)
    {
        go_to_page(next_page);
        LCD_print_at(">", next_page_choice_row, next_page_choice_col);
    }
    return current_choice;
}

/*======================================================================================*/
/**
* function to get into the sub-choice.
* @param value the value that will appear at the first digit of the sub-choice.
* @param digit_number pointer to the digit number of the current value of the sub-choice.
* @param next_digit_row , @param next_digit_col
* where the curser will move for the next digit.
* @param arrow_row , @param arrow_col
* where the arrow for current choice is diplayed.
*/
void enter_sub_choice(uint8_t value,
                      uint8_t* digit_number,
                      uint8_t next_digit_row, uint8_t next_digit_col,
                      uint8_t arrow_row, uint8_t arrow_col)
{
    LCD_print_at("~", arrow_row, arrow_col);
    go_to_next_digit(value, digit_number, next_digit_row, next_digit_col);
}

/*======================================================================================*/
/**
* function to get out from the sub-choice to its main choice.
* @param digit_number pointer to the digit number of the current value of the sub-choice.
* @param arrow_row , @param arrow_col
* where the arrow for current choice is diplayed.
*/
void back_to_main_choice(uint8_t* digit_number, uint8_t arrow_row, uint8_t arrow_col)
{
    (*digit_number) = 0;
    LCD_blink_off();
    LCD_print_at(">", arrow_row, arrow_col);
}

/*======================================================================================*/
/**
* function to go to the next step which will be either move to next digit, enter 
* sub-choice or get out to the main choice and save the enterd values.
* @param value the value that will appear at the next digit of the sub-choice.
* @param digit_number pointer to the digit number of the current value of the sub-choice.
* @param number_of_digits of the current value.
* @param next_digit_row , @param next_digit_col
* where the curser will move for the next digit.
* @param arrow_row , @param arrow_col
* where the arrow for current choice is diplayed.
*/
void next_move(uint8_t value,
               uint8_t* digit_number, uint8_t number_of_digits,
               uint8_t next_digit_row, uint8_t next_digit_col,
               uint8_t arrow_row, uint8_t arrow_col)
{
    if (change_value)
    {
        if (*digit_number < number_of_digits)
        {
            go_to_next_digit(value, digit_number, next_digit_row, next_digit_col);
        }
        else
        {
            back_to_main_choice(digit_number, arrow_row, arrow_col);
            change_value = false;
            check_number_validity(arrow_row);
        }
    }
    else
    {
        enter_sub_choice(value, digit_number, next_digit_row, next_digit_col,
                                        arrow_row, arrow_col);
        change_value = true;
    }
}

/*======================================================================================*/
/**
* function to move to the next digit on the LCD.
* @param value to be displayed.
* @param digitNumber pointer to the digit number to be incremented.
* @param next_row where the updated digit will be displayed.
* @param next_col where the updated digit will be displayed.
*/
void go_to_next_digit(uint8_t value, uint8_t* digitNumber,
                      uint8_t next_row, uint8_t next_col)
{
    char number[2] = "";
    number[0] = value;

    LCD_print_at(number, next_row, next_col);
    LCD_blink_at(next_row, next_col);

    (*digitNumber)++;
}

/*======================================================================================*/
/**
* function to increment or decrement a digit on the LCD.
* @param value to be incremented or decremented.
* @param row , @param col
* where the updated digit will be displayed.
* @param operation 1 for addition and -1 for subtraction.
* @return the updated value.
*/
uint8_t update_digit(uint8_t value, uint8_t row, uint8_t col, int8_t operation)
{
    char number[2] = "";
    number[0] = value;

    /* check the number to be from 0 to 9 */
    if (((operation == 1) && (number[0] < '9') && (number[0] >= '0')) ||
        ((operation == -1) && (number[0] > '0') && (number[0] <= '9')))
    {
        number[0] += operation;
    }
    LCD_print_at(number, row, col);
    LCD_blink_at(row, col);
    return number[0];
}

/*======================================================================================*/
/**
* fuction to check the minimum and maximum allowed values for that entered from the user.
* @param choice the current choice the the user changed its value.
*/
void check_number_validity(uint8_t choice)
{
    if (currentPage == ON_DOSE_PAGE)
    {
        if (strcmp(lcd_dose_values[choice], lcd_dose_max[choice]) > 0)
        {
            sprintf(lcd_dose_values[choice], lcd_dose_max[choice]);
            LCD_print_at(lcd_dose_values[choice], choice, 14);
        }
        else if (strcmp(lcd_dose_values[choice], lcd_dose_min[choice]) < 0)
        {
            sprintf(lcd_dose_values[choice], lcd_dose_min[choice]);
            LCD_print_at(lcd_dose_values[choice], choice, 14);
        }
    }
    else if (currentPage == ON_WARNING_PAGE)
    {
        if (strcmp(lcd_warning_values[choice], lcd_warning_max[choice]) > 0)
        {
            sprintf(lcd_warning_values[choice], lcd_warning_max[choice]);
            LCD_print_at(lcd_warning_values[choice], choice, 14);
        }
        else if (strcmp(lcd_warning_values[choice], lcd_warning_min[choice]) < 0)
        {
            sprintf(lcd_warning_values[choice], lcd_warning_min[choice]);
            LCD_print_at(lcd_warning_values[choice], choice, 14);
        }
    }
    else if (currentPage == ON_PUMPS_PAGE)
    {
        if (strcmp(lcd_pumps_values[choice], lcd_pumps_max[choice]) > 0)
        {
            sprintf(lcd_pumps_values[choice], lcd_pumps_max[choice]);
            LCD_print_at(lcd_pumps_values[choice], choice, 16);
        }
        else if (strcmp(lcd_pumps_values[choice], lcd_pumps_min[choice]) < 0)
        {
            sprintf(lcd_pumps_values[choice], lcd_pumps_min[choice]);
            LCD_print_at(lcd_pumps_values[choice], choice, 16);
        }
    }
}

/*======================================================================================*/
/**
* function to handle the event coming from the menu button.
*/
void handle_menu_event()
{
    /* switch for all possible states */
    switch (currentPage)
    {
        case ON_MAIN_PAGE:
            go_to_page(ON_PASS_PAGE);
            break;

        case ON_PASS_PAGE:
        case ON_MENU_PAGE:
            go_to_page(ON_MAIN_PAGE);
            break;

        case ON_DOSE_PAGE:
        case ON_WARNING_PAGE:
        case ON_PUMPS_PAGE:
        case ON_MODE_SELECT_PAGE:
            digit = 0;
            change_value = 0;
            go_to_page(ON_CONFIRM_SAVE_PAGE);
            confirm_save_choice = Yes;
            break;

        case ON_NEW_PASS_PAGE:
            go_to_page(ON_MENU_PAGE);
            break;

        default:
            break;
    }
}

/*======================================================================================*/
/**
* function to handle the interrupt from the up and down buttons.
* @param operation to move up are down (or increment or decrement).
* @param page1 , @param page2 , @param page3 , @param page4
* the next page that will be displayed after current page reaches its
* minimum or maximum choice.
* @param arrow_row the row where the arrow will be displayed in the second page.
* @param confirm_arrow_col the column where the arrow will be displayed on confirm
* default and save changes pages.
*/
void handle_up_down_event(int8_t operation,
                          uint8_t page1, uint8_t page2, uint8_t page3, uint8_t page4,
                          uint8_t arrow_row,
                          uint8_t confirm_arrow_col)
{
    switch (currentPage)
    {
        case ON_PASS_PAGE:
            password_buffer[password_digit_num-1] = update_digit(password_buffer[password_digit_num-1], 
                                                                 2, password_digit_num+5, operation*-1);
            DEBUG_PRINTLN(password_buffer);
            break;
        case ON_NEW_PASS_PAGE:
            if (password_digit_num <= 4)
            {
            password_buffer[password_digit_num-1] = update_digit(password_buffer[password_digit_num-1], 
                                                                 1, password_digit_num+6, operation*-1);
            }
            else
            {
            password_buffer[password_digit_num-1] = update_digit(password_buffer[password_digit_num-1], 
                                                                 3, password_digit_num+2, operation*-1);
            }
            DEBUG_PRINTLN(password_buffer);
            break;

        case ON_MENU_PAGE:
            menu_choice = go_to_next_choice(menu_choice, ChangePassword, SetDefault,
                                            operation, menu_choice+operation, 0, menu_choice, 0);
            break;

        case ON_DOSE_PAGE:
            if (change_value == 1)
            {
                lcd_dose_values[dose_choice][digit-1] = update_digit(lcd_dose_values[dose_choice][digit-1],
                                                                     dose_choice, digit+13, operation*-1);
            }
            else
            {
                dose_choice = go_to_next_choice(dose_choice, Volume, PrimeRunSpeed,
                                                operation, dose_choice+operation, 0,
                                                dose_choice, 0, page1, arrow_row);
            }
            break;

        case ON_WARNING_PAGE:
            if (change_value == 1)
            {
                lcd_warning_values[warning_choice][digit-1] = update_digit(lcd_warning_values[warning_choice][digit-1],
                                                                           warning_choice, digit+13, operation*-1);
            }
            else
            {
                warning_choice = go_to_next_choice(warning_choice, CycleWarningSet, LevelWarning2,
                                                   operation, warning_choice+operation, 0,
                                                   warning_choice, 0, page2, arrow_row);
            }
            break;

        case ON_PUMPS_PAGE:
            if (change_value == 1)
            {
                lcd_pumps_values[pumps_choice][digit-1] = update_digit(lcd_pumps_values[pumps_choice][digit-1],
                                                                       pumps_choice, digit+15, operation*-1);
            }
            else
            {
                pumps_choice = go_to_next_choice(pumps_choice, Pump1, Pump4, operation, pumps_choice+operation,
                                                 0, pumps_choice, 0, page3, arrow_row);
            }
            break;

        case ON_MODE_SELECT_PAGE:
            mode_choice = go_to_next_choice(mode_choice, Auto, Off,
                                            operation, mode_choice+operation, 0, mode_choice, 0, page4, arrow_row);
            break;

        case ON_CONFIRM_DEFAULT_PAGE:
            set_default_choice = go_to_next_choice(set_default_choice, Yes, No, operation, 3,
                                                   confirm_arrow_col, 3, confirm_arrow_col+(-8*operation));
            break;

        case ON_CONFIRM_SAVE_PAGE:
            confirm_save_choice = go_to_next_choice(confirm_save_choice, Yes, No, operation, 3,
                                                    confirm_arrow_col, 3, confirm_arrow_col+(-8*operation));
            break;

        default:
            break;
    }
}

/*======================================================================================*/
/**
* function to handle the event coming from the enter button.
*/
void handle_enter_event()
{
    switch (currentPage)
    {
        case ON_PASS_PAGE:
            if (password_digit_num < 4)
            {
                LCD_char_at('*', 2, password_digit_num+5);
                go_to_next_digit('0', &password_digit_num, 2, password_digit_num+6);
            }
            else
            {
                incorrect_password = go_to_check_password(parameters.saved_password, password_buffer, 4, ON_MENU_PAGE) ^ 1;
            }
            break;

        case ON_MENU_PAGE:
            // go to change password, dose or set default page
            if (menu_choice == ChangePassword)
            {
                go_to_page(ON_NEW_PASS_PAGE);
            }
            else if (menu_choice == Settings)
            {
                dose_choice = Volume;
                warning_choice = CycleWarningSet;
                pumps_choice = Pump1;
                mode_choice = Auto;
                go_to_page(ON_DOSE_PAGE);
                LCD_print_at(">", dose_choice, 0);
            }
            else if (menu_choice == SetDefault)
            {
                go_to_page(ON_CONFIRM_DEFAULT_PAGE);
                set_default_choice = Yes;
            }
            break;

        case ON_NEW_PASS_PAGE:
            if (password_digit_num < 8)
            {
                if (password_digit_num < 4)
                {
                    LCD_char_at('*', 1, password_digit_num+6);
                    go_to_next_digit('0', &password_digit_num, 1, password_digit_num+7);
                }
                else
                {
                    if (password_digit_num == 4)
                    {
                        LCD_char_at('*', 1, password_digit_num+6);
                    }
                    else
                    {
                        LCD_char_at('*', 3, password_digit_num+2);
                    }
                    go_to_next_digit('0', &password_digit_num, 3, password_digit_num+3);
                }
            }
            else
            {
                if (go_to_check_password(password_buffer, &password_buffer[4], 4, ON_RIGHT_PASS_PAGE, ON_WRONG_PASS_PAGE))
                {
                    snprintf(parameters.saved_password, sizeof(parameters.saved_password), password_buffer);
                    save_to_eeprom();
                }
            }
            break;

        case ON_DOSE_PAGE:
            // access first digit or go to next digit or get out to the main choice
            next_move(lcd_dose_values[dose_choice][digit], &digit, number_of_dose_digits[dose_choice],
                        dose_choice, digit+14, dose_choice, 0);
            break;

        case ON_WARNING_PAGE:
            // access first digit or go to next digit or get out to the main choice
            next_move(lcd_warning_values[warning_choice][digit], &digit, number_of_warning_digits[warning_choice],
                        warning_choice, digit+14, warning_choice, 0);
            break;

        case ON_PUMPS_PAGE:
            // access first digit or go to next digit or get out to the main choice
            if (strcmp(lcd_pumps_values[pumps_choice], "0000"))
            {
                parameters.pump_enable[pumps_choice] = 1;
                LCD_print_at("1", pumps_choice, 9);
            }
            else
            {
                parameters.pump_enable[pumps_choice] = 0;
                LCD_print_at("0", pumps_choice, 9);
            }
            // strcmp(lcd_pumps_values[pumps_choice], "0000") ? LCD_print_at("1", pumps_choice, 9) :
            //                                                  LCD_print_at("0", pumps_choice, 9);
            next_move(lcd_pumps_values[pumps_choice][digit], &digit, number_of_pumps_digits[pumps_choice],
                        pumps_choice, digit+16, pumps_choice, 0);
            break;

        case ON_MODE_SELECT_PAGE:
            // go to mode set page
            go_to_page(ON_MODE_SET_PAGE);
            timer = millis();
            break;

        case ON_CONFIRM_DEFAULT_PAGE:
            // go to default set or menu page
            if (set_default_choice == Yes)
            {
                parameters.set_default = true;
            }
            else if (set_default_choice == No)
            {
                parameters.set_default = false;
                go_to_page(ON_MENU_PAGE);
            }
            break;

        case ON_CONFIRM_SAVE_PAGE:
            // go to default set or menu page
            if (confirm_save_choice == Yes)
            {
                go_to_page(ON_CHANGES_SAVED_PAGE);
                timer = millis();
                save_entered_values();
                save_to_eeprom();
            }
            else if (confirm_save_choice == No)
            {
                go_to_page(ON_MENU_PAGE);

                number_to_string(lcd_dose_values, parameters.dose_volume, parameters.dose_speed,
                                 parameters.trigger_delay_time, parameters.prime_run_speed,
                                 number_of_dose_digits);
                number_to_string(lcd_warning_values, parameters.cycle_warning_set,
                                 parameters.cycle_warning_mul, parameters.level_warning[0],
                                 parameters.level_warning[1], number_of_warning_digits);
                number_to_string(lcd_pumps_values, parameters.pump_cal[0], parameters.pump_cal[1],
                                 parameters.pump_cal[2], parameters.pump_cal[3],
                                 number_of_pumps_digits);
            }
            if (dose_counter >= (((parameters.cycle_warning_mul - 1) * 100000)
                                 + parameters.cycle_warning_set))
            {
                cycle_warning_flag = true;
            }
            else
            {
                cycle_warning_flag = false;
            }
            break;

        default:
            break;
    }
}

/*======================================================================================*/
// Generic catch-all implementation.
template <typename T_ty> struct TypeInfo { static const char * name; };
template <typename T_ty> const char * TypeInfo<T_ty>::name = "unknown";

// Handy macro to make querying stuff easier.
#define TYPE_NAME(var) TypeInfo< typeof(var) >::name

// Handy macro to make defining stuff easier.
#define MAKE_TYPE_INFO(type)  template <> const char * TypeInfo<type>::name = #type;

// Type-specific implementations.
MAKE_TYPE_INFO( int )
MAKE_TYPE_INFO( float )
MAKE_TYPE_INFO( short )

/**
* function to convert the strings to their corresponding values.
* @tparam Pointer1 , @tparam Pointer2 , @tparam Pointer3 , @tparam Pointer4
* to use any pointer type in this function.
* @param buffer ASCII string that will be converted to a number.
* @param value1 , @param value2 , @param value3 , @param value4
* pointers to the values after conversion.
*/
template <class Pointer1, class Pointer2, class Pointer3, class Pointer4>
void string_to_number(char buffer[][10],
                      Pointer1 value1, Pointer2 value2, Pointer3 value3, Pointer4 value4)
{
    DEBUG_PRINTLN("---------> ascii to integer function");

    *value1 = (!strcmp(TYPE_NAME(*value1) ,"float")) ? atof(buffer[0]) : atoi(buffer[0]);
    *value2 = atoi(buffer[1]);
    *value3 = atoi(buffer[2]);
    *value4 = atoi(buffer[3]);
}

/*======================================================================================*/
/**
* function to convert the number values to strings.
* @tparam Type1 , @tparam Type2 , @tparam Type3 , @tparam Type4
* to use any data type in this function.
* @param buffer to save the converted values in strings.
* @param value1 , @param value2 , @param value3 , @param value4
* integer value that will be converted to ASCII.
* @param col the index to start displaying values in it.
* @param number_of_digits array that contains the number of digits of each values.
*/
template <class Type1, class Type2, class Type3, class Type4>
void number_to_string(char buffer[][10],
                      Type1 value1, Type2 value2, Type3 value3, Type4 value4,
                      const uint8_t* number_of_digits)
{
    char temp_buffer[10] = {0};

    /* here we will check the type of the first value (value1) and convert it into a string
    *  to display on the LCD and let the user to change the value.
    *  So in case the value is float, then ("%%0%d.01f") will make it as "00.0" with %d #digits
    *  And in case it is integer, then ("%%0%dd") will make it as "0000" with %d #digits */
    // if( !strcmp(TYPE_NAME(value1) ,"float"))
    // {
    //     snprintf(temp_buffer, 10, "%%0%d.01f", number_of_digits[0]); 
    //     //snprintf(temp_buffer, 10, "%3.01f"); 
    // }
    // else
    // {
    //     snprintf(temp_buffer, 10, "%%0%dd", number_of_digits[0]); // NOLINT [runtime/printf]
    // }
    snprintf(temp_buffer, 10, "%%0%d%s", number_of_digits[0], (!strcmp(TYPE_NAME(value1) ,"float")) ? ".01f":"d" ); // NOLINT [runtime/printf]
    snprintf(buffer[0], 10, temp_buffer, value1); // NOLINT [runtime/printf]

    snprintf(temp_buffer, 10, "%%0%dd", number_of_digits[1]); // NOLINT [runtime/printf]
    snprintf(buffer[1], 10, temp_buffer, value2); // NOLINT [runtime/printf]

    snprintf(temp_buffer, 10, "%%0%dd", number_of_digits[2]); // NOLINT [runtime/printf]
    snprintf(buffer[2], 10, temp_buffer, value3); // NOLINT [runtime/printf]

    snprintf(temp_buffer,10,"%%0%dd",number_of_digits[3]); // NOLINT [runtime/printf]
    snprintf(buffer[3],10,temp_buffer,value4); // NOLINT [runtime/printf]
}


template void number_to_string<uint32_t, uint8_t, uint8_t, int> (char buffer[][10],
                               uint32_t value1, uint8_t value2, uint8_t value3, int value4,
                               const uint8_t* number_of_digits);
// template void number_to_string<uint8_t, bool, bool, bool> (char buffer[][10],
//                                uint8_t value1, bool value2, bool value3, bool value4,
//                                const uint8_t* number_of_digits);
template void number_to_string<float, uint8_t, uint16_t, uint8_t> (char buffer[][10],
                               float value1, uint8_t value2, uint16_t value3, uint8_t value4,
                               const uint8_t* number_of_digits);
template void number_to_string<uint32_t, uint16_t, uint8_t, uint8_t> (char buffer[][10],
                               uint32_t value1, uint16_t value2, uint8_t value3, uint8_t value4,
                               const uint8_t* number_of_digits);
template void number_to_string<uint16_t, uint16_t, uint16_t, uint16_t> (char buffer[][10],
                               uint16_t value1, uint16_t value2, uint16_t value3, uint16_t value4,
                               const uint8_t* number_of_digits);

