#include "app_credintials.h"
#include "app_pumps.h"
#include "app_a4988.h"

extern A4988 stepper1;
extern A4988 stepper2;
extern A4988 stepper3;
extern A4988 stepper4;

int steppers_steps[4];

/*
For each stepper call startMove function to move the stepper by it's steps * it's MICROSTEPS.
To run the auto mode.
*/
void run_auto_mode(float rpm) {
    // set the motor to move continuously for a reasonable time to hit the stopper
    // DEBUG_PRINTLN("steppers_steps in Auto mode");
    clear_block = false;

    for (int i = 0 ; i < 4 ; i++)
    {
      steppers_steps[i] = parameters.pump_cal[i] * parameters.dose_volume;
      DEBUG_PRINTLN(steppers_steps[i]);
    }

    stepper1.setRPM(rpm);
    stepper2.setRPM(rpm);
    stepper3.setRPM(rpm);
    stepper4.setRPM(rpm);

    stepper1.startMove(steppers_steps[0] * STEPPER_1_MICROSTEPS);     // in microsteps
    stepper2.startMove(steppers_steps[1] * STEPPER_2_MICROSTEPS);
    stepper3.startMove(steppers_steps[2] * STEPPER_3_MICROSTEPS);
    stepper4.startMove(steppers_steps[3] * STEPPER_4_MICROSTEPS);
}

/*
For each stepper call startMove function to move the stepper by constant count of steps.
To run the manual mode.
*/
void run_manual_mode(uint32_t steps, float rpm) {
    // set the motor to move continuously for a reasonable time to hit the stopper
    // DEBUG_PRINTLN("move given steps for each motor");
    clear_block = false;

    stepper1.setRPM(rpm);
    stepper2.setRPM(rpm);
    stepper3.setRPM(rpm);
    stepper4.setRPM(rpm);

    stepper1.startMove(steps);     // in microsteps
    stepper2.startMove(steps);
    stepper3.startMove(steps);
    stepper4.startMove(steps);
}

/*
For each stepper call the nextAction function, and check for wait time that returend by it.
If the wait time <= 0  the stepper finished his steps.
*/
void check_steppers_next_action() {
  unsigned wait_time[4] = {0};
  wait_time[0] = stepper1.nextAction();
  // if (wait_time[0] <= 0)
  // {
  //     manual_move_once = true;
  // }
  // if (wait_time != 0)
    //  stepper1.disable();

  wait_time[1] = stepper2.nextAction();
  // if (wait_time != 0)
    //  stepper2.disable();

  wait_time[2] = stepper3.nextAction();
  // if (wait_time != 0)
    //  stepper3.disable();

  wait_time[3] = stepper4.nextAction();
  // if (wait_time != 0)
    //  stepper4.disable();

  if ((wait_time[0] <= 0) && (wait_time[1] <= 0) &&
      (wait_time[2] <= 0) && (wait_time[3] <= 0))
  {
    // DEBUG_PRINTLN("all steppers finished their steps");
    manual_move_once = true;
    clear_block = true;
  }
}

void enable_steppers()
{
  stepper1.enable();
  stepper2.enable();
  stepper3.enable();
  stepper4.enable();
}

void disable_steppers()
{
  stepper1.disable();
  stepper2.disable();
  stepper3.disable();
  stepper4.disable();
}
