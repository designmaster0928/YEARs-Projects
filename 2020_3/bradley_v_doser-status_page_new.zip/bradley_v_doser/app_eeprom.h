#ifndef APP_EEPROM_H_
#define APP_EEPROM_H_

// struct adjustable_parameters{
//     float dose_volume = 2.5;
//     uint8_t dose_speed = 5;
//     uint8_t prime_run_speed = 5;
//     bool pump_enable[4] = {false};
//     uint16_t pump_cal[4] = {1, 1, 1, 1};
//     uint16_t trigger_delay_time = 0;
//     uint32_t cycle_warning_set = 1;
//     uint16_t cycle_warning_mul = 1;
//     uint8_t level_warning[2] = {10, 10};
//     char saved_password[5] = "1020";
//     bool set_default = false;
// };

extern uint8_t initial_data;

void save_to_eeprom(void);
void read_from_eeprom(void);
void save_falg();
uint8_t read_flag();
void save_dose_counts();
void read_dose_counts();

#endif /* APP_EEPROM_H_ */
