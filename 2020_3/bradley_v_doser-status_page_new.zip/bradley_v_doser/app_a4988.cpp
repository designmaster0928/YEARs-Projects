/****************************************************************************************
 * FileName   :	app_a4988.h
 * Created on : Jan 23, 2020
 * Description: the source file for the A4988 stepeer motor driver module.
*****************************************************************************************/

/*************************************** includes ***************************************/
#include "A4988.h"
#include "app_credintials.h"
#include "app_a4988.h"

/*********************************** global variables ***********************************/


/****************************** module classes definitions ******************************/


/********************************* global class objects *********************************/
A4988 stepper1(STEPPER_1_STEPS, STEPPER_1_DIR_PIN, STEPPER_1_STEP_PIN, STEPPER_1_EN_PIN);
A4988 stepper2(STEPPER_2_STEPS, STEPPER_2_DIR_PIN, STEPPER_2_STEP_PIN, STEPPER_2_EN_PIN);
A4988 stepper3(STEPPER_3_STEPS, STEPPER_3_DIR_PIN, STEPPER_3_STEP_PIN, STEPPER_3_EN_PIN);
A4988 stepper4(STEPPER_4_STEPS, STEPPER_4_DIR_PIN, STEPPER_4_STEP_PIN, STEPPER_4_EN_PIN);

/***************************************** ISR ******************************************/


/****************************** static function prototypes ******************************/


/*********************************** callback functions *********************************/


/********************************* function definitions *********************************/
/**
* 
*/
void a4988_init() {
    stepper1.begin(STEPPER_1_RPM, STEPPER_1_MICROSTEPS);
    stepper2.begin(STEPPER_2_RPM, STEPPER_2_MICROSTEPS);
    stepper3.begin(STEPPER_3_RPM, STEPPER_3_MICROSTEPS);
    stepper4.begin(STEPPER_4_RPM, STEPPER_4_MICROSTEPS);

    // if using enable/disable on ENABLE pin (active LOW) instead of SLEEP uncomment next line
    stepper1.setEnableActiveState(LOW);
    stepper2.setEnableActiveState(LOW);
    stepper3.setEnableActiveState(LOW);
    stepper4.setEnableActiveState(LOW);

    stepper1.enable();
    stepper2.enable();
    stepper3.enable();
    stepper4.enable();

    /*
     * Set LINEAR_SPEED (accelerated) profile.
     */
    // stepper1.setSpeedProfile(stepper1.LINEAR_SPEED, MOTOR_ACCEL, MOTOR_DECEL);
    // stepper2.setSpeedProfile(stepper2.LINEAR_SPEED, MOTOR_ACCEL, MOTOR_DECEL);
    // stepper3.setSpeedProfile(stepper3.LINEAR_SPEED, MOTOR_ACCEL, MOTOR_DECEL);
    // stepper4.setSpeedProfile(stepper4.LINEAR_SPEED, MOTOR_ACCEL, MOTOR_DECEL);
}

/*======================================================================================*/
/**
* 
*/
void a4988_rotate() {
    /*
     * Using non-blocking mode to print out the step intervals.
     * We could have just as easily replace everything below this line with 
     * stepper1.rotate(360);
     */
    // stepper1.startRotate(360);
    // stepper1.rotate(360);
    // for (int i = 0 ; i < 200 ; i++) {
    //     stepper1.enable();
    //     stepper2.enable();
    //     if (i > 100) {
    //         stepper1.disable();
    //     }
        stepper1.move(2);
        stepper2.move(2);
        stepper3.move(2);
        stepper4.move(2);
    // }
    // for (int i = 0 ; i<200 ; i++)
    // stepper1.startMove(1);
    // stepper2.startMove(200);
}
