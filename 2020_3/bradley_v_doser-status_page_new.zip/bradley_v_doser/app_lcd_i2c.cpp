/****************************************************************************************
   FileName   :	app_lcd_i2c.h
   Created on : Jan 23, 2020
   Description: the source file for the A4988 stepeer motor driver module.
*****************************************************************************************/

/*************************************** includes ***************************************/
#include "app_credintials.h"
#include "app_lcd_i2c.h"
#include <Wire.h>
#include <Adafruit_LiquidCrystal.h>
#include <LiquidCrystal_I2C.h>

/*********************************** global variables ***********************************/
char int_to_ascii_buffer[21];

/****************************** module classes definitions ******************************/
#define LCD_ROWS_C 4
#define LCD_COLUMNS_C 20

/********************************* global class objects *********************************/
#ifdef ADA_LCD
/* Connect via i2c, address is 0x20 but we care about LSB (A0-A1-A2 not jumpered) */
Adafruit_LiquidCrystal lcd(ADAFRUIT_SLAVE_ADDRESS_1);
#endif

#ifdef ESP_LCD
LiquidCrystal_I2C esp_lcd(0x27, LCD_COLUMNS_C, LCD_ROWS_C);
#endif

//extern SemaphoreHandle_t xMutex;


/***************************************** ISR ******************************************/

/****************************** static function prototypes ******************************/

/*********************************** callback functions *********************************/

/********************************* function definitions *********************************/
/**
  initialize the LCD.
  @param num_of_cols the number of columns of the used LCD.
  @param num_of_raws the number of raws of the used LCD.
*/
void LCD_init(uint8_t num_of_cols, uint8_t num_of_raws)
{
#ifdef ADA_LCD
  lcd.begin(num_of_cols, num_of_raws);
#endif
#ifdef ESP_LCD
  Wire.begin();
  esp_lcd.begin(21, 22);
  esp_lcd.backlight();
#endif
}

/*======================================================================================*/
/**
  function to print a message on the all rows of the LCD.
  @param raw_1 string to be print on the first raw.
  @param raw_2 string to be print on the second raw.
  @param raw_3 string to be print on the third raw.
  @param raw_4 string to be print on the forth raw.
  NOTE: length of the 4 strings must be equal or less than the number of columns of the
        used LCD.
*/
void LCD_print_page(const char *raw_1, const char *raw_2, const char *raw_3, const char *raw_4)
{
  LCD_clear();
#ifdef ADA_LCD
  lcd.setCursor(0, 0);
  lcd.print(raw_1);
  lcd.setCursor(0, 1);
  lcd.print(raw_2);
  lcd.setCursor(0, 2);
  lcd.print(raw_3);
  lcd.setCursor(0, 3);
  lcd.print(raw_4);
#endif
#ifdef ESP_LCD
  esp_lcd.setCursor(0, 0);
  esp_lcd.print(raw_1);
  esp_lcd.setCursor(0, 1);
  esp_lcd.print(raw_2);
  esp_lcd.setCursor(0, 2);
  esp_lcd.print(raw_3);
  esp_lcd.setCursor(0, 3);
  esp_lcd.print(raw_4);
#endif
}

/*======================================================================================*/
/**
  function to print a string in a specific digit of the LCD.
  @param data to be displayed.
  @param row the row number to print data at.
  @param col the index of the raw to print data at.
*/
void LCD_print_at(char *data, uint8_t row, uint8_t col)
{
#ifdef ADA_LCD
  lcd.setCursor(col, row); /* go to digit of (row, column) */
  lcd.print(data);
#endif
#ifdef ESP_LCD
  esp_lcd.setCursor(col, row); /* go to digit of (row, column) */
  esp_lcd.print(data);
#endif
}

/*======================================================================================*/
/**
  function to clear all data on the LCD.
*/
void LCD_clear()
{
#ifdef ADA_LCD
  lcd.clear();
#endif
#ifdef ESP_LCD
  esp_lcd.clear();
#endif
}

/*======================================================================================*/
/**
  function to enable the curser with blinking at a specific digit of the LCD.
  @param row the row number to blink curser at.
  @param col the index of the raw to blink curser at.
*/
void LCD_blink_at(uint8_t row, uint8_t col)
{
#ifdef ADA_LCD
  lcd.setCursor(col, row); /* go to digit of (row, column) */
  lcd.blink();
#endif
#ifdef ESP_LCD
  esp_lcd.setCursor(col, row); /* go to digit of (row, column) */
  esp_lcd.blink();
#endif
}

/*======================================================================================*/
/**
  function to disable the blinking curser.
*/
void LCD_blink_off()
{
#ifdef ADA_LCD
  lcd.noBlink();
#endif
#ifdef ESP_LCD
  esp_lcd.noBlink();
#endif
}

/*======================================================================================*/
/**
  function to enable the blinking curser.
*/
void LCD_blink_on()
{
#ifdef ADA_LCD
  lcd.blink();
#endif
#ifdef ESP_LCD
  esp_lcd.blink();
#endif
}

/*======================================================================================*/
/**
* function to display one character.
* @param data the character to be displayed.
* @param row the row number to print data at.
* @param col the index of the raw to print data at.
*/
void LCD_char_at(uint8_t data, uint8_t row, uint8_t col)
{
#ifdef ADA_LCD
  lcd.setCursor(col, row);
  lcd.write(data);
#endif
#ifdef ESP_LCD
  esp_lcd.setCursor(col, row);
  esp_lcd.write(data);
#endif
}
