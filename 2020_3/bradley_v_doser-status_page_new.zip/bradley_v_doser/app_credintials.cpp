/****************************************************************************************
 * FileName   :	App_credintials.cpp
 * Created on : Dec 17, 2019
 * Description: the source file for application credintials.
*****************************************************************************************/

/*************************************** includes ***************************************/
#include "app_credintials.h"

/*********************************** global variables ***********************************/
/* constant display pages */
const char on_power_page_r1[18] = "   Advanced  Food";
const char on_power_page_r2[15] = "      Solution";
const char on_power_page_r3[1] = "";
const char on_power_page_r4[12] = "FW version:";

const char main_page_r1[20] = "Dose Cnt:          ";
const char main_page_r2[20] = "Product Level:     ";
const char main_page_r3[21] = "Mode:          ET:  ";
const char main_page_r4[1] = "";

const char password_page_r1[20] = "enter your password";
const char password_page_r2[1] = "";
const char password_page_r3[11] = "      0---";
const char password_page_r4[1] = "";

const char menu_page_r1[18] = ">set new password";
const char menu_page_r2[14] = " set settings";
const char menu_page_r3[21] = " set default setting";
const char menu_page_r4[1] = "";

const char change_pass_page_r1[19] = "Enter New Password";
const char change_pass_page_r2[12] = "       0---";
const char change_pass_page_r3[18] = "re-enter Password";
const char change_pass_page_r4[12] = "       ----";

const char pass_changed_page_r1[19] = "  password changed";
const char pass_changed_page_r2[1] = "";
const char pass_changed_page_r3[15] = "     correctly";
const char pass_changed_page_r4[1] = "";

const char not_match_pass_page_r1[19] = "password not match";
const char not_match_pass_page_r2[1] = "";
const char not_match_pass_page_r3[1] = "";
const char not_match_pass_page_r4[1] = "";

const char dose_page_r1[21] = " Dose Volume :----ml";
const char dose_page_r2[19] = " Dose Speed  :---%";
const char dose_page_r3[21] = " Trig. Delay :----ms";
const char dose_page_r4[19] = " Pr.Run Speed:---%";

const char warning_page_r1[21] = " Cy. Warn Set:------";
const char warning_page_r2[20] = " Cy. Warn Mul:-----";
const char warning_page_r3[18] = " Level Warn 1:--%";
const char warning_page_r4[18] = " Level Warn 2:--%";

const char pumps_page_r1[21] = " Pump1 E:- s/ml:----";
const char pumps_page_r2[21] = " Pump2 E:- s/ml:----";
const char pumps_page_r3[21] = " Pump3 E:- s/ml:----";
const char pumps_page_r4[21] = " Pump4 E:- s/ml:----";

const char mode_page_r1[20] = " Set Automatic Mode";
const char mode_page_r2[17] = " Set Manual Mode";
const char mode_page_r3[14] = " Set Off Mode";
const char mode_page_r4[1] = "";

const char mode_set_page_r1[18] = "   Mode is set to";
const char mode_set_page_r2[1] = "";
const char mode_set_page_r3[1] = "";
const char mode_set_page_r4[1] = "";

const char confirm_default_page_r1[18] = "Are you sure, you";
const char confirm_default_page_r2[17] = "want to reset to";
const char confirm_default_page_r3[18] = "default settings?";
const char confirm_default_page_r4[14] = "  >Yes     No";

const char default_set_page_r1[17] = "Default Settings";
const char default_set_page_r2[1] = "";
const char default_set_page_r3[18] = "are set correctly";
const char default_set_page_r4[1] = "";

const char confirm_save_page_r1[19] = "Do you really want";
const char confirm_save_page_r2[16] = "to save the new";
const char confirm_save_page_r3[9] = "changes?";
const char confirm_save_page_r4[14] = "  >Yes     No";

const char changes_saved_page_r1[1] = "";
const char changes_saved_page_r2[16] = "    Changes are";
const char changes_saved_page_r3[13] = "       saved";
const char changes_saved_page_r4[1] = "";

/* adjustable parameters */
// float dose_volume = 2.5;
// uint8_t dose_speed = 5;
// uint8_t prime_run_speed = 5;
// bool pump_enable[4] = {false};
// uint16_t pump_cal[4] = {1, 1, 1, 1};
// uint16_t trigger_delay_time = 0;
// uint32_t cycle_warning_set = 1;
// uint16_t cycle_warning_mul = 1;
// uint8_t level_warning[2] = {10, 10};
// char saved_password[5] = "1020";
// bool set_default = false;

struct adjustable_parameters parameters;

/* display parameters */
uint32_t dose_counter = 0;
uint8_t product_level = 100;
bool healthy_flag = false;
bool fault_flag = false;
bool low_level_1_flag = false;
bool low_level_2_flag = false;
bool cycle_warning_flag = false;
uint8_t external_trigger_flag = false;

char lcd_status_1_values[4][10];
char lcd_status_2_values[4][10];
char lcd_dose_values[4][10];
char lcd_warning_values[4][10];
char lcd_pumps_values[4][10];
const uint8_t number_of_status_1_digits[4] = {9, 3, 1, 1};
const uint8_t number_of_status_2_digits[4] = {1, 1, 1, 1};
const uint8_t number_of_dose_digits[4] = {4, 3, 4, 3};
const uint8_t number_of_warning_digits[4] = {6, 5, 2, 2};
const uint8_t number_of_pumps_digits[4] = {4, 4, 4, 4};

char lcd_dose_min[4][10] = {"02.5", "005", "0000", "005"};
char lcd_warning_min[4][10] = {"000001", "00001", "10", "10"};
char lcd_pumps_min[4][10] = {"0000", "0000", "0000", "0000"};

char lcd_dose_max[4][10] = {"50.0", "100", "2000", "100"};
char lcd_warning_max[4][10] = {"100000", "10000", "90", "90"};
char lcd_pumps_max[4][10] = {"5000", "5000", "5000", "5000"};

bool manual_move_once = false;
bool clear_block = false;

const char firmware_version[9] = "01.01.01";

/********************************* global class objects *********************************/


/***************************************** ISR ******************************************/


/****************************** static function prototypes ******************************/


/*********************************** callback functions *********************************/


/********************************* function definitions *********************************/
/**
* function to check if the passwords are matching or not.
* @param first_pass , @param second_pass
* passwords to be checked for matching.
* @param size of the 2 passwords.
* @return passwords are matched or not.
*/
bool check_password(char* first_pass, char* second_pass, uint8_t size)
{
    DEBUG_PRINTLN("----------> in check_password function");
    char pass_to_check[2][size+1];

    strncpy(pass_to_check[0], first_pass, size);
    pass_to_check[0][size] = '\0';
    strncpy(pass_to_check[1], second_pass, size);
    pass_to_check[1][size] = '\0';

    if (strcmp(pass_to_check[0], pass_to_check[1]))   /* passwords are different */
    {
        return false;
    }
    else
    {
        return true;
    }
}



/*======================================================================================*/
