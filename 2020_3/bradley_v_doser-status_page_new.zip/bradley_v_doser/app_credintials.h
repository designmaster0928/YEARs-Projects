/****************************************************************************************
 * FileName   :	App_credintials.h
 * Created on : Dec 18, 2019
 * Description: the header file for application credintials.
*****************************************************************************************/
#ifndef APP_CREDINTIALS_H_
#define APP_CREDINTIALS_H_

/*************************************** libraries **************************************/
#include <Arduino.h>

/********************************* common header files **********************************/


/******************************** module configurations *********************************/
#define DEBUG

#ifdef DEBUG
  #define DEBUG_ENABLE(x)        Serial.begin(x)
  #define DEBUG_PRINT(x)         Serial.print (x)
  #define DEBUG_PRINTDEC(x)      Serial.print (x, DEC)
  #define DEBUG_PRINTLN(x)       Serial.println (x)
  #define DEBUG_PRINTLNDEC(x)    Serial.println (x, DEC)
  #define DEBUG_PRINTF           Serial.printf
#else
  #define DEBUG_ENABLE(x)
  #define DEBUG_PRINT(x)
  #define DEBUG_PRINTDEC(x)
  #define DEBUG_PRINTLN(x)
  #define DEBUG_PRINTLNDEC(x)
  #define DEBUG_PRINTF
#endif

#define TRIGGER_PIN        14
#define MANUAL_TRIGGER_PIN 13
#define MENU_PIN           26
#define UP_PIN             25
#define DOWN_PIN           33
#define ENTER_PIN          32
#define ALARM_PIN          27
#define BUZZER_PIN         15
#define PRODUCT_LEVEL_PIN  34

#define PAGE_DELAY          2000
#define POWER_PAGE_DELAY    5000
#define PRODUCT_LEVEL_DELAY 500

#define ALARM_MINUTES_DELAY 300000
#define ALARM_SECONDS_DELAY 3000

#define DOSE_SAVING_DELAY   1000*60*10  // 1 sec * number_of_seconds * number_of_minutes

/******************************** function-like macros **********************************/


/********************************* function prototypes **********************************/
bool check_password(char* first_pass, char* second_pass, uint8_t size);

/****************************** structures, unions, enums *******************************/
struct adjustable_parameters {
    float dose_volume = 2.5;
    uint8_t dose_speed = 5;
    uint8_t prime_run_speed = 5;
    bool pump_enable[4] = {false};
    uint16_t pump_cal[4] = {1, 1, 1, 1};
    uint16_t trigger_delay_time = 0;
    uint32_t cycle_warning_set = 1;
    uint16_t cycle_warning_mul = 1;
    uint8_t level_warning[2] = {10, 10};
    char saved_password[5] = "0000";
    bool set_default = false;
};

/******************************* extern global variables ********************************/
extern const char on_power_page_r1[18];
extern const char on_power_page_r2[15];
extern const char on_power_page_r3[1];
extern const char on_power_page_r4[12];

extern const char main_page_r1[20];
extern const char main_page_r2[20];
extern const char main_page_r3[21];
extern const char main_page_r4[1];

extern const char password_page_r1[20];
extern const char password_page_r2[1];
extern const char password_page_r3[11];
extern const char password_page_r4[1];

extern const char menu_page_r1[18];
extern const char menu_page_r2[14];
extern const char menu_page_r3[21];
extern const char menu_page_r4[1];

extern const char change_pass_page_r1[19];
extern const char change_pass_page_r2[12];
extern const char change_pass_page_r3[18];
extern const char change_pass_page_r4[12];

extern const char pass_changed_page_r1[19];
extern const char pass_changed_page_r2[1];
extern const char pass_changed_page_r3[15];
extern const char pass_changed_page_r4[1];

extern const char not_match_pass_page_r1[19];
extern const char not_match_pass_page_r2[1];
extern const char not_match_pass_page_r3[1];
extern const char not_match_pass_page_r4[1];

extern const char dose_page_r1[21];
extern const char dose_page_r2[19];
extern const char dose_page_r3[21];
extern const char dose_page_r4[19];

extern const char warning_page_r1[21];
extern const char warning_page_r2[20];
extern const char warning_page_r3[18];
extern const char warning_page_r4[18];

extern const char pumps_page_r1[21];
extern const char pumps_page_r2[21];
extern const char pumps_page_r3[21];
extern const char pumps_page_r4[21];

extern const char mode_page_r1[20];
extern const char mode_page_r2[17];
extern const char mode_page_r3[14];
extern const char mode_page_r4[1];

extern const char mode_set_page_r1[18];
extern const char mode_set_page_r2[1];
extern const char mode_set_page_r3[1];
extern const char mode_set_page_r4[1];

extern const char confirm_default_page_r1[18];
extern const char confirm_default_page_r2[17];
extern const char confirm_default_page_r3[18];
extern const char confirm_default_page_r4[14];

extern const char default_set_page_r1[17];
extern const char default_set_page_r2[1];
extern const char default_set_page_r3[18];
extern const char default_set_page_r4[1];

extern const char confirm_save_page_r1[19];
extern const char confirm_save_page_r2[16];
extern const char confirm_save_page_r3[9];
extern const char confirm_save_page_r4[14];

extern const char changes_saved_page_r1[1];
extern const char changes_saved_page_r2[16];
extern const char changes_saved_page_r3[13];
extern const char changes_saved_page_r4[1];

extern struct adjustable_parameters parameters;

// extern float dose_volume;
// extern uint8_t dose_speed;
// extern uint8_t prime_run_speed;
// extern bool pump_enable[4];
// extern uint16_t pump_cal[4];
// extern uint16_t trigger_delay_time;
// extern uint32_t cycle_warning_set;
// extern uint16_t cycle_warning_mul;
// extern uint8_t level_warning[2];
// extern char saved_password[5];
// extern bool set_default;

extern uint32_t dose_counter;
extern uint8_t product_level;
extern bool healthy_flag;
extern bool fault_flag;
extern bool low_level_1_flag;
extern bool low_level_2_flag;
extern bool cycle_warning_flag;
extern uint8_t external_trigger_flag;

extern char lcd_status_1_values[4][10];
extern char lcd_status_2_values[4][10];
extern char lcd_dose_values[4][10];
extern char lcd_warning_values[4][10];
extern char lcd_pumps_values[4][10];
extern const uint8_t number_of_status_1_digits[4];
extern const uint8_t number_of_status_2_digits[4];
extern const uint8_t number_of_dose_digits[4];
extern const uint8_t number_of_warning_digits[4];
extern const uint8_t number_of_pumps_digits[4];

extern char lcd_dose_min[4][10];
extern char lcd_warning_min[4][10];
extern char lcd_pumps_min[4][10];

extern char lcd_dose_max[4][10];
extern char lcd_warning_max[4][10];
extern char lcd_pumps_max[4][10];

extern bool manual_move_once;
extern bool clear_block;

extern const char firmware_version[9];

/****************************** extern global class objects *****************************/


#endif /* APP_CREDINTIALS_H_ */
