cd /home/engineer/Arduino/bradley_v_doser/
arduino-cli compile --fqbn esp32:esp32:nodemcu-32s bradley_v_doser.ino
exit
