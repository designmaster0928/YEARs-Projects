/****************************************************************************************
 * FileName   :	app_a4988.h
 * Created on : Jan 23, 2020
 * Description: the header file for the A4988 stepeer motor driver module.
*****************************************************************************************/
#ifndef APP_A4988_H_
#define APP_A4988_H_

/*************************************** libraries **************************************/
#include "A4988.h"

/********************************* common header files **********************************/


/******************************** module configurations *********************************/
/* Motor steps per revolution. Most steppers are 200 steps or 1.8 degrees/step */
#define STEPPER_1_STEPS 200
#define STEPPER_2_STEPS 200
#define STEPPER_3_STEPS 200
#define STEPPER_4_STEPS 200

/* Target RPM for cruise speed */
#define STEPPER_1_RPM 120
#define STEPPER_2_RPM 120
#define STEPPER_3_RPM 120
#define STEPPER_4_RPM 120

/* the maximum rotation speed for the stepper motors */
#define MAX_RPM 200

/* Acceleration and deceleration values are always in FULL steps / s^2 */
#define MOTOR_ACCEL 2000
#define MOTOR_DECEL 1000

/* Microstepping mode. If you hardwired it to save pins, set to the same value here */
#define STEPPER_1_MICROSTEPS 1
#define STEPPER_2_MICROSTEPS 1
#define STEPPER_3_MICROSTEPS 1
#define STEPPER_4_MICROSTEPS 1


#define STEPPER_1_STEP_PIN   23
#define STEPPER_1_EN_PIN     4
#define STEPPER_1_DIR_PIN    0
#define STEPPER_1_SLEEP_PIN  0
#define STEPPER_1_MS1_PIN    0
#define STEPPER_1_MS2_PIN    0
#define STEPPER_1_MS3_PIN    0

#define STEPPER_2_STEP_PIN   19
#define STEPPER_2_EN_PIN     4
#define STEPPER_2_DIR_PIN    0
#define STEPPER_2_SLEEP_PIN  0
#define STEPPER_2_MS1_PIN    0
#define STEPPER_2_MS2_PIN    0
#define STEPPER_2_MS3_PIN    0

#define STEPPER_3_STEP_PIN   18
#define STEPPER_3_EN_PIN     4
#define STEPPER_3_DIR_PIN    0
#define STEPPER_3_SLEEP_PIN  0
#define STEPPER_3_MS1_PIN    0
#define STEPPER_3_MS2_PIN    0
#define STEPPER_3_MS3_PIN    0

#define STEPPER_4_STEP_PIN   5
#define STEPPER_4_EN_PIN     4
#define STEPPER_4_DIR_PIN    0
#define STEPPER_4_SLEEP_PIN  0
#define STEPPER_4_MS1_PIN    0
#define STEPPER_4_MS2_PIN    0
#define STEPPER_4_MS3_PIN    0

/******************************** function-like macros **********************************/


/****************************** structures, unions, enums *******************************/


/****************************** module classes prototypes *******************************/


/********************************* function prototypes **********************************/
void a4988_init();
void a4988_rotate();

/******************************* extern global variables ********************************/


/****************************** extern global class objects *****************************/


#endif /* APP_A4988_H_ */
