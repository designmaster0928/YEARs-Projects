#ifndef APP_PUMPS_H_
#define APP_PUMPS_H_


void run_auto_mode(float rpm);
void run_manual_mode(uint32_t steps, float rpm = 60);
void check_steppers_next_action();
void enable_steppers();
void disable_steppers();

#endif
