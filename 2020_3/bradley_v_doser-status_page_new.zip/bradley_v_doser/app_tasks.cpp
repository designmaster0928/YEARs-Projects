/****************************************************************************************
 * FileName   :	app_tasks.h
 * Created on : Feb 26, 2020
 * Description: the source file for the RTOS TASKS used in the project.
*****************************************************************************************/

/*************************************** includes ***************************************/
#include "app_credintials.h"
#include "app_a4988.h"
#include "app_lcd_i2c.h"
#include "app_control_panel.h"
#include "app_pumps.h"
#include "app_eeprom.h"
#include "app_tasks.h"

/*********************************** global variables ***********************************/
bool powerUp = false;           /* flag to enable some fuctionalities after powering up */
/* interrupt flaags for the buttons */
bool menu_IntFlag = false;
bool up_IntFlag = false;
bool down_IntFlag = false;
bool enter_IntFlag = false;
bool auto_mode = false; //====================== Hend 13-2-2020
bool manual_mode = false;
unsigned long product_level_timer = 0;
uint8_t product_level_buffer = 0;
bool delay_to_run = false;
unsigned long trigger_timer = 0;
bool enable_buzzer = false;
uint8_t alarm_level = 0;
unsigned long alarm_minutes = 0;
unsigned long alarm_seconds = 0;
unsigned long save_dose_time = 0;
bool update_on_trigger = false;

/****************************** module classes definitions ******************************/


/********************************* global class objects *********************************/
TaskHandle_t stepper_task_handler;
SemaphoreHandle_t xMutex;

/***************************************** ISR ******************************************/


/****************************** static function prototypes ******************************/


/*********************************** callback functions *********************************/


/********************************* function definitions *********************************/
/**
* function to create the tasks that will be used in the project.
*/
void tasks_init()
{
    /* initialize binary semaphore */
    xMutex = xSemaphoreCreateMutex();

    xTaskCreatePinnedToCore(stepper_task,   /* Function that implements the task. */
                            "STEEPER",      /* Text name for the task. */
                            1000,           /* Stack size in words, not bytes. */
                            NULL,           /* Parameter passed into the task. */
                            3,              /* Priority at which the task is created. */
                            &stepper_task_handler,
                            0);             /* Used to pass out the created task's handle. */

    xTaskCreatePinnedToCore(lcd_task,       /* Function that implements the task. */
                            "LCD",          /* Text name for the task. */
                            10000,          /* Stack size in words, not bytes. */
                            NULL,           /* Parameter passed into the task. */
                            3,              /* Priority at which the task is created. */
                            NULL,
                            1);             /* Used to pass out the created task's handle. */

    xTaskCreatePinnedToCore(alarms_task,    /* Function that implements the task. */
                            "ALARMS",       /* Text name for the task. */
                            10000,          /* Stack size in words, not bytes. */
                            NULL,           /* Parameter passed into the task. */
                            2,              /* Priority at which the task is created. */
                            NULL,
                            1);             /* Used to pass out the created task's handle. */

    // xTaskCreatePinnedToCore(dose_count_task,/* Function that implements the task. */
    //                         "DOSE_COUNT",   /* Text name for the task. */
    //                         1000,           /* Stack size in words, not bytes. */
    //                         NULL,           /* Parameter passed into the task. */
    //                         1,              /* Priority at which the task is created. */
    //                         NULL,
    //                         1);             /* Used to pass out the created task's handle. */

    // vTaskStartScheduler();
}

/*======================================================================================*/
/**
* task to control the stepper motors.
*/
void lcd_task(void *pvParameters)
{
    for( ;; )
    {
        xSemaphoreTake(xMutex, portMAX_DELAY);

        if ((currentPage == ON_MAIN_PAGE) && external_trigger_flag == 0xFF && clear_block)
        {
            // DEBUG_PRINTLN("clear block");
            external_trigger_flag = 0;
            LCD_char_at('0', 2, 19);
            clear_block = false;
        }

        if (update_on_trigger)
        {
            update_on_trigger = false;
            if (currentPage == ON_MAIN_PAGE)
            {
                // DEBUG_PRINTLN("display block");

                number_to_string(lcd_status_1_values, dose_counter, product_level,
                                 external_trigger_flag, 0, number_of_status_1_digits);

                // display_values(lcd_status_1_values, 4);

                LCD_print_at(lcd_status_1_values[0], 0, 10);
                // LCD_print_at(lcd_status_1_values[1], 1, 15);
                // LCD_print_at(lcd_status_1_values[2], 2, 19);

                LCD_char_at(0xFF, 2, 19);
                if (cycle_warning_flag)
                {
                    // LCD_char_at('1', 3, 18);
                }
                else
                {
                    // LCD_char_at('0', 3, 18);
                }
            }
        }

        /* -------------- handle the interrupt of the MENU button -------------- */
        if (menu_IntFlag && powerUp)
        {
            delay(300);     /* for debouncing */
            menu_IntFlag = false;
            handle_menu_event();
        }

        /* -------------- handle the interrupt of the UP button -------------- */
        if (up_IntFlag && powerUp)
        {
            delay(300);     /* for debouncing */
            up_IntFlag = false;
            handle_up_down_event(UP, NO_PAGE, ON_DOSE_PAGE, ON_WARNING_PAGE, ON_PUMPS_PAGE, 3, 2);
        }

        /* -------------- handle the interrupt of the DOWN button -------------- */
        if (down_IntFlag && powerUp)
        {
            delay(300);     /* for debouncing */
            down_IntFlag = false;
            handle_up_down_event(DOWN, ON_WARNING_PAGE, ON_PUMPS_PAGE, ON_MODE_SELECT_PAGE, NO_PAGE, 0, 10);
        }

        /* -------------- handle the interrupt of the ENTER button -------------- */
        if (enter_IntFlag && powerUp)
        {
            delay(300);     /* for debouncing */
            enter_IntFlag = false;
            handle_enter_event();
        }

        if (powerUp && (millis() - product_level_timer >= PRODUCT_LEVEL_DELAY))
        {
            // DEBUG_PRINT("product_level_timer = ");
            // DEBUG_PRINTLN(product_level_timer);
            // DEBUG_PRINTLN(millis() - product_level_timer);
            product_level_timer = millis();
            product_level_buffer = product_level;
            product_level = analogRead(PRODUCT_LEVEL_PIN) * 100 / 4095;
            if (product_level - product_level_buffer >= 1 ||
                product_level_buffer - product_level >= 1)
            {
                number_to_string(lcd_status_1_values, dose_counter, product_level,
                                 external_trigger_flag, 0, number_of_status_1_digits);

                if (currentPage == ON_MAIN_PAGE)
                {
                    // display_values(lcd_status_1_values, 4);

                    // LCD_print_at(lcd_status_1_values[0], 0, 10);
                    LCD_print_at(lcd_status_1_values[1], 1, 15);
                    // LCD_print_at(lcd_status_1_values[2], 2, 19);
                }
            }
        }

        /* check if the user entered incorrect password */
        if (incorrect_password)
        {
            incorrect_password = false;
            go_to_page(ON_PASS_PAGE);
        }

        if (parameters.set_default)
        {
            /* return all values to their default */
            parameters.set_default = false;
            parameters.dose_volume = 2.5;
            parameters.dose_speed = 5;
            parameters.prime_run_speed = 5;
            for (int i = 0 ; i<4 ; i++)
            {
                parameters.pump_enable[i] = false;
                parameters.pump_cal[i] = 1;
            }
            parameters.trigger_delay_time = 0;
            parameters.cycle_warning_set = 1;
            parameters.cycle_warning_mul = 1;
            parameters.level_warning[0] = 10;
            parameters.level_warning[1] = 10;
            snprintf(parameters.saved_password, sizeof(parameters.saved_password), "0000");
            /* save the default values in EEPROM */
            save_to_eeprom();
            go_to_page(ON_DEFAULT_PAGE);
            timer = millis();
            number_to_string(lcd_dose_values, parameters.dose_volume, parameters.dose_speed,
                             parameters.trigger_delay_time, parameters.prime_run_speed,
                             number_of_dose_digits);
            number_to_string(lcd_warning_values, parameters.cycle_warning_set,
                             parameters.cycle_warning_mul, parameters.level_warning[0],
                             parameters.level_warning[1], number_of_warning_digits);
            number_to_string(lcd_pumps_values, parameters.pump_cal[0], parameters.pump_cal[1],
                             parameters.pump_cal[2], parameters.pump_cal[3],
                             number_of_pumps_digits);
        }

        /* make a delay if the default settings are set correctly then display
        *  the status again */
        delay_for_page(ON_DEFAULT_PAGE, ON_MAIN_PAGE, PAGE_DELAY);

        /* make a delay after the mode is selected then display the status again */
        delay_for_page(ON_MODE_SET_PAGE, ON_MODE_SELECT_PAGE, PAGE_DELAY);

        /* make a delay after saving the new changes then display the status again */
        delay_for_page(ON_CHANGES_SAVED_PAGE, ON_MAIN_PAGE, PAGE_DELAY);

        /* make a delay if the password changed correctly then display the status again */
        delay_for_page(ON_RIGHT_PASS_PAGE, ON_MAIN_PAGE, PAGE_DELAY);

        /* make a delay if the new password doesn't match then let the user to enter a new
        *  password again */
        delay_for_page(ON_WRONG_PASS_PAGE, ON_NEW_PASS_PAGE, PAGE_DELAY);

        if (millis() - save_dose_time >= DOSE_SAVING_DELAY)
        {
            save_dose_time = millis();
            save_dose_counts();
        }

        // taskEXIT_CRITICAL(&mmux);

//      if (product_level <= parameters.level_warning[1] && alarm_level < 2)
//      {
//          alarm_level = 2;
//          enable_buzzer = 1;
//          digitalWrite(BUZZER_PIN, HIGH);
//          digitalWrite(ALARM_PIN, HIGH);
//          low_level_1_flag = 0;
//          low_level_2_flag = 1;
//          if (currentPage == ON_MAIN_PAGE)
//          {
//              number_to_string(lcd_status_1_values, dose_counter, product_level,
//                               external_trigger_flag, 0, number_of_status_1_digits);
//  
//              display_values(lcd_status_1_values, 4);
//          }
//      }
//      else if (product_level <= parameters.level_warning[0] && product_level > parameters.level_warning[1])
//      {
//          if (alarm_level == 0 || alarm_level == 2)
//          {
//              alarm_level = 1;
//              enable_buzzer = 1;
//              digitalWrite(BUZZER_PIN, HIGH);
//              digitalWrite(ALARM_PIN, LOW);
//              alarm_minutes = millis();
//              alarm_seconds = millis();
//              low_level_1_flag = 1;
//              low_level_2_flag = 0;
//              if (currentPage == ON_MAIN_PAGE)
//              {
//                  number_to_string(lcd_status_1_values, dose_counter, product_level,
//                                   external_trigger_flag, 0, number_of_status_1_digits);
//  
//                  display_values(lcd_status_1_values, 4);
//              }
//          }
//          else if (alarm_level == 1)
//          {
//              if (enable_buzzer == 1 && (millis() - alarm_seconds >= ALARM_SECONDS_DELAY))
//              {
//                  enable_buzzer = 0;
//                  digitalWrite(BUZZER_PIN, LOW);
//              }
//              else if (millis() - alarm_minutes >= ALARM_MINUTES_DELAY)
//              {
//                  enable_buzzer = 1;
//                  digitalWrite(BUZZER_PIN, HIGH);
//                  alarm_minutes = millis();
//                  alarm_seconds = millis();
//              }
//          }
//      }
//      else if (product_level > parameters.level_warning[0] && alarm_level > 0)
//      {
//          alarm_level = 0;
//          enable_buzzer = 0;
//          digitalWrite(BUZZER_PIN, LOW);
//          digitalWrite(ALARM_PIN, LOW);
//          low_level_1_flag = 0;
//          low_level_2_flag = 0;
//          if (currentPage == ON_MAIN_PAGE)
//          {
//          number_to_string(lcd_status_1_values, dose_counter, product_level,
//                           external_trigger_flag, 0, number_of_status_1_digits);
//  
//              display_values(lcd_status_1_values, 4);
//          }
//      }
        xSemaphoreGive( xMutex );
        delay(1);
    }
    vTaskDelete(NULL);  /* Passing NULL will cause the calling task to be deleted */
}

/*======================================================================================*/
/**
* task to control the LCD display.
*/
// portMUX_TYPE mmux = portMUX_INITIALIZER_UNLOCKED;

void stepper_task(void *pvParameters)
{
    for( ;; )
    {
        /* ======================= handle the interrupt of the auto mode trigger ================= Hend 13-2-2020*/
        if (auto_mode && (currentMode == Auto)) {
            delay(300);
            // DEBUG_PRINTLN("------------ motors in Auto mode ------------");

            auto_mode = false;
            dose_counter++;
            if (dose_counter >= (((parameters.cycle_warning_mul - 1) * 100000)
                                 + parameters.cycle_warning_set))
            {
                cycle_warning_flag = true;
            }
            if (currentPage == ON_MAIN_PAGE)
            {
                update_on_trigger = true;
                // DEBUG_PRINTLN("display block");
                // DEBUG_PRINTLN(external_trigger_flag);

                // number_to_string(lcd_status_1_values, dose_counter, product_level,
                //                  external_trigger_flag, 0, number_of_status_1_digits);
                // lock
                // display_values(lcd_status_1_values, 4);

                // LCD_print_at(lcd_status_1_values[0], 0, 10);
                // LCD_print_at(lcd_status_1_values[1], 1, 15);
                // LCD_print_at(lcd_status_1_values[2], 2, 19);

                // LCD_char_at(0xFF, 2, 19);
                // if (cycle_warning_flag)
                // {
                //     LCD_char_at('1', 3, 18);
                // }
                // else
                // {
                //     LCD_char_at('0', 3, 18);
                // }
                // unlock
            }
            delay_to_run = true;
            trigger_timer = millis();
        }

        if (delay_to_run && (millis() - trigger_timer >= parameters.trigger_delay_time))
        {
            // DEBUG_PRINTLN("run after delay");
            external_trigger_flag = 0xFF;
            delay_to_run = false;
            run_auto_mode(parameters.dose_speed * MAX_RPM / 100);
        }

        if (manual_mode && ((currentMode == Manual) || manual_dose)) {
            //   delay(300);
            //   DEBUG_PRINTLN("------------ motors in Manual mode ------------");

            if (manual_move_once)
            {
                dose_counter++;
                external_trigger_flag = 0xFF;
                if (dose_counter >= (((parameters.cycle_warning_mul - 1) * 100000)
                                    + parameters.cycle_warning_set))
                {
                    cycle_warning_flag = true;
                }
                if (currentPage == ON_MAIN_PAGE)
                {
                    update_on_trigger = true;
                    // DEBUG_PRINTLN("display block");
                    // DEBUG_PRINTLN(external_trigger_flag);
                    // number_to_string(lcd_status_1_values, dose_counter, product_level,
                    //                  external_trigger_flag, 0, number_of_status_1_digits);

                    // display_values(lcd_status_1_values, 4);

                    // LCD_print_at(lcd_status_1_values[0], 0, 10);
                    // LCD_print_at(lcd_status_1_values[1], 1, 15);
                    // LCD_print_at(lcd_status_1_values[2], 2, 19);

                    // LCD_char_at(external_trigger_flag, 2, 19);
                    // if (cycle_warning_flag)
                    // {
                    //     LCD_char_at('1', 3, 18);
                    // }
                    // else
                    // {
                    //     LCD_char_at('0', 3, 18);
                    // }
                }
                run_manual_mode(200000, parameters.prime_run_speed * MAX_RPM / 100);
                manual_move_once = false;
            }

            if (digitalRead(MANUAL_TRIGGER_PIN))
            {
                manual_mode = false;
                manual_dose = false;
                // DEBUG_PRINTLN("------------ disable motors in Manual mode ------------");
                run_manual_mode(0);
            }
        }

        check_steppers_next_action();

        // if ((currentPage == ON_MAIN_PAGE) && external_trigger_flag == 0xFF && clear_block)
        // {
        //     DEBUG_PRINTLN("clear block");
        //     DEBUG_PRINTLN(clear_block);
        //     external_trigger_flag = 0;
        //     //LCD_char_at('0', 2, 19);
        //     clear_block = false;
        // }

        /* rotate the motors using the manual trigger */
        // if (!(digitalRead(MANUAL_TRIGGER_PIN)))
        // {
        //     delay(30);
        //     while (!(digitalRead(MANUAL_TRIGGER_PIN)))
        //     {
        //         a4988_rotate();
        //     }
        // }
        // a4988_rotate();
        // delay(1000);

        // if (millis() - save_dose_time >= DOSE_SAVING_DELAY)
        // {
        //     save_dose_time = millis();
        //     save_dose_counts();
        // }

        // if (product_level <= parameters.level_warning[1] && alarm_level < 2)
        // {
        //     alarm_level = 2;
        //     enable_buzzer = 1;
        //     digitalWrite(BUZZER_PIN, HIGH);
        //     digitalWrite(ALARM_PIN, HIGH);
        //     low_level_1_flag = 0;
        //     low_level_2_flag = 1;
        //     if (currentPage == ON_MAIN_PAGE)
        //     {
        //          number_to_string(lcd_status_1_values, dose_counter, product_level,
        //                           external_trigger_flag, 0, number_of_status_1_digits);

        //         display_values(lcd_status_1_values, 4);
        //     }
        // }
        // else if (product_level <= parameters.level_warning[0] && product_level > parameters.level_warning[1])
        // {
        //     if (alarm_level == 0 || alarm_level == 2)
        //     {
        //         alarm_level = 1;
        //         enable_buzzer = 1;
        //         digitalWrite(BUZZER_PIN, HIGH);
        //         digitalWrite(ALARM_PIN, LOW);
        //         alarm_minutes = millis();
        //         alarm_seconds = millis();
        //         low_level_1_flag = 1;
        //         low_level_2_flag = 0;
        //         if (currentPage == ON_MAIN_PAGE)
        //         {
        //             number_to_string(lcd_status_1_values, dose_counter, product_level,
        //                              external_trigger_flag, 0, number_of_status_1_digits);

        //             display_values(lcd_status_1_values, 4);
        //         }
        //     }
        //     else if (alarm_level == 1)
        //     {
        //         if (enable_buzzer == 1 && (millis() - alarm_seconds >= ALARM_SECONDS_DELAY))
        //         {
        //             enable_buzzer = 0;
        //             digitalWrite(BUZZER_PIN, LOW);
        //         }
        //         else if (millis() - alarm_minutes >= ALARM_MINUTES_DELAY)
        //         {
        //             enable_buzzer = 1;
        //             digitalWrite(BUZZER_PIN, HIGH);
        //             alarm_minutes = millis();
        //             alarm_seconds = millis();
        //         }
        //     }
        // }
        // else if (product_level > parameters.level_warning[0] && alarm_level > 0)
        // {
        //     alarm_level = 0;
        //     enable_buzzer = 0;
        //     digitalWrite(BUZZER_PIN, LOW);
        //     digitalWrite(ALARM_PIN, LOW);
        //     low_level_1_flag = 0;
        //     low_level_2_flag = 0;
        //     if (currentPage == ON_MAIN_PAGE)
        //     {
        //         number_to_string(lcd_status_1_values, dose_counter, product_level,
        //                          external_trigger_flag, 0, number_of_status_1_digits);

        //         display_values(lcd_status_1_values, 4);
        //     }
        // }
    
        if (!external_trigger_flag)
        {
            delay(100);
        }
        else
        {
            delay(1);
        }
    }
    vTaskDelete(stepper_task_handler);  /* Passing NULL will cause the calling task to be deleted */
}

/*======================================================================================*/
/**
* task to monitor the alarms.
*/
void alarms_task(void *pvParameters)
{
    for( ;; )
    {
        xSemaphoreTake( xMutex, portMAX_DELAY );
        if (product_level <= parameters.level_warning[1] && alarm_level < 2)
        {
            alarm_level = 2;
            enable_buzzer = 1;
            digitalWrite(BUZZER_PIN, HIGH);
            digitalWrite(ALARM_PIN, HIGH);
            low_level_1_flag = 0;
            low_level_2_flag = 1;
            if (currentPage == ON_MAIN_PAGE)
            {
                number_to_string(lcd_status_1_values, dose_counter, product_level,
                                 external_trigger_flag, 0, number_of_status_1_digits);

                // display_values(lcd_status_1_values, 4);
            }
        }
        else if (product_level <= parameters.level_warning[0] && product_level > parameters.level_warning[1])
        {
            if (alarm_level == 0 || alarm_level == 2)
            {
                alarm_level = 1;
                enable_buzzer = 1;
                digitalWrite(BUZZER_PIN, HIGH);
                digitalWrite(ALARM_PIN, LOW);
                alarm_minutes = millis();
                alarm_seconds = millis();
                low_level_1_flag = 1;
                low_level_2_flag = 0;
                if (currentPage == ON_MAIN_PAGE)
                {
                    number_to_string(lcd_status_1_values, dose_counter, product_level,
                                     external_trigger_flag, 0, number_of_status_1_digits);

                    // display_values(lcd_status_1_values, 4);
                }
            }
            else if (alarm_level == 1)
            {
                if (enable_buzzer == 1 && (millis() - alarm_seconds >= ALARM_SECONDS_DELAY))
                {
                    enable_buzzer = 0;
                    digitalWrite(BUZZER_PIN, LOW);
                }
                else if (millis() - alarm_minutes >= ALARM_MINUTES_DELAY)
                {
                    enable_buzzer = 1;
                    digitalWrite(BUZZER_PIN, HIGH);
                    alarm_minutes = millis();
                    alarm_seconds = millis();
                }
            }
        }
        else if (product_level > parameters.level_warning[0] && alarm_level > 0)
        {
            alarm_level = 0;
            enable_buzzer = 0;
            digitalWrite(BUZZER_PIN, LOW);
            digitalWrite(ALARM_PIN, LOW);
            low_level_1_flag = 0;
            low_level_2_flag = 0;
            if (currentPage == ON_MAIN_PAGE)
            {
                number_to_string(lcd_status_1_values, dose_counter, product_level,
                                 external_trigger_flag, 0, number_of_status_1_digits);

                // display_values(lcd_status_1_values, 4);
            }
        }
        xSemaphoreGive( xMutex );
        delay(1);
    }
    vTaskDelete(NULL);  /* Passing NULL will cause the calling task to be deleted */
}

/*======================================================================================*/
/**
* task to monitor the alarms.
*/
// void dose_count_task(void *pvParameters)
// {
//     for( ;; )
//     {
//         while(external_trigger_flag)delay(1);
//         save_dose_counts();
//         delay(DOSE_SAVING_DELAY);
//     }
//     vTaskDelete(NULL);  /* Passing NULL will cause the calling task to be deleted */
// }
