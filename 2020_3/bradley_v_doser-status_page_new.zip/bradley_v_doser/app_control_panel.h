/****************************************************************************************
 * FileName   :	app_control_panel.h
 * Created on : Feb 12, 2020
 * Description: the header file for the functions that will control the LCD pages.
*****************************************************************************************/
#ifndef APP_CONTROL_PANEL_H_
#define APP_CONTROL_PANEL_H_

/*************************************** libraries **************************************/


/********************************* common header files **********************************/


/******************************** module configurations *********************************/
/* the states for LCD pages that will appear */
#define NO_PAGE                 0
#define ON_POWER_PAGE           1
#define ON_MAIN_PAGE            2
#define ON_PASS_PAGE            3
#define ON_MENU_PAGE            4
#define ON_NEW_PASS_PAGE        5
#define ON_RIGHT_PASS_PAGE      6
#define ON_WRONG_PASS_PAGE      7
#define ON_DOSE_PAGE            8
#define ON_WARNING_PAGE         9
#define ON_PUMPS_PAGE           10
#define ON_MODE_SELECT_PAGE     11
#define ON_MODE_SET_PAGE        12
#define ON_CONFIRM_DEFAULT_PAGE 13
#define ON_DEFAULT_PAGE         14
#define ON_CONFIRM_SAVE_PAGE    15
#define ON_CHANGES_SAVED_PAGE   16

/* to increment or decrement a digit on the LCD */
#define INCREMENT 1
#define DECREMENT -1

/* to move to the above or below option */
#define UP   -1
#define DOWN 1

/******************************** function-like macros **********************************/


/****************************** structures, unions, enums *******************************/
enum Menu
{
    ChangePassword, Settings, SetDefault
};

enum Dose
{
    Volume, Speed, TriggerDelay, PrimeRunSpeed
};

enum Warnings
{
    CycleWarningSet, CycleWarningMul, LevelWarning1, LevelWarning2
};

enum pumps
{
    Pump1, Pump2, Pump3, Pump4
};

enum Mode
{
    Auto, Manual, Off
};

enum Setdefault
{
    Yes, No
};

// struct pointer_state {
//     enum Menu p;
//     int x;
//     int y;
// };
// struct pointer_state arrow;

/****************************** module classes prototypes *******************************/


/********************************* function prototypes **********************************/
void go_to_page(uint8_t pageNum);

void display_values(char buffer[][10], uint8_t col);

void save_entered_values();

void delay_for_page(uint8_t current_page, uint8_t next_page, unsigned long delay);

void read_status();

void enter_password(uint8_t first_digit_row, uint8_t first_digit_col);

bool go_to_check_password(char* first_pass, char* second_pass, uint8_t size,
                          uint8_t right_pass_page = NO_PAGE,
                          uint8_t wrong_pass_page = NO_PAGE);

uint8_t go_to_next_choice(uint8_t current_choice, uint8_t min_choice, uint8_t max_choice,
                          int8_t operation,
                          uint8_t next_arrow_row, uint8_t next_arrow_col,
                          uint8_t next_space_row, uint8_t next_space_col,
                          uint8_t next_page = NO_PAGE,
                          uint8_t next_page_choice_row = 0,
                          uint8_t next_page_choice_col = 0);

void enter_sub_choice(uint8_t value,
                      uint8_t* digit_number,
                      uint8_t next_digit_row, uint8_t next_digit_col,
                      uint8_t arrow_row, uint8_t arrow_col);

void back_to_main_choice(uint8_t* digit_number, uint8_t arrow_row, uint8_t arrow_col);

void next_move(uint8_t value,
               uint8_t* digit_number, uint8_t number_of_digits,
               uint8_t next_digit_row, uint8_t next_digit_col,
               uint8_t arrow_row, uint8_t arrow_col);

void go_to_next_digit(uint8_t value, uint8_t* digitNumber,
                      uint8_t next_row, uint8_t next_col);

uint8_t update_digit(uint8_t value, uint8_t row, uint8_t col, int8_t operation);

void check_number_validity(uint8_t choice);

void handle_menu_event();

void handle_up_down_event(int8_t operation,
                          uint8_t page1, uint8_t page2, uint8_t page3, uint8_t page4,
                          uint8_t arrow_row, uint8_t confirm_arrow_col);

void handle_enter_event();

template <class Pointer1, class Pointer2, class Pointer3, class Pointer4>
void string_to_number(char buffer[][10],
                      Pointer1 value1, Pointer2 value2, Pointer3 value3, Pointer4 value4);

template <class Type1, class Type2, class Type3, class Type4>
void number_to_string(char buffer[][10],
                      Type1 value1, Type2 value2, Type3 value3, Type4 value4,
                      const uint8_t* number_of_digits);

/******************************* extern global variables ********************************/
extern unsigned long timer;
extern char password_buffer[9];
extern bool incorrect_password;
extern uint8_t password_digit_num;
extern uint8_t digit;
extern bool change_value;
extern uint8_t currentPage;
extern uint8_t menu_choice;
extern uint8_t dose_choice;
extern uint8_t warning_choice;
extern uint8_t pumps_choice;
extern uint8_t mode_choice;
extern uint8_t set_default_choice;
extern uint8_t currentMode;
extern bool manual_dose;

/****************************** extern global class objects *****************************/


/**************************** template functions definitions ****************************/


#endif /* APP_CONTROL_PANEL_H_ */
