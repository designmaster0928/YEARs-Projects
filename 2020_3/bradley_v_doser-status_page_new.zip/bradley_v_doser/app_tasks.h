/****************************************************************************************
 * FileName   :	app_tasks.h
 * Created on : Feb 26, 2020
 * Description: the header file for the RTOS TASKS used in the project.
*****************************************************************************************/
#ifndef APP_TASKS_H_
#define APP_TASKS_H_

/*************************************** libraries **************************************/


/********************************* common header files **********************************/


/******************************** module configurations *********************************/


/******************************** function-like macros **********************************/


/****************************** structures, unions, enums *******************************/


/****************************** module classes prototypes *******************************/


/********************************* function prototypes **********************************/
void tasks_init();
void stepper_task(void *pvParameters);
void lcd_task(void *pvParameters);
void alarms_task(void *pvParameters);
// void dose_count_task(void *pvParameters);

/******************************* extern global variables ********************************/
extern bool powerUp;
extern bool menu_IntFlag;
extern bool up_IntFlag;
extern bool down_IntFlag;
extern bool enter_IntFlag;
extern bool auto_mode;
extern bool manual_mode;
extern unsigned long product_level_timer;
extern uint8_t product_level_buffer;
extern bool delay_to_run;
extern unsigned long trigger_timer;
extern bool enable_buzzer;
extern uint8_t alarm_level;
extern unsigned long alarm_minutes;
extern unsigned long alarm_seconds;
extern unsigned long save_dose_time;
extern bool update_on_trigger;

/****************************** extern global class objects *****************************/
extern SemaphoreHandle_t xMutex;

#endif /* APP_TASKS_H_ */
