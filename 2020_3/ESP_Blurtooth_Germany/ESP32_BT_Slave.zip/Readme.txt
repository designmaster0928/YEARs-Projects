=========================================================================
>>>>>>>>>>>>>>>>>>>>>      V     D  O  S  E  R      <<<<<<<<<<<<<<<<<<<<<
=========================================================================

;; Description ;;
-----------------

- The main princile of this project is to control 4 stepper motors which

  are working as perestilatic pumps for dosing application.

- You will have two options for working:

    - First one, there is a manual trigger that when it's held tho 4

      motors are working in the same time with the same speed, until the

      trigger is released.

    - Second one, there is a digital trigger that it's pressed and after

      that there will be a delay time and then the motors will work with

      the same speed but each will run for a specific number of steps.

- The project will also have a 4x20 LCD that will display the status of

  the application and some configurations and password.

- There will be 4 buttons keypad (menu, enter, up, down).

- And finaly, there will be an audible piezo device and an LED indicator

  to be active for warnings.

_________________________________________________________________________

;; Refrences ;;
---------------

4988 stepper mottor driver module pinout and datasheet:

(https://components101.com/modules/a4988-stepper-motor-driver-module)

(https://lastminuteengineers.com/a4988-stepper-motor-driver-arduino-tutorial)

_________________________________________________________________________

;; Hardware connections ;;
--------------------------

ESP32 connection:
=================================
|		|digital trigger|
|   		|		|
|		|manual trigger	|
| 		|		|
|		|LED alarm	|
| 		|		|
|		|sound alarm	|
| 		|		|
|		|menu		|
| 		|		|
|		|enter		|
| 		|		|
|		|up		|
| 		|		|
|		|down		|
| 		|		|
|		|product level	|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
=================================

ESP32 connections with 4x20 LCD I2C module:
=================================
|		|		|
|   		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
=================================

4x20 LCD connections with the I2C module:
=================================
|		|		|
|   		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
| 		|		|
|		|		|
=================================

ESP32 connections with 4 motor modules A4988:
=================================
|		|STEP		|
|   		|		|
|		|EN		|
| 		|		|
|Vin		|VDD		|
| 		|		|
|GND		|GND		|
=================================

4 motors connections with the modules A4988:
=================================
|		|1A		|
|   		|		|
|		|1B		|
| 		|		|
|		|2A		|
| 		|		|
|		|2B		|
=================================

A4988 modules connections:
=================================
|VMOT 		|12v with 100uF	|
|		|max capacitor 	|
| 		|to GND		|
|		|		|
|GND 		|GND		|
|		|		|
|MS1 		|GND		|
|		|		|
|MS2 		|GND		|
|		|		|
|MS3 		|GND		|
|		|		|
|RST <--> SLP	|-		|
|		|		|
|DIR 		|GND		|
=================================

_________________________________________________________________________

;; External Libraries ;;
------------------------

1-"----" library -> for .

   ( LINK )

_________________________________________________________________________

;; How it works ;;
------------------



_________________________________________________________________________

;; Code Construction Steps ;;
-----------------------------

1- interfacing ESP32 with one stepper motor controlled by A4988 driver.



